import React from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { FileQuestion, ArrowLeft, Home } from "lucide-react";

export default function Error404() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ backgroundColor: '#F8F6FB' }}>
      <Card className="max-w-2xl w-full border-2 border-gray-200">
        <CardContent className="p-8">
          <div className="flex flex-col items-center text-center">
            <div className="w-20 h-20 rounded-full bg-gray-100 flex items-center justify-center mb-6">
              <FileQuestion className="w-10 h-10 text-gray-600" />
            </div>
            
            <h1 className="text-4xl font-bold mb-2" style={{ color: '#4B2672' }}>
              404
            </h1>
            
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">
              Página Não Encontrada
            </h2>
            
            <p className="text-gray-600 mb-8 max-w-md">
              A página que você está procurando não existe ou foi movida para outro endereço.
            </p>

            <div className="flex gap-4">
              <Button
                onClick={() => navigate(-1)}
                variant="outline"
                className="border-2"
                style={{ borderColor: '#4B2672', color: '#4B2672' }}
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar
              </Button>
              <Button
                onClick={() => navigate('/')}
                className="text-white"
                style={{ backgroundColor: '#4B2672' }}
              >
                <Home className="w-4 h-4 mr-2" />
                Ir para Início
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export const pageConfig = {
  requireAuth: false,
  isPublic: true
};