import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate, Navigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Upload, Save, Eye, X, Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function MediaItemEdit() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  
  const urlParams = new URLSearchParams(window.location.search);
  const mediaId = urlParams.get('id');
  
  const [user, setUser] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const [formData, setFormData] = useState(null);
  const [tagInput, setTagInput] = useState("");
  const [categoryInput, setCategoryInput] = useState("");
  const [uploadingCover, setUploadingCover] = useState(false);
  const [uploadingFile, setUploadingFile] = useState(false);

  // Verificar permissões
  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  // Buscar item
  const { data: mediaItem, isLoading } = useQuery({
    queryKey: ['media-item-edit', mediaId],
    queryFn: async () => {
      const items = await base44.entities.MediaItem.filter({ id: mediaId });
      return items[0];
    },
    enabled: !!mediaId,
  });

  // Buscar consultorias e empresas
  const { data: consultorias = [] } = useQuery({
    queryKey: ['consultorias-active'],
    queryFn: () => base44.entities.Consultoria.filter({ status: 'ativo' }),
    initialData: [],
  });

  const { data: companies = [] } = useQuery({
    queryKey: ['companies-all'],
    queryFn: () => base44.entities.Company.list(),
    initialData: [],
  });

  // Carregar dados no form
  useEffect(() => {
    if (mediaItem) {
      setFormData({
        type: mediaItem.type || "video",
        title: mediaItem.title || "",
        description: mediaItem.description || "",
        cover_url: mediaItem.cover_url || "",
        duration_sec: mediaItem.duration_sec || 0,
        pages: mediaItem.pages || 0,
        provider: mediaItem.provider || "vimeo",
        provider_ref: mediaItem.provider_ref || "",
        file_url: mediaItem.file_url || "",
        tags: mediaItem.tags || [],
        categories: mediaItem.categories || [],
        visibility: mediaItem.visibility || "neutral",
        consultoria_id: mediaItem.consultoria_id || null,
        company_id: mediaItem.company_id || null,
        status: mediaItem.status || "draft"
      });
    }
  }, [mediaItem]);

  const updateMutation = useMutation({
    mutationFn: async (data) => {
      if (!data.title) throw new Error("Título é obrigatório");
      if (data.type === 'video' && !data.provider_ref) throw new Error("URL do vídeo é obrigatória");
      if (data.type === 'ebook' && !data.file_url) throw new Error("Arquivo do e-book é obrigatório");
      if (data.visibility === 'consultoria' && !data.consultoria_id) throw new Error("Selecione uma consultoria");
      if (data.visibility === 'empresa' && !data.company_id) throw new Error("Selecione uma empresa");
      
      const payload = { ...data };
      if (data.status === 'published' && !mediaItem.published_at) {
        payload.published_at = new Date().toISOString();
      }
      
      return base44.entities.MediaItem.update(mediaId, payload);
    },
    onSuccess: () => {
      toast.success("Conteúdo atualizado com sucesso!");
      queryClient.invalidateQueries({ queryKey: ['media-items-admin'] });
      navigate(createPageUrl('MediaLibraryAdmin'));
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao atualizar conteúdo");
    }
  });

  const handleUploadCover = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setUploadingCover(true);
    try {
      const result = await base44.integrations.Core.UploadFile({ file });
      setFormData({ ...formData, cover_url: result.file_url });
      toast.success("Capa enviada com sucesso!");
    } catch (error) {
      toast.error("Erro ao enviar capa");
    } finally {
      setUploadingCover(false);
    }
  };

  const handleUploadFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setUploadingFile(true);
    try {
      const result = await base44.integrations.Core.UploadFile({ file });
      setFormData({ ...formData, file_url: result.file_url });
      toast.success("Arquivo enviado com sucesso!");
    } catch (error) {
      toast.error("Erro ao enviar arquivo");
    } finally {
      setUploadingFile(false);
    }
  };

  const handleAddTag = () => {
    if (tagInput.trim() && !formData.tags.includes(tagInput.trim())) {
      setFormData({
        ...formData,
        tags: [...formData.tags, tagInput.trim()]
      });
      setTagInput("");
    }
  };

  const handleRemoveTag = (tag) => {
    setFormData({
      ...formData,
      tags: formData.tags.filter(t => t !== tag)
    });
  };

  const handleAddCategory = () => {
    if (categoryInput.trim() && !formData.categories.includes(categoryInput.trim())) {
      setFormData({
        ...formData,
        categories: [...formData.categories, categoryInput.trim()]
      });
      setCategoryInput("");
    }
  };

  const handleRemoveCategory = (cat) => {
    setFormData({
      ...formData,
      categories: formData.categories.filter(c => c !== cat)
    });
  };

  // Verificar se é admin
  if (loading || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#F8F6FB' }}>
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin mx-auto mb-4" style={{ color: '#4B2672' }} />
          <p className="text-sm text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  if (!user || user.role !== 'admin') {
    return <Navigate to="/MediaLibraryColaborador" replace />;
  }

  if (!formData) {
    return null;
  }

  return (
    <div className="p-4 md:p-8" style={{ backgroundColor: '#F8F6FB', minHeight: '100vh' }}>
      {/* Header */}
      <div className="flex items-center gap-4 mb-8">
        <Button
          variant="ghost"
          onClick={() => navigate(createPageUrl('MediaLibraryAdmin'))}
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold" style={{ color: '#2E2E2E' }}>
            Editar Conteúdo
          </h1>
          <p className="text-gray-500 mt-1">
            Atualize as informações do conteúdo
          </p>
        </div>
      </div>

      <form onSubmit={(e) => {
        e.preventDefault();
        updateMutation.mutate(formData);
      }} className="max-w-4xl">
        {/* Tipo (desabilitado) */}
        <Card className="shadow-md mb-6">
          <CardHeader>
            <CardTitle>Tipo de Conteúdo</CardTitle>
          </CardHeader>
          <CardContent>
            <Select value={formData.type} disabled>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="video">Vídeo</SelectItem>
                <SelectItem value="ebook">E-book</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-gray-500 mt-2">
              O tipo não pode ser alterado após a criação
            </p>
          </CardContent>
        </Card>

        {/* Metadados */}
        <Card className="shadow-md mb-6">
          <CardHeader>
            <CardTitle>Informações Básicas</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="title">Título *</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="Ex: Técnicas de Mindfulness para o Trabalho"
                required
              />
            </div>

            <div>
              <Label htmlFor="description">Descrição</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Descreva o conteúdo e seus benefícios..."
                rows={4}
              />
            </div>

            {/* URL Vimeo ou arquivo */}
            {formData.type === 'video' ? (
              <div>
                <Label htmlFor="provider_ref">URL do Vimeo *</Label>
                <Input
                  id="provider_ref"
                  value={formData.provider_ref}
                  onChange={(e) => setFormData({ ...formData, provider_ref: e.target.value })}
                  placeholder="https://vimeo.com/1107764573/ebe277b06b"
                  required
                />
                <p className="text-xs text-gray-500 mt-1">
                  Cole o link completo do vídeo no Vimeo
                </p>
              </div>
            ) : (
              <div>
                <Label htmlFor="file_url">Arquivo PDF *</Label>
                <div className="flex gap-2">
                  <Input
                    id="file_url"
                    value={formData.file_url}
                    readOnly
                    placeholder="URL do arquivo PDF"
                  />
                  <Button
                    type="button"
                    onClick={() => document.getElementById('file-upload').click()}
                    disabled={uploadingFile}
                  >
                    {uploadingFile ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                  </Button>
                  <input
                    id="file-upload"
                    type="file"
                    accept=".pdf"
                    className="hidden"
                    onChange={handleUploadFile}
                  />
                </div>
              </div>
            )}

            {/* Duração ou Páginas */}
            {formData.type === 'video' ? (
              <div>
                <Label htmlFor="duration_sec">Duração (segundos)</Label>
                <Input
                  id="duration_sec"
                  type="number"
                  value={formData.duration_sec}
                  onChange={(e) => setFormData({ ...formData, duration_sec: parseInt(e.target.value) || 0 })}
                  placeholder="Ex: 600 (10 minutos)"
                />
              </div>
            ) : (
              <div>
                <Label htmlFor="pages">Número de Páginas</Label>
                <Input
                  id="pages"
                  type="number"
                  value={formData.pages}
                  onChange={(e) => setFormData({ ...formData, pages: parseInt(e.target.value) || 0 })}
                  placeholder="Ex: 25"
                />
              </div>
            )}

            {/* Capa */}
            <div>
              <Label htmlFor="cover_url">Imagem de Capa</Label>
              <div className="flex gap-2">
                <Input
                  id="cover_url"
                  value={formData.cover_url}
                  readOnly
                  placeholder="URL da imagem de capa"
                />
                <Button
                  type="button"
                  onClick={() => document.getElementById('cover-upload').click()}
                  disabled={uploadingCover}
                >
                  {uploadingCover ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                </Button>
                <input
                  id="cover-upload"
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleUploadCover}
                />
              </div>
              {formData.cover_url && (
                <div className="mt-2">
                  <img src={formData.cover_url} alt="Preview" className="h-32 rounded-lg object-cover" />
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Tags e Categorias */}
        <Card className="shadow-md mb-6">
          <CardHeader>
            <CardTitle>Tags e Categorias</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Tags</Label>
              <div className="flex gap-2 mb-2">
                <Input
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddTag())}
                  placeholder="Digite uma tag e pressione Enter"
                />
                <Button type="button" onClick={handleAddTag}>Adicionar</Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {formData.tags.map((tag, idx) => (
                  <Badge key={idx} variant="secondary" className="cursor-pointer" onClick={() => handleRemoveTag(tag)}>
                    {tag} <X className="w-3 h-3 ml-1" />
                  </Badge>
                ))}
              </div>
            </div>

            <div>
              <Label>Categorias</Label>
              <div className="flex gap-2 mb-2">
                <Input
                  value={categoryInput}
                  onChange={(e) => setCategoryInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddCategory())}
                  placeholder="Digite uma categoria e pressione Enter"
                />
                <Button type="button" onClick={handleAddCategory}>Adicionar</Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {formData.categories.map((cat, idx) => (
                  <Badge key={idx} className="cursor-pointer" style={{ backgroundColor: '#4B2672' }} onClick={() => handleRemoveCategory(cat)}>
                    {cat} <X className="w-3 h-3 ml-1" />
                  </Badge>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Visibilidade */}
        <Card className="shadow-md mb-6">
          <CardHeader>
            <CardTitle>Visibilidade e Alvo</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="visibility">Escopo de Visibilidade *</Label>
              <Select value={formData.visibility} onValueChange={(v) => setFormData({ ...formData, visibility: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="neutral">🌐 Neutro (todos os clientes)</SelectItem>
                  <SelectItem value="mednet">🏥 MedNet (clientes com acesso)</SelectItem>
                  <SelectItem value="consultoria">🏢 Consultoria Específica</SelectItem>
                  <SelectItem value="empresa">🏭 Empresa Específica</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {formData.visibility === 'consultoria' && (
              <div>
                <Label htmlFor="consultoria_id">Consultoria</Label>
                <Select value={formData.consultoria_id || ''} onValueChange={(v) => setFormData({ ...formData, consultoria_id: v })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione uma consultoria" />
                  </SelectTrigger>
                  <SelectContent>
                    {consultorias.map(c => (
                      <SelectItem key={c.id} value={c.id}>{c.nome_fantasia}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {formData.visibility === 'empresa' && (
              <div>
                <Label htmlFor="company_id">Empresa</Label>
                <Select value={formData.company_id || ''} onValueChange={(v) => setFormData({ ...formData, company_id: v })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione uma empresa" />
                  </SelectTrigger>
                  <SelectContent>
                    {companies.map(c => (
                      <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Status */}
        <Card className="shadow-md mb-6">
          <CardHeader>
            <CardTitle>Status de Publicação</CardTitle>
          </CardHeader>
          <CardContent>
            <Select value={formData.status} onValueChange={(v) => setFormData({ ...formData, status: v })}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="draft">Rascunho</SelectItem>
                <SelectItem value="published">Publicado</SelectItem>
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        {/* Botões */}
        <div className="flex justify-end gap-3">
          <Button type="button" variant="outline" onClick={() => navigate(createPageUrl('MediaLibraryAdmin'))}>
            Cancelar
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={() => window.open(createPageUrl(`MediaPlayer?id=${mediaId}`), '_blank')}
          >
            <Eye className="w-4 h-4 mr-2" />
            Visualizar
          </Button>
          <Button
            type="submit"
            disabled={updateMutation.isPending}
            className="text-white"
            style={{ backgroundColor: '#4B2672' }}
          >
            {updateMutation.isPending ? (
              <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Salvando...</>
            ) : (
              <><Save className="w-4 h-4 mr-2" /> Salvar Alterações</>
            )}
          </Button>
        </div>
      </form>
    </div>
  );
}