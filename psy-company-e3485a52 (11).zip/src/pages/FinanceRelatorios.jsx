
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Navigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Download, 
  FileText, 
  TrendingUp,
  Users,
  DollarSign,
  BarChart3,
  Calendar
} from "lucide-react";
import { format, subMonths } from "date-fns";
import { toast } from "sonner";
import { formatCurrency } from "../components/billing/billingHelpers";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

export default function FinanceRelatorios() {
  const [user, setUser] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const [contexto, setContexto] = React.useState(null);
  const [contextoId, setContextoId] = React.useState(null);
  const [selectedReport, setSelectedReport] = useState('receita');
  const [selectedPeriod, setSelectedPeriod] = useState('12');

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
        
        const impersonationData = localStorage.getItem('admin_impersonation');
        if (impersonationData) {
          const parsed = JSON.parse(impersonationData);
          if (parsed.tipo === 'consultoria') {
            setContexto('CONSULTORIA');
            setContextoId(parsed.consultoria_id);
          }
        } else if (userData.user_role === 'admin') {
          setContexto('ADMIN');
          setContextoId(null);
        } else if (userData.user_role === 'consultoria') {
          setContexto('CONSULTORIA');
          setContextoId(userData.consultoria_id);
        }
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  const { data: faturas = [] } = useQuery({
    queryKey: ['faturas-relatorios', contexto, contextoId],
    queryFn: async () => {
      if (contexto === 'ADMIN') {
        return await base44.entities.Fatura.filter({
          emitente_tipo: 'ADMIN',
          alvo_tipo: 'CONSULTORIA'
        });
      } else if (contexto === 'CONSULTORIA') {
        return await base44.entities.Fatura.filter({
          emitente_tipo: 'CONSULTORIA',
          emitente_id: contextoId,
          alvo_tipo: 'EMPRESA'
        });
      }
      return [];
    },
    enabled: !!contexto,
  });

  const { data: recebiveis = [] } = useQuery({
    queryKey: ['recebiveis-relatorios', contexto, contextoId],
    queryFn: async () => {
      if (contexto === 'ADMIN') {
        return await base44.entities.Recebivel.filter({
          cliente_tipo: 'CONSULTORIA'
        });
      } else if (contexto === 'CONSULTORIA') {
        return await base44.entities.Recebivel.filter({
          cliente_tipo: 'EMPRESA',
          consultoria_id: contextoId
        });
      }
      return [];
    },
    enabled: !!contexto,
  });

  // Dados para Relatório de Receita
  const getReceitaData = () => {
    const months = parseInt(selectedPeriod);
    const data = [];

    for (let i = months - 1; i >= 0; i--) {
      const date = subMonths(new Date(), i);
      const competencia = format(date, 'yyyy-MM');
      
      const faturasDoMes = faturas.filter(f => f.competencia === competencia);
      const receitaEmitida = faturasDoMes.reduce((acc, f) => acc + (f.valor_liquido || 0), 0);
      const receitaRealizada = faturasDoMes
        .filter(f => f.status === 'PAGA')
        .reduce((acc, f) => acc + (f.valor_liquido || 0), 0);
      
      const recebiveisDoMes = recebiveis.filter(r => r.competencia === competencia);
      const mrr = recebiveisDoMes
        .filter(r => r.status === 'liquidado')
        .reduce((acc, r) => acc + r.valor_original, 0);

      data.push({
        month: format(date, 'MMM/yy'),
        mrr,
        receita_emitida: receitaEmitida,
        receita_realizada: receitaRealizada
      });
    }

    return data;
  };

  // Dados para Relatório de Cobrança
  const getCobrancaData = () => {
    const buckets = {
      '0-15': 0,
      '16-30': 0,
      '31-60': 0,
      '61-90': 0,
      '+90': 0
    };

    const hoje = new Date();
    recebiveis.forEach(r => {
      if (r.status === 'cancelado' || r.status === 'liquidado') return;
      
      const vencimento = new Date(r.vencimento);
      const dias = Math.floor((hoje - vencimento) / (1000 * 60 * 60 * 24));
      
      if (dias <= 0) return;
      if (dias <= 15) buckets['0-15'] += r.saldo;
      else if (dias <= 30) buckets['16-30'] += r.saldo;
      else if (dias <= 60) buckets['31-60'] += r.saldo;
      else if (dias <= 90) buckets['61-90'] += r.saldo;
      else buckets['+90'] += r.saldo;
    });

    return Object.entries(buckets).map(([name, value]) => ({ name, value }));
  };

  const handleExportCSV = () => {
    let data = [];
    let headers = [];

    if (selectedReport === 'receita') {
      headers = ['Mês', 'MRR', 'Receita Emitida', 'Receita Realizada'];
      data = getReceitaData().map(d => [
        d.month,
        d.mrr,
        d.receita_emitida,
        d.receita_realizada
      ]);
    } else if (selectedReport === 'cobranca') {
      headers = ['Bucket', 'Valor em Aberto'];
      data = getCobrancaData().map(d => [d.name, d.value]);
    }

    const csvContent = [headers, ...data]
      .map(row => row.map(cell => `"${cell}"`).join(','))
      .join('\n');

    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `relatorio_${selectedReport}_${new Date().getTime()}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    toast.success('Relatório exportado com sucesso');
  };

  const handleExportPDF = () => {
    toast.info('Exportação PDF em desenvolvimento');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando relatórios...</p>
        </div>
      </div>
    );
  }

  if (!user || (user.user_role !== 'admin' && user.user_role !== 'consultoria')) {
    return <Navigate to={createPageUrl('Error403')} />;
  }

  const receitaData = getReceitaData();
  const cobrancaData = getCobrancaData();

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                Relatórios Financeiros
              </h1>
              <p className="text-gray-600 mt-1">
                Análises e exportações de dados financeiros
              </p>
            </div>
            <div className="flex gap-3">
              <Button variant="outline" onClick={handleExportCSV}>
                <Download className="w-4 h-4 mr-2" />
                Exportar CSV
              </Button>
              <Button variant="outline" onClick={handleExportPDF}>
                <FileText className="w-4 h-4 mr-2" />
                Exportar PDF
              </Button>
            </div>
          </div>
        </div>

        {/* Filtros */}
        <Card className="shadow-md mb-6">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Select value={selectedReport} onValueChange={setSelectedReport}>
                <SelectTrigger>
                  <BarChart3 className="w-4 h-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="receita">Visão de Receita</SelectItem>
                  <SelectItem value="cobranca">Pipeline de Cobrança</SelectItem>
                </SelectContent>
              </Select>

              <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                <SelectTrigger>
                  <Calendar className="w-4 h-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="3">Últimos 3 meses</SelectItem>
                  <SelectItem value="6">Últimos 6 meses</SelectItem>
                  <SelectItem value="12">Últimos 12 meses</SelectItem>
                  <SelectItem value="24">Últimos 24 meses</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Relatório de Receita */}
        {selectedReport === 'receita' && (
          <div className="space-y-6">
            <Card className="shadow-md">
              <CardHeader>
                <CardTitle>Evolução de Receita</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <LineChart data={receitaData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                    <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                    <YAxis 
                      tickFormatter={(value) => `R$ ${(value / 1000).toFixed(0)}k`}
                      tick={{ fontSize: 12 }}
                    />
                    <Tooltip formatter={(value) => formatCurrency(value)} />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="mrr" 
                      stroke="#6B46C1" 
                      strokeWidth={3}
                      name="MRR"
                    />
                    <Line 
                      type="monotone" 
                      dataKey="receita_emitida" 
                      stroke="#805AD5" 
                      strokeWidth={2}
                      strokeDasharray="5 5"
                      name="Receita Emitida"
                    />
                    <Line 
                      type="monotone" 
                      dataKey="receita_realizada" 
                      stroke="#38A169" 
                      strokeWidth={2}
                      name="Receita Realizada"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="shadow-md">
              <CardHeader>
                <CardTitle>Dados Tabulares</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-3 px-4">Mês</th>
                        <th className="text-right py-3 px-4">MRR</th>
                        <th className="text-right py-3 px-4">Receita Emitida</th>
                        <th className="text-right py-3 px-4">Receita Realizada</th>
                      </tr>
                    </thead>
                    <tbody>
                      {receitaData.map((row, idx) => (
                        <tr key={idx} className="border-b hover:bg-gray-50">
                          <td className="py-3 px-4">{row.month}</td>
                          <td className="text-right py-3 px-4 font-semibold text-purple-600">
                            {formatCurrency(row.mrr)}
                          </td>
                          <td className="text-right py-3 px-4">
                            {formatCurrency(row.receita_emitida)}
                          </td>
                          <td className="text-right py-3 px-4 text-green-600 font-semibold">
                            {formatCurrency(row.receita_realizada)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Relatório de Cobrança */}
        {selectedReport === 'cobranca' && (
          <div className="space-y-6">
            <Card className="shadow-md">
              <CardHeader>
                <CardTitle>Pipeline de Cobrança (Aging)</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <BarChart data={cobrancaData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                    <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                    <YAxis 
                      tickFormatter={(value) => `R$ ${(value / 1000).toFixed(0)}k`}
                      tick={{ fontSize: 12 }}
                    />
                    <Tooltip formatter={(value) => formatCurrency(value)} />
                    <Bar dataKey="value" fill="#6B46C1" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="shadow-md">
              <CardHeader>
                <CardTitle>Distribuição por Bucket</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {cobrancaData.map((bucket, idx) => {
                    const total = cobrancaData.reduce((acc, b) => acc + b.value, 0);
                    const percent = total > 0 ? (bucket.value / total) * 100 : 0;
                    
                    return (
                      <div key={idx}>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm font-medium">{bucket.name} dias</span>
                          <span className="text-sm font-semibold text-purple-600">
                            {formatCurrency(bucket.value)} ({percent.toFixed(1)}%)
                          </span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-purple-600 h-2 rounded-full transition-all"
                            style={{ width: `${percent}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
