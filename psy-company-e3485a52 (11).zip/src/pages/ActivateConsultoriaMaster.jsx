import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CheckCircle, AlertCircle, RefreshCw, Lock } from "lucide-react";
import IMentalLogo from "../components/ui/IMentalLogo";

export default function ActivateConsultoriaMaster() {
  const [status, setStatus] = useState('loading'); // loading, success, error, already_active
  const [message, setMessage] = useState('');
  const [consultoriaName, setConsultoriaName] = useState('');
  const [activating, setActivating] = useState(false);
  
  useEffect(() => {
    checkInviteToken();
  }, []);
  
  const checkInviteToken = async () => {
    try {
      const urlParams = new URLSearchParams(window.location.search);
      const token = urlParams.get('token');
      
      if (!token) {
        setStatus('error');
        setMessage('Token de ativação não encontrado na URL.');
        return;
      }
      
      // Buscar o convite
      const invites = await base44.entities.InviteToken.filter({ token });
      
      if (!invites || invites.length === 0) {
        setStatus('error');
        setMessage('Token de ativação inválido ou expirado.');
        return;
      }
      
      const invite = invites[0];
      
      // Verificar se já foi aceito
      if (invite.status === 'accepted') {
        setStatus('already_active');
        setMessage('Esta conta já foi ativada! Você pode fazer login normalmente.');
        return;
      }
      
      // Verificar se expirou
      if (new Date(invite.expires_at) < new Date()) {
        setStatus('error');
        setMessage('Token de ativação expirado. Entre em contato com o administrador.');
        return;
      }
      
      // Buscar consultoria
      const consultorias = await base44.entities.Consultoria.filter({ id: invite.consultoria_id });
      if (consultorias && consultorias.length > 0) {
        setConsultoriaName(consultorias[0].nome_fantasia);
      }
      
      // Token válido - pronto para ativar
      setStatus('ready');
      setMessage('Conta pronta para ser ativada!');
      
    } catch (error) {
      console.error('Error checking invite:', error);
      setStatus('error');
      setMessage('Erro ao verificar token de ativação.');
    }
  };
  
  const handleActivate = async () => {
    try {
      setActivating(true);
      
      const urlParams = new URLSearchParams(window.location.search);
      const token = urlParams.get('token');
      
      // Buscar o convite novamente
      const invites = await base44.entities.InviteToken.filter({ token });
      const invite = invites[0];
      
      // Buscar consultoria com senha
      const consultorias = await base44.entities.Consultoria.filter({ id: invite.consultoria_id });
      const consultoria = consultorias[0];
      const masterData = consultoria.master_user_data;
      
      if (!masterData || !masterData.senha_temp) {
        throw new Error('Dados de autenticação não encontrados');
      }
      
      // Criar usuário no sistema usando base44.auth
      // Como não podemos chamar o endpoint diretamente, vamos marcar como aceito
      // e o usuário precisará fazer login com as credenciais
      
      await base44.entities.InviteToken.update(invite.id, {
        status: 'accepted',
        accepted_at: new Date().toISOString()
      });
      
      await base44.entities.Consultoria.update(consultoria.id, {
        master_user_data: {
          ...masterData,
          login_ativado: true
        }
      });
      
      setStatus('success');
      setMessage('Conta ativada com sucesso! Redirecionando para o login...');
      
      // Redirecionar para login após 3 segundos
      setTimeout(() => {
        window.location.href = '/login';
      }, 3000);
      
    } catch (error) {
      console.error('Error activating account:', error);
      setStatus('error');
      setMessage('Erro ao ativar conta: ' + error.message);
    } finally {
      setActivating(false);
    }
  };
  
  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ backgroundColor: '#F8F6FB' }}>
      <Card className="w-full max-w-md shadow-xl">
        <CardHeader className="text-center pb-4">
          <div className="flex justify-center mb-4">
            <IMentalLogo size="large" />
          </div>
          <CardTitle className="text-2xl font-bold" style={{ color: '#2E2E2E' }}>
            Ativação de Conta
          </CardTitle>
          {consultoriaName && (
            <p className="text-sm text-gray-600 mt-2">
              Consultoria: <strong>{consultoriaName}</strong>
            </p>
          )}
        </CardHeader>
        
        <CardContent className="space-y-4">
          {status === 'loading' && (
            <div className="text-center py-8">
              <RefreshCw className="w-12 h-12 animate-spin mx-auto mb-4" style={{ color: '#4B2672' }} />
              <p className="text-gray-600">Verificando token de ativação...</p>
            </div>
          )}
          
          {status === 'ready' && (
            <>
              <Alert className="bg-blue-50 border-blue-200">
                <Lock className="h-4 w-4 text-blue-600" />
                <AlertDescription className="text-blue-900 text-sm">
                  <p className="font-semibold mb-2">✅ Token Válido</p>
                  <p className="text-xs">
                    Clique no botão abaixo para ativar sua conta e poder fazer login no sistema.
                  </p>
                </AlertDescription>
              </Alert>
              
              <Button
                onClick={handleActivate}
                disabled={activating}
                className="w-full text-white text-lg py-6"
                style={{ backgroundColor: '#4B2672' }}
              >
                {activating ? (
                  <>
                    <RefreshCw className="w-5 h-5 mr-2 animate-spin" />
                    Ativando...
                  </>
                ) : (
                  <>
                    <CheckCircle className="w-5 h-5 mr-2" />
                    Ativar Minha Conta
                  </>
                )}
              </Button>
            </>
          )}
          
          {status === 'success' && (
            <Alert className="bg-green-50 border-green-200">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-900 text-sm">
                <p className="font-semibold mb-2">🎉 Sucesso!</p>
                <p className="text-xs">{message}</p>
              </AlertDescription>
            </Alert>
          )}
          
          {status === 'already_active' && (
            <>
              <Alert className="bg-green-50 border-green-200">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <AlertDescription className="text-green-900 text-sm">
                  <p className="font-semibold mb-2">✅ Conta Já Ativada</p>
                  <p className="text-xs">{message}</p>
                </AlertDescription>
              </Alert>
              
              <Button
                onClick={() => window.location.href = '/login'}
                className="w-full text-white"
                style={{ backgroundColor: '#4B2672' }}
              >
                Ir para Login
              </Button>
            </>
          )}
          
          {status === 'error' && (
            <>
              <Alert className="bg-red-50 border-red-200">
                <AlertCircle className="h-4 w-4 text-red-600" />
                <AlertDescription className="text-red-800 text-sm">
                  <p className="font-semibold mb-2">❌ Erro</p>
                  <p className="text-xs">{message}</p>
                </AlertDescription>
              </Alert>
              
              <Button
                onClick={() => window.location.href = '/'}
                variant="outline"
                className="w-full"
              >
                Voltar para Início
              </Button>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}