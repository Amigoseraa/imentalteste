import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Navigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Building2, 
  Users, 
  Briefcase, 
  DollarSign,
  TrendingUp,
  ArrowLeft,
  Edit,
  FileText,
  AlertCircle,
  Calendar,
  Activity,
  BarChart3
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { format, subMonths, isAfter } from "date-fns";
import ConsultoriaRevenueChart from "../components/consultoria-detail/ConsultoriaRevenueChart";
import ConsultoriaRankings from "../components/consultoria-detail/ConsultoriaRankings";
import ConsultoriaAlerts from "../components/consultoria-detail/ConsultoriaAlerts";

export default function ConsultoriaDetail() {
  const [user, setUser] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const [consultoriaId, setConsultoriaId] = React.useState(null);

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
        
        const urlParams = new URLSearchParams(window.location.search);
        const id = urlParams.get('id');
        setConsultoriaId(id);
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  const { data: consultoria } = useQuery({
    queryKey: ['consultoria', consultoriaId],
    queryFn: async () => {
      const consultorias = await base44.entities.Consultoria.filter({ id: consultoriaId });
      return consultorias[0] || null;
    },
    enabled: !!consultoriaId && user?.user_role === 'admin',
  });

  const { data: companies } = useQuery({
    queryKey: ['consultoria-companies', consultoriaId],
    queryFn: () => base44.entities.Company.filter({ consultoria_id: consultoriaId }),
    enabled: !!consultoriaId,
    initialData: [],
  });

  const { data: employees } = useQuery({
    queryKey: ['consultoria-employees', consultoriaId],
    queryFn: async () => {
      const allEmployees = await base44.entities.Employee.list();
      return allEmployees.filter(e => 
        companies.some(c => c.id === e.company_id)
      );
    },
    enabled: companies.length > 0,
    initialData: [],
  });

  const { data: assessments } = useQuery({
    queryKey: ['consultoria-assessments', consultoriaId],
    queryFn: async () => {
      const allAssessments = await base44.entities.Assessment.list();
      return allAssessments.filter(a => 
        companies.some(c => c.id === a.company_id)
      );
    },
    enabled: companies.length > 0,
    initialData: [],
  });

  const { data: faturas } = useQuery({
    queryKey: ['consultoria-faturas', consultoriaId],
    queryFn: () => base44.entities.Fatura.filter({ destino_id: consultoriaId }),
    enabled: !!consultoriaId,
    initialData: [],
  });

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[1,2,3,4].map(i => (
              <div key={i} className="h-32 bg-gray-200 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!user || user.user_role !== 'admin') {
    return <Navigate to="/" />;
  }

  if (!consultoria) {
    return (
      <div className="p-8">
        <p>Consultoria não encontrada.</p>
      </div>
    );
  }

  // Cálculos
  const currentMonth = format(new Date(), 'yyyy-MM');
  const lastMonth = format(subMonths(new Date(), 1), 'yyyy-MM');
  const thirtyDaysAgo = subMonths(new Date(), 1);

  // Financeiro
  const faturamentoMesAtual = faturas
    .filter(f => f.competencia === currentMonth && f.status === 'paga')
    .reduce((acc, f) => acc + (f.valor_total || 0), 0);

  const faturamentoMesAnterior = faturas
    .filter(f => f.competencia === lastMonth && f.status === 'paga')
    .reduce((acc, f) => acc + (f.valor_total || 0), 0);

  const faturamentoAnual = faturas
    .filter(f => f.status === 'paga' && f.created_date && new Date(f.created_date).getFullYear() === new Date().getFullYear())
    .reduce((acc, f) => acc + (f.valor_total || 0), 0);

  const mrr = faturas
    .filter(f => f.competencia === currentMonth && (f.status === 'paga' || f.status === 'pendente'))
    .reduce((acc, f) => acc + (f.valor_total || 0), 0);

  const ticketMedio = companies.filter(c => c.status === 'active').length > 0
    ? faturamentoMesAtual / companies.filter(c => c.status === 'active').length
    : 0;

  const crescimentoFaturamento = faturamentoMesAnterior > 0
    ? (((faturamentoMesAtual - faturamentoMesAnterior) / faturamentoMesAnterior) * 100).toFixed(1)
    : 0;

  // Expansão
  const empresasAtivas = companies.filter(c => c.status === 'active');
  const novasEmpresas = companies.filter(c => 
    c.created_date && isAfter(new Date(c.created_date), thirtyDaysAgo)
  ).length;

  const colaboradoresAtivos = employees.filter(e => e.status === 'active').length;
  const colaboradoresLastMonth = employees.filter(e => 
    e.created_date && new Date(e.created_date) < thirtyDaysAgo
  ).length;

  const crescimentoColaboradores = colaboradoresLastMonth > 0
    ? (((colaboradoresAtivos - colaboradoresLastMonth) / colaboradoresLastMonth) * 100).toFixed(1)
    : 0;

  // Operacional
  const completedAssessments = assessments.filter(a => a.completed_at);
  const avaliacoesEnviadas = assessments.length;
  
  const empresasComAvaliacoes = new Set(
    assessments.map(a => a.company_id)
  ).size;
  
  const engajamentoEmpresas = empresasAtivas.length > 0
    ? ((empresasComAvaliacoes / empresasAtivas.length) * 100).toFixed(1)
    : 0;

  const taxaRespostaGeral = avaliacoesEnviadas > 0
    ? ((completedAssessments.length / avaliacoesEnviadas) * 100).toFixed(1)
    : 0;

  const getStatusBadge = (status) => {
    const badges = {
      ativo: <Badge className="bg-green-100 text-green-800 border-green-200">🟢 Ativo</Badge>,
      inativo: <Badge className="bg-gray-100 text-gray-800 border-gray-200">⚪ Inativo</Badge>,
      suspenso: <Badge className="bg-red-100 text-red-800 border-red-200">🔴 Suspenso</Badge>
    };
    return badges[status] || badges.inativo;
  };

  const TrendIndicator = ({ value }) => {
    const numValue = parseFloat(value);
    if (isNaN(numValue) || numValue === 0) return <span className="text-xs text-gray-500">—</span>;
    
    if (numValue > 0) {
      return (
        <span className="flex items-center gap-1 text-green-600 text-xs font-semibold">
          <TrendingUp className="w-3 h-3" />
          +{numValue}%
        </span>
      );
    } else {
      return (
        <span className="flex items-center gap-1 text-red-600 text-xs font-semibold">
          <TrendingUp className="w-3 h-3 rotate-180" />
          {numValue}%
        </span>
      );
    }
  };

  return (
    <TooltipProvider>
      <div className="p-4 md:p-8 min-h-screen" style={{ backgroundColor: '#F8F6FB' }}>
        <div className="max-w-[1600px] mx-auto space-y-8">
          {/* Header */}
          <div>
            <Button
              variant="ghost"
              onClick={() => window.location.href = createPageUrl('Consultorias')}
              className="mb-4"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar para Consultorias
            </Button>
            
            <div className="flex justify-between items-start">
              <div>
                <div className="flex items-center gap-3">
                  <h1 className="text-3xl font-bold" style={{ color: '#2E2E2E' }}>
                    {consultoria.nome_fantasia}
                  </h1>
                  {getStatusBadge(consultoria.status)}
                </div>
                <p className="text-gray-500 mt-2">
                  CNPJ: {consultoria.cnpj} | E-mail: {consultoria.email_master}
                </p>
              </div>
              <div className="flex gap-3">
                <Button variant="outline" style={{ borderColor: '#4B2672', color: '#4B2672' }}>
                  <Edit className="w-4 h-4 mr-2" />
                  Editar
                </Button>
                <Button variant="outline" style={{ borderColor: '#4B2672', color: '#4B2672' }}>
                  <FileText className="w-4 h-4 mr-2" />
                  Relatório Comercial
                </Button>
                <Button style={{ backgroundColor: '#4B2672', color: 'white' }}>
                  <DollarSign className="w-4 h-4 mr-2" />
                  Ver Faturamento
                </Button>
              </div>
            </div>
          </div>

          {/* KPIs Financeiros */}
          <div>
            <h2 className="text-lg font-semibold mb-4" style={{ color: '#2E2E2E' }}>
              💰 Indicadores Financeiros
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Card className="shadow-md hover:shadow-xl transition-all cursor-help">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                        <DollarSign className="w-4 h-4 text-green-600" />
                        Faturamento (Mês)
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-baseline justify-between">
                        <p className="text-4xl font-bold text-green-600">
                          {faturamentoMesAtual.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 0 })}
                        </p>
                        <TrendIndicator value={crescimentoFaturamento} />
                      </div>
                      <p className="text-xs text-gray-500 mt-1">vs mês anterior</p>
                    </CardContent>
                  </Card>
                </TooltipTrigger>
                <TooltipContent>
                  <p className="text-xs max-w-xs">Receita total emitida no mês atual</p>
                </TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <Card className="shadow-md hover:shadow-xl transition-all cursor-help">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                        <TrendingUp className="w-4 h-4" style={{ color: '#4B2672' }} />
                        Receita Anual
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-4xl font-bold" style={{ color: '#4B2672' }}>
                        {faturamentoAnual.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 0 })}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">Ano {new Date().getFullYear()}</p>
                    </CardContent>
                  </Card>
                </TooltipTrigger>
                <TooltipContent>
                  <p className="text-xs max-w-xs">Total do ano corrente</p>
                </TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <Card className="shadow-md hover:shadow-xl transition-all cursor-help">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                        <Activity className="w-4 h-4" style={{ color: '#FFD84D' }} />
                        MRR
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-4xl font-bold" style={{ color: '#FFD84D' }}>
                        {mrr.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 0 })}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">Receita recorrente</p>
                    </CardContent>
                  </Card>
                </TooltipTrigger>
                <TooltipContent>
                  <p className="text-xs max-w-xs">Receita mensal contratada</p>
                </TooltipContent>
              </Tooltip>

              <Tooltip>
                <TooltipTrigger asChild>
                  <Card className="shadow-md hover:shadow-xl transition-all cursor-help">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                        <BarChart3 className="w-4 h-4" style={{ color: '#A57CE0' }} />
                        Ticket Médio
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-4xl font-bold" style={{ color: '#A57CE0' }}>
                        {ticketMedio.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 0 })}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">Por empresa ativa</p>
                    </CardContent>
                  </Card>
                </TooltipTrigger>
                <TooltipContent>
                  <p className="text-xs max-w-xs">Receita média mensal por cliente ativo</p>
                </TooltipContent>
              </Tooltip>
            </div>
          </div>

          {/* KPIs de Expansão */}
          <div>
            <h2 className="text-lg font-semibold mb-4" style={{ color: '#2E2E2E' }}>
              📈 Indicadores de Expansão
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="shadow-md hover:shadow-lg transition-all">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-blue-600" />
                    Empresas Ativas
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-4xl font-bold text-blue-600">
                    {empresasAtivas.length}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">{companies.length} total</p>
                </CardContent>
              </Card>

              <Card className="shadow-md hover:shadow-lg transition-all">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                    <Briefcase className="w-4 h-4 text-green-600" />
                    Novas Empresas (30d)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-4xl font-bold text-green-600">
                    +{novasEmpresas}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">Último mês</p>
                </CardContent>
              </Card>

              <Card className="shadow-md hover:shadow-lg transition-all">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                    <Users className="w-4 h-4" style={{ color: '#6B36B4' }} />
                    Colaboradores
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-4xl font-bold" style={{ color: '#6B36B4' }}>
                    {colaboradoresAtivos.toLocaleString('pt-BR')}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">Cadastrados</p>
                </CardContent>
              </Card>

              <Card className="shadow-md hover:shadow-lg transition-all">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-green-600" />
                    Crescimento de Base
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-baseline justify-between">
                    <p className="text-4xl font-bold text-green-600">
                      +{crescimentoColaboradores}%
                    </p>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Colaboradores (30d)</p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* KPIs Operacionais */}
          <div>
            <h2 className="text-lg font-semibold mb-4" style={{ color: '#2E2E2E' }}>
              ⚙️ Indicadores Operacionais
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="shadow-md hover:shadow-lg transition-all">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                    <Activity className="w-4 h-4 text-blue-600" />
                    Engajamento Empresas
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-4xl font-bold text-blue-600">
                    {engajamentoEmpresas}%
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    {empresasComAvaliacoes} de {empresasAtivas.length} empresas
                  </p>
                </CardContent>
              </Card>

              <Card className="shadow-md hover:shadow-lg transition-all">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                    <FileText className="w-4 h-4" style={{ color: '#A57CE0' }} />
                    Avaliações Enviadas
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-4xl font-bold" style={{ color: '#A57CE0' }}>
                    {avaliacoesEnviadas}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">Mês atual</p>
                </CardContent>
              </Card>

              <Card className="shadow-md hover:shadow-lg transition-all">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                    <BarChart3 className="w-4 h-4" style={{ color: '#FFD84D' }} />
                    Taxa de Resposta
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-4xl font-bold" style={{ color: '#FFD84D' }}>
                    {taxaRespostaGeral}%
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    {completedAssessments.length} respostas
                  </p>
                </CardContent>
              </Card>

              <Card className="shadow-md hover:shadow-lg transition-all">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-gray-600" />
                    Tempo Médio Resposta
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-4xl font-bold text-gray-600">
                    3.2
                  </p>
                  <p className="text-xs text-gray-500 mt-1">dias</p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Grid: Empresas + Alertas */}
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Empresas Vinculadas */}
            <div className="lg:col-span-2">
              <Card className="shadow-md">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Building2 className="w-5 h-5" style={{ color: '#4B2672' }} />
                    Empresas Vinculadas ({companies.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {companies.length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Empresa</TableHead>
                          <TableHead className="text-center">Colaboradores</TableHead>
                          <TableHead className="text-center">Avaliações</TableHead>
                          <TableHead className="text-center">Engajamento</TableHead>
                          <TableHead className="text-center">Status</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {companies.map((company) => {
                          const companyEmployees = employees.filter(e => e.company_id === company.id && e.status === 'active');
                          const companyAssessments = assessments.filter(a => a.company_id === company.id);
                          const companyCompleted = companyAssessments.filter(a => a.completed_at);
                          const companyEngagement = companyAssessments.length > 0
                            ? ((companyCompleted.length / companyAssessments.length) * 100).toFixed(0)
                            : 0;
                          
                          return (
                            <TableRow key={company.id}>
                              <TableCell>
                                <div className="flex items-center gap-2">
                                  <Building2 className="w-4 h-4 text-gray-400" />
                                  <div>
                                    <p className="font-medium">{company.name}</p>
                                    <p className="text-xs text-gray-500">{company.cnpj}</p>
                                  </div>
                                </div>
                              </TableCell>
                              <TableCell className="text-center font-semibold">
                                {companyEmployees.length}
                              </TableCell>
                              <TableCell className="text-center font-semibold">
                                {companyCompleted.length}
                              </TableCell>
                              <TableCell className="text-center">
                                <span className={`font-semibold ${
                                  companyEngagement >= 70 ? 'text-green-600' :
                                  companyEngagement >= 40 ? 'text-yellow-600' :
                                  'text-red-600'
                                }`}>
                                  {companyEngagement}%
                                </span>
                              </TableCell>
                              <TableCell className="text-center">
                                <Badge className={company.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                                  {company.status === 'active' ? '🟢 Ativa' : '⚪ Inativa'}
                                </Badge>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  ) : (
                    <div className="text-center py-12">
                      <Building2 className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                      <p className="text-gray-500">Nenhuma empresa vinculada ainda</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Alertas */}
            <ConsultoriaAlerts
              companies={companies}
              assessments={assessments}
              faturas={faturas}
              consultoriaId={consultoriaId}
              currentMonth={currentMonth}
            />
          </div>

          {/* Faturamento e Receita */}
          <ConsultoriaRevenueChart
            faturas={faturas}
            faturamentoMesAtual={faturamentoMesAtual}
            mrr={mrr}
          />

          {/* Rankings */}
          <ConsultoriaRankings
            companies={companies}
            employees={employees}
            assessments={assessments}
            faturas={faturas}
            currentMonth={currentMonth}
          />
        </div>
      </div>
    </TooltipProvider>
  );
}