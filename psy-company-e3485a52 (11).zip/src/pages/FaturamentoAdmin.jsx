import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Navigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  DollarSign, 
  TrendingUp, 
  AlertCircle, 
  CheckCircle, 
  FileText,
  Download,
  Send,
  RefreshCw,
  Eye,
  Edit,
  Settings,
  Calendar
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Checkbox } from "@/components/ui/checkbox";
import { format, addMonths } from "date-fns";
import { toast } from "sonner";
import { generateBillingPreview } from "../components/billing/BillingEngine";
import BillingKPIs from "../components/billing/BillingKPIs";
import BillingPipeline from "../components/billing/BillingPipeline";
import BillingEditModal from "../components/billing/BillingEditModal";
import BillingAutomationSettings from "../components/billing/BillingAutomationSettings";
import EspelhoNFModal from "../components/faturamento/EspelhoNFModal";
import { BILLING_STATUS, formatCurrency, addHistoricoEntry } from "../components/billing/billingHelpers";

export default function FaturamentoAdmin() {
  const [user, setUser] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const [selectedMonth, setSelectedMonth] = useState(format(new Date(), 'yyyy-MM'));
  const [statusFilter, setStatusFilter] = useState('all');
  const [consultoriaFilter, setConsultoriaFilter] = useState('all');
  const [calculando, setCalculando] = useState(false);
  const [previews, setPreviews] = useState([]);
  const [divergencias, setDivergencias] = useState([]);
  const [selectedItems, setSelectedItems] = useState([]);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showEspelhoModal, setShowEspelhoModal] = useState(false);
  const [showAutomationModal, setShowAutomationModal] = useState(false);
  const [editingFatura, setEditingFatura] = useState(null);
  const [espelhoData, setEspelhoData] = useState(null);
  const [autoConfig, setAutoConfig] = useState({
    auto_gerar: false,
    auto_aprovar: false,
    auto_emitir: false,
    auto_enviar: false,
    dia_execucao: 1,
    hora_execucao: '08:00'
  });

  const queryClient = useQueryClient();

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  // Buscar consultorias ativas
  const { data: consultorias = [] } = useQuery({
    queryKey: ['consultorias'],
    queryFn: () => base44.entities.Consultoria.list('-created_date'),
    enabled: user?.user_role === 'admin',
  });

  // Buscar contratos Admin → Consultoria
  const { data: contratos = [] } = useQuery({
    queryKey: ['contratos-consultoria'],
    queryFn: () => base44.entities.ContratoConsultoria.list(),
    enabled: user?.user_role === 'admin',
  });

  // Buscar todas as empresas (para cálculo de base)
  const { data: allCompanies = [] } = useQuery({
    queryKey: ['all-companies'],
    queryFn: () => base44.entities.Company.list(),
    enabled: user?.user_role === 'admin',
  });

  // Buscar todos os colaboradores (para cálculo de base)
  const { data: allEmployees = [] } = useQuery({
    queryKey: ['all-employees'],
    queryFn: () => base44.entities.Employee.list(),
    enabled: user?.user_role === 'admin',
  });

  // Buscar faturas já emitidas (ADMIN → CONSULTORIA)
  const { data: faturas = [] } = useQuery({
    queryKey: ['faturas-admin', selectedMonth],
    queryFn: () => base44.entities.Fatura.filter({
      emitente_tipo: 'ADMIN',
      alvo_tipo: 'CONSULTORIA',
      competencia: selectedMonth
    }),
    enabled: user?.user_role === 'admin',
  });

  // Gerar prévia de faturamento
  const gerarPreviaMutation = useMutation({
    mutationFn: async () => {
      setCalculando(true);
      
      try {
        const result = await generateBillingPreview({
          competencia: selectedMonth,
          emitenteTipo: 'ADMIN',
          emitenteId: null,
          targets: consultorias.filter(c => c.status === 'ativo'),
          contratos,
          baseData: {
            empresas: allCompanies,
            colaboradores: allEmployees
          },
          base44
        });

        setPreviews(result.previews);
        setDivergencias(result.divergencias);
        setSelectedItems([]);
        
        return result;
      } finally {
        setCalculando(false);
      }
    },
    onSuccess: (result) => {
      toast.success(`Prévia gerada para ${result.previews.length} consultorias`);
      if (result.divergencias.length > 0) {
        toast.warning(`${result.divergencias.length} divergências encontradas`);
      }
    },
    onError: () => {
      toast.error('Erro ao gerar prévia de faturamento');
    }
  });

  // Editar fatura
  const editarFaturaMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      const historico = addHistoricoEntry(
        editingFatura,
        'EDICAO_MANUAL',
        'EDITADA',
        user.email,
        'Valores ajustados manualmente'
      );

      return await base44.entities.Fatura.update(id, {
        ...data,
        editada_em: new Date().toISOString(),
        editada_por: user.email,
        historico
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['faturas-admin'] });
      setShowEditModal(false);
      setEditingFatura(null);
      toast.success('Fatura editada com sucesso!');
    },
    onError: () => {
      toast.error('Erro ao editar fatura');
    }
  });

  // Recalcular fatura (volta para automático)
  const recalcularFaturaMutation = useMutation({
    mutationFn: async (faturaId) => {
      // Buscar contrato e recalcular
      const fatura = faturas.find(f => f.id === faturaId);
      const contrato = contratos.find(c => c.consultoria_id === fatura.alvo_id);
      
      // Aqui você recalcularia usando a engine
      // Por simplicidade, vamos apenas mudar o status de volta
      const historico = addHistoricoEntry(
        fatura,
        'RECALCULO',
        'PREVIA',
        user.email,
        'Valores recalculados automaticamente'
      );

      return await base44.entities.Fatura.update(faturaId, {
        origem_calculo: 'AUTOMATICO',
        status: 'PREVIA',
        historico
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['faturas-admin'] });
      setShowEditModal(false);
      toast.success('Fatura recalculada!');
    }
  });

  // Autorizar e emitir faturas
  const autorizarEmitirMutation = useMutation({
    mutationFn: async (consultoriaIds) => {
      const faturasParaAutorizar = [...previews, ...faturas].filter(f => 
        consultoriaIds.includes(f.alvo_id) &&
        (f.status === 'PREVIA' || f.status === 'EDITADA')
      );

      const updated = [];
      for (const fatura of faturasParaAutorizar) {
        const historico = addHistoricoEntry(
          fatura,
          'AUTORIZACAO',
          'AUTORIZADA',
          user.email,
          'Fatura autorizada para envio'
        );

        let faturaData = {
          ...fatura,
          status: 'AUTORIZADA',
          autorizada_em: new Date().toISOString(),
          autorizada_por: user.email,
          historico
        };

        // Se auto_emitir está ativo, já muda para ENVIADA
        if (autoConfig.auto_emitir) {
          faturaData.status = 'ENVIADA';
          faturaData.enviada_em = new Date().toISOString();
        }

        if (fatura.id) {
          const result = await base44.entities.Fatura.update(fatura.id, faturaData);
          updated.push(result);
        } else {
          const result = await base44.entities.Fatura.create(faturaData);
          updated.push(result);
        }
      }

      return updated;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['faturas-admin'] });
      toast.success(`${data.length} faturas autorizadas com sucesso!`);
      gerarPreviaMutation.mutate(); // Recalcular prévia
    },
    onError: () => {
      toast.error('Erro ao autorizar faturas');
    }
  });

  // Enviar faturas por e-mail
  const enviarFaturasMutation = useMutation({
    mutationFn: async (faturaIds) => {
      const faturasParaEnviar = faturas.filter(f => 
        faturaIds.includes(f.id) &&
        (f.status === 'AUTORIZADA' || f.status === 'ENVIADA')
      );
      
      for (const fatura of faturasParaEnviar) {
        const historico = addHistoricoEntry(
          fatura,
          'ENVIO_EMAIL',
          'ENVIADA',
          user.email,
          'E-mail de cobrança enviado'
        );

        await base44.entities.Fatura.update(fatura.id, {
          status: 'ENVIADA',
          enviada_em: new Date().toISOString(),
          reenvios: [...(fatura.reenvios || []), {
            data: new Date().toISOString(),
            usuario: user.email
          }],
          historico
        });

        // Enviar e-mail (simulado - implementar integração real)
        try {
          const consultoria = consultorias.find(c => c.id === fatura.alvo_id);
          await base44.integrations.Core.SendEmail({
            from_name: 'iMental',
            to: consultoria?.email_master || '',
            subject: `Fatura iMental - ${fatura.competencia}`,
            body: `Olá ${fatura.alvo_nome},\n\nSua fatura referente ao mês ${fatura.competencia} está disponível.\n\nValor: R$ ${fatura.valor_liquido.toFixed(2)}\nVencimento: ${format(new Date(fatura.vencimento_em), 'dd/MM/yyyy')}\n\nAcesse a plataforma para mais detalhes.`
          });
        } catch (e) {
          console.error('Erro ao enviar e-mail:', e);
        }
      }

      return faturasParaEnviar.length;
    },
    onSuccess: (count) => {
      queryClient.invalidateQueries({ queryKey: ['faturas-admin'] });
      toast.success(`${count} faturas enviadas por e-mail!`);
    },
    onError: () => {
      toast.error('Erro ao enviar faturas');
    }
  });

  // Marcar como paga
  const marcarComoPagaMutation = useMutation({
    mutationFn: async (faturaId) => {
      const fatura = faturas.find(f => f.id === faturaId);
      const historico = addHistoricoEntry(
        fatura,
        'PAGAMENTO',
        'PAGA',
        user.email,
        'Pagamento confirmado'
      );

      return await base44.entities.Fatura.update(faturaId, {
        status: 'PAGA',
        paga_em: new Date().toISOString(),
        historico
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['faturas-admin'] });
      toast.success('Fatura marcada como paga!');
    }
  });

  const handleGerarPrevia = () => {
    gerarPreviaMutation.mutate();
  };

  const handleAutorizarEmitir = () => {
    if (selectedItems.length === 0) {
      toast.error('Selecione pelo menos uma consultoria');
      return;
    }
    
    autorizarEmitirMutation.mutate(selectedItems);
  };

  const handleEnviarSelecionadas = () => {
    const faturasParaEnviar = faturas
      .filter(f => selectedItems.includes(f.alvo_id) && (f.status === 'AUTORIZADA' || f.status === 'ENVIADA'))
      .map(f => f.id);
    
    if (faturasParaEnviar.length === 0) {
      toast.error('Nenhuma fatura autorizada selecionada');
      return;
    }
    
    enviarFaturasMutation.mutate(faturasParaEnviar);
  };

  const handleEditFatura = (fatura) => {
    setEditingFatura(fatura);
    setShowEditModal(true);
  };

  const handleSaveEdit = (data) => {
    editarFaturaMutation.mutate({
      id: editingFatura.id,
      data
    });
  };

  const handleRecalculate = () => {
    if (editingFatura?.id) {
      recalcularFaturaMutation.mutate(editingFatura.id);
    }
  };

  const handleVisualizarEspelho = (fatura) => {
    const consultoria = consultorias.find(c => c.id === fatura.alvo_id);
    setEspelhoData({
      consultoria: 'iMental',
      empresa: fatura.alvo_nome,
      cnpj: consultoria?.cnpj || '',
      competencia: fatura.competencia,
      modelo: fatura.modelo_cobranca,
      base: fatura.meta?.base_calculo?.descricao || '',
      base_quantidade: fatura.meta?.base_calculo?.quantidade || 0,
      preco_unitario: fatura.itens?.[0]?.valor_unitario || 0,
      valor_bruto: fatura.valor_bruto,
      desconto_percent: fatura.desconto_percent,
      descontos: fatura.desconto_valor,
      valor_liquido: fatura.valor_liquido,
      vencimento: fatura.vencimento_em
    });
    setShowEspelhoModal(true);
  };

  const handleExportarCSV = () => {
    const data = previews.length > 0 ? previews : faturas;
    const csvContent = [
      ['Consultoria', 'CNPJ', 'Modelo', 'Base', 'Valor Bruto', 'Desconto', 'Valor Líquido', 'Vencimento', 'Status'].join(','),
      ...data.map(item => [
        item.alvo_nome,
        consultorias.find(c => c.id === item.alvo_id)?.cnpj || '',
        item.modelo_cobranca,
        item.meta?.base_calculo?.descricao || '',
        item.valor_bruto?.toFixed(2) || '',
        item.desconto_percent || 0,
        item.valor_liquido?.toFixed(2) || '',
        format(new Date(item.vencimento_em), 'dd/MM/yyyy'),
        item.status
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `Faturamento_Admin_${selectedMonth}.csv`;
    link.click();
  };

  const handleSaveAutomation = (config) => {
    setAutoConfig(config);
    // Aqui você salvaria em ConfiguracaoFaturamento
    toast.success('Configurações de automação salvas!');
  };

  const toggleSelectAll = () => {
    const items = previews.length > 0 ? previews : faturas;
    if (selectedItems.length === items.length) {
      setSelectedItems([]);
    } else {
      setSelectedItems(items.map(item => item.alvo_id));
    }
  };

  const toggleSelectItem = (alvoId) => {
    setSelectedItems(prev => 
      prev.includes(alvoId)
        ? prev.filter(id => id !== alvoId)
        : [...prev, alvoId]
    );
  };

  const getStatusBadge = (status) => {
    const config = BILLING_STATUS[status] || BILLING_STATUS.PREVIA;
    return (
      <Badge 
        className="text-xs"
        style={{ 
          backgroundColor: config.bgColor,
          color: config.color
        }}
      >
        {config.label}
      </Badge>
    );
  };

  const getModeloBadge = (modelo) => {
    const config = {
      'FIXO_MENSAL': { label: 'Fixo Mensal', color: 'bg-green-100 text-green-800' },
      'POR_EMPRESA_ATIVA': { label: 'Por Empresa', color: 'bg-blue-100 text-blue-800' },
      'POR_COLABORADOR_ATIVO': { label: 'Por Colaborador', color: 'bg-purple-100 text-purple-800' },
      'HIBRIDO': { label: 'Híbrido', color: 'bg-yellow-100 text-yellow-800' }
    };
    const { label, color } = config[modelo] || config['FIXO_MENSAL'];
    return <Badge className={color}>{label}</Badge>;
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="grid grid-cols-4 gap-6">
            {[1,2,3,4].map(i => (
              <div key={i} className="h-32 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  };

  if (!user || user.user_role !== 'admin') {
    return <Navigate to="/" />;
  }

  // Calcular contagens por status para o pipeline
  const allData = [...previews, ...faturas];
  const faturasCounts = {
    PREVIA: allData.filter(f => f.status === 'PREVIA').length,
    EDITADA: allData.filter(f => f.status === 'EDITADA').length,
    AUTORIZADA: allData.filter(f => f.status === 'AUTORIZADA').length,
    ENVIADA: allData.filter(f => f.status === 'ENVIADA').length,
  };

  const displayData = previews.length > 0 ? previews : faturas;
  const filteredData = displayData.filter(item => {
    const statusMatch = statusFilter === 'all' || item.status === statusFilter;
    const consultoriaMatch = consultoriaFilter === 'all' || item.alvo_id === consultoriaFilter;
    return statusMatch && consultoriaMatch;
  });

  return (
    <TooltipProvider>
      <div className="p-4 md:p-8 min-h-screen" style={{ backgroundColor: '#F8F6FB' }}>
        <div className="max-w-[1800px] mx-auto space-y-8">
          {/* Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <h1 className="text-3xl font-bold" style={{ color: '#2E2E2E' }}>
                  Faturamento Admin iMental
                </h1>
              </div>
              <p className="text-gray-500">
                Gestão de faturas emitidas para consultorias parceiras
              </p>
            </div>
            <Button
              onClick={handleGerarPrevia}
              disabled={calculando}
              className="text-white"
              style={{ backgroundColor: '#4B2672' }}
            >
              {calculando ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Calculando...
                </>
              ) : (
                <>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Gerar Faturas do Mês
                </>
              )}
            </Button>
          </div>

          {/* Pipeline Visual */}
          <BillingPipeline 
            currentStatus={allData[0]?.status || 'PREVIA'} 
            faturasCounts={faturasCounts}
          />

          {/* KPIs */}
          <BillingKPIs 
            faturas={allData}
            divergencias={divergencias}
            autoConfig={autoConfig}
          />

          {/* Filtros */}
          <Card className="shadow-md">
            <CardContent className="p-6">
              <div className="flex flex-wrap gap-4 items-end">
                <div className="flex-1 min-w-[200px]">
                  <label className="text-sm font-medium text-gray-700 mb-2 block">
                    Competência
                  </label>
                  <Input
                    type="month"
                    value={selectedMonth}
                    onChange={(e) => setSelectedMonth(e.target.value)}
                  />
                </div>

                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos</SelectItem>
                    <SelectItem value="PREVIA">Prévia</SelectItem>
                    <SelectItem value="EDITADA">Editada</SelectItem>
                    <SelectItem value="AUTORIZADA">Autorizada</SelectItem>
                    <SelectItem value="ENVIADA">Enviada</SelectItem>
                    <SelectItem value="PAGA">Paga</SelectItem>
                    <SelectItem value="VENCIDA">Vencida</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={consultoriaFilter} onValueChange={setConsultoriaFilter}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Todas consultorias" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas consultorias</SelectItem>
                    {consultorias.map(c => (
                      <SelectItem key={c.id} value={c.id}>{c.nome_fantasia}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Button
                  onClick={handleAutorizarEmitir}
                  disabled={selectedItems.length === 0 || autorizarEmitirMutation.isPending}
                  className="text-white"
                  style={{ backgroundColor: '#4B2672' }}
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Autorizar e Emitir
                </Button>

                <Button
                  onClick={handleEnviarSelecionadas}
                  disabled={selectedItems.length === 0 || enviarFaturasMutation.isPending}
                  variant="outline"
                  style={{ borderColor: '#00B37E', color: '#00B37E' }}
                >
                  <Send className="w-4 h-4 mr-2" />
                  Enviar E-mails
                </Button>

                <Button
                  onClick={handleExportarCSV}
                  disabled={displayData.length === 0}
                  variant="outline"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Exportar CSV
                </Button>

                <Button
                  onClick={() => setShowAutomationModal(true)}
                  variant="outline"
                >
                  <Settings className="w-4 h-4 mr-2" />
                  Automação
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Divergências */}
          {divergencias.length > 0 && (
            <Alert className="border-2 border-yellow-200 bg-yellow-50">
              <AlertCircle className="h-4 h-4" />
              <AlertDescription>
                <strong>{divergencias.length} divergências encontradas:</strong>
                <ul className="mt-2 ml-4 list-disc text-sm">
                  {divergencias.slice(0, 5).map((div, idx) => (
                    <li key={idx}>{div.alvo}: {div.motivo}</li>
                  ))}
                  {divergencias.length > 5 && (
                    <li className="text-gray-600">... e mais {divergencias.length - 5}</li>
                  )}
                </ul>
              </AlertDescription>
            </Alert>
          )}

          {/* Tabela */}
          <Card className="shadow-md">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Faturas Emitidas — Consultorias</CardTitle>
                {filteredData.length > 0 && (
                  <Badge variant="outline" className="text-sm">
                    {selectedItems.length} de {filteredData.length} selecionadas
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent>
              {filteredData.length > 0 ? (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-gray-50">
                        <TableHead className="w-12">
                          <Checkbox
                            checked={selectedItems.length === filteredData.length}
                            onCheckedChange={toggleSelectAll}
                          />
                        </TableHead>
                        <TableHead>Consultoria</TableHead>
                        <TableHead className="text-center">Contrato</TableHead>
                        <TableHead className="text-center">Base de Cálculo</TableHead>
                        <TableHead className="text-center">Origem</TableHead>
                        <TableHead className="text-right">Valor Bruto</TableHead>
                        <TableHead className="text-center">Desconto</TableHead>
                        <TableHead className="text-right">Valor Líquido</TableHead>
                        <TableHead className="text-center">Vencimento</TableHead>
                        <TableHead className="text-center">Status</TableHead>
                        <TableHead className="text-right">Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredData.map((fatura) => {
                        const consultoria = consultorias.find(c => c.id === fatura.alvo_id);
                        
                        return (
                          <TableRow key={fatura.id || fatura.alvo_id} className="hover:bg-gray-50">
                            <TableCell>
                              <Checkbox
                                checked={selectedItems.includes(fatura.alvo_id)}
                                onCheckedChange={() => toggleSelectItem(fatura.alvo_id)}
                              />
                            </TableCell>
                            <TableCell>
                              <div>
                                <p className="font-semibold">{fatura.alvo_nome}</p>
                                <p className="text-xs text-gray-500">{consultoria?.cnpj || '—'}</p>
                              </div>
                            </TableCell>
                            <TableCell className="text-center">
                              {getModeloBadge(fatura.modelo_cobranca)}
                            </TableCell>
                            <TableCell className="text-center text-sm">
                              {fatura.meta?.base_calculo?.descricao || '—'}
                            </TableCell>
                            <TableCell className="text-center">
                              {fatura.origem_calculo === 'MANUAL' ? (
                                <Badge className="bg-yellow-100 text-yellow-800 text-xs">
                                  Manual
                                </Badge>
                              ) : (
                                <Badge className="bg-gray-100 text-gray-600 text-xs">
                                  Automático
                                </Badge>
                              )}
                            </TableCell>
                            <TableCell className="text-right font-medium">
                              {(fatura.valor_bruto || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                            </TableCell>
                            <TableCell className="text-center">
                              {fatura.desconto_percent > 0 ? `${fatura.desconto_percent}%` : '—'}
                            </TableCell>
                            <TableCell className="text-right font-bold" style={{ color: '#00B37E' }}>
                              {(fatura.valor_liquido || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                            </TableCell>
                            <TableCell className="text-center text-sm">
                              {format(new Date(fatura.vencimento_em), 'dd/MM/yyyy')}
                            </TableCell>
                            <TableCell className="text-center">
                              {getStatusBadge(fatura.status)}
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end gap-2">
                                {(fatura.status === 'PREVIA' || fatura.status === 'EDITADA') && (
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <Button
                                        variant="ghost"
                                        size="icon"
                                        onClick={() => handleEditFatura(fatura)}
                                        title="Editar fatura"
                                      >
                                        <Edit className="w-4 h-4" />
                                      </Button>
                                    </TooltipTrigger>
                                    <TooltipContent>Editar fatura</TooltipContent>
                                  </Tooltip>
                                )}
                                {fatura.status !== 'PREVIA' && fatura.status !== 'PAGA' && (
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <Button
                                        variant="ghost"
                                        size="icon"
                                        onClick={() => marcarComoPagaMutation.mutate(fatura.id)}
                                        title="Marcar como paga"
                                      >
                                        <CheckCircle className="w-4 h-4 text-green-600" />
                                      </Button>
                                    </TooltipTrigger>
                                    <TooltipContent>Marcar como paga</TooltipContent>
                                  </Tooltip>
                                )}
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      onClick={() => handleVisualizarEspelho(fatura)}
                                      title="Ver espelho"
                                    >
                                      <Eye className="w-4 h-4" />
                                    </Button>
                                  </TooltipTrigger>
                                  <TooltipContent>Ver espelho NF</TooltipContent>
                                </Tooltip>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="text-center py-16">
                  <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-700 mb-2">
                    Nenhuma fatura de consultoria para o período
                  </h3>
                  <p className="text-gray-500 mb-6">
                    Selecione a competência e clique em "Gerar Faturas do Mês"
                  </p>
                  <Button 
                    onClick={handleGerarPrevia}
                    style={{ backgroundColor: '#4B2672', color: 'white' }}
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Gerar Faturas Agora
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Modals */}
      <BillingEditModal
        open={showEditModal}
        onClose={() => {
          setShowEditModal(false);
          setEditingFatura(null);
        }}
        fatura={editingFatura}
        onSave={handleSaveEdit}
        onRecalculate={handleRecalculate}
      />

      <EspelhoNFModal
        open={showEspelhoModal}
        onClose={() => setShowEspelhoModal(false)}
        data={espelhoData}
      />

      <BillingAutomationSettings
        open={showAutomationModal}
        onClose={() => setShowAutomationModal(false)}
        config={autoConfig}
        onSave={handleSaveAutomation}
      />
    </TooltipProvider>
  );
}