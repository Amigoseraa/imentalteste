
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Navigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Progress } from "@/components/ui/progress";
import {
  Activity,
  AlertTriangle,
  CheckCircle,
  XCircle,
  RefreshCw,
  Trash2,
  Beaker,
  Database, // Added Database icon
  Loader2, // Added Loader2 icon
} from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";
import { seedDemo, cleanupDemoData } from "../components/utils/demoSeeder";
import { seedTestData } from "../components/utils/testDataSeeder"; // Added import for seedTestData

export default function SystemDiagnostics() {
  const [user, setUser] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const [showResetDialog, setShowResetDialog] = React.useState(false);
  const [showSeedDialog, setShowSeedDialog] = React.useState(false);
  const [showQuickSeedDialog, setShowQuickSeedDialog] = React.useState(false); // New state for quick seed dialog
  const [seedProgress, setSeedProgress] = React.useState(null); // For seedDemo
  const [resetOptions, setResetOptions] = useState({
    createBackup: true,
    confirmed: false
  });
  const [seedOptions, setSeedOptions] = useState({
    profile: 'medio',
    months: 6,
    mode: 'reset',
    withBilling: true
  });

  // New state for test data seeding
  const [seedingTestData, setSeedingTestData] = useState(false);
  const [testSeedProgress, setTestSeedProgress] = useState({ step: '', message: '', progress: 0 });
  const [testSeedResult, setTestSeedResult] = useState(null);


  const queryClient = useQueryClient();

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  const { data: selfCheckResult, refetch: runSelfCheck, isLoading: checkingKPIs } = useQuery({
    queryKey: ['kpi-selfcheck'],
    queryFn: async () => {
      const consultorias = await base44.entities.Consultoria.list();
      const companies = await base44.entities.Company.list();
      const employees = await base44.entities.Employee.list();
      const assessments = await base44.entities.Assessment.list();
      const faturas = await base44.entities.Fatura.list();
      const pagamentos = await base44.entities.Pagamento.list();

      const issues = [];
      const warnings = [];

      const companiesWithoutConsultoria = companies.filter(c => !c.consultoria_id);
      if (companiesWithoutConsultoria.length > 0) {
        issues.push({
          severity: 'error',
          component: 'Multitenancy',
          message: `${companiesWithoutConsultoria.length} empresas sem consultoria_id`,
          count: companiesWithoutConsultoria.length
        });
      }

      const employeesWithoutCompany = employees.filter(e => !e.company_id);
      if (employeesWithoutCompany.length > 0) {
        issues.push({
          severity: 'error',
          component: 'Multitenancy',
          message: `${employeesWithoutCompany.length} colaboradores sem company_id`,
          count: employeesWithoutCompany.length
        });
      }

      const assessmentsOrphan = assessments.filter(a =>
        !employees.some(e => e.id === a.employee_id)
      );
      if (assessmentsOrphan.length > 0) {
        warnings.push({
          severity: 'warning',
          component: 'Avaliações',
          message: `${assessmentsOrphan.length} avaliações com employee_id inválido`,
          count: assessmentsOrphan.length
        });
      }

      const faturasEmitidas = faturas.filter(f =>
        ['AUTORIZADA', 'ENVIADA', 'PAGA', 'VENCIDA'].includes(f.status)
      );
      const faturasPagas = faturas.filter(f => f.status === 'PAGA');
      const faturasPendentes = faturas.filter(f =>
        ['AUTORIZADA', 'ENVIADA'].includes(f.status)
      );
      const faturasVencidas = faturas.filter(f => f.status === 'VENCIDA');

      const somaEmitidas = faturasEmitidas.reduce((acc, f) => acc + (f.valor_liquido || 0), 0);
      const somaPagas = faturasPagas.reduce((acc, f) => acc + (f.valor_liquido || 0), 0);
      const somaPendentes = faturasPendentes.reduce((acc, f) => acc + (f.valor_liquido || 0), 0);
      const somaVencidas = faturasVencidas.reduce((acc, f) => acc + (f.valor_liquido || 0), 0);

      const totalParcial = somaPagas + somaPendentes + somaVencidas;
      const diff = Math.abs(somaEmitidas - totalParcial);

      if (diff > 0.01) {
        warnings.push({
          severity: 'warning',
          component: 'Financeiro',
          message: `Divergência de R$ ${diff.toFixed(2)} entre emitidas e soma de pagas+pendentes+vencidas`,
          detail: `Emitidas: ${somaEmitidas.toFixed(2)} | Soma: ${totalParcial.toFixed(2)}`
        });
      }

      const pagamentosOrphan = pagamentos.filter(p =>
        !faturas.some(f => f.id === p.fatura_id)
      );
      if (pagamentosOrphan.length > 0) {
        issues.push({
          severity: 'error',
          component: 'Pagamentos',
          message: `${pagamentosOrphan.length} pagamentos com fatura_id inválido`,
          count: pagamentosOrphan.length
        });
      }

      const companiesWithFewAssessments = companies.map(c => {
        const companyAssessments = assessments.filter(a =>
          a.company_id === c.id && a.completed_at
        );
        return {
          company: c.name,
          count: companyAssessments.length
        };
      }).filter(c => c.count > 0 && c.count < 5);

      if (companiesWithFewAssessments.length > 0) {
        warnings.push({
          severity: 'info',
          component: 'Amostras',
          message: `${companiesWithFewAssessments.length} empresas com amostra insuficiente (<5 avaliações)`,
          count: companiesWithFewAssessments.length
        });
      }

      return {
        status: issues.length === 0 ? 'healthy' : 'error',
        issues,
        warnings,
        stats: {
          consultorias: consultorias.length,
          companies: companies.length,
          employees: employees.length,
          assessments: assessments.length,
          faturas: faturas.length,
          pagamentos: pagamentos.length
        },
        timestamp: new Date().toISOString()
      };
    },
    enabled: user?.user_role === 'admin',
  });

  const reprocessMutation = useMutation({
    mutationFn: async () => {
      const currentMonth = format(new Date(), 'yyyy-MM');
      const faturas = await base44.entities.Fatura.filter({ competencia: currentMonth });

      const mrr = faturas
        .filter(f => f.status !== 'CANCELADA')
        .reduce((acc, f) => acc + (f.valor_liquido || 0), 0);

      const receitaRealizada = faturas
        .filter(f => f.status === 'PAGA')
        .reduce((acc, f) => acc + (f.valor_liquido || 0), 0);

      const aging = {
        bucket_0_15: 0,
        bucket_16_30: 0,
        bucket_31_60: 0,
        bucket_61_90: 0,
        bucket_90_plus: 0
      };

      faturas.forEach(f => {
        if (!['AUTORIZADA', 'ENVIADA', 'VENCIDA'].includes(f.status)) return;
        if (!f.vencimento_em) return;

        const dias = Math.floor((new Date() - new Date(f.vencimento_em)) / (1000 * 60 * 60 * 24));
        const valor = f.valor_liquido || 0;

        if (dias <= 15) aging.bucket_0_15 += valor;
        else if (dias <= 30) aging.bucket_16_30 += valor;
        else if (dias <= 60) aging.bucket_31_60 += valor;
        else if (dias <= 90) aging.bucket_61_90 += valor;
        else aging.bucket_90_plus += valor;
      });

      const snapshot = {
        competencia: currentMonth,
        alvo_tipo: 'ADMIN',
        alvo_id: null,
        mrr,
        arr: mrr * 12,
        receita_prevista: faturas.reduce((acc, f) => acc + (f.valor_liquido || 0), 0),
        receita_realizada: receitaRealizada,
        aging_buckets: aging
      };

      const existing = await base44.entities.FinanceSnapshot.filter({
        competencia: currentMonth,
        alvo_tipo: 'ADMIN'
      });

      if (existing.length > 0) {
        await base44.entities.FinanceSnapshot.update(existing[0].id, snapshot);
      } else {
        await base44.entities.FinanceSnapshot.create(snapshot);
      }

      return { success: true };
    },
    onSuccess: () => {
      queryClient.invalidateQueries();
      toast.success('KPIs e Snapshots reprocessados com sucesso!');
      runSelfCheck();
    },
  });

  const resetMutation = useMutation({
    mutationFn: async (options) => {
      if (options.createBackup) {
        toast.info('Criando backup...');
        await new Promise(resolve => setTimeout(resolve, 2000));
      }

      const entitiesToClear = [
        'Pagamento',
        'DunningLog',
        'Fatura',
        'ContratoEmpresa',
        'ContratoConsultoria',
        'FinanceSnapshot',
        'Recebivel',
        'Assessment',
        'Action',
        'Employee',
        'GHE',
        'Department',
        'Company',
        'Consultoria',
        'AuditLog'
      ];

      for (const entityName of entitiesToClear) {
        try {
          const records = await base44.entities[entityName].list();
          for (const record of records) {
            await base44.entities[entityName].delete(record.id);
          }
        } catch (error) {
          console.error(`Error clearing ${entityName}:`, error);
        }
      }

      return { success: true };
    },
    onSuccess: () => {
      queryClient.invalidateQueries();
      setShowResetDialog(false);
      toast.success('Bases de dados zeradas com sucesso!');
    },
    onError: (error) => {
      toast.error(error.message || 'Erro ao executar reset');
    }
  });

  const seedMutation = useMutation({
    mutationFn: async (config) => {
      return await seedDemo(config, (step, message, percent) => {
        setSeedProgress({ step, message, percent });
      });
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries();
      setShowSeedDialog(false);
      setSeedProgress(null);
      toast.success(`Dados fictícios gerados! ${result.summary.consultorias} consultorias, ${result.summary.empresas} empresas.`);
      setTimeout(() => reprocessMutation.mutate(), 1000);
    },
    onError: (error) => {
      toast.error(error.message || 'Erro ao gerar dados fictícios');
      setSeedProgress(null);
    }
  });

  const cleanupDemoMutation = useMutation({
    mutationFn: cleanupDemoData,
    onSuccess: () => {
      queryClient.invalidateQueries();
      toast.success('Dados de demonstração removidos!');
      runSelfCheck();
    },
  });

  const quickSeedMutation = useMutation({
    mutationFn: async () => {
      const consultorias = await base44.entities.Consultoria.list();
      const companies = await base44.entities.Company.list();

      if (consultorias.length === 0 || companies.length === 0) {
        throw new Error('É necessário ter ao menos 1 consultoria e 1 empresa cadastradas primeiro.');
      }

      const employees = await base44.entities.Employee.list();

      if (employees.length === 0) {
        throw new Error('É necessário ter ao menos 1 colaborador cadastrado primeiro.');
      }

      // Gerar avaliações para colaboradores existentes
      let assessmentsCreated = 0;
      // Cap at 20 assessments to keep it "quick"
      const maxAssessments = Math.min(employees.length, 20);

      for (let i = 0; i < maxAssessments; i++) {
        const employee = employees[i];

        // PHQ-9
        const phq9Score = Math.floor(Math.random() * 20);
        let phq9Classification = "Mínimo";
        if (phq9Score >= 15) phq9Classification = "Grave";
        else if (phq9Score >= 10) phq9Classification = "Moderado";
        else if (phq9Score >= 5) phq9Classification = "Leve";

        // GAD-7
        const gad7Score = Math.floor(Math.random() * 15);
        let gad7Classification = "Mínimo";
        if (gad7Score >= 15) gad7Classification = "Grave";
        else if (gad7Score >= 10) gad7Classification = "Moderado";
        else if (gad7Score >= 5) gad7Classification = "Leve";

        // PRIMA-EF
        const primaScore = 2.5 + Math.random() * 1.5; // score between 2.5 and 4.0
        let primaClassification = "Baixo";
        if (primaScore < 2.5) primaClassification = "Alto";
        else if (primaScore < 3.5) primaClassification = "Moderado";

        const responses = {};
        for (let j = 1; j <= 30; j++) {
          responses[`q${j}`] = Math.floor(Math.random() * 3) + 2; // Responses between 2 and 4
        }

        await base44.entities.Assessment.create({
          employee_id: employee.id,
          company_id: employee.company_id,
          department_id: employee.department_id,
          assessment_type: 'PRIMA-EF,PHQ-9,GAD-7',
          assessment_token: `quick_${employee.id}_${Date.now()}_${i}`, // Ensure unique token
          assessment_name: `Avaliação Rápida ${format(new Date(), 'MM/yyyy')}`,
          due_date: format(new Date(), 'yyyy-MM-dd'),
          term_accepted: true,
          term_accepted_at: new Date().toISOString(),
          prima_responses: responses,
          prima_score: parseFloat(primaScore.toFixed(2)),
          prima_classification: primaClassification,
          phq9_score: phq9Score,
          phq9_classification: phq9Classification,
          gad7_score: gad7Score,
          gad7_classification: gad7Classification,
          has_suicide_risk: phq9Score >= 15 && Math.random() < 0.2, // 20% chance if score is high
          completed_at: new Date().toISOString(),
          seed_tag: 'quick_demo' // Mark with a specific seed tag
        });

        assessmentsCreated++;
      }

      // Gerar faturas
      let faturasCreated = 0;
      const competencia = format(new Date(), 'yyyy-MM');

      for (const consultoria of consultorias) {
        const empresasConsultoria = companies.filter(c => c.consultoria_id === consultoria.id);
        if (empresasConsultoria.length === 0) continue;

        const valor = empresasConsultoria.length * 49.90; // Example value

        // Check for existing quick_demo fatura to avoid duplicates for same month/consultoria
        const existingFatura = await base44.entities.Fatura.filter({
          competencia: competencia,
          alvo_tipo: 'CONSULTORIA',
          alvo_id: consultoria.id,
          seed_tag: 'quick_demo'
        });

        if (existingFatura.length === 0) {
          await base44.entities.Fatura.create({
            competencia,
            alvo_tipo: 'CONSULTORIA',
            alvo_id: consultoria.id,
            alvo_nome: consultoria.nome_fantasia,
            emitente_tipo: 'ADMIN',
            emitente_id: null,
            modelo_cobranca: 'POR_EMPRESA_ATIVA',
            valor_bruto: valor,
            valor_liquido: valor,
            status: ['AUTORIZADA', 'PAGA', 'VENCIDA'][Math.floor(Math.random() * 3)],
            vencimento_em: format(new Date(), 'yyyy-MM-10'),
            emitida_em: new Date().toISOString(),
            autorizada_em: new Date().toISOString(),
            idempotency_key: `${competencia}|CONSULTORIA|${consultoria.id}|quick`, // Ensure uniqueness for this specific quick seed
            seed_tag: 'quick_demo'
          });

          faturasCreated++;
        }
      }

      // Gerar pagamentos
      const recentFaturas = await base44.entities.Fatura.filter({ seed_tag: 'quick_demo', competencia: competencia });
      let pagamentosCreated = 0;

      for (const fatura of recentFaturas) {
        if (fatura.status === 'PAGA') {
          // Check for existing quick_demo pagamento to avoid duplicates
          const existingPagamento = await base44.entities.Pagamento.filter({
            fatura_id: fatura.id,
            seed_tag: 'quick_demo'
          });

          if (existingPagamento.length === 0) {
            await base44.entities.Pagamento.create({
              fatura_id: fatura.id,
              valor_liquido: fatura.valor_liquido,
              taxa: 0,
              meio: 'pix',
              pago_em: new Date().toISOString(),
              origem: 'manual',
              conciliado: true,
              criado_por: user.email,
              seed_tag: 'quick_demo'
            });
            pagamentosCreated++;
          }
        }
      }

      return {
        assessments: assessmentsCreated,
        faturas: faturasCreated,
        pagamentos: pagamentosCreated
      };
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries();
      setShowQuickSeedDialog(false);
      toast.success(`Criados: ${result.assessments} avaliações, ${result.faturas} faturas, ${result.pagamentos} pagamentos`);
      setTimeout(() => reprocessMutation.mutate(), 1000); // Reprocess KPIs after seed
    },
    onError: (error) => {
      toast.error(error.message || 'Erro ao criar dados');
      setShowQuickSeedDialog(false);
    }
  });

  const handleSeedTestData = async () => {
    if (!window.confirm('Isso irá criar colaboradores e avaliações fake em TODAS as empresas. Confirma?')) {
      return;
    }

    setSeedingTestData(true);
    setTestSeedProgress({ step: 'start', message: 'Iniciando...', progress: 0 });
    setTestSeedResult(null);

    try {
      const result = await seedTestData({
        employeesPerCompany: 15,
        assessmentPercentage: 80,
        onProgress: (progress) => {
          setTestSeedProgress(progress);
        },
        userEmail: user.email, // Pass the current user's email for AuditLog or creator fields if applicable
      });

      setTestSeedResult(result);
      toast.success(`Dados criados com sucesso! ${result.totalEmployees} colaboradores e ${result.totalAssessments} avaliações`);

      // Recarregar queries
      queryClient.invalidateQueries({ queryKey: ['kpi-selfcheck'] });

    } catch (error) {
      console.error('Error seeding data:', error);
      toast.error(`Erro ao criar dados: ${error.message}`);
    } finally {
      setSeedingTestData(false);
    }
  };


  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  if (!user || user.user_role !== 'admin') {
    return <Navigate to="/" />;
  }

  return (
    <div className="p-4 md:p-8 min-h-screen" style={{ backgroundColor: '#F8F6FB' }} data-testid="page-content">
      <div className="max-w-6xl mx-auto space-y-8">
        <div className="flex flex-wrap justify-between items-start gap-4">
          <div>
            <h1 className="text-3xl font-bold" style={{ color: '#2E2E2E' }}>
              Diagnóstico do Sistema
            </h1>
            <p className="text-gray-500 mt-2">
              Monitore a saúde e consistência dos dados do iMental
            </p>
          </div>
          <div className="flex flex-wrap gap-3">
            <Button
              variant="outline"
              onClick={() => runSelfCheck()}
              disabled={checkingKPIs}
              data-testid="run-diagnostics"
            >
              {checkingKPIs ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Verificando...
                </>
              ) : (
                <>
                  <Activity className="w-4 h-4 mr-2" />
                  Executar Diagnóstico
                </>
              )}
            </Button>
            <Button
              onClick={() => setShowQuickSeedDialog(true)}
              disabled={quickSeedMutation.isPending}
              data-testid="quick-seed"
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              <Beaker className="w-4 h-4 mr-2" />
              Criar Dados Rápido
            </Button>
            <Button
              onClick={() => setShowSeedDialog(true)}
              disabled={seedMutation.isPending}
              data-testid="seed-demo"
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              <Beaker className="w-4 h-4 mr-2" />
              Popular Completo
            </Button>
          </div>
        </div>

        {selfCheckResult && (
          <>
            <Card className={`shadow-md border-2 ${
              selfCheckResult.status === 'healthy'
                ? 'border-green-200 bg-green-50'
                : 'border-red-200 bg-red-50'
            }`} data-testid="health-status">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  {selfCheckResult.status === 'healthy' ? (
                    <>
                      <CheckCircle className="w-12 h-12 text-green-600" />
                      <div>
                        <h3 className="text-xl font-bold text-green-900">
                          Sistema Saudável
                        </h3>
                        <p className="text-green-700">
                          Todos os indicadores vinculados e consistentes
                        </p>
                      </div>
                    </>
                  ) : (
                    <>
                      <XCircle className="w-12 h-12 text-red-600" />
                      <div>
                        <h3 className="text-xl font-bold text-red-900">
                          Inconsistências Detectadas
                        </h3>
                        <p className="text-red-700">
                          {selfCheckResult.issues.length} erro(s) e {selfCheckResult.warnings.length} aviso(s)
                        </p>
                      </div>
                    </>
                  )}
                </div>
                <div className="mt-4 text-xs text-gray-600">
                  Última verificação: {format(new Date(selfCheckResult.timestamp), 'dd/MM/yyyy HH:mm:ss')}
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {Object.entries(selfCheckResult.stats).map(([key, value]) => (
                <Card key={key} className="shadow-sm" data-testid="kpi-card">
                  <CardContent className="p-4">
                    <p className="text-xs text-gray-500 uppercase">{key}</p>
                    <p className="text-2xl font-bold" style={{ color: '#4B2672' }}>{value}</p>
                  </CardContent>
                </Card>
              ))}
            </div>

            {selfCheckResult.issues.length > 0 && (
              <Card className="shadow-md border-2 border-red-200" data-testid="error-state">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-red-900">
                    <AlertTriangle className="w-5 h-5" />
                    Erros Críticos
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {selfCheckResult.issues.map((issue, idx) => (
                      <Alert key={idx} className="bg-red-50 border-red-200">
                        <AlertDescription className="flex items-start justify-between">
                          <div>
                            <Badge className="bg-red-100 text-red-800 mb-2">
                              {issue.component}
                            </Badge>
                            <p className="text-red-900">{issue.message}</p>
                          </div>
                          {issue.count && (
                            <span className="text-2xl font-bold text-red-600">{issue.count}</span>
                          )}
                        </AlertDescription>
                      </Alert>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {selfCheckResult.warnings.length > 0 && (
              <Card className="shadow-md border-2 border-yellow-200">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-yellow-900">
                    <AlertTriangle className="w-5 h-5" />
                    Avisos
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {selfCheckResult.warnings.map((warning, idx) => (
                      <Alert key={idx} className="bg-yellow-50 border-yellow-200">
                        <AlertDescription className="flex items-start justify-between">
                          <div>
                            <Badge className="bg-yellow-100 text-yellow-800 mb-2">
                              {warning.component}
                            </Badge>
                            <p className="text-yellow-900">{warning.message}</p>
                          </div>
                          {warning.count && (
                            <span className="text-2xl font-bold text-yellow-600">{warning.count}</span>
                          )}
                        </AlertDescription>
                      </Alert>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </>
        )}

        {/* Botão de Seed de Dados */}
        <Card className="shadow-md border-2 border-blue-300">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-blue-900">
              <Database className="w-5 h-5" />
              Popular Dados de Teste
            </CardTitle>
            <CardDescription>
              Crie colaboradores e avaliações fictícias em massa
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert className="bg-blue-50 border-blue-200">
              <AlertDescription className="text-blue-800">
                <p className="font-semibold mb-2">⚠️ Ferramenta de Teste</p>
                <p className="text-sm">
                  Esta ferramenta criará colaboradores e avaliações fake em TODAS as empresas ativas para fins de teste e demonstração.
                </p>
                <ul className="text-sm mt-2 ml-4 list-disc">
                  <li>15 colaboradores por empresa</li>
                  <li>80% dos colaboradores terão avaliações completas</li>
                  <li>Dados gerados automaticamente com CPF, email e telefone fictícios</li>
                  <li>Scores e classificações realistas</li>
                </ul>
              </AlertDescription>
            </Alert>

            {seedingTestData && (
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <Loader2 className="w-5 h-5 animate-spin text-blue-600" />
                  <div className="flex-1">
                    <p className="text-sm font-medium">{testSeedProgress.message}</p>
                    {testSeedProgress.progress > 0 && (
                      <div className="mt-2 w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                          style={{ width: `${testSeedProgress.progress}%` }}
                        />
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {testSeedResult && (
              <Alert className="bg-green-50 border-green-200">
                <AlertDescription className="text-green-800">
                  <p className="font-semibold mb-2">✅ Dados Criados com Sucesso!</p>
                  <ul className="text-sm space-y-1">
                    <li>• <strong>{testSeedResult.totalEmployees}</strong> colaboradores criados</li>
                    <li>• <strong>{testSeedResult.totalAssessments}</strong> avaliações completas</li>
                    <li>• <strong>{testSeedResult.companies}</strong> empresas processadas</li>
                  </ul>
                </AlertDescription>
              </Alert>
            )}

            <div className="flex gap-3">
              <Button
                onClick={handleSeedTestData}
                disabled={seedingTestData}
                className="text-white"
                style={{ backgroundColor: '#4B2672' }}
              >
                {seedingTestData ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Criando Dados...
                  </>
                ) : (
                  <>
                    <Database className="w-4 h-4 mr-2" />
                    Criar Dados de Teste
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>


        <Card className="shadow-md border-2 border-green-300">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-900">
              <Beaker className="w-5 h-5" />
              Zona de Demonstração
            </CardTitle>
            <CardDescription>
              Ferramentas para popular e gerenciar dados fictícios
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert className="bg-green-50 border-green-200">
              <AlertDescription className="text-green-900 text-sm">
                <strong>ℹ️ Dados Fictícios:</strong> Crie dados de demonstração. Os dados gerados por "Popular Completo" são marcados com <code className="bg-green-100 px-1 rounded">seed_tag='demo'</code> e os de "Criar Dados Rápido" com <code className="bg-green-100 px-1 rounded">seed_tag='quick_demo'</code>
              </AlertDescription>
            </Alert>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button
                variant="outline"
                onClick={() => setShowQuickSeedDialog(true)}
                disabled={quickSeedMutation.isPending}
                className="h-auto py-4 flex-col items-start border-blue-300 hover:bg-blue-50"
              >
                <div className="flex items-center gap-2 mb-2">
                  <Beaker className="w-5 h-5 text-blue-600" />
                  <span className="font-semibold text-blue-900">Criar Dados Rápido</span>
                </div>
                <p className="text-xs text-gray-600 text-left">
                  Gera avaliações, faturas e pagamentos com dados existentes (~30 segundos)
                </p>
              </Button>

              <Button
                variant="outline"
                onClick={() => setShowSeedDialog(true)}
                disabled={seedMutation.isPending}
                className="h-auto py-4 flex-col items-start border-green-300 hover:bg-green-50"
              >
                <div className="flex items-center gap-2 mb-2">
                  <Beaker className="w-5 h-5 text-green-600" />
                  <span className="font-semibold text-green-900">Popular Completo</span>
                </div>
                <p className="text-xs text-gray-600 text-left">
                  Gera consultorias, empresas, colaboradores e avaliações (vários minutos)
                </p>
              </Button>

              <Button
                variant="outline"
                onClick={() => cleanupDemoMutation.mutate()}
                disabled={cleanupDemoMutation.isPending}
                className="h-auto py-4 flex-col items-start border-orange-300 hover:bg-orange-50"
                data-testid="cleanup-demo"
              >
                <div className="flex items-center gap-2 mb-2">
                  <Trash2 className="w-5 h-5 text-orange-600" />
                  <span className="font-semibold text-orange-900">Apagar Dados Demo</span>
                </div>
                <p className="text-xs text-gray-600 text-left">
                  Remove registros marcados como demonstração (<code>seed_tag='demo'</code> ou <code>'quick_demo'</code>)
                </p>
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-md border-2 border-red-300">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-900">
              <AlertTriangle className="w-5 h-5" />
              Zona de Perigo
            </CardTitle>
            <CardDescription>
              Ações irreversíveis - use apenas em ambientes de teste
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Alert className="bg-red-50 border-red-200 mb-4">
              <AlertDescription className="text-red-900">
                <strong>⚠️ ATENÇÃO:</strong> O reset apagará todos os dados. Esta ação não pode ser desfeita.
              </AlertDescription>
            </Alert>

            <Button
              variant="destructive"
              onClick={() => setShowResetDialog(true)}
              className="w-full"
              data-testid="reset-system"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Reset Completo do Sistema
            </Button>
          </CardContent>
        </Card>
      </div>

      <Dialog open={showSeedDialog} onOpenChange={setShowSeedDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-green-900">
              <Beaker className="w-5 h-5" />
              Popular Dados Fictícios
            </DialogTitle>
            <DialogDescription>
              Gere dados de demonstração realistas
            </DialogDescription>
          </DialogHeader>

          {seedProgress ? (
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="font-medium capitalize">{seedProgress.step.replace('_', ' ')}</span>
                  <span className="text-gray-500">{seedProgress.percent}%</span>
                </div>
                <Progress value={seedProgress.percent} className="h-2" />
                <p className="text-xs text-gray-600">{seedProgress.message}</p>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <Label className="mb-2 block">Perfil de Carga</Label>
                <Select
                  value={seedOptions.profile}
                  onValueChange={(value) => setSeedOptions({...seedOptions, profile: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="leve">Leve (1 consultoria, ~100 colaboradores)</SelectItem>
                    <SelectItem value="medio">Médio (3 consultorias, ~500 colaboradores)</SelectItem>
                    <SelectItem value="completo">Completo (5 consultorias, ~1500 colaboradores)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="mb-2 block">Período Histórico</Label>
                <Select
                  value={String(seedOptions.months)}
                  onValueChange={(value) => setSeedOptions({...seedOptions, months: parseInt(value)})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="3">3 meses</SelectItem>
                    <SelectItem value="6">6 meses</SelectItem>
                    <SelectItem value="12">12 meses</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="mb-2 block">Modo</Label>
                <RadioGroup
                  value={seedOptions.mode}
                  onValueChange={(value) => setSeedOptions({...seedOptions, mode: value})}
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="reset" id="reset" aria-checked={seedOptions.mode === 'reset'} />
                    <Label htmlFor="reset">Zerar e Recriar</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="merge" id="merge" aria-checked={seedOptions.mode === 'merge'} />
                    <Label htmlFor="merge">Mesclar</Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="billing"
                  checked={seedOptions.withBilling}
                  onCheckedChange={(checked) => setSeedOptions({...seedOptions, withBilling: checked})}
                />
                <Label htmlFor="billing">Incluir Faturamento</Label>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowSeedDialog(false)} disabled={seedMutation.isPending}>
              Cancelar
            </Button>
            {!seedProgress && (
              <Button
                onClick={() => seedMutation.mutate(seedOptions)}
                disabled={seedMutation.isPending}
                className="bg-green-600 hover:bg-green-700 text-white"
              >
                <Beaker className="w-4 h-4 mr-2" />
                Iniciar
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog Quick Seed */}
      <Dialog open={showQuickSeedDialog} onOpenChange={setShowQuickSeedDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-blue-900">
              <Beaker className="w-5 h-5" />
              Criar Dados Rápido
            </DialogTitle>
            <DialogDescription>
              Gera dados de avaliação e financeiro usando colaboradores e empresas existentes
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <Alert className="bg-blue-50 border-blue-200">
              <AlertDescription className="text-sm text-blue-900">
                <strong>✓ Criará:</strong>
                <ul className="list-disc list-inside mt-2 space-y-1">
                  <li>Até 20 avaliações completas (PRIMA-EF, PHQ-9, GAD-7) para colaboradores existentes.</li>
                  <li>Faturas para todas as consultorias existentes no mês atual.</li>
                  <li>Pagamentos para as faturas marcadas como 'PAGA'.</li>
                </ul>
                <p className="mt-2 text-xs">⚠️ Requer que existam ao menos 1 Consultoria, 1 Empresa e 1 Colaborador.</p>
                <p className="mt-1 text-xs">⏱️ Tempo estimado: ~30 segundos</p>
              </AlertDescription>
            </Alert>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowQuickSeedDialog(false)} disabled={quickSeedMutation.isPending}>
              Cancelar
            </Button>
            <Button
              onClick={() => quickSeedMutation.mutate()}
              disabled={quickSeedMutation.isPending}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              {quickSeedMutation.isPending ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Criando...
                </>
              ) : (
                <>
                  <Beaker className="w-4 h-4 mr-2" />
                  Criar Agora
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showResetDialog} onOpenChange={setShowResetDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-900">
              <AlertTriangle className="w-5 h-5" />
              Confirmar Reset
            </DialogTitle>
            <DialogDescription>
              Esta ação apagará permanentemente todos os dados
            </DialogDescription>
          </DialogHeader>

          <Alert className="bg-red-50 border-red-200">
            <AlertDescription className="text-red-900 text-sm">
              Todos os dados serão removidos permanentemente
            </AlertDescription>
          </Alert>

          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Checkbox
                id="backup"
                checked={resetOptions.createBackup}
                onCheckedChange={(checked) => setResetOptions({...resetOptions, createBackup: checked})}
              />
              <Label htmlFor="backup">Criar backup antes</Label>
            </div>

            <div className="flex items-center gap-2">
              <Checkbox
                id="confirm"
                checked={resetOptions.confirmed}
                onCheckedChange={(checked) => setResetOptions({...resetOptions, confirmed: checked})}
              />
              <Label htmlFor="confirm" className="font-semibold text-red-900">
                Entendo que esta ação não pode ser desfeita
              </Label>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowResetDialog(false)}>
              Cancelar
            </Button>
            <Button
              variant="destructive"
              onClick={() => resetMutation.mutate(resetOptions)}
              disabled={!resetOptions.confirmed || resetMutation.isPending}
            >
              {resetMutation.isPending ? 'Executando...' : 'Confirmar Reset'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
