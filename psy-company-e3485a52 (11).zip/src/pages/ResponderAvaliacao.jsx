
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import WelcomeScreen from "../components/responder-avaliacao/WelcomeScreen";
import ConsentScreen from "../components/responder-avaliacao/ConsentScreen";
import QuestionScreen from "../components/responder-avaliacao/QuestionScreen";
import SummaryScreen from "../components/responder-avaliacao/SummaryScreen";
import FeedbackConclusao from "../components/responder-avaliacao/FeedbackConclusao"; // Changed import from ThankYouScreen to FeedbackConclusao
// PHQ9ResultScreen and ThankYouScreen are no longer needed
import { AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

const QUESTIONS = {
  'PHQ-9': [
    { id: 'q1', text: 'Pouco interesse ou prazer em fazer as coisas', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]},
    { id: 'q2', text: 'Sentir-se para baixo, deprimido ou sem esperança', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]},
    { id: 'q3', text: 'Problemas para adormecer, manter o sono ou dormir demais', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]},
    { id: 'q4', text: 'Sentir-se cansado ou com pouca energia', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]},
    { id: 'q5', text: 'Falta de apetite ou comer em excesso', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]},
    { id: 'q6', text: 'Sentir-se mal consigo mesmo, sentir-se fracassado ou ter decepcionado sua família', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]},
    { id: 'q7', text: 'Dificuldade de concentração em tarefas cotidianas, como ler ou assistir TV', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]},
    { id: 'q8', text: 'Mover-se ou falar tão devagar que outras pessoas percebem, ou estar tão agitado que não consegue ficar parado', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]},
    { id: 'q9', text: 'Pensamentos de que seria melhor estar morto ou de se machucar', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]}
  ],
  'GAD-7': [
    { id: 'q1', text: 'Sentir-se nervoso, ansioso ou tenso', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]},
    { id: 'q2', text: 'Não conseguir parar de se preocupar', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]},
    { id: 'q3', text: 'Preocupar-se demais com diferentes coisas', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]},
    { id: 'q4', text: 'Dificuldade para relaxar', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]},
    { id: 'q5', text: 'Ficar tão inquieto que é difícil permanecer parado', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]},
    { id: 'q6', text: 'Irritar-se ou perder a paciência facilmente', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]},
    { id: 'q7', text: 'Sentir medo como se algo terrível pudesse acontecer', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]}
  ],
  'PRIMA-EF': [
    { id: 'q1', text: 'As tarefas que realizo são variadas e evitam a monotonia', category: 'A. Teor do Trabalho', scale: [
      { value: 1, label: 'Discordo totalmente' },
      { value: 2, label: 'Discordo' },
      { value: 3, label: 'Neutro' },
      { value: 4, label: 'Concordo' },
      { value: 5, label: 'Concordo totalmente' }
    ]},
    { id: 'q2', text: 'Meu trabalho é significativo e utiliza minhas habilidades', category: 'A. Teor do Trabalho', scale: [
      { value: 1, label: 'Discordo totalmente' },
      { value: 2, label: 'Discordo' },
      { value: 3, label: 'Neutro' },
      { value: 4, label: 'Concordo' },
      { value: 5, label: 'Concordo totalmente' }
    ]},
    { id: 'q3', text: 'O ambiente de trabalho me protege de exposição contínua a situações estressantes', category: 'A. Teor do Trabalho', scale: [
      { value: 1, label: 'Discordo totalmente' },
      { value: 2, label: 'Discordo' },
      { value: 3, label: 'Neutro' },
      { value: 4, label: 'Concordo' },
      { value: 5, label: 'Concordo totalmente' }
    ]},
    { id: 'q4', text: 'Tenho autonomia para decidir como realizar minhas tarefas', category: 'B. Autonomia e Controle', scale: [
      { value: 1, label: 'Discordo totalmente' },
      { value: 2, label: 'Discordo' },
      { value: 3, label: 'Neutro' },
      { value: 4, label: 'Concordo' },
      { value: 5, label: 'Concordo totalmente' }
    ]},
    { id: 'q5', text: 'Posso influenciar as decisões que afetam meu trabalho', category: 'B. Autonomia e Controle', scale: [
      { value: 1, label: 'Discordo totalmente' },
      { value: 2, label: 'Discordo' },
      { value: 3, label: 'Neutro' },
      { value: 4, label: 'Concordo' },
      { value: 5, label: 'Concordo totalmente' }
    ]},
    // ... adicionar todas as 24 perguntas do PRIMA-EF
  ]
};

// Meta tag para indicar que esta página é pública
export const pageConfig = {
  requireAuth: false,
  isPublic: true
};

export default function ResponderAvaliacaoPage() {
  const navigate = useNavigate();

  const [step, setStep] = useState('loading');
  const [assessment, setAssessment] = useState(null);
  const [employee, setEmployee] = useState(null);
  const [company, setCompany] = useState(null);
  const [questionnaires, setQuestionnaires] = useState([]);
  const [currentQuestionnaireIndex, setCurrentQuestionnaireIndex] = useState(0);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [responses, setResponses] = useState({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  // Removed phq9Score state as it's no longer used for an intermediate screen
  const [hasQuestion9Risk, setHasQuestion9Risk] = useState(false);

  useEffect(() => {
    loadAssessment();
  }, []);

  const loadAssessment = async () => {
    setStep('loading');
    setLoading(true);

    try {
      // Pegar ID da URL usando URLSearchParams
      const urlParams = new URLSearchParams(window.location.search);
      const assessmentId = urlParams.get('id');

      if (!assessmentId) {
        setError('ID da avaliação não encontrado.');
        setStep('error');
        return;
      }

      // Verificar sessão
      const stored = localStorage.getItem('collab_session');
      if (!stored) {
        window.location.href = createPageUrl('Responder');
        return;
      }

      const session = JSON.parse(stored);
      if (session.exp < Date.now()) {
        localStorage.removeItem('collab_session');
        window.location.href = createPageUrl('Responder');
        return;
      }

      // Carregar avaliação
      const assessments = await base44.entities.Assessment.filter({ id: assessmentId });
      
      if (assessments.length === 0) {
        setError('Avaliação não encontrada.');
        setStep('error');
        return;
      }

      const ass = assessments[0];

      // Verificar se pertence ao colaborador da sessão
      if (ass.employee_id !== session.employee_id) {
        setError('Você não tem permissão para acessar esta avaliação.');
        setStep('error');
        return;
      }

      // Verificar se já foi concluída
      if (ass.completed_at) {
        setError('Esta avaliação já foi concluída.');
        setStep('error');
        return;
      }

      setAssessment(ass);

      // Carregar dados do colaborador e empresa
      const empData = await base44.entities.Employee.filter({ id: ass.employee_id });
      if (empData.length > 0) setEmployee(empData[0]);

      const compData = await base44.entities.Company.filter({ id: ass.company_id });
      if (compData.length > 0) setCompany(compData[0]);

      // Parse questionários
      const types = ass.assessment_type.split(',');
      setQuestionnaires(types);

      // Carregar respostas salvas
      const savedResponses = {};
      types.forEach(type => {
        if (type === 'PHQ-9' && ass.phq9_responses) {
          Object.assign(savedResponses, ass.phq9_responses);
        }
        if (type === 'GAD-7' && ass.gad7_responses) {
          Object.assign(savedResponses, ass.gad7_responses);
        }
        if (type === 'PRIMA-EF' && ass.prima_responses) {
          Object.assign(savedResponses, ass.prima_responses);
        }
      });
      setResponses(savedResponses);

      // Decidir etapa inicial
      if (!ass.term_accepted) {
        setStep('welcome');
      } else if (Object.keys(savedResponses).length === 0) {
        setStep('welcome');
      } else {
        // Encontrar última pergunta respondida
        let lastQuestIndex = 0;
        let lastQuestionIndex = 0;
        
        for (let qi = 0; qi < types.length; qi++) {
          const questions = QUESTIONS[types[qi]] || [];
          for (let i = 0; i < questions.length; i++) {
            const qId = `${types[qi]}_${questions[i].id}`;
            if (savedResponses[qId] !== undefined) {
              lastQuestIndex = qi;
              lastQuestionIndex = i + 1;
            }
          }
        }

        setCurrentQuestionnaireIndex(lastQuestIndex);
        setCurrentQuestionIndex(lastQuestionIndex);
        
        // Se todas as perguntas foram respondidas, ir para summary
        const totalQuestions = types.reduce((sum, t) => sum + (QUESTIONS[t]?.length || 0), 0);
        if (Object.keys(savedResponses).length >= totalQuestions) {
          setStep('summary');
        } else {
          setStep('questions');
        }
      }

      setLoading(false);
    } catch (err) {
      console.error('Error loading assessment:', err);
      setError('Erro ao carregar avaliação.');
      setStep('error');
      setLoading(false);
    }
  };

  const handleStartFromWelcome = () => {
    if (!assessment.term_accepted) {
      setStep('consent');
    } else {
      setStep('questions');
    }
  };

  const handleConsentAccept = async () => {
    try {
      setLoading(true);
      await base44.entities.Assessment.update(assessment.id, {
        term_accepted: true,
        term_accepted_at: new Date().toISOString()
      });
      setAssessment(prev => ({ ...prev, term_accepted: true }));
      setStep('questions');
    } catch (err) {
      console.error('Error accepting consent:', err);
      setError('Erro ao registrar aceite.');
    } finally {
      setLoading(false);
    }
  };

  const handleAnswerQuestion = async (answer) => {
    const questionnaireType = questionnaires[currentQuestionnaireIndex];
    const questions = QUESTIONS[questionnaireType] || [];
    const question = questions[currentQuestionIndex];
    
    const qId = `${questionnaireType}_${question.id}`;
    
    const newResponses = {
      ...responses,
      [qId]: answer
    };
    setResponses(newResponses);

    // Verificar risco na pergunta 9 do PHQ-9
    if (questionnaireType === 'PHQ-9' && question.id === 'q9' && answer > 0) {
      setHasQuestion9Risk(true);
    }

    // Autosave
    try {
      const updateData = {};
      
      if (questionnaireType === 'PHQ-9') {
        const phq9Responses = {};
        Object.keys(newResponses).forEach(key => {
          if (key.startsWith('PHQ-9_')) {
            phq9Responses[key.replace('PHQ-9_', '')] = newResponses[key];
          }
        });
        updateData.phq9_responses = phq9Responses;
      } else if (questionnaireType === 'GAD-7') {
        const gad7Responses = {};
        Object.keys(newResponses).forEach(key => {
          if (key.startsWith('GAD-7_')) {
            gad7Responses[key.replace('GAD-7_', '')] = newResponses[key];
          }
        });
        updateData.gad7_responses = gad7Responses;
      } else if (questionnaireType === 'PRIMA-EF') {
        const primaResponses = {};
        Object.keys(newResponses).forEach(key => {
          if (key.startsWith('PRIMA-EF_')) {
            primaResponses[key.replace('PRIMA-EF_', '')] = newResponses[key];
          }
        });
        updateData.prima_responses = primaResponses;
      }

      await base44.entities.Assessment.update(assessment.id, updateData);
    } catch (err) {
      console.error('Error autosaving:', err);
    }

    // Avançar para próxima pergunta
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      // Fim do questionário atual
      if (currentQuestionnaireIndex < questionnaires.length - 1) {
        // Próximo questionário
        setCurrentQuestionnaireIndex(prev => prev + 1);
        setCurrentQuestionIndex(0);
      } else {
        // Última pergunta de todos os questionários - ir para resumo
        setStep('summary');
      }
    }
  };

  // handleContinueFromPHQ9Result function removed as PHQ9ResultScreen is no longer part of the flow

  const handlePreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    } else if (currentQuestionnaireIndex > 0) {
      setCurrentQuestionnaireIndex(prev => prev - 1);
      const prevQuestionnaire = questionnaires[currentQuestionnaireIndex - 1];
      const prevQuestions = QUESTIONS[prevQuestionnaire] || [];
      setCurrentQuestionIndex(prevQuestions.length - 1);
    }
  };

  const handleSubmitFinal = async () => {
    setLoading(true);
    try {
      const updateData = {
        completed_at: new Date().toISOString(),
      };

      questionnaires.forEach(type => {
        const questionnaireResponses = {};
        Object.keys(responses).forEach(key => {
          if (key.startsWith(`${type}_`)) {
            const qId = key.replace(`${type}_`, '');
            questionnaireResponses[qId] = responses[key];
          }
        });

        if (type === 'PHQ-9') {
          updateData.phq9_responses = questionnaireResponses;
          const score = Object.values(questionnaireResponses).reduce((a, b) => a + b, 0);
          updateData.phq9_score = score;
          updateData.phq9_classification = 
            score <= 4 ? 'Mínimo' :
            score <= 9 ? 'Leve' :
            score <= 14 ? 'Moderado' :
            score <= 19 ? 'Moderado-Grave' : 'Grave';
          
          // Salvar flag de risco (apenas para profissionais)
          if (hasQuestion9Risk) {
            updateData.has_suicide_risk = true;
          }
        } else if (type === 'GAD-7') {
          updateData.gad7_responses = questionnaireResponses;
          const score = Object.values(questionnaireResponses).reduce((a, b) => a + b, 0);
          updateData.gad7_score = score;
          updateData.gad7_classification = 
            score <= 4 ? 'Mínimo' :
            score <= 9 ? 'Leve' :
            score <= 14 ? 'Moderado' : 'Grave';
        } else if (type === 'PRIMA-EF') {
          updateData.prima_responses = questionnaireResponses;
          const values = Object.values(questionnaireResponses);
          const avg = values.reduce((a, b) => a + b, 0) / values.length;
          updateData.prima_score = avg;
          updateData.prima_classification = 
            avg >= 3.5 ? 'Alto' :
            avg >= 2.5 ? 'Moderado' : 'Baixo';
        }
      });

      await base44.entities.Assessment.update(assessment.id, updateData);

      setStep('thankyou');
    } catch (err) {
      console.error('Error submitting:', err);
      setError('Erro ao enviar respostas.');
    } finally {
      setLoading(false);
    }
  };

  const getTotalQuestions = () => {
    return questionnaires.reduce((total, type) => {
      return total + (QUESTIONS[type]?.length || 0);
    }, 0);
  };

  const getCurrentQuestionNumber = () => {
    let count = 0;
    for (let i = 0; i < currentQuestionnaireIndex; i++) {
      count += (QUESTIONS[questionnaires[i]]?.length || 0);
    }
    return count + currentQuestionIndex + 1;
  };

  const getProgress = () => {
    return (getCurrentQuestionNumber() / getTotalQuestions()) * 100;
  };

  if (step === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-gray-100">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Carregando avaliação...</p>
        </div>
      </div>
    );
  }

  if (step === 'error') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-gray-100 p-4">
        <Card className="max-w-md w-full">
          <CardContent className="p-8 text-center">
            <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Ops!</h2>
            <p className="text-gray-600 mb-6">{error}</p>
            <Button onClick={() => navigate(createPageUrl('ColaboradorAvaliacoes'))} variant="outline">
              Voltar para Minhas Avaliações
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (step === 'welcome') {
    return (
      <WelcomeScreen
        assessment={assessment}
        questionnaires={questionnaires}
        company={company}
        onStart={handleStartFromWelcome}
      />
    );
  }

  if (step === 'consent') {
    return (
      <ConsentScreen
        company={company}
        onAccept={handleConsentAccept}
        onDecline={() => navigate(createPageUrl('ColaboradorAvaliacoes'))}
        loading={loading}
      />
    );
  }

  if (step === 'questions') {
    const questionnaireType = questionnaires[currentQuestionnaireIndex];
    const questions = QUESTIONS[questionnaireType] || [];
    const question = questions[currentQuestionIndex];

    return (
      <QuestionScreen
        question={question}
        questionnaire={questionnaireType}
        currentQuestion={getCurrentQuestionNumber()}
        totalQuestions={getTotalQuestions()}
        progress={getProgress()}
        onAnswer={handleAnswerQuestion}
        onPrevious={handlePreviousQuestion}
        canGoPrevious={currentQuestionIndex > 0 || currentQuestionnaireIndex > 0}
        assessmentName={assessment.assessment_name}
      />
    );
  }

  // Removed if (step === 'phq9_result') block

  if (step === 'summary') {
    return (
      <SummaryScreen
        assessment={assessment}
        questionnaires={questionnaires}
        onSubmit={handleSubmitFinal}
        onGoBack={() => {
          // Voltar para última pergunta
          const lastQuestIndex = questionnaires.length - 1;
          const lastQuestions = QUESTIONS[questionnaires[lastQuestIndex]] || [];
          setCurrentQuestionnaireIndex(lastQuestIndex);
          setCurrentQuestionIndex(lastQuestions.length - 1);
          setStep('questions');
        }}
        loading={loading}
      />
    );
  }

  if (step === 'thankyou') {
    return (
      <FeedbackConclusao // Changed from ThankYouScreen to FeedbackConclusao
        company={company}
        hasQuestion9Risk={hasQuestion9Risk} // Passed the new prop
        onReturn={() => navigate(createPageUrl('ColaboradorAvaliacoes'))} // Changed prop name to onReturn
      />
    );
  }

  return null;
}

// Exportar configuração para o base44 saber que é pública
ResponderAvaliacaoPage.isPublic = true;
