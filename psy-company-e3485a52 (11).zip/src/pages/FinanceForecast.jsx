import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Navigate } from "react-router-dom";
import FinancePageLayout from "../components/finance/FinancePageLayout";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import { toast } from "sonner";

export default function FinanceForecast() {
  const [user, setUser] = React.useState(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  if (!user || (user.user_role !== 'admin' && user.user_role !== 'consultoria')) {
    return <Navigate to="/dashboard" />;
  }

  return (
    <FinancePageLayout
      currentPage="FinanceForecast"
      userRole={user.user_role}
      title="Previsões (Forecast)"
      subtitle="Projeção de receitas e fluxo de caixa"
      actions={
        <Button variant="outline" onClick={() => toast.info('Exportação em desenvolvimento')}>
          <Download className="w-4 h-4 mr-2" />
          Exportar
        </Button>
      }
    >
      <div className="bg-white rounded-xl p-8 shadow-md text-center">
        <p className="text-gray-500 mb-4">Módulo de Previsões em desenvolvimento</p>
        <p className="text-sm text-gray-400">
          Em breve: forecast 3/6/12 meses, projeção de fluxo, análise de riscos
        </p>
      </div>
    </FinancePageLayout>
  );
}