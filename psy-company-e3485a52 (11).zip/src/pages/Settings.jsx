import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Navigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Palette, Mail, Shield, Bell, AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { toast } from "sonner";
import PageHeader from "../components/common/PageHeader";
import { getEffectiveContext } from "../components/utils/impersonationContext";

export default function Settings() {
  const [user, setUser] = React.useState(null);
  const [context, setContext] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const queryClient = useQueryClient();

  const [personalData, setPersonalData] = React.useState({
    color_primary: '#4B2672',
    color_secondary: '#FFD84D',
    email_sender_name: '',
    logo_light: '',
    logo_dark: ''
  });

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
        
        const effectiveContext = getEffectiveContext(userData);
        setContext(effectiveContext);
        
        console.log('=== Settings Page ===');
        console.log('Context:', effectiveContext);
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  const { data: consultoria } = useQuery({
    queryKey: ['consultoria-settings', context?.consultoria_id],
    queryFn: async () => {
      if (!context?.consultoria_id) return null;
      const consultorias = await base44.entities.Consultoria.filter({ id: context.consultoria_id });
      return consultorias[0] || null;
    },
    enabled: !!context?.consultoria_id,
  });

  React.useEffect(() => {
    if (consultoria) {
      setPersonalData({
        color_primary: consultoria.color_primary || '#4B2672',
        color_secondary: consultoria.color_secondary || '#FFD84D',
        email_sender_name: consultoria.email_sender_name || '',
        logo_light: consultoria.logo_light || '',
        logo_dark: consultoria.logo_dark || ''
      });
    }
  }, [consultoria]);

  const updateMutation = useMutation({
    mutationFn: (data) => {
      if (!context?.consultoria_id) throw new Error('Consultoria não identificada');
      return base44.entities.Consultoria.update(context.consultoria_id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['consultoria-settings'] });
      toast.success('Configurações atualizadas com sucesso!');
    },
    onError: (error) => {
      toast.error('Erro ao atualizar: ' + error.message);
    },
  });

  const handleSavePersonalization = () => {
    updateMutation.mutate(personalData);
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  if (!user || !context) {
    return <Navigate to="/" />;
  }

  if (!context.consultoria_id) {
    return (
      <div className="p-8">
        <Alert className="border-yellow-200 bg-yellow-50">
          <AlertCircle className="h-4 w-4 text-yellow-600" />
          <AlertDescription className="text-yellow-800">
            Selecione uma consultoria para acessar as configurações.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 min-h-screen" style={{ backgroundColor: '#F8F6FB' }}>
      <PageHeader
        title="Configurações"
        description={`Gerencie as configurações de ${consultoria?.nome_fantasia || 'sua consultoria'}`}
      />

      <Tabs defaultValue="personalizacao" className="mt-6">
        <TabsList className="grid w-full grid-cols-4 max-w-2xl">
          <TabsTrigger value="personalizacao">
            <Palette className="w-4 h-4 mr-2" />
            Personalização
          </TabsTrigger>
          <TabsTrigger value="email">
            <Mail className="w-4 h-4 mr-2" />
            E-mails
          </TabsTrigger>
          <TabsTrigger value="notificacoes">
            <Bell className="w-4 h-4 mr-2" />
            Notificações
          </TabsTrigger>
          <TabsTrigger value="seguranca">
            <Shield className="w-4 h-4 mr-2" />
            Segurança
          </TabsTrigger>
        </TabsList>

        <TabsContent value="personalizacao" className="mt-6">
          <Card className="shadow-md">
            <CardHeader>
              <CardTitle>Personalização Visual</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="color_primary">Cor Primária</Label>
                  <div className="flex gap-2 mt-1">
                    <Input
                      id="color_primary"
                      type="color"
                      value={personalData.color_primary}
                      onChange={(e) => setPersonalData({...personalData, color_primary: e.target.value})}
                      className="w-20 h-10"
                    />
                    <Input
                      value={personalData.color_primary}
                      onChange={(e) => setPersonalData({...personalData, color_primary: e.target.value})}
                      placeholder="#4B2672"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="color_secondary">Cor Secundária</Label>
                  <div className="flex gap-2 mt-1">
                    <Input
                      id="color_secondary"
                      type="color"
                      value={personalData.color_secondary}
                      onChange={(e) => setPersonalData({...personalData, color_secondary: e.target.value})}
                      className="w-20 h-10"
                    />
                    <Input
                      value={personalData.color_secondary}
                      onChange={(e) => setPersonalData({...personalData, color_secondary: e.target.value})}
                      placeholder="#FFD84D"
                    />
                  </div>
                </div>

                <div className="md:col-span-2">
                  <Label htmlFor="email_sender_name">Nome do Remetente (E-mails)</Label>
                  <Input
                    id="email_sender_name"
                    value={personalData.email_sender_name}
                    onChange={(e) => setPersonalData({...personalData, email_sender_name: e.target.value})}
                    placeholder={consultoria?.nome_fantasia || 'Nome da Consultoria'}
                    className="mt-1"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t">
                <Button
                  onClick={handleSavePersonalization}
                  disabled={updateMutation.isPending}
                  className="text-white"
                  style={{ backgroundColor: '#4B2672' }}
                >
                  {updateMutation.isPending ? 'Salvando...' : 'Salvar Alterações'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="email" className="mt-6">
          <Card className="shadow-md">
            <CardHeader>
              <CardTitle>Configurações de E-mail</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-500">
                Configure preferências de envio de e-mails e notificações.
              </p>
              <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                <p className="text-sm text-blue-800">
                  💡 Em breve você poderá configurar templates de e-mail personalizados.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notificacoes" className="mt-6">
          <Card className="shadow-md">
            <CardHeader>
              <CardTitle>Preferências de Notificações</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-500">
                Gerencie quais notificações você deseja receber.
              </p>
              <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                <p className="text-sm text-blue-800">
                  💡 Em breve você poderá configurar preferências de notificações.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="seguranca" className="mt-6">
          <Card className="shadow-md">
            <CardHeader>
              <CardTitle>Configurações de Segurança</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-500">
                Configurações de senha e autenticação.
              </p>
              <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                <p className="text-sm text-blue-800">
                  💡 Em breve você poderá alterar sua senha e configurar autenticação de dois fatores.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}