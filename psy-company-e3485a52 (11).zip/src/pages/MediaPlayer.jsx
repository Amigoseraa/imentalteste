import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { 
  ArrowLeft, 
  Star, 
  CheckCircle,
  Clock,
  Eye,
  MessageSquare,
  ThumbsUp,
  FileText,
  ExternalLink
} from "lucide-react";
import { toast } from "sonner";

export default function MediaPlayer() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState("");
  const [progress, setProgress] = useState(0);
  const progressIntervalRef = useRef(null);
  
  const urlParams = new URLSearchParams(window.location.search);
  const mediaId = urlParams.get('id');

  useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadUser();
  }, []);

  // Buscar mídia
  const { data: mediaItem } = useQuery({
    queryKey: ['media-item-player', mediaId],
    queryFn: async () => {
      const items = await base44.entities.MediaItem.filter({ id: mediaId });
      return items[0];
    },
    enabled: !!mediaId,
  });

  // Buscar progresso do usuário
  const { data: userProgress } = useQuery({
    queryKey: ['media-progress-user', mediaId, user?.email],
    queryFn: async () => {
      const progressList = await base44.entities.MediaProgress.filter({
        media_id: mediaId,
        user_id: user?.email
      });
      return progressList[0];
    },
    enabled: !!mediaId && !!user,
  });

  // Buscar feedback do usuário
  const { data: userFeedback } = useQuery({
    queryKey: ['media-feedback-user', mediaId, user?.email],
    queryFn: async () => {
      const feedbacks = await base44.entities.MediaFeedback.filter({
        media_id: mediaId,
        user_id: user?.email
      });
      return feedbacks[0];
    },
    enabled: !!mediaId && !!user,
  });

  // Buscar todos os comentários aprovados
  const { data: comments = [] } = useQuery({
    queryKey: ['media-comments', mediaId],
    queryFn: () => base44.entities.MediaFeedback.filter({
      media_id: mediaId,
      status: 'approved'
    }),
    enabled: !!mediaId,
    initialData: [],
  });

  // Buscar conteúdos relacionados
  const { data: relatedMedia = [] } = useQuery({
    queryKey: ['media-related', mediaItem?.categories],
    queryFn: async () => {
      if (!mediaItem?.categories || mediaItem.categories.length === 0) return [];
      
      const allMedia = await base44.entities.MediaItem.filter({ status: 'published' });
      return allMedia.filter(item => 
        item.id !== mediaId && 
        item.categories?.some(cat => mediaItem.categories.includes(cat))
      ).slice(0, 6);
    },
    enabled: !!mediaItem,
    initialData: [],
  });

  // Atualizar progresso
  const updateProgressMutation = useMutation({
    mutationFn: async (newProgress) => {
      if (!user) return;
      
      if (userProgress) {
        return base44.entities.MediaProgress.update(userProgress.id, {
          progress: newProgress,
          last_position_sec: 0,
          completed_at: newProgress >= 100 ? new Date().toISOString() : null
        });
      } else {
        return base44.entities.MediaProgress.create({
          media_id: mediaId,
          user_id: user.email,
          company_id: user.company_id,
          consultoria_id: user.consultoria_id,
          progress: newProgress,
          started_at: new Date().toISOString(),
          completed_at: newProgress >= 100 ? new Date().toISOString() : null
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['media-progress-user', mediaId, user?.email] });
    }
  });

  // Incrementar view count
  const incrementViewMutation = useMutation({
    mutationFn: () => base44.entities.MediaItem.update(mediaId, {
      view_count: (mediaItem?.view_count || 0) + 1
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['media-item-player', mediaId] });
    }
  });

  // Enviar avaliação
  const submitFeedbackMutation = useMutation({
    mutationFn: async ({ rating: newRating, comment: newComment }) => {
      if (userFeedback) {
        return base44.entities.MediaFeedback.update(userFeedback.id, {
          rating: newRating,
          comment: newComment,
          status: 'pending'
        });
      } else {
        return base44.entities.MediaFeedback.create({
          media_id: mediaId,
          user_id: user.email,
          user_name: user.full_name,
          company_id: user.company_id,
          consultoria_id: user.consultoria_id,
          rating: newRating,
          comment: newComment,
          status: 'pending'
        });
      }
    },
    onSuccess: () => {
      toast.success("Avaliação enviada! Aguardando moderação.");
      setComment("");
      queryClient.invalidateQueries({ queryKey: ['media-feedback-user', mediaId, user?.email] });
    }
  });

  // Incrementar view ao carregar
  useEffect(() => {
    if (mediaItem && user) {
      incrementViewMutation.mutate();
    }
  }, [mediaItem?.id, user?.id]);

  // Carregar progresso inicial
  useEffect(() => {
    if (userProgress) {
      setProgress(userProgress.progress || 0);
    }
  }, [userProgress]);

  // Carregar rating inicial
  useEffect(() => {
    if (userFeedback) {
      setRating(userFeedback.rating || 0);
    }
  }, [userFeedback]);

  // Simular atualização de progresso para vídeos
  useEffect(() => {
    if (mediaItem?.type === 'video' && progress < 100) {
      progressIntervalRef.current = setInterval(() => {
        setProgress(prev => {
          const newProgress = Math.min(prev + 1, 100);
          if (newProgress >= 100) {
            clearInterval(progressIntervalRef.current);
            updateProgressMutation.mutate(100);
          } else if (newProgress % 10 === 0) {
            // Salvar a cada 10%
            updateProgressMutation.mutate(newProgress);
          }
          return newProgress;
        });
      }, (mediaItem.duration_sec || 600) * 10); // Dividir duração em 100 partes
    }

    return () => {
      if (progressIntervalRef.current) {
        clearInterval(progressIntervalRef.current);
      }
    };
  }, [mediaItem?.type, mediaItem?.duration_sec]);

  const handleMarkComplete = () => {
    setProgress(100);
    updateProgressMutation.mutate(100);
    toast.success("Marcado como concluído!");
  };

  const handleSubmitFeedback = () => {
    if (rating === 0) {
      toast.error("Selecione uma avaliação");
      return;
    }
    submitFeedbackMutation.mutate({ rating, comment });
  };

  // Extrair ID do Vimeo da URL
  const getVimeoEmbedUrl = (url) => {
    if (!url) return null;
    
    // Exemplo: https://vimeo.com/1107764573/ebe277b06b?fl=ip&fe=ec
    const match = url.match(/vimeo\.com\/(\d+)/);
    if (match) {
      const videoId = match[1];
      // Extrair hash se existir
      const hashMatch = url.match(/\/([a-f0-9]+)\?/);
      const hash = hashMatch ? `?h=${hashMatch[1]}` : '';
      return `https://player.vimeo.com/video/${videoId}${hash}`;
    }
    return url;
  };

  if (!mediaItem) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#0F0F0F' }}>
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 mx-auto mb-4" style={{ borderColor: '#4B2672' }}></div>
          <p className="text-sm text-gray-400">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#0F0F0F' }}>
      {/* Header */}
      <div className="bg-black/50 backdrop-blur-sm p-4 border-b border-gray-800">
        <div className="max-w-7xl mx-auto flex items-center gap-4">
          <Button
            variant="ghost"
            onClick={() => navigate(-1)}
            className="text-white hover:bg-gray-800"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-white">{mediaItem.title}</h1>
            <div className="flex items-center gap-4 mt-1 text-sm text-gray-400">
              <span className="flex items-center gap-1">
                <Clock className="w-4 h-4" />
                {mediaItem.duration_sec ? `${Math.floor(mediaItem.duration_sec / 60)}min` : `${mediaItem.pages} páginas`}
              </span>
              <span className="flex items-center gap-1">
                <Eye className="w-4 h-4" />
                {mediaItem.view_count || 0} visualizações
              </span>
              {mediaItem.avg_rating > 0 && (
                <span className="flex items-center gap-1">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  {mediaItem.avg_rating.toFixed(1)}
                </span>
              )}
            </div>
          </div>
          {progress >= 100 && (
            <Badge className="bg-green-600 text-white">
              <CheckCircle className="w-4 h-4 mr-1" />
              Concluído
            </Badge>
          )}
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-4 md:p-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Player / Viewer */}
          <div className="lg:col-span-2 space-y-6">
            {mediaItem.type === 'video' ? (
              <div className="relative aspect-video bg-black rounded-lg overflow-hidden">
                <iframe
                  src={getVimeoEmbedUrl(mediaItem.provider_ref)}
                  className="w-full h-full"
                  frameBorder="0"
                  allow="autoplay; fullscreen; picture-in-picture"
                  allowFullScreen
                  title={mediaItem.title}
                />
                
                {/* Progress overlay */}
                {progress > 0 && progress < 100 && (
                  <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-800">
                    <div 
                      className="h-full bg-purple-600 transition-all"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                )}
              </div>
            ) : (
              <Card className="bg-gray-900 border-gray-800">
                <CardContent className="p-8 text-center">
                  <FileText className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-white mb-2">E-book Disponível</h3>
                  <p className="text-gray-400 mb-6">{mediaItem.pages} páginas</p>
                  <Button
                    onClick={() => window.open(mediaItem.file_url, '_blank')}
                    className="text-white"
                    style={{ backgroundColor: '#4B2672' }}
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Abrir PDF
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* Descrição */}
            <Card className="bg-gray-900 border-gray-800">
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold text-white mb-4">Sobre este conteúdo</h2>
                <p className="text-gray-300 leading-relaxed mb-4">
                  {mediaItem.description || "Sem descrição disponível."}
                </p>
                
                {/* Tags */}
                {mediaItem.tags && mediaItem.tags.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-4">
                    {mediaItem.tags.map((tag, idx) => (
                      <Badge key={idx} variant="secondary" className="bg-gray-800 text-gray-300">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                )}

                {/* Categorias */}
                {mediaItem.categories && mediaItem.categories.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {mediaItem.categories.map((cat, idx) => (
                      <Badge key={idx} className="bg-purple-900 text-purple-200">
                        {cat}
                      </Badge>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Avaliação */}
            <Card className="bg-gray-900 border-gray-800">
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold text-white mb-4">Sua Avaliação</h2>
                
                {/* Stars */}
                <div className="flex gap-2 mb-4">
                  {[1, 2, 3, 4, 5].map(star => (
                    <button
                      key={star}
                      onClick={() => setRating(star)}
                      onMouseEnter={() => setHoverRating(star)}
                      onMouseLeave={() => setHoverRating(0)}
                      className="transition-transform hover:scale-110"
                    >
                      <Star 
                        className={`w-8 h-8 ${
                          star <= (hoverRating || rating)
                            ? 'fill-yellow-400 text-yellow-400'
                            : 'text-gray-600'
                        }`}
                      />
                    </button>
                  ))}
                </div>

                {/* Comentário */}
                <Textarea
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  placeholder="Compartilhe sua opinião (opcional)..."
                  className="bg-gray-800 border-gray-700 text-white mb-4"
                  rows={3}
                />

                <Button
                  onClick={handleSubmitFeedback}
                  disabled={rating === 0 || submitFeedbackMutation.isPending}
                  className="w-full text-white"
                  style={{ backgroundColor: '#4B2672' }}
                >
                  <ThumbsUp className="w-4 h-4 mr-2" />
                  Enviar Avaliação
                </Button>
              </CardContent>
            </Card>

            {/* Comentários */}
            {comments.length > 0 && (
              <Card className="bg-gray-900 border-gray-800">
                <CardContent className="p-6">
                  <h2 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
                    <MessageSquare className="w-5 h-5" />
                    Comentários ({comments.length})
                  </h2>
                  <div className="space-y-4">
                    {comments.map(feedback => (
                      <div key={feedback.id} className="border-b border-gray-800 pb-4 last:border-0">
                        <div className="flex items-start gap-3">
                          <div className="w-10 h-10 rounded-full bg-purple-600 flex items-center justify-center text-white font-semibold">
                            {feedback.user_name?.charAt(0) || 'U'}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-semibold text-white">{feedback.user_name}</span>
                              <div className="flex">
                                {[...Array(5)].map((_, i) => (
                                  <Star 
                                    key={i}
                                    className={`w-3 h-3 ${
                                      i < feedback.rating 
                                        ? 'fill-yellow-400 text-yellow-400' 
                                        : 'text-gray-600'
                                    }`}
                                  />
                                ))}
                              </div>
                            </div>
                            {feedback.comment && (
                              <p className="text-gray-300 text-sm">{feedback.comment}</p>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Ações */}
            <Card className="bg-gray-900 border-gray-800">
              <CardContent className="p-4 space-y-3">
                {progress < 100 && (
                  <Button
                    onClick={handleMarkComplete}
                    className="w-full text-white"
                    style={{ backgroundColor: '#4B2672' }}
                  >
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Marcar como Concluído
                  </Button>
                )}
              </CardContent>
            </Card>

            {/* Conteúdos Relacionados */}
            {relatedMedia.length > 0 && (
              <Card className="bg-gray-900 border-gray-800">
                <CardContent className="p-4">
                  <h3 className="text-lg font-semibold text-white mb-4">Relacionados</h3>
                  <div className="space-y-3">
                    {relatedMedia.map(item => (
                      <button
                        key={item.id}
                        onClick={() => navigate(`/MediaPlayer?id=${item.id}`)}
                        className="w-full flex gap-3 p-2 rounded-lg hover:bg-gray-800 transition-colors text-left"
                      >
                        <div className="w-24 aspect-video rounded overflow-hidden bg-gray-800 flex-shrink-0">
                          {item.cover_url ? (
                            <img src={item.cover_url} alt={item.title} className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center">
                              {item.type === 'video' ? (
                                <FileText className="w-6 h-6 text-gray-600" />
                              ) : (
                                <FileText className="w-6 h-6 text-gray-600" />
                              )}
                            </div>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="text-sm font-medium text-white line-clamp-2 mb-1">
                            {item.title}
                          </h4>
                          <div className="flex items-center gap-2 text-xs text-gray-400">
                            {item.duration_sec && (
                              <span>{Math.floor(item.duration_sec / 60)}min</span>
                            )}
                            {item.avg_rating > 0 && (
                              <span className="flex items-center gap-1">
                                <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                                {item.avg_rating.toFixed(1)}
                              </span>
                            )}
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}