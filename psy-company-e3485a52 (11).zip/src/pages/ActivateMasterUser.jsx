import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CheckCircle, XCircle, Loader2, Key } from "lucide-react";
import IMentalLogo from "../components/ui/IMentalLogo";

export default function ActivateMasterUser() {
  const [token, setToken] = useState("");
  const [loading, setLoading] = useState(true);
  const [activating, setActivating] = useState(false);
  const [consultoria, setConsultoria] = useState(null);
  const [masterData, setMasterData] = useState(null);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const tokenFromUrl = urlParams.get('token');
    
    console.log('=== ActivateMasterUser Page Loaded ===');
    console.log('URL:', window.location.href);
    console.log('Token from URL:', tokenFromUrl);
    
    if (tokenFromUrl) {
      setToken(tokenFromUrl);
      validateToken(tokenFromUrl);
    } else {
      setError('Token não fornecido na URL');
      setLoading(false);
    }
  }, []);

  const validateToken = async (tokenValue) => {
    try {
      setLoading(true);
      setError(null);

      console.log('🔍 Validando token:', tokenValue);

      const invites = await base44.entities.InviteToken.filter({
        token: tokenValue,
        status: 'pending'
      });

      console.log('Invites found:', invites);

      if (!invites || invites.length === 0) {
        setError('Token inválido ou já utilizado');
        setLoading(false);
        return;
      }

      const invite = invites[0];
      console.log('Invite:', invite);

      if (new Date(invite.expires_at) < new Date()) {
        setError('Token expirado');
        setLoading(false);
        return;
      }

      const consultorias = await base44.entities.Consultoria.filter({
        id: invite.consultoria_id
      });

      console.log('Consultorias found:', consultorias);

      if (!consultorias || consultorias.length === 0) {
        setError('Consultoria não encontrada');
        setLoading(false);
        return;
      }

      const consultoriaData = consultorias[0];
      console.log('Consultoria:', consultoriaData);
      console.log('Master user data:', consultoriaData.master_user_data);
      
      setConsultoria(consultoriaData);
      setMasterData(consultoriaData.master_user_data);
      
      if (consultoriaData.master_user_data?.senha_temp) {
        setPassword(consultoriaData.master_user_data.senha_temp);
        setConfirmPassword(consultoriaData.master_user_data.senha_temp);
      }

      setLoading(false);
    } catch (err) {
      console.error('Error validating token:', err);
      setError('Erro ao validar token: ' + err.message);
      setLoading(false);
    }
  };

  const handleActivate = async () => {
    try {
      setActivating(true);
      setError(null);

      console.log('=== Ativando conta ===');
      console.log('Email:', masterData.email);
      console.log('Password:', password ? '****' : 'empty');

      if (!password || password.length < 8) {
        setError('A senha deve ter no mínimo 8 caracteres');
        setActivating(false);
        return;
      }

      if (password !== confirmPassword) {
        setError('As senhas não coincidem');
        setActivating(false);
        return;
      }

      console.log('📝 Chamando base44.auth.register...');
      
      const registerResponse = await base44.auth.register({
        email: masterData.email,
        password: password,
        full_name: masterData.nome
      });

      console.log('Register response:', registerResponse);

      if (registerResponse) {
        console.log('✅ Usuário registrado com sucesso!');
        
        const invites = await base44.entities.InviteToken.filter({
          token: token,
          status: 'pending'
        });

        if (invites && invites.length > 0) {
          await base44.entities.InviteToken.update(invites[0].id, {
            status: 'accepted',
            accepted_at: new Date().toISOString()
          });
          console.log('✅ InviteToken marcado como aceito');
        }

        await base44.entities.Consultoria.update(consultoria.id, {
          master_user_data: {
            ...masterData,
            login_ativado: true,
            senha_temp: password,
            updated_at: new Date().toISOString()
          }
        });
        console.log('✅ Consultoria atualizada');

        setSuccess(true);

        setTimeout(() => {
          window.location.href = '/login';
        }, 3000);
      }
    } catch (err) {
      console.error('❌ Error activating:', err);
      console.error('Error details:', err.message);
      setError('Erro ao ativar conta: ' + err.message);
    } finally {
      setActivating(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#F8F6FB' }}>
        <Card className="w-full max-w-md">
          <CardContent className="pt-6">
            <div className="flex flex-col items-center gap-4">
              <Loader2 className="w-8 h-8 animate-spin" style={{ color: '#4B2672' }} />
              <p className="text-sm text-gray-600">Validando token...</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (error && !consultoria) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4" style={{ backgroundColor: '#F8F6FB' }}>
        <Card className="w-full max-w-md">
          <CardHeader>
            <div className="flex justify-center mb-4">
              <IMentalLogo size="large" />
            </div>
            <CardTitle className="text-center text-red-600 flex items-center justify-center gap-2">
              <XCircle className="w-6 h-6" />
              Erro na Ativação
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Alert className="bg-red-50 border-red-200">
              <AlertDescription className="text-red-800">
                {error}
              </AlertDescription>
            </Alert>
            <Button
              onClick={() => window.location.href = '/'}
              className="w-full mt-4"
              variant="outline"
            >
              Voltar ao Início
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4" style={{ backgroundColor: '#F8F6FB' }}>
        <Card className="w-full max-w-md">
          <CardHeader>
            <div className="flex justify-center mb-4">
              <IMentalLogo size="large" />
            </div>
            <CardTitle className="text-center text-green-600 flex items-center justify-center gap-2">
              <CheckCircle className="w-6 h-6" />
              Conta Ativada!
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Alert className="bg-green-50 border-green-200">
              <AlertDescription className="text-green-800">
                <p className="font-semibold mb-2">✅ Sua conta foi ativada com sucesso!</p>
                <p className="text-sm">Redirecionando para a página de login...</p>
              </AlertDescription>
            </Alert>
            <div className="mt-4 p-3 bg-gray-50 rounded-lg">
              <p className="text-xs text-gray-600 mb-2">Suas credenciais:</p>
              <p className="text-sm"><strong>Email:</strong> {masterData.email}</p>
              <p className="text-sm"><strong>Senha:</strong> {password}</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ backgroundColor: '#F8F6FB' }}>
      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="flex justify-center mb-4">
            <IMentalLogo size="large" />
          </div>
          <CardTitle className="text-center flex items-center justify-center gap-2" style={{ color: '#4B2672' }}>
            <Key className="w-6 h-6" />
            Ativar Conta Master
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert className="bg-blue-50 border-blue-200">
            <AlertDescription className="text-blue-900">
              <p className="font-semibold mb-1">Bem-vindo, {masterData?.nome}!</p>
              <p className="text-sm">
                Você está ativando sua conta como usuário master da consultoria <strong>{consultoria?.nome_fantasia}</strong>.
              </p>
            </AlertDescription>
          </Alert>

          {error && (
            <Alert className="bg-red-50 border-red-200">
              <AlertDescription className="text-red-800">
                {error}
              </AlertDescription>
            </Alert>
          )}

          <div className="space-y-3">
            <div>
              <Label>Email</Label>
              <Input
                type="email"
                value={masterData?.email || ''}
                disabled
                className="bg-gray-50"
              />
            </div>

            <div>
              <Label>Senha</Label>
              <Input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Defina sua senha"
              />
            </div>

            <div>
              <Label>Confirmar Senha</Label>
              <Input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Confirme sua senha"
              />
            </div>
          </div>

          <Button
            onClick={handleActivate}
            disabled={activating}
            className="w-full text-white"
            style={{ backgroundColor: '#4B2672' }}
          >
            {activating ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Ativando...
              </>
            ) : (
              'Ativar Conta'
            )}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}