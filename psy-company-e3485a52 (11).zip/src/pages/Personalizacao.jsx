import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Palette, Upload, RotateCcw, Sun, Moon, CheckCircle, Info } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { toast } from "sonner";

const PRESET_COLORS = [
  { name: 'iMental Roxo', primary: '#4B2672', secondary: '#FFD84D' },
  { name: 'Azul Corporativo', primary: '#1E40AF', secondary: '#3B82F6' },
  { name: 'Verde Sustentável', primary: '#065F46', secondary: '#10B981' },
  { name: 'Laranja Energia', primary: '#C2410C', secondary: '#F97316' },
  { name: 'Cinza Profissional', primary: '#374151', secondary: '#9CA3AF' },
];

export default function Personalizacao() {
  const [user, setUser] = React.useState(null);
  const [entityType, setEntityType] = useState(null); // 'consultoria' ou 'empresa'
  const [entityId, setEntityId] = useState(null);
  const [entity, setEntity] = useState(null);
  const [darkMode, setDarkMode] = useState(false);
  
  const [formData, setFormData] = useState({
    logo_light: '',
    logo_dark: '',
    favicon_url: '',
    color_primary: '#4B2672',
    color_secondary: '#FFD84D',
    modo_white_label: false,
    permite_personalizacao_empresas: true
  });

  const queryClient = useQueryClient();

  useEffect(() => {
    const loadUser = async () => {
      const userData = await base44.auth.me();
      setUser(userData);
    };
    loadUser();

    const urlParams = new URLSearchParams(window.location.search);
    const tipo = urlParams.get('tipo');
    const id = urlParams.get('id');
    
    setEntityType(tipo);
    setEntityId(id);
  }, []);

  useEffect(() => {
    const loadEntity = async () => {
      if (!entityId || !entityType) return;
      
      try {
        if (entityType === 'consultoria') {
          const data = await base44.entities.Consultoria.filter({ id: entityId });
          if (data[0]) {
            setEntity(data[0]);
            setFormData({
              logo_light: data[0].logo_light || '',
              logo_dark: data[0].logo_dark || '',
              favicon_url: data[0].favicon_url || '',
              color_primary: data[0].color_primary || '#4B2672',
              color_secondary: data[0].color_secondary || '#FFD84D',
              modo_white_label: data[0].modo_white_label || false,
              permite_personalizacao_empresas: data[0].permite_personalizacao_empresas !== false
            });
          }
        } else if (entityType === 'empresa') {
          const data = await base44.entities.Company.filter({ id: entityId });
          if (data[0]) {
            setEntity(data[0]);
            setFormData({
              logo_light: data[0].logo_light || '',
              logo_dark: data[0].logo_dark || '',
              favicon_url: data[0].favicon_url || '',
              color_primary: data[0].color_primary || '#4B2672',
              color_secondary: data[0].color_secondary || '#FFD84D',
            });
          }
        }
      } catch (error) {
        console.error('Error loading entity:', error);
      }
    };
    
    loadEntity();
  }, [entityId, entityType]);

  useEffect(() => {
    document.documentElement.style.setProperty('--color-primary', formData.color_primary);
    document.documentElement.style.setProperty('--color-secondary', formData.color_secondary);
  }, [formData.color_primary, formData.color_secondary]);

  const handleFileUpload = async (file, field) => {
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFormData({ ...formData, [field]: file_url });
      toast.success('Upload realizado com sucesso!');
    } catch (error) {
      toast.error('Erro ao fazer upload');
    }
  };

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      if (entityType === 'consultoria') {
        return await base44.entities.Consultoria.update(entityId, data);
      } else {
        return await base44.entities.Company.update(entityId, data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [entityType === 'consultoria' ? 'consultorias' : 'companies'] });
      toast.success('✅ Configurações salvas com sucesso!');
    },
  });

  const handleSave = () => {
    saveMutation.mutate(formData);
  };

  const handleReset = () => {
    setFormData({
      ...formData,
      color_primary: '#4B2672',
      color_secondary: '#FFD84D'
    });
    toast.success('Cores restauradas para o padrão iMental');
  };

  if (!entity) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 min-h-screen" style={{ backgroundColor: '#F8F6FB' }}>
      <div className="max-w-5xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3" style={{ color: '#2E2E2E' }}>
            <Palette className="w-8 h-8" style={{ color: '#4B2672' }} />
            Personalização da Identidade Visual
          </h1>
          <p className="text-gray-600 mt-2">
            Adapte a plataforma iMental à identidade visual da sua marca.
            Faça upload do seu logotipo, escolha suas cores e veja as alterações em tempo real.
          </p>
        </div>

        {/* Logos */}
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle>Logotipos</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <Label className="mb-2 block">Logo para fundo claro</Label>
                <div className="border-2 border-dashed rounded-lg p-6 text-center bg-white">
                  {formData.logo_light ? (
                    <div>
                      <img 
                        src={formData.logo_light} 
                        alt="Logo Light" 
                        className="max-h-20 mx-auto mb-3"
                      />
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => setFormData({...formData, logo_light: ''})}
                      >
                        Remover
                      </Button>
                    </div>
                  ) : (
                    <div>
                      <Upload className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                      <Input
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleFileUpload(e.target.files[0], 'logo_light')}
                        className="mt-2"
                      />
                    </div>
                  )}
                </div>
              </div>

              <div>
                <Label className="mb-2 block">Logo para fundo escuro</Label>
                <div className="border-2 border-dashed rounded-lg p-6 text-center" style={{ backgroundColor: '#2E2E2E' }}>
                  {formData.logo_dark ? (
                    <div>
                      <img 
                        src={formData.logo_dark} 
                        alt="Logo Dark" 
                        className="max-h-20 mx-auto mb-3"
                      />
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => setFormData({...formData, logo_dark: ''})}
                      >
                        Remover
                      </Button>
                    </div>
                  ) : (
                    <div>
                      <Upload className="w-8 h-8 mx-auto mb-2 text-white" />
                      <Input
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleFileUpload(e.target.files[0], 'logo_dark')}
                        className="mt-2"
                      />
                    </div>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Cores */}
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle>Cores do Sistema</CardTitle>
            <p className="text-sm text-gray-600">
              Escolha as cores principais da sua marca para botões, cabeçalhos e gráficos
            </p>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="color_primary">Cor Primária</Label>
                <div className="flex gap-3 items-center mt-2">
                  <Input
                    type="color"
                    id="color_primary"
                    value={formData.color_primary}
                    onChange={(e) => setFormData({...formData, color_primary: e.target.value})}
                    className="w-20 h-12"
                  />
                  <Input
                    type="text"
                    value={formData.color_primary}
                    onChange={(e) => setFormData({...formData, color_primary: e.target.value})}
                    placeholder="#4B2672"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="color_secondary">Cor Secundária</Label>
                <div className="flex gap-3 items-center mt-2">
                  <Input
                    type="color"
                    id="color_secondary"
                    value={formData.color_secondary}
                    onChange={(e) => setFormData({...formData, color_secondary: e.target.value})}
                    className="w-20 h-12"
                  />
                  <Input
                    type="text"
                    value={formData.color_secondary}
                    onChange={(e) => setFormData({...formData, color_secondary: e.target.value})}
                    placeholder="#FFD84D"
                  />
                </div>
              </div>
            </div>

            <div>
              <Label className="mb-3 block">Paletas Pré-definidas</Label>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                {PRESET_COLORS.map((preset, idx) => (
                  <Button
                    key={idx}
                    variant="outline"
                    className="flex flex-col items-center gap-2 h-auto py-3"
                    onClick={() => setFormData({
                      ...formData,
                      color_primary: preset.primary,
                      color_secondary: preset.secondary
                    })}
                  >
                    <div className="flex gap-1">
                      <div className="w-6 h-6 rounded" style={{ backgroundColor: preset.primary }}></div>
                      <div className="w-6 h-6 rounded" style={{ backgroundColor: preset.secondary }}></div>
                    </div>
                    <span className="text-xs">{preset.name}</span>
                  </Button>
                ))}
              </div>
            </div>

            <Button variant="outline" onClick={handleReset}>
              <RotateCcw className="w-4 h-4 mr-2" />
              Restaurar padrão iMental
            </Button>
          </CardContent>
        </Card>

        {/* Preview */}
        <Card className="shadow-md">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Visualização da Interface</CardTitle>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setDarkMode(!darkMode)}
              >
                {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div 
              className="p-6 rounded-lg"
              style={{ 
                backgroundColor: darkMode ? '#2E2E2E' : '#FFFFFF',
                color: darkMode ? '#FFFFFF' : '#2E2E2E'
              }}
            >
              <div className="space-y-4">
                <div 
                  className="p-4 rounded-lg"
                  style={{ backgroundColor: formData.color_primary }}
                >
                  {formData[darkMode ? 'logo_dark' : 'logo_light'] ? (
                    <img 
                      src={formData[darkMode ? 'logo_dark' : 'logo_light']} 
                      alt="Logo Preview" 
                      className="h-8"
                    />
                  ) : (
                    <p className="text-white font-bold">Logo da Empresa</p>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <Button 
                    className="text-white font-semibold"
                    style={{ backgroundColor: formData.color_primary }}
                  >
                    Botão Primário
                  </Button>
                  <Button 
                    variant="outline"
                    style={{ 
                      borderColor: formData.color_primary,
                      color: formData.color_primary
                    }}
                  >
                    Botão Secundário
                  </Button>
                </div>

                <div 
                  className="p-4 rounded-lg"
                  style={{ backgroundColor: darkMode ? '#374151' : '#F8F6FB' }}
                >
                  <div className="flex items-center gap-2 mb-2">
                    <div 
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: formData.color_secondary }}
                    ></div>
                    <p className="font-semibold">Card de Dashboard</p>
                  </div>
                  <p className="text-sm opacity-70">Exemplo de conteúdo com sua cor secundária</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Opções White Label (apenas consultorias) */}
        {entityType === 'consultoria' && (
          <Card className="shadow-md border-2" style={{ borderColor: '#A57CE0' }}>
            <CardHeader>
              <CardTitle>Aplicação e Herança de Branding</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="white_label" className="text-base">Modo White Label</Label>
                  <p className="text-sm text-gray-600">
                    Aplicar identidade visual da Consultoria para todas as empresas vinculadas
                  </p>
                </div>
                <Switch
                  id="white_label"
                  checked={formData.modo_white_label}
                  onCheckedChange={(checked) => setFormData({...formData, modo_white_label: checked})}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="permite_custom" className="text-base">Personalização Individual</Label>
                  <p className="text-sm text-gray-600">
                    Permitir que empresas personalizem seu visual individualmente
                  </p>
                </div>
                <Switch
                  id="permite_custom"
                  checked={formData.permite_personalizacao_empresas}
                  onCheckedChange={(checked) => setFormData({...formData, permite_personalizacao_empresas: checked})}
                />
              </div>

              <Alert>
                <Info className="w-4 h-4" />
                <AlertDescription>
                  Com o Modo White Label ativo, suas cores e logos serão aplicados automaticamente em todas as empresas vinculadas, 
                  mantendo uma identidade visual consistente.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        )}

        {/* Botão Salvar */}
        <div className="flex justify-end gap-3">
          <Button variant="outline" onClick={() => window.history.back()}>
            Cancelar
          </Button>
          <Button 
            onClick={handleSave}
            disabled={saveMutation.isPending}
            className="text-white"
            style={{ backgroundColor: formData.color_primary }}
          >
            {saveMutation.isPending ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                Salvando...
              </>
            ) : (
              <>
                <CheckCircle className="w-4 h-4 mr-2" />
                Salvar Configurações
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}