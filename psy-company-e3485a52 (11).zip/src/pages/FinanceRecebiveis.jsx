
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Navigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DollarSign,
  Clock,
  AlertCircle,
  CheckCircle,
  TrendingUp,
  Download,
  Send,
  Edit,
  X,
  FileText,
  Filter
} from "lucide-react";
import { format, addDays, isAfter, isBefore, differenceInDays } from "date-fns";
import { toast } from "sonner";
import FinanceKPICard from "../components/finance/FinanceKPICard";
import AgingWidget from "../components/finance/AgingWidget";
import ReceivableDrawer from "../components/finance/ReceivableDrawer";
import PaymentModal from "../components/finance/PaymentModal";
import { formatCurrency } from "../components/billing/billingHelpers";

export default function FinanceRecebiveis() {
  const [user, setUser] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const [contexto, setContexto] = React.useState(null);
  const [contextoId, setContextoId] = React.useState(null);
  
  const [selectedMonth, setSelectedMonth] = useState(format(new Date(), 'yyyy-MM'));
  const [statusFilter, setStatusFilter] = useState('all');
  const [formaPagamentoFilter, setFormaPagamentoFilter] = useState('all');
  const [consultoriaFilter, setConsultoriaFilter] = useState('all');
  const [empresaFilter, setEmpresaFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  
  const [selectedItems, setSelectedItems] = useState([]);
  const [showDrawer, setShowDrawer] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedRecebivel, setSelectedRecebivel] = useState(null);

  const queryClient = useQueryClient();

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
        
        const impersonationData = localStorage.getItem('admin_impersonation');
        if (impersonationData) {
          const parsed = JSON.parse(impersonationData);
          if (parsed.tipo === 'consultoria') {
            setContexto('CONSULTORIA');
            setContextoId(parsed.consultoria_id);
          }
        } else if (userData.user_role === 'admin') {
          setContexto('ADMIN');
          setContextoId(null);
        } else if (userData.user_role === 'consultoria') {
          setContexto('CONSULTORIA');
          setContextoId(userData.consultoria_id);
        }
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  const { data: recebiveis = [] } = useQuery({
    queryKey: ['recebiveis', contexto, contextoId, selectedMonth],
    queryFn: async () => {
      if (contexto === 'ADMIN') {
        return await base44.entities.Recebivel.filter({
          cliente_tipo: 'CONSULTORIA'
        });
      } else if (contexto === 'CONSULTORIA') {
        return await base44.entities.Recebivel.filter({
          cliente_tipo: 'EMPRESA',
          consultoria_id: contextoId
        });
      }
      return [];
    },
    enabled: !!contexto,
  });

  const { data: pagamentos = [] } = useQuery({
    queryKey: ['pagamentos'],
    queryFn: () => base44.entities.Pagamento.list(),
    enabled: !!contexto,
  });

  const { data: consultorias = [] } = useQuery({
    queryKey: ['consultorias'],
    queryFn: () => base44.entities.Consultoria.list(),
    enabled: contexto === 'ADMIN',
  });

  const { data: empresas = [] } = useQuery({
    queryKey: ['empresas-finance', contextoId],
    queryFn: async () => {
      if (contexto === 'CONSULTORIA') {
        return await base44.entities.Company.filter({ consultoria_id: contextoId });
      }
      return await base44.entities.Company.list();
    },
    enabled: !!contexto,
  });

  const registrarPagamentoMutation = useMutation({
    mutationFn: async ({ recebivelId, pagamentoData }) => {
      const recebivel = recebiveis.find(r => r.id === recebivelId);
      const novoSaldo = recebivel.saldo - pagamentoData.valor_liquido;
      
      await base44.entities.Pagamento.create({
        fatura_id: recebivel.fatura_id,
        recebivel_id: recebivelId,
        ...pagamentoData,
        criado_por: user.email
      });

      const novoStatus = novoSaldo <= 0 ? 'liquidado' : 
                        novoSaldo < recebivel.valor_original ? 'parcial' : 
                        recebivel.status;

      const historico = [
        ...(recebivel.historico || []),
        {
          evento: 'pagamento_registrado',
          data: new Date().toISOString(),
          usuario: user.email,
          detalhes: `Pagamento de ${formatCurrency(pagamentoData.valor_liquido)} via ${pagamentoData.meio}`
        }
      ];

      await base44.entities.Recebivel.update(recebivelId, {
        saldo: novoSaldo,
        status: novoStatus,
        historico
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['recebiveis'] });
      queryClient.invalidateQueries({ queryKey: ['pagamentos'] });
      setShowPaymentModal(false);
      setSelectedRecebivel(null);
      toast.success('Pagamento registrado com sucesso');
    },
  });

  const cancelarRecebivelMutation = useMutation({
    mutationFn: async ({ recebivelId, motivo }) => {
      const recebivel = recebiveis.find(r => r.id === recebivelId);
      
      const historico = [
        ...(recebivel.historico || []),
        {
          evento: 'cancelamento',
          data: new Date().toISOString(),
          usuario: user.email,
          detalhes: motivo
        }
      ];

      await base44.entities.Recebivel.update(recebivelId, {
        status: 'cancelado',
        cancelado_em: new Date().toISOString(),
        cancelado_por: user.email,
        motivo_cancelamento: motivo,
        historico
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['recebiveis'] });
      toast.success('Título cancelado');
    },
  });

  // Calcular KPIs
  const hoje = new Date();
  const daquiA7Dias = addDays(hoje, 7);

  const recebiveisAtivos = recebiveis.filter(r => 
    r.status !== 'cancelado' && r.status !== 'liquidado'
  );

  const totalEmAberto = recebiveisAtivos.reduce((acc, r) => acc + r.saldo, 0);
  
  const vencendoEm7Dias = recebiveisAtivos
    .filter(r => {
      const venc = new Date(r.vencimento);
      return isAfter(venc, hoje) && isBefore(venc, daquiA7Dias);
    })
    .reduce((acc, r) => acc + r.saldo, 0);

  const totalVencido = recebiveis
    .filter(r => r.status === 'vencido')
    .reduce((acc, r) => acc + r.saldo, 0);

  const recebidoNoMes = pagamentos
    .filter(p => {
      const pagoDt = new Date(p.pago_em);
      return format(pagoDt, 'yyyy-MM') === selectedMonth;
    })
    .reduce((acc, p) => acc + p.valor_liquido, 0);

  const totalEmitido = recebiveis
    .filter(r => r.competencia === selectedMonth && r.status !== 'cancelado')
    .reduce((acc, r) => acc + r.valor_original, 0);

  const inadimplencia = totalEmitido > 0 ? (totalVencido / totalEmitido) * 100 : 0;

  // DSO
  let somaValorDias = 0;
  let somaValor = 0;
  recebiveisAtivos.forEach(r => {
    const dias = differenceInDays(hoje, new Date(r.emissao));
    somaValorDias += r.saldo * dias;
    somaValor += r.saldo;
  });
  const dso = somaValor > 0 ? somaValorDias / somaValor : 0;

  const mrrRealizado = recebiveis
    .filter(r => r.status === 'liquidado' && r.competencia === selectedMonth)
    .reduce((acc, r) => acc + r.valor_original, 0);

  // Aging
  const agingData = {
    bucket_0_15: 0,
    bucket_16_30: 0,
    bucket_31_60: 0,
    bucket_61_90: 0,
    bucket_90_plus: 0
  };

  recebiveisAtivos.forEach(r => {
    const dias = differenceInDays(hoje, new Date(r.vencimento));
    if (dias <= 0) return; // não vencido
    if (dias <= 15) agingData.bucket_0_15 += r.saldo;
    else if (dias <= 30) agingData.bucket_16_30 += r.saldo;
    else if (dias <= 60) agingData.bucket_31_60 += r.saldo;
    else if (dias <= 90) agingData.bucket_61_90 += r.saldo;
    else agingData.bucket_90_plus += r.saldo;
  });

  // Filtros
  let filteredRecebiveis = recebiveis.filter(r => {
    if (statusFilter !== 'all' && r.status !== statusFilter) return false;
    if (formaPagamentoFilter !== 'all' && r.forma_pagamento !== formaPagamentoFilter) return false;
    if (contexto === 'ADMIN' && consultoriaFilter !== 'all' && r.consultoria_id !== consultoriaFilter) return false;
    if (empresaFilter !== 'all' && r.empresa_id !== empresaFilter) return false;
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      return r.titulo_num.toLowerCase().includes(term) || 
             r.referencia?.toLowerCase().includes(term);
    }
    return true;
  });

  const handleExportCSV = () => {
    const headers = ['Nº Título', 'Cliente', 'Competência', 'Emissão', 'Vencimento', 'Valor Original', 'Saldo', 'Status', 'Forma Pagamento'];
    const rows = filteredRecebiveis.map(r => [
      r.titulo_num,
      r.cliente_tipo === 'CONSULTORIA' ? 
        consultorias.find(c => c.id === r.consultoria_id)?.nome_fantasia || r.consultoria_id :
        empresas.find(e => e.id === r.empresa_id)?.name || r.empresa_id,
      r.competencia,
      format(new Date(r.emissao), 'dd/MM/yyyy'),
      format(new Date(r.vencimento), 'dd/MM/yyyy'),
      r.valor_original,
      r.saldo,
      r.status,
      r.forma_pagamento
    ]);

    const csvContent = [headers, ...rows]
      .map(row => row.map(cell => `"${cell}"`).join(','))
      .join('\n');

    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `recebiveis_${selectedMonth}_${new Date().getTime()}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    toast.success('CSV exportado com sucesso');
  };

  const getStatusBadge = (status) => {
    const badges = {
      em_aberto: <Badge className="bg-blue-100 text-blue-800">Em Aberto</Badge>,
      parcial: <Badge className="bg-yellow-100 text-yellow-800">Parcial</Badge>,
      liquidado: <Badge className="bg-green-100 text-green-800">Liquidado</Badge>,
      vencido: <Badge className="bg-red-100 text-red-800">Vencido</Badge>,
      cancelado: <Badge className="bg-gray-100 text-gray-800">Cancelado</Badge>
    };
    return badges[status] || status;
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando recebíveis...</p>
        </div>
      </div>
    );
  }

  if (!user || (user.user_role !== 'admin' && user.user_role !== 'consultoria')) {
    return <Navigate to={createPageUrl('Error403')} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                Recebíveis
              </h1>
              <p className="text-gray-600 mt-1">
                Gestão de contas a receber e aging de títulos
              </p>
            </div>
            <div className="flex gap-3">
              <Button variant="outline" onClick={handleExportCSV}>
                <Download className="w-4 h-4 mr-2" />
                Exportar CSV
              </Button>
            </div>
          </div>
        </div>

        {/* Filtros */}
        <Card className="shadow-md mb-6">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Input
                placeholder="Buscar por nº título..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os status</SelectItem>
                  <SelectItem value="em_aberto">Em Aberto</SelectItem>
                  <SelectItem value="parcial">Parcial</SelectItem>
                  <SelectItem value="liquidado">Liquidado</SelectItem>
                  <SelectItem value="vencido">Vencido</SelectItem>
                  <SelectItem value="cancelado">Cancelado</SelectItem>
                </SelectContent>
              </Select>
              <Select value={formaPagamentoFilter} onValueChange={setFormaPagamentoFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Forma Pagamento" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas as formas</SelectItem>
                  <SelectItem value="boleto">Boleto</SelectItem>
                  <SelectItem value="pix">PIX</SelectItem>
                  <SelectItem value="cartao">Cartão</SelectItem>
                  <SelectItem value="ted_dep">TED/Depósito</SelectItem>
                  <SelectItem value="outros">Outros</SelectItem>
                </SelectContent>
              </Select>
              <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {[...Array(12)].map((_, i) => {
                    const date = new Date();
                    date.setMonth(date.getMonth() - i);
                    const value = format(date, 'yyyy-MM');
                    return (
                      <SelectItem key={value} value={value}>
                        {format(date, 'MMMM/yyyy')}
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* KPIs */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <FinanceKPICard
            title="Total em Aberto"
            value={totalEmAberto}
            format="currency"
            icon={DollarSign}
            colorScheme="purple"
          />
          <FinanceKPICard
            title="Vencendo em 7 dias"
            value={vencendoEm7Dias}
            format="currency"
            icon={Clock}
            colorScheme="yellow"
          />
          <FinanceKPICard
            title="Vencidos"
            value={totalVencido}
            format="currency"
            icon={AlertCircle}
            colorScheme="red"
          />
          <FinanceKPICard
            title="Recebido no Mês"
            value={recebidoNoMes}
            format="currency"
            icon={CheckCircle}
            colorScheme="green"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <FinanceKPICard
            title="DSO"
            subtitle="Days Sales Outstanding"
            value={dso}
            format="days"
            icon={Clock}
            colorScheme="gray"
          />
          <FinanceKPICard
            title="Inadimplência"
            subtitle="% do total emitido"
            value={inadimplencia}
            format="percent"
            icon={AlertCircle}
            colorScheme="red"
          />
          <FinanceKPICard
            title="MRR Realizado"
            subtitle="Receita recebida no mês"
            value={mrrRealizado}
            format="currency"
            icon={TrendingUp}
            colorScheme="green"
          />
          <FinanceKPICard
            title="Títulos Ativos"
            value={recebiveisAtivos.length}
            icon={FileText}
            colorScheme="purple"
          />
        </div>

        {/* Aging */}
        <div className="mb-8">
          <AgingWidget data={agingData} />
        </div>

        {/* Tabela */}
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle>Títulos de Recebíveis ({filteredRecebiveis.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {filteredRecebiveis.length > 0 ? (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead className="w-[50px]">
                        <Checkbox />
                      </TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Nº Título</TableHead>
                      <TableHead>Cliente</TableHead>
                      <TableHead>Competência</TableHead>
                      <TableHead>Emissão</TableHead>
                      <TableHead>Vencimento</TableHead>
                      <TableHead>Valor</TableHead>
                      <TableHead>Saldo</TableHead>
                      <TableHead>Forma</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredRecebiveis.map((recebivel) => {
                      const cliente = recebivel.cliente_tipo === 'CONSULTORIA' ?
                        consultorias.find(c => c.id === recebivel.consultoria_id) :
                        empresas.find(e => e.id === recebivel.empresa_id);

                      return (
                        <TableRow key={recebivel.id} className="hover:bg-gray-50">
                          <TableCell>
                            <Checkbox />
                          </TableCell>
                          <TableCell>
                            {getStatusBadge(recebivel.status)}
                          </TableCell>
                          <TableCell>
                            <button
                              className="text-purple-600 hover:underline font-semibold"
                              onClick={() => {
                                setSelectedRecebivel(recebivel);
                                setShowDrawer(true);
                              }}
                            >
                              {recebivel.titulo_num}
                            </button>
                          </TableCell>
                          <TableCell>
                            {cliente?.nome_fantasia || cliente?.name || '—'}
                          </TableCell>
                          <TableCell>{recebivel.competencia}</TableCell>
                          <TableCell>{format(new Date(recebivel.emissao), 'dd/MM/yyyy')}</TableCell>
                          <TableCell>{format(new Date(recebivel.vencimento), 'dd/MM/yyyy')}</TableCell>
                          <TableCell className="font-semibold">
                            {formatCurrency(recebivel.valor_original)}
                          </TableCell>
                          <TableCell className="font-semibold text-orange-600">
                            {formatCurrency(recebivel.saldo)}
                          </TableCell>
                          <TableCell className="capitalize">
                            {recebivel.forma_pagamento.replace('_', '/')}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              {recebivel.status !== 'cancelado' && recebivel.status !== 'liquidado' && (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => {
                                    setSelectedRecebivel(recebivel);
                                    setShowPaymentModal(true);
                                  }}
                                >
                                  <DollarSign className="w-4 h-4" />
                                </Button>
                              )}
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => {
                                  setSelectedRecebivel(recebivel);
                                  setShowDrawer(true);
                                }}
                              >
                                <FileText className="w-4 h-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="text-center py-12">
                <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">Nenhum recebível encontrado</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Drawer de Detalhes */}
        {showDrawer && selectedRecebivel && (
          <ReceivableDrawer
            recebivel={selectedRecebivel}
            onClose={() => {
              setShowDrawer(false);
              setSelectedRecebivel(null);
            }}
            onPayment={() => {
              setShowDrawer(false);
              setShowPaymentModal(true);
            }}
            onCancel={(motivo) => {
              cancelarRecebivelMutation.mutate({
                recebivelId: selectedRecebivel.id,
                motivo
              });
              setShowDrawer(false);
            }}
          />
        )}

        {/* Modal de Pagamento */}
        {showPaymentModal && selectedRecebivel && (
          <PaymentModal
            recebivel={selectedRecebivel}
            onClose={() => {
              setShowPaymentModal(false);
              setSelectedRecebivel(null);
            }}
            onSubmit={(pagamentoData) => {
              registrarPagamentoMutation.mutate({
                recebivelId: selectedRecebivel.id,
                pagamentoData
              });
            }}
          />
        )}
      </div>
    </div>
  );
}
