
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Navigate, Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import {
  DollarSign,
  TrendingUp,
  Activity,
  Clock,
  AlertCircle,
  FileText,
  Wallet,
  ArrowRight
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { format, subMonths } from "date-fns";
import FinanceKPICard from "../components/finance/FinanceKPICard";
import MRRChart from "../components/finance/MRRChart";
import AgingWidget from "../components/finance/AgingWidget";

export default function FinanceOverview() {
  const [user, setUser] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const [contexto, setContexto] = React.useState(null);
  const [contextoId, setContextoId] = React.useState(null);

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
        
        const impersonationData = localStorage.getItem('admin_impersonation');
        if (impersonationData) {
          const parsed = JSON.parse(impersonationData);
          if (parsed.tipo === 'consultoria') {
            setContexto('CONSULTORIA');
            setContextoId(parsed.consultoria_id);
          }
        } else if (userData.user_role === 'admin') {
          setContexto('ADMIN');
          setContextoId(null);
        } else if (userData.user_role === 'consultoria') {
          setContexto('CONSULTORIA');
          setContextoId(userData.consultoria_id);
        }
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  const currentMonth = format(new Date(), 'yyyy-MM');
  const previousMonth = format(subMonths(new Date(), 1), 'yyyy-MM');

  const { data: faturas = [] } = useQuery({
    queryKey: ['faturas-finance', contexto, contextoId],
    queryFn: async () => {
      if (contexto === 'ADMIN') {
        return await base44.entities.Fatura.filter({
          emitente_tipo: 'ADMIN',
          alvo_tipo: 'CONSULTORIA'
        });
      } else if (contexto === 'CONSULTORIA') {
        return await base44.entities.Fatura.filter({
          emitente_tipo: 'CONSULTORIA',
          emitente_id: contextoId,
          alvo_tipo: 'EMPRESA'
        });
      }
      return [];
    },
    enabled: !!contexto,
  });

  const { data: pagamentos = [] } = useQuery({
    queryKey: ['pagamentos-finance'],
    queryFn: () => base44.entities.Pagamento.list(),
    enabled: !!contexto,
  });

  // Calcular KPIs
  const faturasAtual = faturas.filter(f => f.competencia === currentMonth);
  const faturasAnterior = faturas.filter(f => f.competencia === previousMonth);
  
  const mrrAtual = faturasAtual.reduce((acc, f) => acc + (f.valor_liquido || 0), 0);
  const mrrAnterior = faturasAnterior.reduce((acc, f) => acc + (f.valor_liquido || 0), 0);
  const deltaMRR = mrrAnterior > 0 ? ((mrrAtual - mrrAnterior) / mrrAnterior) * 100 : 0;

  const arr = mrrAtual * 12;

  const receitaRealizada = faturasAtual
    .filter(f => f.status === 'PAGA')
    .reduce((acc, f) => acc + (f.valor_liquido || 0), 0);

  const receitaPrevista = faturasAtual
    .filter(f => f.status !== 'CANCELADA')
    .reduce((acc, f) => acc + (f.valor_liquido || 0), 0);

  const faturasEmitidas = faturasAtual.filter(f => 
    ['AUTORIZADA', 'ENVIADA', 'PAGA', 'VENCIDA'].includes(f.status)
  );
  const faturasPagas = faturasAtual.filter(f => f.status === 'PAGA');
  const taxaRecebimento = faturasEmitidas.length > 0 
    ? (faturasPagas.length / faturasEmitidas.length) * 100
    : 0;

  const faturasVencidas = faturas.filter(f => 
    f.status === 'VENCIDA' && 
    new Date(f.vencimento_em) < new Date()
  );
  const totalVencido = faturasVencidas.reduce((acc, f) => acc + (f.valor_liquido || 0), 0);
  const totalEmAberto = faturas
    .filter(f => ['AUTORIZADA', 'ENVIADA', 'VENCIDA'].includes(f.status))
    .reduce((acc, f) => acc + (f.valor_liquido || 0), 0);
  const inadimplencia = totalEmAberto > 0 ? (totalVencido / totalEmAberto) * 100 : 0;

  // DSO simplificado
  const diasMedios = 30;
  const dso = diasMedios * (totalEmAberto / (receitaPrevista || 1));

  // Dados para aging
  const agingData = {
    bucket_0_15: 0,
    bucket_16_30: 0,
    bucket_31_60: 0,
    bucket_61_90: 0,
    bucket_90_plus: 0
  };

  faturas.forEach(f => {
    if (!['AUTORIZADA', 'ENVIADA', 'VENCIDA'].includes(f.status)) return;
    if (!f.vencimento_em) return;

    const dias = Math.floor((new Date() - new Date(f.vencimento_em)) / (1000 * 60 * 60 * 24));
    const valor = f.valor_liquido || 0;

    if (dias <= 15) agingData.bucket_0_15 += valor;
    else if (dias <= 30) agingData.bucket_16_30 += valor;
    else if (dias <= 60) agingData.bucket_31_60 += valor;
    else if (dias <= 90) agingData.bucket_61_90 += valor;
    else agingData.bucket_90_plus += valor;
  });

  // Dados históricos para MRR (últimos 12 meses)
  const mrrHistorico = [];
  for (let i = 11; i >= 0; i--) {
    const mes = format(subMonths(new Date(), i), 'yyyy-MM');
    const faturasDoMes = faturas.filter(f => f.competencia === mes);
    const mrrMes = faturasDoMes.reduce((acc, f) => acc + (f.valor_liquido || 0), 0);
    const receitaMes = faturasDoMes
      .filter(f => f.status === 'PAGA')
      .reduce((acc, f) => acc + (f.valor_liquido || 0), 0);

    mrrHistorico.push({
      month: format(subMonths(new Date(), i), 'MMM/yy'),
      mrr: mrrMes,
      receita_realizada: receitaMes
    });
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando dados financeiros...</p>
        </div>
      </div>
    );
  }

  if (!user || (user.user_role !== 'admin' && user.user_role !== 'consultoria')) {
    return <Navigate to={createPageUrl('Error403')} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                Financeiro {contexto === 'ADMIN' ? 'iMental' : 'da Consultoria'}
              </h1>
              <p className="text-gray-600 mt-1">
                Visão geral de receitas, recebíveis e métricas financeiras
              </p>
            </div>
            <div className="flex gap-3">
              <Link to={createPageUrl(contexto === 'ADMIN' ? 'FaturamentoAdmin' : 'FaturamentoConsultoria')}>
                <Button variant="outline">
                  <FileText className="w-4 h-4 mr-2" />
                  Ir para Faturamento
                </Button>
              </Link>
              <Select defaultValue="30">
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="30">30 dias</SelectItem>
                  <SelectItem value="90">90 dias</SelectItem>
                  <SelectItem value="365">12 meses</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <FinanceKPICard
            title="MRR"
            subtitle="Receita Recorrente Mensal"
            value={mrrAtual}
            delta={deltaMRR}
            format="currency"
            icon={DollarSign}
            colorScheme="purple"
          />
          <FinanceKPICard
            title="ARR"
            subtitle="Receita Recorrente Anual"
            value={arr}
            format="currency"
            icon={TrendingUp}
            colorScheme="purple"
          />
          <FinanceKPICard
            title="Receita Realizada"
            subtitle={`${format(new Date(), 'MMMM/yyyy')}`}
            value={receitaRealizada}
            format="currency"
            icon={Wallet}
            colorScheme="green"
          />
          <FinanceKPICard
            title="Taxa de Recebimento"
            subtitle="Faturas pagas / emitidas"
            value={taxaRecebimento}
            format="percent"
            icon={Activity}
            colorScheme="green"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <FinanceKPICard
            title="DSO"
            subtitle="Days Sales Outstanding"
            value={dso}
            format="days"
            icon={Clock}
            colorScheme="yellow"
          />
          <FinanceKPICard
            title="Inadimplência"
            subtitle="% do total em aberto"
            value={inadimplencia}
            format="percent"
            icon={AlertCircle}
            colorScheme="red"
          />
          <FinanceKPICard
            title="Total em Aberto"
            subtitle="Aguardando pagamento"
            value={totalEmAberto}
            format="currency"
            icon={FileText}
            colorScheme="yellow"
          />
          <FinanceKPICard
            title="Total Vencido"
            subtitle="Faturas atrasadas"
            value={totalVencido}
            format="currency"
            icon={AlertCircle}
            colorScheme="red"
          />
        </div>

        {/* Gráficos */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <MRRChart data={mrrHistorico} />
          <AgingWidget data={agingData} />
        </div>

        {/* Links rápidos */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Link to={createPageUrl(contexto === 'ADMIN' ? 'FaturamentoAdmin' : 'FaturamentoConsultoria')}>
            <div className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-shadow cursor-pointer border-2 border-transparent hover:border-purple-200">
              <FileText className="w-8 h-8 text-purple-600 mb-3" />
              <h3 className="font-semibold text-gray-900 mb-2">Faturamento</h3>
              <p className="text-sm text-gray-600 mb-4">
                Gerar, editar e enviar faturas
              </p>
              <div className="flex items-center text-purple-600 text-sm font-medium">
                Acessar <ArrowRight className="w-4 h-4 ml-1" />
              </div>
            </div>
          </Link>

          <Link to={createPageUrl('FinanceRecebiveis')}>
            <div className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-shadow cursor-pointer border-2 border-transparent hover:border-purple-200">
              <Wallet className="w-8 h-8 text-green-600 mb-3" />
              <h3 className="font-semibold text-gray-900 mb-2">Recebíveis</h3>
              <p className="text-sm text-gray-600 mb-4">
                Gerenciar contas a receber
              </p>
              <div className="flex items-center text-green-600 text-sm font-medium">
                Acessar <ArrowRight className="w-4 h-4 ml-1" />
              </div>
            </div>
          </Link>

          <Link to={createPageUrl('FinanceRelatorios')}>
            <div className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-shadow cursor-pointer border-2 border-transparent hover:border-purple-200">
              <Activity className="w-8 h-8 text-blue-600 mb-3" />
              <h3 className="font-semibold text-gray-900 mb-2">Relatórios</h3>
              <p className="text-sm text-gray-600 mb-4">
                Exportar e analisar dados
              </p>
              <div className="flex items-center text-blue-600 text-sm font-medium">
                Acessar <ArrowRight className="w-4 h-4 ml-1" />
              </div>
            </div>
          </Link>
        </div>
      </div>
    </div>
  );
}
