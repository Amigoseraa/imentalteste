import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Navigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Plus, Send, RefreshCw, Search } from "lucide-react";
import AssessmentStatsCards from "../components/assessments/AssessmentStatsCards";
import AssessmentGroupCard from "../components/assessments/AssessmentGroupCard";
import NewAssessmentDialog from "../components/assessments/NewAssessmentDialog";
import ResendModal from "../components/assessments/ResendModal";
import RemindersConfigModal from "../components/assessments/RemindersConfigModal";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";

export default function Assessments() {
  const [user, setUser] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const [companyId, setCompanyId] = React.useState(null);
  const [showNewDialog, setShowNewDialog] = useState(false);
  const [showResendDialog, setShowResendDialog] = useState(false);
  const [showRemindersDialog, setShowRemindersDialog] = useState(false);
  const [generatedLinks, setGeneratedLinks] = React.useState([]);
  const [showLinksDialog, setShowLinksDialog] = React.useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState('all');
  const [dateFilter, setDateFilter] = useState('all');
  const [selectedGroupForReminders, setSelectedGroupForReminders] = useState(null);

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
        
        const impersonationData = localStorage.getItem('admin_impersonation');
        if (impersonationData) {
          const parsed = JSON.parse(impersonationData);
          setCompanyId(parsed.company_id);
        } else {
          setCompanyId(userData.company_id);
        }
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  const queryClient = useQueryClient();

  const { data: assessments, isLoading: loadingAssessments } = useQuery({
    queryKey: ['assessments', companyId],
    queryFn: async () => {
      if (!companyId) return [];
      return await base44.entities.Assessment.filter(
        { company_id: companyId },
        '-created_date'
      );
    },
    enabled: !!companyId,
    initialData: [],
  });

  const { data: employees } = useQuery({
    queryKey: ['employees', companyId],
    queryFn: async () => {
      if (!companyId) return [];
      return await base44.entities.Employee.filter({ 
        company_id: companyId,
        status: 'active'
      });
    },
    enabled: !!companyId,
    initialData: [],
  });

  const { data: departments } = useQuery({
    queryKey: ['departments', companyId],
    queryFn: async () => {
      if (!companyId) return [];
      return await base44.entities.Department.filter({ company_id: companyId });
    },
    enabled: !!companyId,
    initialData: [],
  });

  const { data: company } = useQuery({
    queryKey: ['company', companyId],
    queryFn: async () => {
      if (!companyId) return null;
      const companies = await base44.entities.Company.filter({ id: companyId });
      return companies[0] || null;
    },
    enabled: !!companyId,
  });

  const createAssessmentsMutation = useMutation({
    mutationFn: async ({ assessmentName, selectedQuestionnaires, selectedEmployees, dueDate, sendEmails }) => {
      const results = [];
      const links = [];
      
      for (const employee of selectedEmployees) {
        const token = `${employee.id}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        
        const assessmentData = {
          employee_id: employee.id,
          company_id: companyId,
          department_id: employee.department_id,
          assessment_type: selectedQuestionnaires.join(','),
          assessment_token: token,
          assessment_name: assessmentName,
          due_date: dueDate ? new Date(dueDate).toISOString() : null,
          term_accepted: false,
          prima_responses: {},
          phq9_responses: {},
          gad7_responses: {},
          hseit_responses: {},
          jcq_responses: {}
        };

        const assessment = await base44.entities.Assessment.create(assessmentData);
        
        const genericUrl = `${window.location.origin}/Responder`;
        
        links.push({
          employee: employee.name,
          email: employee.email,
          phone: employee.phone,
          link: genericUrl
        });
        
        if (sendEmails) {
          const questionnaireNames = selectedQuestionnaires.map(q => {
            if (q === 'PHQ-9') return 'PHQ-9 (Depressão)';
            if (q === 'GAD-7') return 'GAD-7 (Ansiedade)';
            if (q === 'PRIMA-EF') return 'PRIMA-EF (Riscos Psicossociais)';
            if (q === 'HSE-IT') return 'HSE-IT (Indicador HSE)';
            if (q === 'JCQ') return 'JCQ (Conteúdo do Trabalho)';
            return q;
          }).join(', ');

          const emailBody = `
            Olá ${employee.name},

            Você foi convidado(a) a participar de avaliações de saúde e bem-estar da ${company?.name || 'empresa'}.

            Nome da Avaliação: ${assessmentName}
            Questionários incluídos: ${questionnaireNames}
            Prazo de resposta: ${dueDate ? new Date(dueDate).toLocaleDateString('pt-BR') : 'Sem prazo definido'}

            Estas avaliações são confidenciais e seus resultados serão usados apenas de forma agregada para melhorar o ambiente de trabalho.

            Para responder, acesse: ${genericUrl}
            Use seu CPF e data de nascimento para identificação.

            Obrigado pela sua participação!

            Equipe PsyCompany
          `;

          try {
            await base44.integrations.Core.SendEmail({
              from_name: company?.name || 'PsyCompany',
              to: employee.email,
              subject: `Convite: Avaliação de Bem-Estar - ${assessmentName}`,
              body: emailBody
            });
          } catch (emailError) {
            console.error(`Error sending email to ${employee.email}:`, emailError);
          }
        }
        
        results.push(assessment);
      }
      
      return { assessments: results, links };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['assessments', companyId] });
      setShowNewDialog(false);
      
      if (data.links && data.links.length > 0) {
        setGeneratedLinks(data.links);
        setShowLinksDialog(true);
      }
      toast.success('Avaliação criada e convites enviados!');
    },
    onError: () => {
      toast.error('Erro ao criar avaliação.');
    }
  });

  const resendInvitationsMutation = useMutation({
    mutationFn: async ({ subject, bodyTemplate }) => {
      const pendingAssessments = assessments.filter(a => !a.completed_at);

      for (const assessment of pendingAssessments) {
        const employee = employees.find(e => e.id === assessment.employee_id);
        if (!employee) continue;

        const assessmentUrl = `${window.location.origin}/Responder`;
        const questionnaireNames = assessment.assessment_type.split(',').map(q => {
          if (q === 'PHQ-9') return 'PHQ-9 (Depressão)';
          if (q === 'GAD-7') return 'GAD-7 (Ansiedade)';
          if (q === 'PRIMA-EF') return 'PRIMA-EF (Riscos Psicossociais)';
          if (q === 'HSE-IT') return 'HSE-IT (Indicador HSE)';
          if (q === 'JCQ') return 'JCQ (Conteúdo do Trabalho)';
          return q;
        }).join(', ');

        const emailBody = bodyTemplate
          .replace(/\{\{employee_name\}\}/g, employee.name)
          .replace(/\{\{company_name\}\}/g, company?.name || 'sua empresa')
          .replace(/\{\{assessment_name\}\}/g, assessment.assessment_name || 'Avaliação de Bem-Estar')
          .replace(/\{\{questionnaire_names\}\}/g, questionnaireNames)
          .replace(/\{\{due_date\}\}/g, assessment.due_date ? new Date(assessment.due_date).toLocaleDateString('pt-BR') : 'Sem prazo definido')
          .replace(/\{\{assessment_url\}\}/g, assessmentUrl);

        try {
          await base44.integrations.Core.SendEmail({
            from_name: company?.name || 'PsyCompany',
            to: employee.email,
            subject: subject,
            body: emailBody
          });
        } catch (emailError) {
          console.error(`Error sending resend email to ${employee.email}:`, emailError);
        }
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['assessments', companyId] });
      setShowResendDialog(false);
      toast.success('Convites reenviados com sucesso!');
    },
    onError: (error) => {
      console.error("Error resending invitations:", error);
      toast.error('Erro ao reenviar convites.');
    }
  });

  const updateReminderConfigMutation = useMutation({
    mutationFn: async (reminderData) => {
      if (!companyId) throw new Error("Company ID is not defined.");
      await base44.entities.Company.update(companyId, {
        reminder_enabled: reminderData.enabled,
        reminder_frequency: reminderData.frequency,
        reminder_send_time: reminderData.sendTime,
        reminder_subject: reminderData.subject,
        reminder_body_template: reminderData.bodyTemplate,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['company', companyId] });
      setShowRemindersDialog(false);
      toast.success('Lembretes configurados.');
    },
    onError: (error) => {
      console.error("Error saving reminder configuration:", error);
      toast.error('Erro ao salvar configuração de lembretes.');
    }
  });

  const handleConfigureReminders = (group) => {
    setSelectedGroupForReminders(group);
    setShowRemindersDialog(true);
  };

  const handleViewReport = (group) => {
    const firstAssessmentId = group.assessments[0]?.id;
    if (firstAssessmentId) {
      window.location.href = `/AssessmentReport?group=${encodeURIComponent(group.name)}&id=${firstAssessmentId}`;
    } else {
      toast.error('Nenhuma avaliação encontrada neste grupo para gerar relatório.');
    }
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1,2,3].map(i => (
              <div key={i} className="h-32 bg-gray-200 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" />;
  }

  if (user.user_role === 'admin' && !localStorage.getItem('admin_impersonation')) {
    return <Navigate to="/Companies" />;
  }

  if (!companyId) {
    return (
      <div className="p-8">
        <Card className="border-2 border-yellow-200 bg-yellow-50">
          <CardContent className="p-6">
            <p className="text-yellow-800 font-medium">
              Sua conta não está vinculada a nenhuma empresa ou não foi selecionada uma empresa para visualização. Entre em contato com o administrador.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const groupedAssessments = {};
  assessments.forEach(assessment => {
    const key = assessment.assessment_name || 'Sem Nome';
    if (!groupedAssessments[key]) {
      groupedAssessments[key] = {
        name: key,
        created_date: assessment.created_date,
        due_date: assessment.due_date,
        assessment_type: assessment.assessment_type,
        assessments: []
      };
    }
    groupedAssessments[key].assessments.push(assessment);
  });

  let assessmentGroups = Object.values(groupedAssessments).sort(
    (a, b) => new Date(b.created_date) - new Date(a.created_date)
  );

  if (searchTerm) {
    assessmentGroups = assessmentGroups.filter(group => 
      group.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }

  if (selectedDepartment !== 'all') {
    assessmentGroups = assessmentGroups.filter(group =>
      group.assessments.some(a => a.department_id === selectedDepartment)
    );
  }

  if (dateFilter !== 'all') {
    const now = new Date();
    assessmentGroups = assessmentGroups.filter(group => {
      const createdDate = new Date(group.created_date);
      const diffDays = (now - createdDate) / (1000 * 60 * 60 * 24);
      
      if (dateFilter === '7days') return diffDays <= 7;
      if (dateFilter === '30days') return diffDays <= 30;
      if (dateFilter === '90days') return diffDays <= 90;
      return true;
    });
  }

  const pendingAssessments = assessments.filter(a => !a.completed_at);

  return (
    <div className="p-4 md:p-8 min-h-screen" style={{ backgroundColor: '#F8F8FA' }}>
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold" style={{ color: '#2B2240' }}>Gestão de Avaliações</h1>
            <p className="text-gray-500 mt-2">
              Envie e acompanhe as avaliações psicossociais dos colaboradores
            </p>
          </div>
          <div className="flex gap-3 flex-wrap">
            {pendingAssessments.length > 0 && (
              <Button 
                variant="outline"
                onClick={() => setShowResendDialog(true)}
                disabled={resendInvitationsMutation.isPending}
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                {resendInvitationsMutation.isPending ? 'Reenviando...' : 'Reenviar Pendentes'}
              </Button>
            )}
            <Button 
              onClick={() => setShowNewDialog(true)}
              className="text-white hover:shadow-lg transition-all"
              style={{ backgroundColor: '#5E2C91' }}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#4C2378'}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#5E2C91'}
            >
              <Plus className="w-4 h-4 mr-2" />
              Nova Avaliação
            </Button>
          </div>
        </div>

        <AssessmentStatsCards 
          assessments={assessments}
          employees={employees}
          assessmentGroups={assessmentGroups}
        />

        <Card className="shadow-md">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Buscar avaliação..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                <SelectTrigger>
                  <SelectValue placeholder="Todos os departamentos" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os departamentos</SelectItem>
                  {departments.map(dept => (
                    <SelectItem key={dept.id} value={dept.id}>
                      {dept.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={dateFilter} onValueChange={setDateFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Período" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todo período</SelectItem>
                  <SelectItem value="7days">Últimos 7 dias</SelectItem>
                  <SelectItem value="30days">Últimos 30 dias</SelectItem>
                  <SelectItem value="90days">Últimos 90 dias</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-4">
          {assessmentGroups.length > 0 ? (
            assessmentGroups.map((group, idx) => (
              <AssessmentGroupCard
                key={idx}
                group={group}
                employees={employees}
                departments={departments}
                company={company}
                onConfigureReminders={handleConfigureReminders}
                onViewReport={handleViewReport}
              />
            ))
          ) : (
            <Card className="border-2 border-dashed border-gray-300">
              <CardContent className="flex flex-col items-center justify-center py-16">
                <Send className="w-16 h-16 text-gray-400 mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  {searchTerm || selectedDepartment !== 'all' || dateFilter !== 'all' 
                    ? 'Nenhuma avaliação encontrada com os filtros aplicados'
                    : 'Nenhuma avaliação enviada ainda'
                  }
                </h3>
                <p className="text-gray-500 text-center max-w-md mb-6">
                  {searchTerm || selectedDepartment !== 'all' || dateFilter !== 'all'
                    ? 'Tente ajustar os filtros de busca'
                    : 'Comece criando uma nova avaliação e enviando aos colaboradores'
                  }
                </p>
                {!searchTerm && selectedDepartment === 'all' && dateFilter === 'all' && (
                  <Button 
                    onClick={() => setShowNewDialog(true)}
                    className="text-white"
                    style={{ backgroundColor: '#5E2C91' }}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Criar Primeira Avaliação
                  </Button>
                )}
              </CardContent>
            </Card>
          )}
        </div>

        <NewAssessmentDialog
          open={showNewDialog}
          onOpenChange={setShowNewDialog}
          employees={employees}
          departments={departments}
          onSubmit={(data) => createAssessmentsMutation.mutate(data)}
          isSubmitting={createAssessmentsMutation.isPending}
        />

        <ResendModal
          open={showResendDialog}
          onOpenChange={setShowResendDialog}
          departments={departments}
          pendingCount={pendingAssessments.length}
          onResend={(data) => resendInvitationsMutation.mutate(data)}
          isSubmitting={resendInvitationsMutation.isPending}
        />

        <RemindersConfigModal
          open={showRemindersDialog}
          onOpenChange={setShowRemindersDialog}
          assessment={selectedGroupForReminders}
          onSave={(data) => updateReminderConfigMutation.mutate(data)}
          isSubmitting={updateReminderConfigMutation.isPending}
        />

        <Dialog open={showLinksDialog} onOpenChange={setShowLinksDialog}>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>✅ Avaliações Criadas com Sucesso</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <Alert className="bg-blue-50 border-blue-200">
                <AlertDescription className="text-blue-900">
                  <p className="font-semibold mb-2">📋 Links de Avaliação Gerados</p>
                  <p className="text-sm">
                    Os links abaixo foram gerados para cada colaborador. Você pode copiá-los e enviá-los manualmente por e-mail, WhatsApp ou qualquer outro canal de comunicação. Os colaboradores deverão usar CPF e data de nascimento para identificação.
                  </p>
                </AlertDescription>
              </Alert>

              <div className="space-y-3">
                {generatedLinks.map((item, index) => (
                  <Card key={index} className="border-2">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <p className="font-semibold text-gray-900">{item.employee}</p>
                          <p className="text-sm text-gray-600">{item.email}</p>
                          <p className="text-xs text-gray-500">{item.phone}</p>
                          <div className="mt-2 p-2 bg-gray-50 rounded border text-xs font-mono break-all">
                            {item.link}
                          </div>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            navigator.clipboard.writeText(item.link);
                            toast.success('Link copiado!');
                          }}
                        >
                          Copiar Link
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t">
                <Button
                  variant="outline"
                  onClick={() => {
                    const allLinks = generatedLinks.map(item => 
                      `${item.employee} (${item.email}${item.phone ? `, ${item.phone}` : ''}): ${item.link}`
                    ).join('\n\n');
                    navigator.clipboard.writeText(allLinks);
                    toast.success('Todos os links copiados!');
                  }}
                >
                  Copiar Todos os Links
                </Button>
                <Button onClick={() => setShowLinksDialog(false)}>
                  Fechar
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}