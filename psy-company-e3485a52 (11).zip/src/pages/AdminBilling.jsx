import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Navigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Download, RefreshCw, Send, CheckCircle } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";
import { generateBillingPreview } from "../components/billing/BillingEngine";
import BillingKPIs from "../components/billing/BillingKPIs";

export default function AdminBilling() {
  const [user, setUser] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const [competencia, setCompetencia] = useState(format(new Date(), 'yyyy-MM'));
  const [calculando, setCalculando] = useState(false);
  const [previews, setPreviews] = useState([]);
  const [divergencias, setDivergencias] = useState([]);

  const queryClient = useQueryClient();

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  const { data: consultorias = [] } = useQuery({
    queryKey: ['consultorias-billing'],
    queryFn: () => base44.entities.Consultoria.list(),
    enabled: user?.user_role === 'admin',
  });

  const { data: contratos = [] } = useQuery({
    queryKey: ['contratos-consultoria'],
    queryFn: () => base44.entities.ContratoConsultoria.filter({ status: 'ATIVO' }),
    enabled: user?.user_role === 'admin',
  });

  const { data: empresas = [] } = useQuery({
    queryKey: ['all-companies-billing'],
    queryFn: () => base44.entities.Company.list(),
    enabled: user?.user_role === 'admin',
  });

  const { data: colaboradores = [] } = useQuery({
    queryKey: ['all-employees-billing'],
    queryFn: () => base44.entities.Employee.list(),
    enabled: user?.user_role === 'admin',
  });

  const handleGerarPrevia = async () => {
    setCalculando(true);
    try {
      const result = await generateBillingPreview({
        competencia,
        emitenteTipo: 'ADMIN',
        emitenteId: null,
        targets: consultorias.filter(c => c.status === 'ativo'),
        contratos,
        baseData: {
          empresas,
          colaboradores
        },
        base44
      });

      setPreviews(result.previews);
      setDivergencias(result.divergencias);
      toast.success(`Prévia gerada para ${result.previews.length} consultorias`);
    } catch (error) {
      console.error('Erro ao gerar prévia:', error);
      toast.error('Erro ao gerar prévia de faturamento');
    } finally {
      setCalculando(false);
    }
  };

  if (loading) {
    return <div className="p-8">Carregando...</div>;
  }

  if (!user || user.user_role !== 'admin') {
    return <Navigate to="/" />;
  }

  return (
    <div className="p-4 md:p-8 min-h-screen" style={{ backgroundColor: '#F8F6FB' }}>
      <div className="max-w-[1800px] mx-auto space-y-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold" style={{ color: '#2E2E2E' }}>
              Faturamento Admin iMental
            </h1>
            <p className="text-gray-500 mt-2">
              Gestão de faturamento para consultorias parceiras
            </p>
          </div>
        </div>

        <Card className="shadow-md">
          <CardContent className="p-6">
            <div className="flex flex-wrap gap-4 items-end">
              <div className="flex-1 min-w-[200px]">
                <label className="text-sm font-medium text-gray-700 mb-2 block">
                  Competência
                </label>
                <Input
                  type="month"
                  value={competencia}
                  onChange={(e) => setCompetencia(e.target.value)}
                />
              </div>
              
              <Button 
                onClick={handleGerarPrevia}
                disabled={calculando}
                variant="outline"
                style={{ borderColor: '#4B2672', color: '#4B2672' }}
              >
                <RefreshCw className={`w-4 h-4 mr-2 ${calculando ? 'animate-spin' : ''}`} />
                {calculando ? 'Calculando...' : 'Gerar Prévia'}
              </Button>

              <Button
                onClick={() => toast.info('Funcionalidade em desenvolvimento')}
                disabled={previews.length === 0}
                className="text-white"
                style={{ backgroundColor: '#4B2672' }}
              >
                <CheckCircle className="w-4 h-4 mr-2" />
                Autorizar e Emitir
              </Button>

              <Button
                onClick={() => toast.info('Funcionalidade em desenvolvimento')}
                disabled={previews.length === 0}
                variant="outline"
                style={{ borderColor: '#00B37E', color: '#00B37E' }}
              >
                <Send className="w-4 h-4 mr-2" />
                Enviar E-mails
              </Button>

              <Button
                onClick={() => toast.info('Funcionalidade em desenvolvimento')}
                disabled={previews.length === 0}
                variant="outline"
              >
                <Download className="w-4 h-4 mr-2" />
                Exportar CSV
              </Button>
            </div>
          </CardContent>
        </Card>

        <BillingKPIs faturas={previews} divergencias={divergencias} />

        <Card className="shadow-md">
          <CardHeader>
            <CardTitle>Lista de Faturamento — Prévia</CardTitle>
          </CardHeader>
          <CardContent>
            {previews.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="text-left p-3 text-sm font-semibold">Consultoria</th>
                      <th className="text-center p-3 text-sm font-semibold">Modelo</th>
                      <th className="text-center p-3 text-sm font-semibold">Base</th>
                      <th className="text-right p-3 text-sm font-semibold">Valor Bruto</th>
                      <th className="text-center p-3 text-sm font-semibold">Desconto</th>
                      <th className="text-right p-3 text-sm font-semibold">Valor Líquido</th>
                      <th className="text-center p-3 text-sm font-semibold">Vencimento</th>
                    </tr>
                  </thead>
                  <tbody>
                    {previews.map((preview, idx) => (
                      <tr key={idx} className="border-t hover:bg-gray-50">
                        <td className="p-3">
                          <p className="font-semibold">{preview.alvo_nome}</p>
                        </td>
                        <td className="p-3 text-center text-sm">
                          {preview.modelo_cobranca.replace(/_/g, ' ')}
                        </td>
                        <td className="p-3 text-center text-sm">
                          {preview.meta?.base_calculo?.descricao || '—'}
                        </td>
                        <td className="p-3 text-right font-medium">
                          {preview.valor_bruto.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                        </td>
                        <td className="p-3 text-center text-sm">
                          {preview.desconto_percent > 0 ? `${preview.desconto_percent}%` : '—'}
                        </td>
                        <td className="p-3 text-right font-bold text-green-600">
                          {preview.valor_liquido.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                        </td>
                        <td className="p-3 text-center text-sm">
                          {format(new Date(preview.vencimento_em), 'dd/MM/yyyy')}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-500 mb-4">Nenhuma prévia gerada</p>
                <Button onClick={handleGerarPrevia} style={{ backgroundColor: '#4B2672', color: 'white' }}>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Gerar Prévia Agora
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}