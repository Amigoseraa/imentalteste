import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Shield, 
  Clock, 
  CheckCircle, 
  PlayCircle, 
  AlertCircle,
  Eye,
  ArrowLeft,
  HelpCircle,
  Volume2,
  Sun
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import ConsentTerm from "../components/respond/ConsentTerm";

export default function CollaboratorPortal() {
  const { slug } = useParams();
  const navigate = useNavigate();
  
  const [step, setStep] = useState('loading'); // loading, auth, portal, error
  const [employee, setEmployee] = useState(null);
  const [company, setCompany] = useState(null);
  const [assessments, setAssessments] = useState([]);
  const [cpf, setCpf] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [error, setError] = useState('');
  const [attemptCount, setAttemptCount] = useState(0);
  const [selectedAssessment, setSelectedAssessment] = useState(null);
  const [showConsent, setShowConsent] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const [isImpersonating, setIsImpersonating] = useState(false);

  useEffect(() => {
    loadEmployee();
    
    // Check if impersonating
    const urlParams = new URLSearchParams(window.location.search);
    setIsImpersonating(urlParams.get('impersonate') === 'true');
  }, [slug]);

  const loadEmployee = async () => {
    setStep('loading');
    try {
      const employees = await base44.entities.Employee.filter({ slug_publico: slug });
      
      if (employees.length === 0) {
        setError('Link inválido ou expirado. Entre em contato com o RH.');
        setStep('error');
        return;
      }

      const emp = employees[0];
      
      if (emp.status !== 'active') {
        setError('Este colaborador não está mais ativo. Entre em contato com o RH.');
        setStep('error');
        return;
      }

      setEmployee(emp);

      const compData = await base44.entities.Company.filter({ id: emp.company_id });
      if (compData.length > 0) {
        setCompany(compData[0]);
      }

      // Check if already authenticated
      const stored = localStorage.getItem(`collab_auth_${slug}`);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed.exp > Date.now() && parsed.employee_id === emp.id) {
          await loadAssessments(emp.id);
          setStep('portal');
          return;
        }
      }

      setStep('auth');
    } catch (err) {
      console.error(err);
      setError('Erro ao carregar informações. Tente novamente.');
      setStep('error');
    }
  };

  const loadAssessments = async (employeeId) => {
    try {
      const allAssessments = await base44.entities.Assessment.filter({ 
        employee_id: employeeId 
      }, '-created_date');
      setAssessments(allAssessments);
    } catch (err) {
      console.error('Error loading assessments:', err);
    }
  };

  const handleAuth = async () => {
    if (attemptCount >= 5) {
      setError('Número máximo de tentativas excedido. Tente novamente em 15 minutos.');
      return;
    }

    const cleanCpf = cpf.replace(/\D/g, '');
    const employeeCpf = employee.cpf?.replace(/\D/g, '');

    if (cleanCpf === employeeCpf && birthDate === employee.birth_date) {
      // Store auth
      localStorage.setItem(`collab_auth_${slug}`, JSON.stringify({
        employee_id: employee.id,
        exp: Date.now() + (30 * 24 * 60 * 60 * 1000) // 30 dias
      }));

      await loadAssessments(employee.id);
      setStep('portal');
    } else {
      setAttemptCount(prev => prev + 1);
      setError('Dados incorretos. Verifique seu CPF e data de nascimento.');
    }
  };

  const handleStartAssessment = async (assessment) => {
    if (isImpersonating) {
      alert('Modo visualização: não é possível iniciar avaliações');
      return;
    }

    // Check if term was accepted
    if (!assessment.term_accepted) {
      setSelectedAssessment(assessment);
      setShowConsent(true);
    } else {
      // Go directly to questions
      navigate(`/respond/${assessment.assessment_token}`);
    }
  };

  const handleConsentAccept = async () => {
    try {
      await base44.entities.Assessment.update(selectedAssessment.id, {
        term_accepted: true,
        term_accepted_at: new Date().toISOString()
      });
      setShowConsent(false);
      navigate(`/respond/${selectedAssessment.assessment_token}`);
    } catch (err) {
      console.error('Error accepting term:', err);
      alert('Erro ao registrar aceite. Tente novamente.');
    }
  };

  const getAssessmentStatus = (assessment) => {
    if (assessment.completed_at) return 'completed';
    if (assessment.prima_responses && Object.keys(assessment.prima_responses).length > 0) return 'in_progress';
    return 'pending';
  };

  const getEstimatedTime = (assessmentType) => {
    if (!assessmentType) return '5-10 min';
    const types = assessmentType.split(',');
    const times = {
      'PHQ-9': 3,
      'GAD-7': 2,
      'PRIMA-EF': 10,
      'HSE-IT': 12,
      'JCQ': 8
    };
    const total = types.reduce((sum, t) => sum + (times[t] || 5), 0);
    return `~${total} min`;
  };

  if (step === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-gray-100">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  if (step === 'error') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-gray-100 p-4">
        <Card className="max-w-md w-full">
          <CardContent className="p-8 text-center">
            <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Acesso Negado</h2>
            <p className="text-gray-600">{error}</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (step === 'auth') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-gray-100 p-4">
        <Card className="max-w-md w-full">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <CardTitle className="text-2xl font-bold">Identificação do Colaborador</CardTitle>
            <p className="text-gray-600 text-sm mt-2">
              Usamos seu CPF e data de nascimento apenas para confirmar sua identidade.
              Suas respostas são confidenciais.
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            {error && (
              <Alert className="bg-red-50 border-red-200">
                <AlertDescription className="text-red-800">
                  {error}
                </AlertDescription>
              </Alert>
            )}

            <div>
              <Label htmlFor="cpf">CPF *</Label>
              <Input
                id="cpf"
                value={cpf}
                onChange={(e) => {
                  const value = e.target.value.replace(/\D/g, '');
                  const formatted = value
                    .replace(/(\d{3})(\d)/, '$1.$2')
                    .replace(/(\d{3})(\d)/, '$1.$2')
                    .replace(/(\d{3})(\d{1,2})$/, '$1-$2');
                  setCpf(formatted);
                  setError('');
                }}
                placeholder="000.000.000-00"
                maxLength={14}
                className="text-lg"
              />
            </div>

            <div>
              <Label htmlFor="birthDate">Data de Nascimento *</Label>
              <Input
                id="birthDate"
                type="date"
                value={birthDate}
                onChange={(e) => {
                  setBirthDate(e.target.value);
                  setError('');
                }}
                className="text-lg"
              />
            </div>

            <Button
              onClick={handleAuth}
              disabled={!cpf || !birthDate}
              className="w-full bg-blue-600 hover:bg-blue-700 text-lg py-6"
            >
              Continuar
            </Button>

            {attemptCount > 0 && attemptCount < 5 && (
              <p className="text-sm text-gray-500 text-center">
                Tentativas restantes: {5 - attemptCount}
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  // Portal view
  const pendingAssessments = assessments.filter(a => getAssessmentStatus(a) === 'pending');
  const inProgressAssessments = assessments.filter(a => getAssessmentStatus(a) === 'in_progress');
  const completedAssessments = assessments.filter(a => getAssessmentStatus(a) === 'completed');

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-gray-100">
      {isImpersonating && (
        <div className="bg-blue-600 text-white px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Eye className="w-5 h-5" />
            <div>
              <p className="font-semibold">Visualizando como: {employee.name}</p>
              <p className="text-xs text-blue-100">Modo Gestor (somente leitura)</p>
            </div>
          </div>
          <Button 
            variant="outline" 
            className="bg-white text-blue-600 hover:bg-blue-50"
            onClick={() => window.close()}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar ao Painel
          </Button>
        </div>
      )}

      <div className="max-w-5xl mx-auto p-4 py-8 space-y-6">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <Shield className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900">Olá, {employee.name.split(' ')[0]}! 👋</h1>
          <p className="text-gray-600 mt-2">
            Aqui você encontra as avaliações de saúde e bem-estar enviadas para você.
            Suas respostas são confidenciais.
          </p>
        </div>

        {/* Welcome Banner */}
        <Alert className="bg-blue-50 border-blue-200">
          <AlertDescription className="text-blue-900">
            <strong>Obrigado por participar!</strong> Leva poucos minutos e ajuda a melhorar o ambiente de trabalho. 
            Suas respostas são anônimas e tratadas de forma agregada.
          </AlertDescription>
        </Alert>

        {/* Pending Assessments */}
        {pendingAssessments.length > 0 && (
          <div>
            <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
              <Clock className="w-5 h-5 text-orange-500" />
              Pendentes ({pendingAssessments.length})
            </h2>
            <div className="grid gap-4">
              {pendingAssessments.map(assessment => (
                <Card key={assessment.id} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg text-gray-900 mb-2">
                          {assessment.assessment_name || 'Avaliação de Bem-Estar'}
                        </h3>
                        <div className="flex flex-wrap gap-2 mb-3">
                          {assessment.assessment_type?.split(',').map((type, idx) => (
                            <Badge key={idx} variant="outline" className="bg-blue-50 text-blue-700">
                              {type}
                            </Badge>
                          ))}
                        </div>
                        <div className="flex items-center gap-4 text-sm text-gray-600">
                          <span className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            {getEstimatedTime(assessment.assessment_type)}
                          </span>
                          {assessment.due_date && (
                            <span className="flex items-center gap-1">
                              <AlertCircle className="w-4 h-4 text-orange-500" />
                              Prazo: {new Date(assessment.due_date).toLocaleDateString('pt-BR')}
                            </span>
                          )}
                        </div>
                      </div>
                      <Button
                        onClick={() => handleStartAssessment(assessment)}
                        className="bg-blue-600 hover:bg-blue-700"
                        disabled={isImpersonating}
                      >
                        <PlayCircle className="w-4 h-4 mr-2" />
                        Começar Agora
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* In Progress */}
        {inProgressAssessments.length > 0 && (
          <div>
            <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
              <PlayCircle className="w-5 h-5 text-blue-500" />
              Em Andamento ({inProgressAssessments.length})
            </h2>
            <div className="grid gap-4">
              {inProgressAssessments.map(assessment => (
                <Card key={assessment.id} className="border-blue-200 hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg text-gray-900 mb-2">
                          {assessment.assessment_name || 'Avaliação de Bem-Estar'}
                        </h3>
                        <div className="flex flex-wrap gap-2 mb-3">
                          {assessment.assessment_type?.split(',').map((type, idx) => (
                            <Badge key={idx} variant="outline" className="bg-blue-50 text-blue-700">
                              {type}
                            </Badge>
                          ))}
                        </div>
                        <p className="text-sm text-gray-600">Você já começou esta avaliação</p>
                      </div>
                      <Button
                        onClick={() => !isImpersonating && navigate(`/respond/${assessment.assessment_token}`)}
                        variant="outline"
                        className="border-blue-600 text-blue-600"
                        disabled={isImpersonating}
                      >
                        Retomar
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Completed */}
        {completedAssessments.length > 0 && (
          <div>
            <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-green-500" />
              Concluídas ({completedAssessments.length})
            </h2>
            <div className="grid gap-4">
              {completedAssessments.map(assessment => (
                <Card key={assessment.id} className="bg-gray-50">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg text-gray-900 mb-2">
                          {assessment.assessment_name || 'Avaliação de Bem-Estar'}
                        </h3>
                        <div className="flex flex-wrap gap-2 mb-3">
                          {assessment.assessment_type?.split(',').map((type, idx) => (
                            <Badge key={idx} variant="outline" className="bg-gray-200 text-gray-700">
                              {type}
                            </Badge>
                          ))}
                        </div>
                        <p className="text-sm text-gray-600">
                          Enviada em {new Date(assessment.completed_at).toLocaleDateString('pt-BR')} às {new Date(assessment.completed_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      </div>
                      <Badge className="bg-green-100 text-green-800">
                        <CheckCircle className="w-4 h-4 mr-1" />
                        Concluída
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Empty State */}
        {assessments.length === 0 && (
          <Card>
            <CardContent className="p-12 text-center">
              <AlertCircle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                Nenhuma Avaliação Disponível
              </h3>
              <p className="text-gray-600">
                Não há avaliações ativas para você no momento.
              </p>
            </CardContent>
          </Card>
        )}

        {/* Help Section */}
        <div className="flex justify-center gap-4 pt-6">
          <Button
            variant="outline"
            onClick={() => setShowHelp(true)}
            className="gap-2"
          >
            <HelpCircle className="w-4 h-4" />
            Como Funciona?
          </Button>
        </div>
      </div>

      {/* Consent Modal */}
      {showConsent && selectedAssessment && (
        <ConsentTerm
          company={company}
          onAccept={handleConsentAccept}
          onDecline={() => setShowConsent(false)}
        />
      )}

      {/* Help Modal */}
      <Dialog open={showHelp} onOpenChange={setShowHelp}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Como Funciona?</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-blue-600 font-bold">1</span>
              </div>
              <div>
                <h4 className="font-semibold mb-1">Tempo de Resposta</h4>
                <p className="text-sm text-gray-600">
                  Cada avaliação leva de 5 a 15 minutos. Você pode pausar e retomar quando quiser.
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-blue-600 font-bold">2</span>
              </div>
              <div>
                <h4 className="font-semibold mb-1">Confidencialidade</h4>
                <p className="text-sm text-gray-600">
                  Suas respostas são totalmente confidenciais e anônimas. Ninguém verá suas respostas individuais.
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-blue-600 font-bold">3</span>
              </div>
              <div>
                <h4 className="font-semibold mb-1">Pausar e Retomar</h4>
                <p className="text-sm text-gray-600">
                  Pode fechar e voltar depois. Suas respostas são salvas automaticamente.
                </p>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}