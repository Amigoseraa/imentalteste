
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Navigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Building2, Users, Briefcase, TrendingUp, DollarSign, Activity, AlertCircle, FileText } from "lucide-react";
import PageHeader from "../components/common/PageHeader";
import { getEffectiveContext } from "../components/utils/impersonationContext";
import IMScoreKPIs from "../components/dashboard/IMScoreKPIs";
import SeverityDistribution from "../components/dashboard/SeverityDistribution";
import CategoryRadarChart from "../components/dashboard/CategoryRadarChart";
import TemporalEvolution from "../components/dashboard/TemporalEvolution";
import DepartmentRanking from "../components/dashboard/DepartmentRanking";
import TopRisks from "../components/dashboard/TopRisks";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function ConsultoriaDashboard() {
  const [user, setUser] = React.useState(null);
  const [context, setContext] = React.useState(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
        
        const effectiveContext = getEffectiveContext(userData);
        setContext(effectiveContext);
        
        console.log('=== ConsultoriaDashboard ===');
        console.log('Effective context:', effectiveContext);
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  const { data: consultoria } = useQuery({
    queryKey: ['consultoria', context?.consultoria_id],
    queryFn: async () => {
      if (!context?.consultoria_id) return null;
      const consultorias = await base44.entities.Consultoria.filter({ id: context.consultoria_id });
      return consultorias[0] || null;
    },
    enabled: !!context?.consultoria_id,
  });

  const { data: companies = [] } = useQuery({
    queryKey: ['companies', context?.consultoria_id],
    queryFn: async () => {
      if (!context?.consultoria_id) return [];
      return await base44.entities.Company.filter({ consultoria_id: context.consultoria_id });
    },
    enabled: !!context?.consultoria_id,
    initialData: [],
  });

  const { data: employees = [] } = useQuery({
    queryKey: ['employees-consultoria', context?.consultoria_id],
    queryFn: async () => {
      if (!context?.consultoria_id) return [];
      const allEmployees = await base44.entities.Employee.list();
      return allEmployees.filter(e => 
        companies.some(c => c.id === e.company_id) && e.status === 'active'
      );
    },
    enabled: !!context?.consultoria_id && companies.length > 0,
    initialData: [],
  });

  const { data: assessments = [] } = useQuery({
    queryKey: ['assessments-consultoria', context?.consultoria_id],
    queryFn: async () => {
      if (!context?.consultoria_id) return [];
      const allAssessments = await base44.entities.Assessment.list();
      return allAssessments.filter(a => 
        companies.some(c => c.id === a.company_id)
      );
    },
    enabled: !!context?.consultoria_id && companies.length > 0,
    initialData: [],
  });

  const { data: faturas = [] } = useQuery({
    queryKey: ['faturas-consultoria', context?.consultoria_id],
    queryFn: async () => {
      if (!context?.consultoria_id) return [];
      return await base44.entities.Fatura.filter({ 
        alvo_id: context.consultoria_id,
        alvo_tipo: 'CONSULTORIA'
      });
    },
    enabled: !!context?.consultoria_id,
    initialData: [],
  });

  const { data: departments = [] } = useQuery({
    queryKey: ['departments-consultoria', context?.consultoria_id],
    queryFn: async () => {
      if (!context?.consultoria_id || companies.length === 0) return [];
      const allDepartments = await base44.entities.Department.list();
      return allDepartments.filter(d => 
        companies.some(c => c.id === d.company_id)
      );
    },
    enabled: !!context?.consultoria_id && companies.length > 0,
    initialData: [],
  });

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[1,2,3,4].map(i => (
              <div key={i} className="h-32 bg-gray-200 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!user || !context || !context.consultoria_id) {
    return (
      <div className="p-8">
        <Alert className="border-yellow-200 bg-yellow-50">
          <AlertCircle className="h-4 w-4 text-yellow-600" />
          <AlertDescription className="text-yellow-800">
            Não há uma consultoria selecionada para visualização.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  // Calcular KPIs
  const completedAssessments = assessments.filter(a => a.completed_at);
  const engajamento = employees.length > 0
    ? ((completedAssessments.length / employees.length) * 100).toFixed(1)
    : 0;

  const currentMonth = new Date().toISOString().slice(0, 7);
  const faturamentoMes = faturas
    .filter(f => f.competencia === currentMonth && f.status === 'PAGA')
    .reduce((acc, f) => acc + (f.valor_liquido || 0), 0);

  return (
    <div className="p-4 md:p-8 min-h-screen" style={{ backgroundColor: '#F8F6FB' }}>
      <PageHeader
        title={consultoria?.nome_fantasia || 'Dashboard da Consultoria'}
        description="Visão geral do desempenho e indicadores"
      />

      {/* KPIs Principais */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="shadow-md hover:shadow-lg transition-all">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <Building2 className="w-4 h-4" style={{ color: '#4B2672' }} />
              Empresas Ativas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-4xl font-bold" style={{ color: '#4B2672' }}>
              {companies.filter(c => c.status === 'active').length}
            </p>
            <p className="text-xs text-gray-500 mt-1">
              {companies.length} total
            </p>
          </CardContent>
        </Card>

        <Card className="shadow-md hover:shadow-lg transition-all">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <Users className="w-4 h-4 text-blue-600" />
              Colaboradores
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-4xl font-bold text-blue-600">
              {employees.length}
            </p>
            <p className="text-xs text-gray-500 mt-1">
              Cadastrados ativos
            </p>
          </CardContent>
        </Card>

        <Card className="shadow-md hover:shadow-lg transition-all">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <FileText className="w-4 h-4 text-green-600" />
              Avaliações
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-4xl font-bold text-green-600">
              {completedAssessments.length}
            </p>
            <p className="text-xs text-gray-500 mt-1">
              {engajamento}% de engajamento
            </p>
          </CardContent>
        </Card>

        <Card className="shadow-md hover:shadow-lg transition-all">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <DollarSign className="w-4 h-4" style={{ color: '#FFD84D' }} />
              Faturamento
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-4xl font-bold" style={{ color: '#FFD84D' }}>
              {faturamentoMes.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 0 })}
            </p>
            <p className="text-xs text-gray-500 mt-1">
              Mês atual
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Dashboards de Saúde Mental */}
      {completedAssessments.length > 0 ? (
        <>
          <IMScoreKPIs assessments={completedAssessments} employees={employees} />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
            <SeverityDistribution assessments={completedAssessments} />
            <CategoryRadarChart assessments={completedAssessments} />
          </div>

          <div className="mt-6">
            <TemporalEvolution assessments={completedAssessments} />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
            <DepartmentRanking 
              assessments={completedAssessments} 
              employees={employees} 
              companies={companies}
              departments={departments}
            />
            <TopRisks assessments={completedAssessments} />
          </div>
        </>
      ) : (
        <Alert className="mt-6">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Ainda não há avaliações concluídas. Os gráficos e insights aparecerão assim que houver dados disponíveis.
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}
