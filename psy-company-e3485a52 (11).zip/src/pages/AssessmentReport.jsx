import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Navigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowLeft, 
  Download, 
  FileText, 
  Users, 
  CheckCircle,
  Clock,
  TrendingUp,
  Copy,
  Bell
} from "lucide-react";
import { 
  LineChart, 
  Line, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip as RechartsTooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from "recharts";
import { format, parseISO } from "date-fns";
import { toast } from "sonner";

export default function AssessmentReport() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [companyId, setCompanyId] = useState(null);

  const urlParams = new URLSearchParams(window.location.search);
  const groupName = urlParams.get('group');
  const assessmentId = urlParams.get('id');

  useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
        
        const impersonationData = localStorage.getItem('admin_impersonation');
        if (impersonationData) {
          const parsed = JSON.parse(impersonationData);
          setCompanyId(parsed.company_id);
        } else {
          setCompanyId(userData.company_id);
        }
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  const { data: assessments } = useQuery({
    queryKey: ['assessment-group', companyId, groupName],
    queryFn: async () => {
      if (!companyId) return [];
      const all = await base44.entities.Assessment.filter({ company_id: companyId }, '-created_date');
      return all.filter(a => a.assessment_name === groupName);
    },
    enabled: !!companyId && !!groupName,
    initialData: [],
  });

  const { data: employees } = useQuery({
    queryKey: ['employees', companyId],
    queryFn: async () => {
      if (!companyId) return [];
      return await base44.entities.Employee.filter({ company_id: companyId });
    },
    enabled: !!companyId,
    initialData: [],
  });

  const { data: departments } = useQuery({
    queryKey: ['departments', companyId],
    queryFn: async () => {
      if (!companyId) return [];
      return await base44.entities.Department.filter({ company_id: companyId });
    },
    enabled: !!companyId,
    initialData: [],
  });

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[1,2,3,4].map(i => (
              <div key={i} className="h-32 bg-gray-200 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" />;
  }

  if (!companyId || !groupName) {
    return (
      <div className="p-8">
        <Card>
          <CardContent className="p-6">
            <p className="text-gray-600">Parâmetros inválidos. Volte para a lista de avaliações.</p>
            <Button className="mt-4" onClick={() => window.history.back()}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const total = assessments.length;
  const completed = assessments.filter(a => a.completed_at).length;
  const pending = total - completed;
  const responseRate = total > 0 ? ((completed / total) * 100).toFixed(1) : 0;

  const firstAssessment = assessments[0];
  const questionnaires = firstAssessment?.assessment_type?.split(',').map(q => q.trim()) || [];

  // Dados para gráfico de progresso temporal
  const getTemporalData = () => {
    const dailyData = {};
    assessments.forEach(a => {
      if (a.completed_at) {
        const day = format(parseISO(a.completed_at), 'dd/MM');
        dailyData[day] = (dailyData[day] || 0) + 1;
      }
    });
    
    return Object.entries(dailyData).map(([day, count]) => ({
      day,
      respostas: count
    }));
  };

  // Dados para gráfico por departamento
  const getDepartmentData = () => {
    const deptData = {};
    departments.forEach(dept => {
      deptData[dept.id] = {
        name: dept.name,
        completed: 0,
        pending: 0
      };
    });

    assessments.forEach(a => {
      if (deptData[a.department_id]) {
        if (a.completed_at) {
          deptData[a.department_id].completed++;
        } else {
          deptData[a.department_id].pending++;
        }
      }
    });

    return Object.values(deptData).filter(d => d.completed + d.pending > 0);
  };

  // Dados de distribuição de status
  const getStatusData = () => [
    { name: 'Respondidas', value: completed, color: '#10b981' },
    { name: 'Pendentes', value: pending, color: '#f59e0b' }
  ];

  const handleCopyLink = async () => {
    const link = `${window.location.origin}/Responder`;
    try {
      await navigator.clipboard.writeText(link);
      toast.success('Link copiado. Compartilhe com seus colaboradores.');
    } catch (error) {
      toast.error('Não foi possível copiar o link.');
    }
  };

  const handleExportPDF = () => {
    window.print();
    toast.success('Use a função de impressão do navegador para salvar como PDF');
  };

  const handleExportCSV = () => {
    const headers = ['Colaborador', 'Departamento', 'Status', 'Data de Envio', 'Data de Resposta'];
    const rows = assessments.map(a => {
      const employee = employees.find(e => e.id === a.employee_id);
      const dept = departments.find(d => d.id === a.department_id);
      return [
        employee?.name || 'Desconhecido',
        dept?.name || '-',
        a.completed_at ? 'Respondido' : 'Pendente',
        format(parseISO(a.created_date), 'dd/MM/yyyy HH:mm'),
        a.completed_at ? format(parseISO(a.completed_at), 'dd/MM/yyyy HH:mm') : '-'
      ];
    });

    const csvContent = [headers, ...rows].map(row => row.join(',')).join('\n');
    const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `Relatorio_${groupName.replace(/[^a-z0-9]/gi, '_')}_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    
    toast.success('CSV exportado com sucesso');
  };

  const temporalData = getTemporalData();
  const departmentData = getDepartmentData();
  const statusData = getStatusData();

  return (
    <div className="p-4 md:p-8 min-h-screen" style={{ backgroundColor: '#F8F8FA' }}>
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <Button 
              variant="ghost" 
              onClick={() => window.history.back()}
              className="mb-4"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar
            </Button>
            <h1 className="text-3xl font-bold" style={{ color: '#2B2240' }}>
              Relatório: {groupName}
            </h1>
            <div className="flex flex-wrap gap-3 mt-3">
              <Badge variant="outline">
                <FileText className="w-3 h-3 mr-1" />
                Criada em: {firstAssessment && format(parseISO(firstAssessment.created_date), 'dd/MM/yyyy HH:mm')}
              </Badge>
              {firstAssessment?.due_date && (
                <Badge variant="outline">
                  <Clock className="w-3 h-3 mr-1" />
                  Prazo: {format(parseISO(firstAssessment.due_date), 'dd/MM/yyyy')}
                </Badge>
              )}
              {questionnaires.map((q, idx) => (
                <Badge key={idx} style={{ backgroundColor: '#EFE6F8', color: '#5E2C91' }}>
                  {q}
                </Badge>
              ))}
            </div>
          </div>
          <div className="flex flex-wrap gap-3">
            <Button variant="outline" onClick={handleCopyLink}>
              <Copy className="w-4 h-4 mr-2" />
              Copiar Link
            </Button>
            <Button variant="outline" onClick={handleExportCSV}>
              <Download className="w-4 h-4 mr-2" />
              Exportar CSV
            </Button>
            <Button variant="outline" onClick={handleExportPDF}>
              <FileText className="w-4 h-4 mr-2" />
              Exportar PDF
            </Button>
          </div>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="shadow-md">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center">
                  <Users className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Total Convidados</p>
                  <p className="text-2xl font-bold text-gray-900">{total}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-md">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-green-50 rounded-xl flex items-center justify-center">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Respondidas</p>
                  <p className="text-2xl font-bold text-green-600">{completed}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-md">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-orange-50 rounded-xl flex items-center justify-center">
                  <Clock className="w-6 h-6 text-orange-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Pendentes</p>
                  <p className="text-2xl font-bold text-orange-600">{pending}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-md">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ backgroundColor: '#EFE6F8' }}>
                  <TrendingUp className="w-6 h-6" style={{ color: '#5E2C91' }} />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Taxa de Resposta</p>
                  <p className="text-2xl font-bold" style={{ color: '#5E2C91' }}>{responseRate}%</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Gráficos */}
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Progresso Temporal */}
          <Card className="shadow-md">
            <CardHeader>
              <CardTitle>Progresso ao Longo do Tempo</CardTitle>
            </CardHeader>
            <CardContent>
              {temporalData.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={temporalData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" />
                    <YAxis />
                    <RechartsTooltip />
                    <Legend />
                    <Line type="monotone" dataKey="respostas" stroke="#5E2C91" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center text-gray-400">
                  Aguardando respostas para gerar gráfico
                </div>
              )}
            </CardContent>
          </Card>

          {/* Distribuição de Status */}
          <Card className="shadow-md">
            <CardHeader>
              <CardTitle>Distribuição de Status</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={statusData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {statusData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <RechartsTooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Respostas por Departamento */}
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle>Respostas por Departamento</CardTitle>
          </CardHeader>
          <CardContent>
            {departmentData.length > 0 ? (
              <ResponsiveContainer width="100%" height={350}>
                <BarChart data={departmentData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <RechartsTooltip />
                  <Legend />
                  <Bar dataKey="completed" fill="#10b981" name="Respondidas" />
                  <Bar dataKey="pending" fill="#f59e0b" name="Pendentes" />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[350px] flex items-center justify-center text-gray-400">
                Aguardando dados
              </div>
            )}
          </CardContent>
        </Card>

        {/* Nota de Privacidade */}
        <Card className="border-2" style={{ borderColor: '#A77BCA', backgroundColor: '#EFE6F8' }}>
          <CardContent className="p-6">
            <p className="text-sm" style={{ color: '#5E2C91' }}>
              <strong>🔒 Privacidade:</strong> Este relatório apresenta apenas dados agregados e anônimos. 
              Pontuações individuais e informações clínicas são confidenciais e acessíveis apenas por profissionais de saúde autorizados.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}