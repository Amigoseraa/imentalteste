import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate, Navigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Plus,
  Search,
  Edit,
  Trash2,
  Eye,
  Video,
  FileText,
  TrendingUp,
  Star,
  Clock,
  Filter,
  Download,
  MessageSquare,
  CheckCircle,
  XCircle
} from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

export default function MediaLibraryAdmin() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [visibilityFilter, setVisibilityFilter] = useState("all");
  const [deleteDialog, setDeleteDialog] = useState(null);
  const [moderationDialog, setModerationDialog] = useState(null);
  const [user, setUser] = React.useState(null);
  const [loading, setLoading] = React.useState(true);

  // Verificar permissões
  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  // Buscar todos os conteúdos
  const { data: allMedia = [], isLoading } = useQuery({
    queryKey: ['media-items-admin'],
    queryFn: () => base44.entities.MediaItem.list('-created_date'),
    initialData: [],
  });

  // Buscar analytics agregados
  const { data: analytics = [] } = useQuery({
    queryKey: ['media-analytics'],
    queryFn: () => base44.entities.MediaAnalyticsSnapshot.list('-date'),
    initialData: [],
  });

  // Buscar feedbacks pendentes
  const { data: pendingFeedbacks = [] } = useQuery({
    queryKey: ['media-feedbacks-pending'],
    queryFn: () => base44.entities.MediaFeedback.filter({ status: 'pending' }),
    initialData: [],
  });

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.MediaItem.delete(id),
    onSuccess: () => {
      toast.success("Conteúdo excluído com sucesso!");
      queryClient.invalidateQueries({ queryKey: ['media-items-admin'] });
      setDeleteDialog(null);
    },
    onError: () => {
      toast.error("Erro ao excluir conteúdo");
    }
  });

  // Publish/Unpublish mutation
  const togglePublishMutation = useMutation({
    mutationFn: ({ id, newStatus }) => 
      base44.entities.MediaItem.update(id, {
        status: newStatus,
        published_at: newStatus === 'published' ? new Date().toISOString() : null
      }),
    onSuccess: () => {
      toast.success("Status atualizado!");
      queryClient.invalidateQueries({ queryKey: ['media-items-admin'] });
    }
  });

  // Moderate feedback
  const moderateFeedbackMutation = useMutation({
    mutationFn: ({ id, status }) => 
      base44.entities.MediaFeedback.update(id, { 
        status,
        moderated_at: new Date().toISOString()
      }),
    onSuccess: () => {
      toast.success("Comentário moderado!");
      queryClient.invalidateQueries({ queryKey: ['media-feedbacks-pending'] });
      setModerationDialog(null);
    }
  });

  // Verificar se é admin
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#F8F6FB' }}>
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 mx-auto mb-4" style={{ borderColor: '#4B2672' }}></div>
          <p className="text-sm text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  if (!user || user.role !== 'admin') {
    return <Navigate to="/MediaLibraryColaborador" replace />;
  }

  // Filtrar conteúdos
  const filteredMedia = allMedia.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.description?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || item.status === statusFilter;
    const matchesType = typeFilter === 'all' || item.type === typeFilter;
    const matchesVisibility = visibilityFilter === 'all' || item.visibility === visibilityFilter;
    
    return matchesSearch && matchesStatus && matchesType && matchesVisibility;
  });

  // KPIs
  const totalPublished = allMedia.filter(m => m.status === 'published').length;
  const totalDrafts = allMedia.filter(m => m.status === 'draft').length;
  const totalViews = allMedia.reduce((sum, m) => sum + (m.view_count || 0), 0);
  const avgRating = allMedia.length > 0
    ? (allMedia.reduce((sum, m) => sum + (m.avg_rating || 0), 0) / allMedia.length).toFixed(1)
    : 0;

  const getStatusBadge = (status) => {
    return status === 'published' 
      ? <Badge className="bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" />Publicado</Badge>
      : <Badge className="bg-gray-100 text-gray-800"><XCircle className="w-3 h-3 mr-1" />Rascunho</Badge>;
  };

  const getVisibilityBadge = (visibility) => {
    const badges = {
      neutral: <Badge variant="secondary">🌐 Neutro</Badge>,
      mednet: <Badge className="bg-blue-100 text-blue-800">🏥 MedNet</Badge>,
      consultoria: <Badge className="bg-purple-100 text-purple-800">🏢 Consultoria</Badge>,
      empresa: <Badge className="bg-orange-100 text-orange-800">🏭 Empresa</Badge>
    };
    return badges[visibility] || badges.neutral;
  };

  const getTypeBadge = (type) => {
    return type === 'video'
      ? <Badge className="bg-red-100 text-red-800"><Video className="w-3 h-3 mr-1" />Vídeo</Badge>
      : <Badge className="bg-blue-100 text-blue-800"><FileText className="w-3 h-3 mr-1" />E-book</Badge>;
  };

  if (isLoading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[1,2,3,4].map(i => (
              <div key={i} className="h-32 bg-gray-200 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8" style={{ backgroundColor: '#F8F6FB', minHeight: '100vh' }}>
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold" style={{ color: '#2E2E2E' }}>
            Biblioteca de Conteúdos
          </h1>
          <p className="text-gray-500 mt-2">
            Gerencie vídeos e e-books de saúde mental
          </p>
        </div>
        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={() => toast.info('Exportação em desenvolvimento')}
            style={{ borderColor: '#4B2672', color: '#4B2672' }}
          >
            <Download className="w-4 h-4 mr-2" />
            Exportar
          </Button>
          <Button
            onClick={() => navigate(createPageUrl('MediaItemCreate'))}
            className="text-white shadow-lg hover:shadow-xl transition-all"
            style={{ background: 'linear-gradient(135deg, #4B2672 0%, #6B36B4 100%)' }}
          >
            <Plus className="w-4 h-4 mr-2" />
            Novo Conteúdo
          </Button>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="shadow-md hover:shadow-lg transition-shadow">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-green-600" />
              Publicados
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-4xl font-bold text-green-600">{totalPublished}</p>
            <p className="text-xs text-gray-500 mt-1">
              {totalDrafts} rascunhos
            </p>
          </CardContent>
        </Card>

        <Card className="shadow-md hover:shadow-lg transition-shadow">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <Eye className="w-4 h-4 text-blue-600" />
              Visualizações
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-4xl font-bold text-blue-600">{totalViews.toLocaleString('pt-BR')}</p>
            <p className="text-xs text-gray-500 mt-1">
              Total acumulado
            </p>
          </CardContent>
        </Card>

        <Card className="shadow-md hover:shadow-lg transition-shadow">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <Star className="w-4 h-4 text-yellow-600" />
              Avaliação Média
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-4xl font-bold text-yellow-600">{avgRating}</p>
            <p className="text-xs text-gray-500 mt-1">
              De 5 estrelas
            </p>
          </CardContent>
        </Card>

        <Card className="shadow-md hover:shadow-lg transition-shadow">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-orange-600" />
              Comentários Pendentes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-4xl font-bold text-orange-600">{pendingFeedbacks.length}</p>
            <p className="text-xs text-gray-500 mt-1">
              Aguardando moderação
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Filtros */}
      <Card className="shadow-md mb-6">
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div className="relative md:col-span-2">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Buscar por título ou descrição..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os status</SelectItem>
                <SelectItem value="published">Publicados</SelectItem>
                <SelectItem value="draft">Rascunhos</SelectItem>
              </SelectContent>
            </Select>

            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os tipos</SelectItem>
                <SelectItem value="video">Vídeos</SelectItem>
                <SelectItem value="ebook">E-books</SelectItem>
              </SelectContent>
            </Select>

            <Select value={visibilityFilter} onValueChange={setVisibilityFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Visibilidade" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas</SelectItem>
                <SelectItem value="neutral">Neutro</SelectItem>
                <SelectItem value="mednet">MedNet</SelectItem>
                <SelectItem value="consultoria">Consultoria</SelectItem>
                <SelectItem value="empresa">Empresa</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Tabela */}
      <Card className="shadow-md">
        <CardHeader>
          <CardTitle>Conteúdos ({filteredMedia.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50">
                  <TableHead>Conteúdo</TableHead>
                  <TableHead className="text-center">Tipo</TableHead>
                  <TableHead className="text-center">Visibilidade</TableHead>
                  <TableHead className="text-center">Status</TableHead>
                  <TableHead className="text-center">Views</TableHead>
                  <TableHead className="text-center">Rating</TableHead>
                  <TableHead className="text-center">Publicado</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredMedia.map(item => (
                  <TableRow key={item.id} className="hover:bg-gray-50">
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div className="w-16 h-10 rounded overflow-hidden bg-gray-200 flex-shrink-0">
                          {item.cover_url ? (
                            <img src={item.cover_url} alt={item.title} className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center">
                              {item.type === 'video' ? (
                                <Video className="w-4 h-4 text-gray-400" />
                              ) : (
                                <FileText className="w-4 h-4 text-gray-400" />
                              )}
                            </div>
                          )}
                        </div>
                        <div>
                          <p className="font-semibold text-sm">{item.title}</p>
                          {item.duration_sec && (
                            <p className="text-xs text-gray-500">
                              <Clock className="w-3 h-3 inline mr-1" />
                              {Math.floor(item.duration_sec / 60)}min
                            </p>
                          )}
                          {item.pages && (
                            <p className="text-xs text-gray-500">
                              <FileText className="w-3 h-3 inline mr-1" />
                              {item.pages} páginas
                            </p>
                          )}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-center">
                      {getTypeBadge(item.type)}
                    </TableCell>
                    <TableCell className="text-center">
                      {getVisibilityBadge(item.visibility)}
                    </TableCell>
                    <TableCell className="text-center">
                      {getStatusBadge(item.status)}
                    </TableCell>
                    <TableCell className="text-center font-semibold text-blue-600">
                      {item.view_count || 0}
                    </TableCell>
                    <TableCell className="text-center">
                      {item.avg_rating > 0 ? (
                        <span className="flex items-center justify-center gap-1 text-yellow-600 font-semibold">
                          <Star className="w-4 h-4 fill-yellow-400" />
                          {item.avg_rating.toFixed(1)}
                        </span>
                      ) : (
                        <span className="text-gray-400">—</span>
                      )}
                    </TableCell>
                    <TableCell className="text-center text-xs text-gray-500">
                      {item.published_at ? format(new Date(item.published_at), 'dd/MM/yyyy') : '—'}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => window.open(createPageUrl(`MediaPlayer?id=${item.id}`), '_blank')}
                          title="Visualizar"
                        >
                          <Eye className="w-4 h-4 text-gray-600" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => navigate(createPageUrl(`MediaItemEdit?id=${item.id}`))}
                          title="Editar"
                        >
                          <Edit className="w-4 h-4 text-gray-600" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => togglePublishMutation.mutate({
                            id: item.id,
                            newStatus: item.status === 'published' ? 'draft' : 'published'
                          })}
                          title={item.status === 'published' ? 'Despublicar' : 'Publicar'}
                        >
                          {item.status === 'published' ? (
                            <XCircle className="w-4 h-4 text-orange-600" />
                          ) : (
                            <CheckCircle className="w-4 h-4 text-green-600" />
                          )}
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setDeleteDialog(item)}
                          title="Excluir"
                        >
                          <Trash2 className="w-4 h-4 text-red-600" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Dialog de Exclusão */}
      {deleteDialog && (
        <Dialog open={!!deleteDialog} onOpenChange={() => setDeleteDialog(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Confirmar Exclusão</DialogTitle>
            </DialogHeader>
            <p className="text-sm text-gray-600">
              Tem certeza que deseja excluir o conteúdo "{deleteDialog.title}"? Esta ação não pode ser desfeita.
            </p>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDeleteDialog(null)}>
                Cancelar
              </Button>
              <Button
                variant="destructive"
                onClick={() => deleteMutation.mutate(deleteDialog.id)}
                disabled={deleteMutation.isPending}
              >
                {deleteMutation.isPending ? 'Excluindo...' : 'Excluir'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}