
import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Brain, 
  BarChart3, 
  Lock, 
  MessageCircle, 
  CheckCircle, 
  Shield,
  ArrowRight,
  ExternalLink,
  Heart,
  Users,
  TrendingUp
} from "lucide-react";
import { motion } from "framer-motion";
import IMentalLogo from "../components/ui/IMentalLogo";

export default function LandingPage() {
  const [user, setUser] = React.useState(null);
  const [checkingAuth, setCheckingAuth] = React.useState(true);

  React.useEffect(() => {
    const checkAuth = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
      } catch (error) {
        // Não autenticado, está ok para uma página pública
      } finally {
        setCheckingAuth(false);
      }
    };
    checkAuth();
  }, []);

  const handleGoToDashboard = () => {
    if (!user) return;

    if (user.user_role === 'admin') {
      window.location.href = createPageUrl('AdminDashboard');
    } else {
      window.location.href = createPageUrl('Dashboard');
    }
  };

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header Fixo */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm shadow-sm transition-all">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <IMentalLogo variant="dark" size="default" />

            <nav className="hidden md:flex items-center gap-8">
              <button 
                onClick={() => scrollToSection('sobre')}
                className="font-medium transition-colors"
                style={{ color: '#6B6B6B' }}
                onMouseEnter={(e) => e.currentTarget.style.color = '#4B2672'}
                onMouseLeave={(e) => e.currentTarget.style.color = '#6B6B6B'}
              >
                Sobre
              </button>
              <button 
                onClick={() => scrollToSection('funcionalidades')}
                className="font-medium transition-colors"
                style={{ color: '#6B6B6B' }}
                onMouseEnter={(e) => e.currentTarget.style.color = '#4B2672'}
                onMouseLeave={(e) => e.currentTarget.style.color = '#6B6B6B'}
              >
                Funcionalidades
              </button>
              <a 
                href="https://imental.com.br/contato"
                target="_blank"
                rel="noopener noreferrer"
                className="font-medium transition-colors"
                style={{ color: '#6B6B6B' }}
                onMouseEnter={(e) => e.currentTarget.style.color = '#4B2672'}
                onMouseLeave={(e) => e.currentTarget.style.color = '#6B6B6B'}
              >
                Contato
              </a>

              {!checkingAuth && (
                user ? (
                  <Button 
                    onClick={handleGoToDashboard}
                    className="font-bold text-white rounded-lg px-7 py-6 hover:shadow-lg transition-all"
                    style={{ backgroundColor: '#4B2672' }}
                    onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#3C1E5B'}
                    onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#4B2672'}
                  >
                    Ir para meu painel
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                ) : (
                  <a href="/login">
                    <Button 
                      className="font-bold text-white rounded-lg px-7 py-6 hover:shadow-lg transition-all"
                      style={{ backgroundColor: '#4B2672' }}
                      onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#3C1E5B'}
                      onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#4B2672'}
                    >
                      Entrar na Plataforma
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </a>
                )
              )}
            </nav>

            {/* Mobile Menu Button */}
            <div className="md:hidden">
              {!checkingAuth && (user ? (
                <Button 
                  size="sm"
                  onClick={handleGoToDashboard}
                  className="font-bold text-white"
                  style={{ backgroundColor: '#4B2672' }}
                >
                  Meu Painel
                </Button>
              ) : (
                <a href="/login">
                  <Button 
                    size="sm"
                    className="font-bold text-white"
                    style={{ backgroundColor: '#4B2672' }}
                  >
                    Entrar
                  </Button>
                </a>
              ))}
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section 
        className="pt-32 pb-20 px-4 sm:px-6 lg:px-8"
        style={{ background: 'linear-gradient(180deg, #F8F6FB 0%, #FFFFFF 100%)' }}
      >
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="mb-8">
                <IMentalLogo variant="dark" size="large" />
              </div>
              
              <h2 className="text-2xl md:text-3xl font-semibold mb-4" style={{ color: '#A57CE0' }}>
                Plataforma de Gestão de Saúde Mental e Riscos Psicossociais
              </h2>
              <p className="text-xl mb-6" style={{ color: '#FFD84D', fontWeight: 600 }}>
                💡 Dados que cuidam de pessoas.
              </p>
              <p className="text-lg mb-8 leading-relaxed" style={{ color: '#6B6B6B' }}>
                A iMental combina ciência, tecnologia e psicologia ocupacional
                para apoiar empresas na promoção de um ambiente de trabalho mais saudável e produtivo.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 mb-4">
                <a href="/login">
                  <Button 
                    size="lg"
                    className="font-bold text-white text-lg px-8 py-6 rounded-lg hover:shadow-xl transition-all w-full sm:w-auto"
                    style={{ backgroundColor: '#4B2672' }}
                    onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#3C1E5B'}
                    onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#4B2672'}
                  >
                    Entrar na Plataforma
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </a>
                <Button 
                  size="lg"
                  variant="outline"
                  className="text-lg px-8 py-6 rounded-lg border-2 font-semibold w-full sm:w-auto"
                  style={{ borderColor: '#4B2672', color: '#4B2672' }}
                  onClick={() => scrollToSection('como-funciona')}
                >
                  Saiba mais
                </Button>
              </div>
              <p className="text-sm flex items-center gap-2" style={{ color: '#6B6B6B' }}>
                <Lock className="w-4 h-4" style={{ color: '#4B2672' }} />
                Acesso seguro e confidencial
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="hidden lg:block"
            >
              <div className="bg-white rounded-2xl shadow-2xl p-8" style={{ borderTop: '4px solid #4B2672' }}>
                <div className="space-y-6">
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 rounded-full flex items-center justify-center" style={{ backgroundColor: '#F8F6FB' }}>
                      <BarChart3 className="w-8 h-8" style={{ color: '#4B2672' }} />
                    </div>
                    <div>
                      <div className="text-3xl font-bold" style={{ color: '#4B2672' }}>85.2</div>
                      <div className="text-sm" style={{ color: '#6B6B6B' }}>Índice de Bem-Estar Corporativo</div>
                    </div>
                  </div>
                  <div className="h-px" style={{ backgroundColor: '#E8E3F5' }} />
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 rounded-lg" style={{ backgroundColor: '#F8F6FB' }}>
                      <div className="text-2xl font-bold" style={{ color: '#4B2672' }}>92%</div>
                      <div className="text-xs" style={{ color: '#6B6B6B' }}>Engajamento</div>
                    </div>
                    <div className="p-4 rounded-lg" style={{ backgroundColor: '#FFD84D' }}>
                      <div className="text-2xl font-bold" style={{ color: '#4B2672' }}>12%</div>
                      <div className="text-xs" style={{ color: '#4B2672' }}>Risco Alto</div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Benefícios Section */}
      <section id="funcionalidades" className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-4" style={{ color: '#2E2E2E' }}>
              🌿 Por que escolher a <span style={{ color: '#4B2672' }}>iMental</span>?
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: Brain,
                title: 'Avaliações Científicas',
                description: 'Instrumentos reconhecidos como PRIMA-EF, PHQ-9, GAD-7 e HSE-IT, com base científica e validação internacional.'
              },
              {
                icon: BarChart3,
                title: 'Dashboards Estratégicos',
                description: 'Indicadores claros e em tempo real sobre bem-estar, engajamento e riscos psicossociais.'
              },
              {
                icon: Lock,
                title: 'Confidencialidade Garantida',
                description: 'Dados 100% anônimos e tratados conforme a LGPD.'
              },
              {
                icon: Heart,
                title: 'Ações e Insights',
                description: 'Transforme dados em programas de saúde mental personalizados e sustentáveis.'
              }
            ].map((benefit, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card 
                  className="h-full hover:shadow-xl transition-all duration-300 border-2 hover:-translate-y-1"
                  style={{ borderColor: '#E8E3F5' }}
                >
                  <CardContent className="p-8">
                    <div 
                      className="w-16 h-16 rounded-full flex items-center justify-center mb-6"
                      style={{ backgroundColor: '#4B2672' }}
                    >
                      <benefit.icon className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-xl font-bold mb-3" style={{ color: '#2E2E2E' }}>
                      {benefit.title}
                    </h3>
                    <p className="leading-relaxed" style={{ color: '#6B6B6B' }}>
                      {benefit.description}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Como Funciona Section */}
      <section 
        id="como-funciona"
        className="py-20 px-4 sm:px-6 lg:px-8"
        style={{ backgroundColor: '#F8F6FB' }}
      >
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-4" style={{ color: '#2E2E2E' }}>
              🔄 Como a <span style={{ color: '#4B2672' }}>iMental</span> funciona
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8 mb-12">
            {[
              {
                number: '1',
                title: 'Diagnóstico',
                description: 'Os colaboradores respondem questionários breves de forma simples e segura.'
              },
              {
                number: '2',
                title: 'Análise Inteligente',
                description: 'A plataforma consolida resultados e gera indicadores psicossociais e de bem-estar (IBC).'
              },
              {
                number: '3',
                title: 'Ação e Melhoria Contínua',
                description: 'As empresas recebem insights e planos de ação estratégicos para fortalecer a saúde mental corporativa.'
              }
            ].map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                className="text-center"
              >
                <div 
                  className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 text-3xl font-bold text-white"
                  style={{ backgroundColor: '#4B2672' }}
                >
                  {step.number}
                </div>
                <h3 className="text-2xl font-bold mb-4" style={{ color: '#2E2E2E' }}>
                  {step.title}
                </h3>
                <p className="text-lg leading-relaxed" style={{ color: '#6B6B6B' }}>
                  {step.description}
                </p>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <p className="text-2xl font-semibold mb-8" style={{ color: '#A57CE0' }}>
              "Ciência e tecnologia a serviço do bem-estar humano."
            </p>
            <Button 
              size="lg"
              className="font-bold text-white text-lg px-8 py-6 rounded-lg hover:shadow-xl transition-all"
              style={{ backgroundColor: '#4B2672' }}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#3C1E5B'}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#4B2672'}
              onClick={() => scrollToSection('contato')}
            >
              Quero conhecer mais
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Segurança Section */}
      <section id="sobre" className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <div 
              className="w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-8"
              style={{ backgroundColor: '#4B2672' }}
            >
              <Shield className="w-12 h-12 text-white" />
            </div>
            <h2 className="text-4xl md:text-5xl font-bold mb-6" style={{ color: '#2E2E2E' }}>
              🔐 Segurança e Credibilidade
            </h2>
            <div className="space-y-6 text-lg leading-relaxed" style={{ color: '#6B6B6B' }}>
              <p>
                <strong style={{ color: '#4B2672' }}>Desenvolvida pela iMental</strong>, referência em 
                Psicologia Ocupacional e Saúde Mental Corporativa.
              </p>
              <p>
                A iMental segue as diretrizes da <strong>NR-01 e NR-17</strong>, utilizando metodologias 
                reconhecidas internacionalmente (PRIMA-EF, HSE, JCQ, PHQ-9 e GAD-7).
              </p>
              <p>
                <strong>100% aderente à LGPD</strong>, com dados criptografados e apresentação de resultados 
                apenas de forma anônima e agregada.
              </p>
            </div>
            <div className="mt-12 p-6 rounded-xl" style={{ backgroundColor: '#F8F6FB' }}>
              <p className="text-lg font-semibold" style={{ color: '#4B2672' }}>
                📚 Baseada em instrumentos validados cientificamente, com ética e responsabilidade corporativa.
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer 
        id="contato"
        className="py-12 px-4 sm:px-6 lg:px-8 text-white"
        style={{ backgroundColor: '#2E2E2E' }}
      >
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 mb-8">
            <div>
              <div className="mb-4">
                <IMentalLogo variant="light" size="default" />
              </div>
              <p className="mb-2" style={{ color: '#A57CE0' }}>Inteligência em Saúde Mental Corporativa</p>
              <p className="text-sm mb-4" style={{ color: '#A57CE0' }}>Uma solução completa para gestão de saúde mental</p>
              <a 
                href="https://imental.com.br"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 transition-colors"
                style={{ color: '#FFD84D' }}
                onMouseEnter={(e) => e.currentTarget.style.color = '#FFF'}
                onMouseLeave={(e) => e.currentTarget.style.color = '#FFD84D'}
              >
                www.imental.com.br
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-4">Links Úteis</h3>
              <div className="space-y-2">
                <a href="#" className="block transition-colors" style={{ color: '#A57CE0' }}>
                  Política de Privacidade
                </a>
                <a href="#" className="block transition-colors" style={{ color: '#A57CE0' }}>
                  Termos de Uso
                </a>
                <a href="mailto:contato@imental.com.br" className="block transition-colors" style={{ color: '#A57CE0' }}>
                  Contato
                </a>
              </div>
            </div>
          </div>
          <div className="border-t pt-8 text-center" style={{ borderColor: 'rgba(255,255,255,0.1)' }}>
            <p style={{ color: '#A57CE0' }}>
              © 2025 <strong style={{ color: '#FFD84D' }}>iMental</strong> – Todos os direitos reservados.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export const pageConfig = {
  requireAuth: false,
  isPublic: true
};
