
import React, { useState, useEffect } from "react";
import { useLocation, Navigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { LogOut, ChevronDown, Menu, X, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Alert, AlertDescription } from "@/components/ui/alert";
import IMentalLogo from "./components/ui/IMentalLogo";
import ContextSelector from "./components/layout/ContextSelector";
import SidebarFactory from "./components/layout/SidebarFactory";
import { getEffectiveContext } from "./components/utils/impersonationContext";

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [user, setUser] = useState(null);
  const [context, setContext] = useState(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Páginas que não precisam de layout NEM autenticação
  const noLayoutPages = ['LandingPage', 'Responder', 'ResponderAvaliacao', 'Error403', 'Error404', 'PostLogin', 'ActivateMasterUser'];
  
  // Determinar se precisa de layout ANTES de usar hooks
  const needsLayout = !noLayoutPages.includes(currentPageName);

  useEffect(() => {
    // Só carrega usuário se precisar de layout
    if (!needsLayout) {
      setLoading(false);
      return;
    }

    const loadUserAndMenu = async () => {
      try {
        setError(null);
        
        const isAuthenticated = await base44.auth.isAuthenticated();
        
        if (!isAuthenticated) {
          setError('authentication');
          setLoading(false);
          return;
        }

        const userData = await base44.auth.me();
        console.log('User data loaded:', userData);
        setUser(userData);

        // Usar getEffectiveContext para obter o contexto correto
        const effectiveContext = getEffectiveContext(userData);
        console.log('Effective context:', effectiveContext);
        setContext(effectiveContext);
      } catch (error) {
        console.error('Error loading user:', error);
        
        if (error.message?.includes('Network Error') || error.message?.includes('401')) {
          setError('authentication');
        } else {
          setError('unknown');
        }
      } finally {
        setLoading(false);
      }
    };

    loadUserAndMenu();
  }, [location.pathname, currentPageName, needsLayout]);

  const handleContextChange = async () => {
    setLoading(true);
    setError(null);
    
    await new Promise(resolve => setTimeout(resolve, 100));
    
    try {
      const userData = await base44.auth.me();
      setUser(userData);

      const effectiveContext = getEffectiveContext(userData);
      setContext(effectiveContext);
    } catch (error) {
      console.error('Error reloading:', error);
      
      if (error.message?.includes('Network Error') || error.message?.includes('401')) {
        setError('authentication');
      } else {
        setError('unknown');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      localStorage.removeItem('admin_impersonation');
      await base44.auth.logout();
    } catch (error) {
      console.error('Error logging out:', error);
      window.location.href = '/login';
    }
  };

  // Se não precisa de layout, renderizar direto
  if (!needsLayout) {
    return <div data-testid="page-content">{children}</div>;
  }

  if (error === 'authentication' && !loading) {
    localStorage.removeItem('admin_impersonation');
    return <Navigate to="/login" replace />;
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#F8F6FB' }}>
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 mx-auto mb-4" style={{ borderColor: '#4B2672' }}></div>
          <p className="text-sm text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  if (error === 'unknown') {
    return (
      <div className="min-h-screen flex items-center justify-center p-4" style={{ backgroundColor: '#F8F6FB' }}>
        <div className="max-w-md w-full">
          <Alert className="border-red-200 bg-red-50">
            <AlertCircle className="h-4 w-4 text-red-600" />
            <AlertDescription className="text-red-800">
              <p className="font-semibold mb-2">Erro ao carregar aplicação</p>
              <p className="text-sm mb-4">
                Houve um problema ao carregar seus dados. Por favor, tente novamente.
              </p>
              <div className="flex gap-2">
                <Button 
                  onClick={() => window.location.reload()} 
                  size="sm"
                  className="text-white"
                  style={{ backgroundColor: '#4B2672' }}
                >
                  Recarregar Página
                </Button>
                <Button 
                  onClick={handleLogout} 
                  variant="outline" 
                  size="sm"
                >
                  Fazer Login Novamente
                </Button>
              </div>
            </AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  if (!user || !context) {
    return <Navigate to="/login" replace />;
  }

  console.log('Rendering layout with context:', context);

  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: '#F8F6FB' }} data-testid="app-layout">
      {context.original_role === 'admin' && (
        <ContextSelector user={user} onContextChange={handleContextChange} />
      )}

      <div className="flex flex-1">
        <aside 
          className="hidden lg:flex lg:flex-col lg:w-64 border-r"
          style={{ backgroundColor: '#FFFFFF', borderColor: '#E5E1EB' }}
          data-testid="sidebar"
        >
          <div className="p-6 border-b" style={{ borderColor: '#E5E1EB' }}>
            <IMentalLogo size="lg" />
          </div>

          <SidebarFactory role={context.role} context={context} />

          {user && (
            <div className="p-4 border-t" style={{ borderColor: '#E5E1EB' }} data-testid="user-menu">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="w-full flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-gray-50 transition-colors">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center text-white font-semibold" style={{ backgroundColor: '#4B2672' }}>
                      {context.full_name?.charAt(0) || user.email?.charAt(0) || 'U'}
                    </div>
                    <div className="flex-1 text-left min-w-0">
                      <div className="text-sm font-medium truncate" style={{ color: '#4B2672' }}>
                        {context.is_impersonating ? context.full_name : (user.full_name || 'Usuário')}
                      </div>
                      <div className="text-xs truncate" style={{ color: '#6B5B7F' }}>
                        {context.is_impersonating ? `(${context.original_email})` : user.email}
                      </div>
                    </div>
                    <ChevronDown className="w-4 h-4 flex-shrink-0" style={{ color: '#6B5B7F' }} />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>Minha Conta</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout} className="text-red-600 cursor-pointer" data-testid="logout-button">
                    <LogOut className="w-4 h-4 mr-2" />
                    Sair
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          )}
        </aside>

        <div className="lg:hidden fixed top-0 left-0 right-0 z-50 bg-white border-b flex items-center justify-between px-4 py-3" style={{ borderColor: '#E5E1EB' }}>
          <IMentalLogo size="sm" />
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X /> : <Menu />}
          </Button>
        </div>

        {mobileMenuOpen && (
          <div className="lg:hidden fixed inset-0 z-40 bg-white overflow-y-auto" style={{ top: '60px' }}>
            <SidebarFactory role={context.role} context={context} />
            
            {user && (
              <div className="p-4 border-t" style={{ borderColor: '#E5E1EB' }}>
                <div className="flex items-center gap-3 px-4 py-3 rounded-lg" style={{ backgroundColor: '#F8F6FB' }}>
                  <div className="w-10 h-10 rounded-full flex items-center justify-center text-white font-semibold" style={{ backgroundColor: '#4B2672' }}>
                    {context.full_name?.charAt(0) || user.email?.charAt(0) || 'U'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate" style={{ color: '#4B2672' }}>
                      {context.is_impersonating ? context.full_name : (user.full_name || 'Usuário')}
                    </div>
                    <div className="text-xs truncate" style={{ color: '#6B5B7F' }}>
                      {context.is_impersonating ? `(${context.original_email})` : user.email}
                    </div>
                  </div>
                </div>
                <Button 
                  onClick={handleLogout}
                  variant="outline"
                  className="w-full mt-3 text-red-600 border-red-200 hover:bg-red-50"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Sair
                </Button>
              </div>
            )}
          </div>
        )}

        <main className="flex-1 lg:pt-0 pt-16 overflow-x-hidden" data-testid="page-content">
          {children}
        </main>
      </div>
    </div>
  );
}
