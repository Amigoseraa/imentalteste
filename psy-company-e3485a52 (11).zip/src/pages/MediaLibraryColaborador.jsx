import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Search, 
  Play, 
  Clock, 
  Star, 
  Filter,
  BookOpen,
  Video,
  TrendingUp,
  Eye
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function MediaLibraryColaborador() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedType, setSelectedType] = useState("all");
  const [user, setUser] = React.useState(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  // Buscar todos os conteúdos publicados
  const { data: allMedia = [] } = useQuery({
    queryKey: ['media-items-published'],
    queryFn: () => base44.entities.MediaItem.filter({ status: 'published' }),
    initialData: [],
  });

  // Buscar progresso do usuário
  const { data: userProgress = [] } = useQuery({
    queryKey: ['media-progress', user?.email],
    queryFn: () => base44.entities.MediaProgress.filter({ user_id: user?.email }),
    enabled: !!user,
    initialData: [],
  });

  // Buscar assignments do usuário (conteúdos atribuídos)
  const { data: assignments = [] } = useQuery({
    queryKey: ['media-assignments', user?.company_id],
    queryFn: () => base44.entities.MediaAssignment.filter({ company_id: user?.company_id }),
    enabled: !!user?.company_id,
    initialData: [],
  });

  // Filtrar conteúdos visíveis para o usuário
  const visibleMedia = allMedia.filter(item => {
    // Neutro: sempre visível
    if (item.visibility === 'neutral') return true;
    
    // MedNet: verificar se empresa tem acesso (assumir que sim por enquanto)
    if (item.visibility === 'mednet') return true;
    
    // Consultoria: verificar se empresa pertence à consultoria
    if (item.visibility === 'consultoria' && user?.consultoria_id) {
      return item.consultoria_id === user.consultoria_id;
    }
    
    // Empresa: verificar se é a mesma empresa
    if (item.visibility === 'empresa' && user?.company_id) {
      return item.company_id === user.company_id;
    }
    
    return false;
  });

  // Aplicar filtros
  const filteredMedia = visibleMedia.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.description?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || 
                           (item.categories || []).includes(selectedCategory);
    const matchesType = selectedType === 'all' || item.type === selectedType;
    
    return matchesSearch && matchesCategory && matchesType;
  });

  // Extrair todas as categorias únicas
  const allCategories = [...new Set(visibleMedia.flatMap(item => item.categories || []))];

  // Continuar assistindo (progresso > 0 e < 100)
  const continueWatching = visibleMedia.filter(item => {
    const progress = userProgress.find(p => p.media_id === item.id);
    return progress && progress.progress > 0 && progress.progress < 100;
  });

  // Novos conteúdos (últimos 30 dias)
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
  const newContent = visibleMedia.filter(item => 
    item.published_at && new Date(item.published_at) > thirtyDaysAgo
  ).slice(0, 10);

  // Mais assistidos (por view_count)
  const trending = [...visibleMedia]
    .sort((a, b) => (b.view_count || 0) - (a.view_count || 0))
    .slice(0, 10);

  // Para você (conteúdos atribuídos)
  const assignedMediaIds = assignments.map(a => a.media_id);
  const forYou = visibleMedia.filter(item => assignedMediaIds.includes(item.id));

  const MediaCard = ({ item }) => {
    const progress = userProgress.find(p => p.media_id === item.id);
    const isAssigned = assignedMediaIds.includes(item.id);
    
    const handleClick = () => {
      navigate(createPageUrl(`MediaPlayer?id=${item.id}`));
    };

    return (
      <div
        onClick={handleClick}
        className="group relative cursor-pointer transition-all duration-300 hover:scale-105"
      >
        <div className="relative aspect-video rounded-lg overflow-hidden bg-gray-900">
          {item.cover_url ? (
            <img 
              src={item.cover_url} 
              alt={item.title}
              className="w-full h-full object-cover group-hover:opacity-70 transition-opacity"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-purple-600 to-blue-600">
              {item.type === 'video' ? (
                <Video className="w-16 h-16 text-white opacity-50" />
              ) : (
                <BookOpen className="w-16 h-16 text-white opacity-50" />
              )}
            </div>
          )}
          
          {/* Overlay on hover */}
          <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
            <Play className="w-16 h-16 text-white" />
          </div>

          {/* Progress bar */}
          {progress && progress.progress > 0 && (
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-700">
              <div 
                className="h-full bg-purple-600 transition-all"
                style={{ width: `${progress.progress}%` }}
              />
            </div>
          )}

          {/* Badges */}
          <div className="absolute top-2 left-2 flex gap-2">
            {item.type === 'video' && (
              <Badge className="bg-red-600 text-white">
                <Video className="w-3 h-3 mr-1" />
                Vídeo
              </Badge>
            )}
            {item.type === 'ebook' && (
              <Badge className="bg-blue-600 text-white">
                <BookOpen className="w-3 h-3 mr-1" />
                E-book
              </Badge>
            )}
            {isAssigned && (
              <Badge className="bg-yellow-600 text-white">
                ⭐ Para você
              </Badge>
            )}
          </div>

          {/* Duration/Pages */}
          {item.duration_sec && (
            <div className="absolute top-2 right-2">
              <Badge variant="secondary" className="bg-black/70 text-white">
                <Clock className="w-3 h-3 mr-1" />
                {Math.floor(item.duration_sec / 60)}min
              </Badge>
            </div>
          )}
        </div>

        {/* Info */}
        <div className="mt-3 space-y-1">
          <h3 className="font-semibold text-sm line-clamp-2 group-hover:text-purple-600 transition-colors">
            {item.title}
          </h3>
          {item.description && (
            <p className="text-xs text-gray-600 line-clamp-2">
              {item.description}
            </p>
          )}
          <div className="flex items-center gap-2 text-xs text-gray-500">
            {item.avg_rating > 0 && (
              <div className="flex items-center gap-1">
                <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                <span>{item.avg_rating.toFixed(1)}</span>
              </div>
            )}
            {item.view_count > 0 && (
              <div className="flex items-center gap-1">
                <Eye className="w-3 h-3" />
                <span>{item.view_count}</span>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  const Carousel = ({ title, items, icon: Icon }) => {
    if (items.length === 0) return null;
    
    return (
      <div className="mb-12">
        <div className="flex items-center gap-2 mb-4">
          {Icon && <Icon className="w-5 h-5" style={{ color: '#4B2672' }} />}
          <h2 className="text-2xl font-bold" style={{ color: '#2E2E2E' }}>
            {title}
          </h2>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
          {items.map(item => (
            <MediaCard key={item.id} item={item} />
          ))}
        </div>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#0F0F0F' }}>
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 mx-auto mb-4" style={{ borderColor: '#4B2672' }}></div>
          <p className="text-sm text-gray-400">Carregando biblioteca...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#0F0F0F' }}>
      {/* Hero Banner */}
      <div 
        className="relative h-[60vh] bg-cover bg-center"
        style={{
          backgroundImage: newContent[0]?.cover_url 
            ? `linear-gradient(to top, #0F0F0F, transparent), url(${newContent[0].cover_url})`
            : 'linear-gradient(135deg, #4B2672 0%, #6B36B4 100%)'
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-[#0F0F0F] via-transparent to-transparent" />
        
        <div className="relative h-full flex items-end p-8 md:p-12">
          <div className="max-w-2xl">
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-4">
              Ações de Saúde Mental
            </h1>
            <p className="text-xl text-gray-300 mb-6">
              Vídeos e e-books para apoiar seu bem-estar e desenvolvimento
            </p>
            {newContent[0] && (
              <Button
                onClick={() => navigate(createPageUrl(`MediaPlayer?id=${newContent[0].id}`))}
                size="lg"
                className="text-white"
                style={{ backgroundColor: '#4B2672' }}
              >
                <Play className="w-5 h-5 mr-2" />
                Começar Agora
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="sticky top-0 z-40 bg-[#0F0F0F]/95 backdrop-blur-sm border-b border-gray-800 p-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-500" />
            <Input
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar conteúdos..."
              className="pl-10 bg-gray-900 border-gray-800 text-white placeholder-gray-500"
            />
          </div>
          
          <Select value={selectedType} onValueChange={setSelectedType}>
            <SelectTrigger className="w-full md:w-48 bg-gray-900 border-gray-800 text-white">
              <SelectValue placeholder="Tipo" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os tipos</SelectItem>
              <SelectItem value="video">Vídeos</SelectItem>
              <SelectItem value="ebook">E-books</SelectItem>
            </SelectContent>
          </Select>

          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-full md:w-48 bg-gray-900 border-gray-800 text-white">
              <SelectValue placeholder="Categoria" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas categorias</SelectItem>
              {allCategories.map(cat => (
                <SelectItem key={cat} value={cat}>{cat}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto p-8 space-y-12">
        {/* Continuar Assistindo */}
        {continueWatching.length > 0 && (
          <Carousel 
            title="Continuar Assistindo" 
            items={continueWatching}
            icon={Play}
          />
        )}

        {/* Para Você */}
        {forYou.length > 0 && (
          <Carousel 
            title="Recomendado Para Você" 
            items={forYou}
            icon={Star}
          />
        )}

        {/* Novos Conteúdos */}
        {newContent.length > 0 && (
          <Carousel 
            title="Lançamentos" 
            items={newContent}
          />
        )}

        {/* Mais Assistidos */}
        {trending.length > 0 && (
          <Carousel 
            title="Mais Assistidos" 
            items={trending}
            icon={TrendingUp}
          />
        )}

        {/* Por Categoria */}
        {allCategories.map(category => {
          const categoryItems = visibleMedia.filter(item => 
            (item.categories || []).includes(category)
          ).slice(0, 10);
          
          if (categoryItems.length === 0) return null;
          
          return (
            <Carousel 
              key={category}
              title={category} 
              items={categoryItems}
            />
          );
        })}

        {/* Resultados da Busca */}
        {searchTerm && (
          <div>
            <h2 className="text-2xl font-bold text-white mb-6">
              Resultados para "{searchTerm}"
            </h2>
            {filteredMedia.length > 0 ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
                {filteredMedia.map(item => (
                  <MediaCard key={item.id} item={item} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-400">Nenhum resultado encontrado</p>
              </div>
            )}
          </div>
        )}

        {/* Estado vazio */}
        {!searchTerm && visibleMedia.length === 0 && (
          <div className="text-center py-20">
            <Video className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-400 mb-2">
              Nenhum conteúdo disponível
            </h3>
            <p className="text-gray-500">
              Novos conteúdos serão adicionados em breve
            </p>
          </div>
        )}
      </div>
    </div>
  );
}