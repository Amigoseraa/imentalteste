import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/utils";
import { Card, CardContent } from "@/components/ui/card";
import { Brain } from "lucide-react";

export default function PostLogin() {
  const [status, setStatus] = useState('Redirecionando...');

  useEffect(() => {
    const redirect = async () => {
      try {
        // Tentar obter sessão do usuário
        const user = await base44.auth.me();
        
        if (!user) {
          // Sem sessão, voltar para login
          window.location.href = '/login';
          return;
        }

        // Verificar se há intended URL
        const intended = localStorage.getItem('intended_url');
        
        if (intended) {
          // Validar se é uma rota privada válida
          const privateRoutes = ['/admin', '/empresa', '/Dashboard', '/AdminDashboard', '/Assessments', '/Employees', '/Departments', '/Companies', '/Settings'];
          const isValidPrivate = privateRoutes.some(route => intended.startsWith(route) || intended.includes(route));
          
          if (isValidPrivate) {
            localStorage.removeItem('intended_url');
            setStatus('Retomando sua navegação...');
            window.location.href = intended;
            return;
          }
        }

        // Redirecionar baseado no role
        if (user.user_role === 'admin') {
          setStatus('Redirecionando para Dashboard Admin...');
          window.location.href = createPageUrl('AdminDashboard');
        } else if (user.user_role === 'manager' || user.user_role === 'employee') {
          setStatus('Redirecionando para Dashboard da Empresa...');
          window.location.href = createPageUrl('Dashboard');
        } else {
          // Fallback seguro
          setStatus('Redirecionando para Dashboard...');
          window.location.href = createPageUrl('Dashboard');
        }
      } catch (error) {
        console.error('post-login-error', error);
        setStatus('Erro ao redirecionar. Tentando novamente...');
        setTimeout(() => {
          window.location.href = '/login';
        }, 2000);
      }
    };

    redirect();
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-gray-100 flex items-center justify-center p-4">
      <Card className="max-w-md w-full shadow-xl">
        <CardContent className="p-8 text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-purple-800 rounded-full flex items-center justify-center mx-auto mb-4">
            <Brain className="w-8 h-8 text-white" />
          </div>
          <div className="w-12 h-12 border-4 border-purple-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <h2 className="text-xl font-bold mb-2" style={{ color: '#2B2240' }}>
            {status}
          </h2>
          <p className="text-gray-600 text-sm">
            Por favor aguarde...
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

PostLogin.isPublic = true;