import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Navigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Building2, Edit, Trash2, Users, Download, Upload, Info } from "lucide-react";
import PageHeader from "../components/common/PageHeader";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { toast } from "sonner";

export default function Departments() {
  const [user, setUser] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const [companyId, setCompanyId] = React.useState(null);
  const [showDialog, setShowDialog] = useState(false);
  const [editingDept, setEditingDept] = useState(null);
  const [formData, setFormData] = useState({
    name: "",
    manager_id: ""
  });

  const queryClient = useQueryClient();

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
        
        const impersonationData = localStorage.getItem('admin_impersonation');
        if (impersonationData) {
          const parsed = JSON.parse(impersonationData);
          setCompanyId(parsed.company_id);
        } else {
          setCompanyId(userData.company_id);
        }
      } catch (error) {
        console.error("Error loading user:", error);
        toast.error("Erro ao carregar dados do usuário.");
      } finally {
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  const { data: company } = useQuery({
    queryKey: ['company', companyId],
    queryFn: async () => {
      if (!companyId) return null;
      const companies = await base44.entities.Company.filter({ id: companyId });
      return companies[0] || null;
    },
    enabled: !!companyId,
  });

  const { data: departments } = useQuery({
    queryKey: ['departments', companyId],
    queryFn: async () => {
      if (!companyId) return [];
      return await base44.entities.Department.filter(
        { company_id: companyId }
      );
    },
    enabled: !!companyId,
    initialData: [],
  });

  const { data: employees } = useQuery({
    queryKey: ['employees', companyId],
    queryFn: async () => {
      if (!companyId) return [];
      return await base44.entities.Employee.filter({ 
        company_id: companyId,
        status: 'active'
      });
    },
    enabled: !!companyId,
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: async (data) => {
      const departmentData = {
        company_id: companyId,
        name: data.name
      };
      
      if (data.manager_id) {
        departmentData.manager_id = data.manager_id;
      }
      
      return await base44.entities.Department.create(departmentData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['departments', companyId] });
      setShowDialog(false);
      resetForm();
      toast.success('Departamento criado com sucesso!');
    },
    onError: (error) => {
      toast.error(error.message || 'Erro ao criar departamento');
    }
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }) => await base44.entities.Department.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['departments', companyId] });
      setShowDialog(false);
      setEditingDept(null);
      resetForm();
      toast.success('Departamento atualizado com sucesso!');
    },
    onError: (error) => {
      toast.error(error.message || 'Erro ao atualizar departamento');
    }
  });

  const deleteMutation = useMutation({
    mutationFn: async (id) => await base44.entities.Department.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['departments', companyId] });
      toast.success('Departamento removido com sucesso!');
    },
    onError: (error) => {
      toast.error(error.message || 'Erro ao remover departamento');
    }
  });

  const resetForm = () => {
    setFormData({ name: "", manager_id: "" });
    setEditingDept(null);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingDept) {
      updateMutation.mutate({ id: editingDept.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleEdit = (dept) => {
    setEditingDept(dept);
    setFormData({
      name: dept.name,
      manager_id: dept.manager_id || ""
    });
    setShowDialog(true);
  };

  const getEmployeeCount = (departmentId) => {
    return employees.filter(e => e.department_id === departmentId).length;
  };

  const activeEmployees = employees.filter(e => e.status === 'active');
  const hasActiveEmployees = activeEmployees.length > 0;

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  if (!user || (user.user_role !== 'admin' && user.user_role !== 'manager')) {
    return <Navigate to="/" />;
  }

  if (!companyId || !company) {
    return (
      <div className="p-8">
        <Card className="border-2 border-yellow-200 bg-yellow-50">
          <CardContent className="p-6">
            <p className="text-yellow-800 font-medium">
              Não há uma empresa selecionada para visualização. Por favor, entre em contato com o suporte ou selecione uma empresa.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const breadcrumbs = [
    { label: "iMental", href: "Dashboard" },
    { label: company.name, href: "Dashboard" },
    { label: "Departamentos" }
  ];

  const actions = [
    <Button 
      key="import"
      variant="outline"
      disabled
    >
      <Upload className="w-4 h-4 mr-2" />
      Importar CSV
    </Button>,
    <Button 
      key="export"
      variant="outline"
      disabled={departments.length === 0}
    >
      <Download className="w-4 h-4 mr-2" />
      Exportar
    </Button>,
    <Button 
      key="new"
      onClick={() => setShowDialog(true)}
      className="text-white"
      style={{ backgroundColor: '#4B2672' }}
    >
      <Plus className="w-4 h-4 mr-2" />
      Novo Departamento
    </Button>
  ];

  return (
    <div className="p-4 md:p-8 min-h-screen" style={{ backgroundColor: '#F8F6FB' }}>
      <div className="max-w-7xl mx-auto space-y-8">
        <PageHeader
          title="Departamentos"
          description="Organize sua empresa por áreas ou setores"
          breadcrumbs={breadcrumbs}
          actions={actions}
        />

        <Card className="shadow-md">
          <CardHeader>
            <CardTitle>Todos os Departamentos ({departments.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {departments.length > 0 ? (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead>Nome</TableHead>
                      <TableHead>Gestor</TableHead>
                      <TableHead>Colaboradores</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {departments.map((dept) => {
                      const manager = employees.find(e => e.id === dept.manager_id);
                      
                      return (
                        <TableRow key={dept.id} className="hover:bg-gray-50">
                          <TableCell className="font-medium">
                            <div className="flex items-center gap-2">
                              <Building2 className="w-4 h-4 text-gray-400" />
                              {dept.name}
                            </div>
                          </TableCell>
                          <TableCell className="text-sm">
                            {manager ? manager.name : '—'}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1 text-sm text-gray-600">
                              <Users className="w-4 h-4" />
                              {getEmployeeCount(dept.id)}
                            </div>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                onClick={() => handleEdit(dept)}
                                title="Editar"
                              >
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => {
                                  if (confirm(`Tem certeza que deseja excluir "${dept.name}"? Isso não remove os colaboradores vinculados.`)) {
                                    deleteMutation.mutate(dept.id);
                                  }
                                }}
                                title="Excluir"
                              >
                                <Trash2 className="w-4 h-4 text-red-500" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="text-center py-16">
                <Building2 className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-700 mb-2">
                  Nenhum departamento cadastrado
                </h3>
                <p className="text-gray-500 mb-6">
                  Organize sua empresa por áreas ou setores
                </p>
                <Button 
                  onClick={() => setShowDialog(true)}
                  className="text-white"
                  style={{ backgroundColor: '#4B2672' }}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Criar Primeiro Departamento
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        <Dialog open={showDialog} onOpenChange={(open) => {
          setShowDialog(open);
          if (!open) resetForm();
        }}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingDept ? 'Editar Departamento' : 'Novo Departamento'}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="name">Nome do Departamento *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  placeholder="Ex: Recursos Humanos, TI, Vendas..."
                  required
                />
              </div>
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Label htmlFor="manager">
                    Gestor do Departamento {hasActiveEmployees && '*'}
                  </Label>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Info className="w-4 h-4 text-gray-400 cursor-help" />
                      </TooltipTrigger>
                      <TooltipContent className="max-w-xs">
                        <p className="text-sm">
                          {hasActiveEmployees 
                            ? 'Selecione um colaborador ativo da sua empresa para ser o gestor' 
                            : 'Cadastre colaboradores posteriormente e edite este departamento para vincular um gestor'
                          }
                        </p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                {hasActiveEmployees ? (
                  <Select 
                    value={formData.manager_id} 
                    onValueChange={(value) => setFormData({...formData, manager_id: value})}
                    required={hasActiveEmployees}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o gestor" />
                    </SelectTrigger>
                    <SelectContent>
                      {activeEmployees.map(employee => (
                        <SelectItem key={employee.id} value={employee.id}>
                          <div className="flex flex-col">
                            <span className="font-medium">{employee.name}</span>
                            {employee.position && (
                              <span className="text-xs text-gray-500">{employee.position}</span>
                            )}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : (
                  <div className="p-3 bg-gray-50 border border-gray-200 rounded-md">
                    <p className="text-sm text-gray-500">
                      Nenhum colaborador ativo cadastrado. Você poderá definir o gestor depois.
                    </p>
                  </div>
                )}
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <Button type="button" variant="outline" onClick={() => setShowDialog(false)}>
                  Cancelar
                </Button>
                <Button 
                  type="submit" 
                  disabled={createMutation.isPending || updateMutation.isPending}
                  className="text-white"
                  style={{ backgroundColor: '#4B2672' }}
                >
                  {createMutation.isPending || updateMutation.isPending
                    ? 'Salvando...' 
                    : editingDept ? 'Salvar Alterações' : 'Criar Departamento'
                  }
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}