
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Navigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Download, Calendar, BarChart3, Brain } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

import AdminKPIs from "../components/admin-dashboard/AdminKPIs";
import TemporalEvolutionChart from "../components/admin-dashboard/TemporalEvolutionChart";
import ConsultoriaRanking from "../components/admin-dashboard/ConsultoriaRanking";
import EngagementRanking from "../components/admin-dashboard/EngagementRanking";
import IntelligentAlerts from "../components/admin-dashboard/IntelligentAlerts";
import PerformanceInsights from "../components/admin-dashboard/PerformanceInsights";

import FinancialKPIs from "../components/admin-dashboard/FinancialKPIs";
import RevenueEvolutionChart from "../components/admin-dashboard/RevenueEvolutionChart";
import RevenueDistributionChart from "../components/admin-dashboard/RevenueDistributionChart";
import ConsultoriaRevenueRanking from "../components/admin-dashboard/ConsultoriaRevenueRanking";
import FinancialOperationalMetrics from "../components/admin-dashboard/FinancialOperationalMetrics";

import TechnicalKPIs from "../components/admin-dashboard/TechnicalKPIs";
import SeverityDistribution from "../components/admin-dashboard/SeverityDistribution";
import RiskDistributionPie from "../components/admin-dashboard/RiskDistributionPie";
import TechnicalTemporalEvolution from "../components/admin-dashboard/TechnicalTemporalEvolution";
import TechnicalInsights from "../components/admin-dashboard/TechnicalInsights";

export default function AdminDashboard() {
  const [user, setUser] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const [selectedPeriod, setSelectedPeriod] = useState('all');
  const [activeTab, setActiveTab] = useState('performance');

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  const { data: consultorias = [], isLoading: loadingConsultorias } = useQuery({
    queryKey: ['consultorias'],
    queryFn: () => base44.entities.Consultoria.list('-created_date'),
    enabled: user?.user_role === 'admin',
    initialData: [],
  });

  const { data: companies = [], isLoading: loadingCompanies } = useQuery({
    queryKey: ['all-companies'],
    queryFn: () => base44.entities.Company.list('-created_date'),
    enabled: user?.user_role === 'admin',
    initialData: [],
  });

  const { data: assessments = [], isLoading: loadingAssessments } = useQuery({
    queryKey: ['all-assessments'],
    queryFn: () => base44.entities.Assessment.list('-created_date'),
    enabled: user?.user_role === 'admin',
    initialData: [],
  });

  const { data: employees = [], isLoading: loadingEmployees } = useQuery({
    queryKey: ['all-employees'],
    queryFn: () => base44.entities.Employee.list(),
    enabled: user?.user_role === 'admin',
    initialData: [],
  });

  const { data: faturas = [], isLoading: loadingFaturas } = useQuery({
    queryKey: ['all-faturas'],
    queryFn: () => base44.entities.Fatura.list(),
    enabled: user?.user_role === 'admin',
    initialData: [],
  });

  const handleExportReport = async () => {
    const reportData = {
      generated_at: new Date().toISOString(),
      period: selectedPeriod,
      mode: activeTab,
      consultorias_count: consultorias.filter(c => c.status === 'ativo').length,
      companies_count: companies.length,
      assessments_count: assessments.filter(a => a.completed_at).length,
      employees_count: employees.length,
      summary: `Relatório ${activeTab === 'performance' ? 'de Performance' : activeTab === 'financial' ? 'Financeiro' : 'Técnico'} - iMental`
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Relatorio_Admin_iMental_${activeTab}_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  if (loading || loadingConsultorias || loadingCompanies || loadingAssessments || loadingEmployees || loadingFaturas) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[1,2,3,4].map(i => (
              <div key={i} className="h-32 bg-gray-200 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!user || user.user_role !== 'admin') {
    return <Navigate to="/" />;
  }

  const completedAssessments = Array.isArray(assessments) ? assessments.filter(a => a.completed_at) : [];

  // Detectar se há dados no sistema
  const hasData = consultorias.length > 0 || companies.length > 0 || employees.length > 0 || assessments.length > 0;

  return (
    <div className="p-4 md:p-8 min-h-screen" style={{ backgroundColor: '#F8F6FB' }}>
      <div className="max-w-[1800px] mx-auto space-y-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold" style={{ color: '#2E2E2E' }}>
              Dashboard Geral – Administrador iMental
            </h1>
            <p className="text-gray-500 mt-2">
              Visão consolidada do ecossistema, faturamento e dados de saúde mental corporativa
            </p>
            {!hasData && (
              <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <p className="text-sm text-blue-800">
                  🚀 Sistema limpo e pronto para começar. Cadastre sua primeira consultoria para ver os indicadores em ação!
                </p>
              </div>
            )}
          </div>
          <div className="flex gap-3">
            <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
              <SelectTrigger className="w-48">
                <Calendar className="w-4 h-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os períodos</SelectItem>
                <SelectItem value="30">Últimos 30 dias</SelectItem>
                <SelectItem value="90">Últimos 90 dias</SelectItem>
                <SelectItem value="180">Últimos 6 meses</SelectItem>
                <SelectItem value="365">Último ano</SelectItem>
              </SelectContent>
            </Select>
            <Button 
              variant="outline"
              onClick={handleExportReport}
              style={{ borderColor: '#4B2672', color: '#4B2672' }}
              disabled={!hasData}
            >
              <Download className="w-4 h-4 mr-2" />
              Gerar Relatório
            </Button>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full max-w-3xl mx-auto grid-cols-3 h-14 p-1" style={{ backgroundColor: '#F8F6FB' }}>
            <TabsTrigger 
              value="performance" 
              className="data-[state=active]:bg-white data-[state=active]:shadow-md flex items-center gap-2 h-12"
              style={{ 
                color: activeTab === 'performance' ? '#4B2672' : '#6B6B6B',
                fontWeight: activeTab === 'performance' ? '600' : '500'
              }}
            >
              <BarChart3 className="w-5 h-5" />
              Performance
            </TabsTrigger>
            <TabsTrigger 
              value="financial" 
              className="data-[state=active]:bg-white data-[state=active]:shadow-md flex items-center gap-2 h-12"
              style={{ 
                color: activeTab === 'financial' ? '#4B2672' : '#6B6B6B',
                fontWeight: activeTab === 'financial' ? '600' : '500'
              }}
            >
              <BarChart3 className="w-5 h-5" />
              Financeiro
            </TabsTrigger>
            <TabsTrigger 
              value="technical" 
              className="data-[state=active]:bg-white data-[state=active]:shadow-md flex items-center gap-2 h-12"
              style={{ 
                color: activeTab === 'technical' ? '#4B2672' : '#6B6B6B',
                fontWeight: activeTab === 'technical' ? '600' : '500'
              }}
            >
              <Brain className="w-5 h-5" />
              Técnico
            </TabsTrigger>
          </TabsList>

          <TabsContent value="performance" className="space-y-8 mt-8">
            <AdminKPIs user={user} />

            <TemporalEvolutionChart 
              consultorias={consultorias}
              companies={companies}
              employees={employees}
              assessments={completedAssessments}
            />

            <div className="grid lg:grid-cols-2 gap-6">
              <ConsultoriaRanking 
                consultorias={consultorias}
                companies={companies}
                assessments={completedAssessments}
                employees={employees}
              />
              <EngagementRanking
                consultorias={consultorias}
                companies={companies}
                assessments={completedAssessments}
                employees={employees}
              />
            </div>

            <PerformanceInsights
              consultorias={consultorias}
              companies={companies}
              assessments={completedAssessments}
              employees={employees}
            />

            <IntelligentAlerts
              consultorias={consultorias}
              companies={companies}
              assessments={completedAssessments}
            />
          </TabsContent>

          <TabsContent value="financial" className="space-y-8 mt-8">
            <FinancialKPIs
              consultorias={consultorias}
              faturas={faturas}
            />

            <RevenueEvolutionChart
              faturas={faturas}
            />

            <div className="grid lg:grid-cols-2 gap-6">
              <RevenueDistributionChart
                consultorias={consultorias}
                faturas={faturas}
              />
              <ConsultoriaRevenueRanking
                consultorias={consultorias}
                faturas={faturas}
              />
            </div>

            <FinancialOperationalMetrics
              consultorias={consultorias}
              companies={companies}
              employees={employees}
              faturas={faturas}
            />
          </TabsContent>

          <TabsContent value="technical" className="space-y-8 mt-8">
            <TechnicalKPIs
              assessments={completedAssessments}
            />

            <div className="grid lg:grid-cols-2 gap-6">
              <SeverityDistribution
                assessments={completedAssessments}
              />
              <RiskDistributionPie
                assessments={completedAssessments}
              />
            </div>

            <TechnicalTemporalEvolution
              assessments={completedAssessments}
            />

            <TechnicalInsights
              assessments={completedAssessments}
            />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
