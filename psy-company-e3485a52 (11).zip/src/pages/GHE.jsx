import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Navigate, Link, useLocation, useSearchParams } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Plus, Briefcase, Edit, Trash2, Search, Download, Upload, Home, Building2, Users, Settings, AlertCircle } from "lucide-react";
import { toast } from "sonner";

export default function GHE() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [companyId, setCompanyId] = useState(null);
  const [showDialog, setShowDialog] = useState(false);
  const [editingGHE, setEditingGHE] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [searchParams] = useSearchParams();
  const location = useLocation();

  const [formData, setFormData] = useState({
    nome: "",
    descricao: "",
    caracteristicas: "",
    status: "ativo"
  });

  const queryClient = useQueryClient();

  useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
        
        const impersonationData = localStorage.getItem('admin_impersonation');
        if (impersonationData) {
          const parsed = JSON.parse(impersonationData);
          setCompanyId(parsed.company_id);
        } else {
          setCompanyId(userData.company_id);
        }
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  useEffect(() => {
    if (searchParams.get('action') === 'new') {
      setShowDialog(true);
    }
  }, [searchParams]);

  const { data: company } = useQuery({
    queryKey: ['company', companyId],
    queryFn: async () => {
      if (!companyId) return null;
      const companies = await base44.entities.Company.filter({ id: companyId });
      return companies[0] || null;
    },
    enabled: !!companyId,
  });

  const { data: ghes } = useQuery({
    queryKey: ['ghes', companyId],
    queryFn: async () => {
      if (!companyId) return [];
      return await base44.entities.GHE.filter({ empresa_id: companyId });
    },
    enabled: !!companyId,
    initialData: [],
  });

  const { data: employees } = useQuery({
    queryKey: ['employees', companyId],
    queryFn: async () => {
      if (!companyId) return [];
      return await base44.entities.Employee.filter({ company_id: companyId });
    },
    enabled: !!companyId,
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: async (data) => {
      return await base44.entities.GHE.create({
        ...data,
        empresa_id: companyId
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ghes', companyId] });
      setShowDialog(false);
      resetForm();
      toast.success('GHE cadastrado com sucesso!');
    },
    onError: (error) => {
      toast.error(error.message || 'Erro ao cadastrar GHE');
    }
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      return await base44.entities.GHE.update(id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ghes', companyId] });
      setShowDialog(false);
      setEditingGHE(null);
      resetForm();
      toast.success('GHE atualizado com sucesso!');
    },
    onError: (error) => {
      toast.error(error.message || 'Erro ao atualizar GHE');
    }
  });

  const deleteMutation = useMutation({
    mutationFn: async (id) => {
      const relatedEmployees = employees.filter(e => e.ghe_id === id);
      if (relatedEmployees.length > 0) {
        throw new Error(`Não é possível excluir: ${relatedEmployees.length} colaborador(es) vinculado(s)`);
      }
      return await base44.entities.GHE.delete(id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ghes', companyId] });
      toast.success('GHE removido com sucesso!');
    },
    onError: (error) => {
      toast.error(error.message || 'Erro ao remover GHE');
    }
  });

  const resetForm = () => {
    setFormData({
      nome: "",
      descricao: "",
      caracteristicas: "",
      status: "ativo"
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!formData.nome) {
      toast.error('Nome é obrigatório');
      return;
    }

    if (editingGHE) {
      updateMutation.mutate({ id: editingGHE.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleEdit = (ghe) => {
    setEditingGHE(ghe);
    setFormData({
      nome: ghe.nome,
      descricao: ghe.descricao || "",
      caracteristicas: ghe.caracteristicas || "",
      status: ghe.status
    });
    setShowDialog(true);
  };

  const handleDelete = (id) => {
    if (confirm('Tem certeza que deseja excluir este GHE?')) {
      deleteMutation.mutate(id);
    }
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  if (!user || !companyId) {
    return <Navigate to="/" />;
  }

  const filteredGHEs = ghes.filter(ghe => {
    const matchesSearch = ghe.nome?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         ghe.descricao?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || ghe.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // Sub-navegação
  const tabs = [
    { name: "Visão Geral", icon: Home, path: "/Dashboard" },
    { name: "Departamentos", icon: Building2, path: "/Departments" },
    { name: "GHE", icon: Briefcase, path: "/GHE", active: true },
    { name: "Colaboradores", icon: Users, path: "/Employees" },
    { name: "Configurações", icon: Settings, path: "/Settings" }
  ];

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#F8F6FB' }}>
      {/* Breadcrumbs */}
      <div className="border-b bg-white px-6 py-3">
        <div className="max-w-[1800px] mx-auto">
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <span className="font-medium" style={{ color: '#4B2672' }}>iMental</span>
            <span>›</span>
            <span className="font-medium">{company?.name}</span>
            <span>›</span>
            <span>GHE</span>
          </div>
        </div>
      </div>

      {/* Sub-navegação */}
      <div className="border-b bg-white">
        <div className="max-w-[1800px] mx-auto px-6">
          <nav className="flex gap-1">
            {tabs.map(tab => {
              const isActive = tab.active;
              return (
                <Link
                  key={tab.path}
                  to={createPageUrl(tab.path.slice(1))}
                  className={`flex items-center gap-2 px-4 py-3 border-b-2 text-sm font-medium transition-colors ${
                    isActive 
                      ? 'border-[#4B2672] text-[#4B2672]' 
                      : 'border-transparent text-gray-600 hover:text-gray-900 hover:border-gray-300'
                  }`}
                >
                  <tab.icon className="w-4 h-4" />
                  {tab.name}
                </Link>
              );
            })}
          </nav>
        </div>
      </div>

      <div className="p-6 max-w-[1800px] mx-auto">
        {ghes.length === 0 && searchTerm === '' && statusFilter === 'all' ? (
          <Card className="border-2 border-dashed">
            <CardContent className="p-12 text-center">
              <Briefcase className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Você ainda não cadastrou GHE
              </h3>
              <p className="text-gray-600 mb-6 max-w-md mx-auto">
                Agrupe colaboradores com exposição semelhante a riscos psicossociais. Facilita a análise e gestão de riscos por grupo.
              </p>
              <div className="flex gap-3 justify-center">
                <Button
                  onClick={() => setShowDialog(true)}
                  style={{ backgroundColor: '#A57CE0', color: 'white' }}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Novo GHE
                </Button>
                <Button variant="outline">
                  <Upload className="w-4 h-4 mr-2" />
                  Importar CSV
                </Button>
              </div>
            </CardContent>
          </Card>
        ) : (
          <>
            <div className="flex justify-between items-center mb-6">
              <div>
                <h1 className="text-3xl font-bold" style={{ color: '#2E2E2E' }}>
                  Grupos Homogêneos de Exposição (GHE)
                </h1>
                <p className="text-gray-600 mt-1">{ghes.length} {ghes.length === 1 ? 'grupo cadastrado' : 'grupos cadastrados'}</p>
              </div>
              <div className="flex gap-3">
                <Button variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Exportar
                </Button>
                <Button variant="outline">
                  <Upload className="w-4 h-4 mr-2" />
                  Importar CSV
                </Button>
                <Button
                  onClick={() => setShowDialog(true)}
                  style={{ backgroundColor: '#A57CE0', color: 'white' }}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Novo GHE
                </Button>
              </div>
            </div>

            <Card className="shadow-md">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Lista de GHE</CardTitle>
                  <div className="flex gap-3">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <Input
                        placeholder="Buscar GHE..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 w-64"
                      />
                    </div>
                    <Select value={statusFilter} onValueChange={setStatusFilter}>
                      <SelectTrigger className="w-40">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Todos Status</SelectItem>
                        <SelectItem value="ativo">Ativo</SelectItem>
                        <SelectItem value="inativo">Inativo</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nome / Descrição</TableHead>
                      <TableHead>Características</TableHead>
                      <TableHead className="text-center">Colaboradores</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredGHEs.map(ghe => {
                      const gheEmployees = employees.filter(e => e.ghe_id === ghe.id);
                      return (
                        <TableRow key={ghe.id}>
                          <TableCell>
                            <div>
                              <div className="font-medium">{ghe.nome}</div>
                              {ghe.descricao && (
                                <div className="text-sm text-gray-600">{ghe.descricao}</div>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="text-sm text-gray-600 max-w-xs truncate">
                              {ghe.caracteristicas || '—'}
                            </div>
                          </TableCell>
                          <TableCell className="text-center">
                            <Badge variant="outline">{gheEmployees.length}</Badge>
                          </TableCell>
                          <TableCell>
                            <Badge className={ghe.status === 'ativo' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                              {ghe.status === 'ativo' ? 'Ativo' : 'Inativo'}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex gap-2 justify-end">
                              <Button variant="ghost" size="icon" onClick={() => handleEdit(ghe)}>
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                onClick={() => handleDelete(ghe.id)}
                                className="text-red-600 hover:text-red-700"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </>
        )}
      </div>

      <Dialog open={showDialog} onOpenChange={(open) => {
        setShowDialog(open);
        if (!open) {
          setEditingGHE(null);
          resetForm();
        }
      }}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editingGHE ? 'Editar GHE' : 'Novo GHE'}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label>Nome *</Label>
              <Input
                value={formData.nome}
                onChange={(e) => setFormData({...formData, nome: e.target.value})}
                placeholder="Ex: Administrativo - Setor A"
                required
              />
            </div>

            <div>
              <Label>Descrição</Label>
              <Textarea
                value={formData.descricao}
                onChange={(e) => setFormData({...formData, descricao: e.target.value})}
                placeholder="Descreva as atividades e riscos deste grupo"
                rows={3}
              />
            </div>

            <div>
              <Label>Características</Label>
              <Textarea
                value={formData.caracteristicas}
                onChange={(e) => setFormData({...formData, caracteristicas: e.target.value})}
                placeholder="Características gerais do grupo"
                rows={3}
              />
            </div>

            <div>
              <Label>Status</Label>
              <Select value={formData.status} onValueChange={(value) => setFormData({...formData, status: value})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ativo">Ativo</SelectItem>
                  <SelectItem value="inativo">Inativo</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setShowDialog(false)}>
                Cancelar
              </Button>
              <Button type="submit" style={{ backgroundColor: '#A57CE0', color: 'white' }}>
                {editingGHE ? 'Atualizar' : 'Criar'} GHE
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}