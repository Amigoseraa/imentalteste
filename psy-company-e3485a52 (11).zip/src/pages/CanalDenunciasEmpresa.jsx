import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  ShieldAlert,
  Search,
  MessageSquare,
  Clock,
  CheckCircle,
  AlertCircle,
  Filter,
  ChevronRight,
  TrendingUp,
  Users,
  Calendar
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function CanalDenunciasEmpresa() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [categoriaFilter, setCategoriaFilter] = useState("all");
  const [user, setUser] = useState(null);
  const [companyId, setCompanyId] = useState(null);
  const [loading, setLoading] = useState(true);

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
        
        const impersonationData = localStorage.getItem('admin_impersonation');
        if (impersonationData) {
          const parsed = JSON.parse(impersonationData);
          setCompanyId(parsed.company_id);
        } else {
          setCompanyId(userData.company_id);
        }
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  // Buscar empresa
  const { data: company } = useQuery({
    queryKey: ['company', companyId],
    queryFn: async () => {
      if (!companyId) return null;
      const companies = await base44.entities.Company.filter({ id: companyId });
      return companies[0] || null;
    },
    enabled: !!companyId,
  });

  // Buscar denúncias da empresa
  const { data: denuncias = [] } = useQuery({
    queryKey: ['denuncias-empresa', companyId],
    queryFn: () => base44.entities.Denuncia.filter({ empresa_id: companyId }, '-created_date'),
    enabled: !!companyId && !loading,
    initialData: [],
  });

  // Filtrar denúncias
  const filteredDenuncias = denuncias.filter(denuncia => {
    const matchesSearch = denuncia.protocolo.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         denuncia.descricao_inicial?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || denuncia.status === statusFilter;
    const matchesCategoria = categoriaFilter === 'all' || denuncia.categoria === categoriaFilter;
    
    return matchesSearch && matchesStatus && matchesCategoria;
  });

  // KPIs
  const totalDenuncias = denuncias.length;
  const denunciasAbertas = denuncias.filter(d => d.status === 'aberto').length;
  const denunciasEmResposta = denuncias.filter(d => d.status === 'em_resposta').length;
  const denunciasFinalizadas = denuncias.filter(d => d.status === 'finalizado').length;
  const denunciasNaoLidas = denuncias.filter(d => d.mensagens_nao_lidas_empresa > 0).length;

  const getCategoriaLabel = (cat) => {
    const labels = {
      assedio_moral: "Assédio Moral",
      assedio_sexual: "Assédio Sexual",
      discriminacao: "Discriminação",
      conduta_indevida: "Conduta Indevida",
      outros: "Outros"
    };
    return labels[cat] || cat;
  };

  const getStatusBadge = (status) => {
    const badges = {
      aberto: <Badge className="bg-yellow-100 text-yellow-800"><Clock className="w-3 h-3 mr-1" />Aberto</Badge>,
      em_resposta: <Badge className="bg-blue-100 text-blue-800"><MessageSquare className="w-3 h-3 mr-1" />Em Resposta</Badge>,
      finalizado: <Badge className="bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" />Finalizado</Badge>
    };
    return badges[status] || status;
  };

  const getCategoriaColor = (cat) => {
    const colors = {
      assedio_moral: "bg-red-100 text-red-800",
      assedio_sexual: "bg-red-200 text-red-900",
      discriminacao: "bg-orange-100 text-orange-800",
      conduta_indevida: "bg-purple-100 text-purple-800",
      outros: "bg-gray-100 text-gray-800"
    };
    return colors[cat] || "bg-gray-100 text-gray-800";
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#F8F6FB' }}>
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 mx-auto mb-4" style={{ borderColor: '#4B2672' }}></div>
          <p className="text-sm text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  if (!company?.canal_denuncias_ativo) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6" style={{ backgroundColor: '#F8F6FB' }}>
        <Card className="max-w-md">
          <CardContent className="pt-6 text-center">
            <ShieldAlert className="w-16 h-16 mx-auto mb-4 text-gray-400" />
            <h2 className="text-xl font-semibold mb-2">Módulo Não Disponível</h2>
            <p className="text-gray-600 mb-4">
              O Canal de Denúncias não está ativo para sua empresa.
            </p>
            <Button onClick={() => navigate(createPageUrl('Dashboard'))} variant="outline">
              Voltar ao Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6" style={{ backgroundColor: '#F8F6FB' }}>
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl" style={{ backgroundColor: '#4CAF50' }}>
              <ShieldAlert className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold" style={{ color: '#4B2672' }}>Gestão de Denúncias</h1>
              <p className="text-sm text-gray-600">Acompanhe e responda as denúncias recebidas</p>
            </div>
          </div>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg" style={{ backgroundColor: '#F3F0F7' }}>
                  <ShieldAlert className="w-5 h-5" style={{ color: '#4B2672' }} />
                </div>
                <div>
                  <p className="text-2xl font-bold" style={{ color: '#4B2672' }}>{totalDenuncias}</p>
                  <p className="text-xs text-gray-600">Total</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-yellow-50">
                  <Clock className="w-5 h-5 text-yellow-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-yellow-600">{denunciasAbertas}</p>
                  <p className="text-xs text-gray-600">Abertas</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-blue-50">
                  <MessageSquare className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-blue-600">{denunciasEmResposta}</p>
                  <p className="text-xs text-gray-600">Em Resposta</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-green-50">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-green-600">{denunciasFinalizadas}</p>
                  <p className="text-xs text-gray-600">Finalizadas</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-red-50">
                  <AlertCircle className="w-5 h-5 text-red-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-red-600">{denunciasNaoLidas}</p>
                  <p className="text-xs text-gray-600">Não Lidas</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filtros */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Buscar por protocolo..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>

              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Todos os status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os status</SelectItem>
                  <SelectItem value="aberto">Aberto</SelectItem>
                  <SelectItem value="em_resposta">Em Resposta</SelectItem>
                  <SelectItem value="finalizado">Finalizado</SelectItem>
                </SelectContent>
              </Select>

              <Select value={categoriaFilter} onValueChange={setCategoriaFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Todas categorias" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas categorias</SelectItem>
                  <SelectItem value="assedio_moral">Assédio Moral</SelectItem>
                  <SelectItem value="assedio_sexual">Assédio Sexual</SelectItem>
                  <SelectItem value="discriminacao">Discriminação</SelectItem>
                  <SelectItem value="conduta_indevida">Conduta Indevida</SelectItem>
                  <SelectItem value="outros">Outros</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Lista de Denúncias */}
        {filteredDenuncias.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <ShieldAlert className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <h3 className="text-lg font-semibold mb-2 text-gray-700">Nenhuma denúncia encontrada</h3>
              <p className="text-gray-500">
                {searchTerm || statusFilter !== 'all' || categoriaFilter !== 'all'
                  ? 'Tente ajustar os filtros de busca'
                  : 'Quando denúncias forem recebidas, elas aparecerão aqui'
                }
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4">
            {filteredDenuncias.map((denuncia) => (
              <Card
                key={denuncia.id}
                className="cursor-pointer hover:shadow-lg transition-all duration-200"
                onClick={() => navigate(createPageUrl(`DenunciaChat?id=${denuncia.id}`))}
              >
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <span className="text-sm font-mono font-semibold" style={{ color: '#4B2672' }}>
                          {denuncia.protocolo}
                        </span>
                        {getStatusBadge(denuncia.status)}
                        {denuncia.anonimo ? (
                          <Badge variant="outline" className="bg-gray-50">
                            <Users className="w-3 h-3 mr-1" />
                            Anônima
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-blue-50 text-blue-700">
                            <Users className="w-3 h-3 mr-1" />
                            {denuncia.colaborador_nome}
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-600 mb-3">
                        <Calendar className="w-4 h-4" />
                        {format(new Date(denuncia.created_date), "dd 'de' MMMM 'de' yyyy 'às' HH:mm", { locale: ptBR })}
                      </div>
                      <div className="mb-2">
                        <Badge className={getCategoriaColor(denuncia.categoria)}>
                          {getCategoriaLabel(denuncia.categoria)}
                        </Badge>
                      </div>
                      <p className="text-gray-700 line-clamp-2">
                        {denuncia.descricao_inicial}
                      </p>
                    </div>
                    <div className="text-right ml-4">
                      {denuncia.mensagens_nao_lidas_empresa > 0 && (
                        <Badge className="bg-red-500 text-white mb-2">
                          {denuncia.mensagens_nao_lidas_empresa} nova{denuncia.mensagens_nao_lidas_empresa > 1 ? 's' : ''}
                        </Badge>
                      )}
                      <ChevronRight className="w-5 h-5 text-gray-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}