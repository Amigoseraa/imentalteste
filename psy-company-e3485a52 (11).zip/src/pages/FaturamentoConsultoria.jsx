import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Navigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DollarSign, TrendingUp, Calendar, FileText, AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import PageHeader from "../components/common/PageHeader";
import { getEffectiveContext } from "../components/utils/impersonationContext";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";

export default function FaturamentoConsultoria() {
  const [user, setUser] = React.useState(null);
  const [context, setContext] = React.useState(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
        
        const effectiveContext = getEffectiveContext(userData);
        setContext(effectiveContext);
        
        console.log('=== FaturamentoConsultoria ===');
        console.log('Context:', effectiveContext);
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  const { data: faturas = [] } = useQuery({
    queryKey: ['faturas-consultoria', context?.consultoria_id],
    queryFn: async () => {
      if (!context?.consultoria_id) return [];
      return await base44.entities.Fatura.filter({ 
        alvo_id: context.consultoria_id,
        alvo_tipo: 'CONSULTORIA'
      });
    },
    enabled: !!context?.consultoria_id,
    initialData: [],
  });

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1,2,3].map(i => (
              <div key={i} className="h-32 bg-gray-200 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!user || !context || !context.consultoria_id) {
    return (
      <div className="p-8">
        <Alert className="border-red-200 bg-red-50">
          <AlertCircle className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-800">
            Consultoria não encontrada ou você não tem permissão para acessar este módulo.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  // Calcular totais
  const totalFaturado = faturas
    .filter(f => f.status === 'PAGA')
    .reduce((acc, f) => acc + (f.valor_liquido || 0), 0);

  const totalPendente = faturas
    .filter(f => f.status === 'PENDENTE' || f.status === 'ENVIADA')
    .reduce((acc, f) => acc + (f.valor_liquido || 0), 0);

  const totalVencido = faturas
    .filter(f => f.status === 'VENCIDA')
    .reduce((acc, f) => acc + (f.valor_liquido || 0), 0);

  const getStatusBadge = (status) => {
    const badges = {
      PAGA: <Badge className="bg-green-100 text-green-800">✓ Paga</Badge>,
      PENDENTE: <Badge className="bg-yellow-100 text-yellow-800">○ Pendente</Badge>,
      ENVIADA: <Badge className="bg-blue-100 text-blue-800">→ Enviada</Badge>,
      VENCIDA: <Badge className="bg-red-100 text-red-800">✕ Vencida</Badge>,
      CANCELADA: <Badge className="bg-gray-100 text-gray-800">— Cancelada</Badge>,
    };
    return badges[status] || badges.PENDENTE;
  };

  return (
    <div className="p-4 md:p-8 min-h-screen" style={{ backgroundColor: '#F8F6FB' }}>
      <PageHeader
        title="Faturamento"
        description="Acompanhe suas faturas e histórico financeiro"
      />

      {/* KPIs Financeiros */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="shadow-md hover:shadow-lg transition-all">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-green-600" />
              Total Faturado
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-4xl font-bold text-green-600">
              {totalFaturado.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
            </p>
            <p className="text-xs text-gray-500 mt-1">
              {faturas.filter(f => f.status === 'PAGA').length} faturas pagas
            </p>
          </CardContent>
        </Card>

        <Card className="shadow-md hover:shadow-lg transition-all">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-yellow-600" />
              Pendente
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-4xl font-bold text-yellow-600">
              {totalPendente.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
            </p>
            <p className="text-xs text-gray-500 mt-1">
              {faturas.filter(f => f.status === 'PENDENTE' || f.status === 'ENVIADA').length} faturas
            </p>
          </CardContent>
        </Card>

        <Card className="shadow-md hover:shadow-lg transition-all">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-600" />
              Vencido
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-4xl font-bold text-red-600">
              {totalVencido.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
            </p>
            <p className="text-xs text-gray-500 mt-1">
              {faturas.filter(f => f.status === 'VENCIDA').length} faturas vencidas
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Tabela de Faturas */}
      <Card className="shadow-md">
        <CardHeader>
          <CardTitle>Histórico de Faturas</CardTitle>
        </CardHeader>
        <CardContent>
          {faturas.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50">
                    <TableHead>Competência</TableHead>
                    <TableHead>Valor</TableHead>
                    <TableHead>Vencimento</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {faturas
                    .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))
                    .map((fatura) => (
                    <TableRow key={fatura.id}>
                      <TableCell>
                        {format(new Date(fatura.competencia + '-01'), 'MMMM/yyyy')}
                      </TableCell>
                      <TableCell className="font-semibold">
                        {(fatura.valor_liquido || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                      </TableCell>
                      <TableCell>
                        {fatura.vencimento_em ? format(new Date(fatura.vencimento_em), 'dd/MM/yyyy') : '—'}
                      </TableCell>
                      <TableCell>
                        {getStatusBadge(fatura.status)}
                      </TableCell>
                      <TableCell>
                        <FileText className="w-4 h-4 text-gray-400" />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <FileText className="w-12 h-12 mx-auto mb-3 text-gray-300" />
              <p>Nenhuma fatura encontrada</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}