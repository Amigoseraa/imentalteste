
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Shield, 
  Clock, 
  CheckCircle, 
  PlayCircle, 
  AlertCircle,
  Eye,
  ArrowLeft,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  Brain
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { format } from "date-fns";

import IMentalLogo from "@/components/ui/IMentalLogo";

// Meta tag para indicar que esta página é pública
export const pageConfig = {
  requireAuth: false,
  isPublic: true
};

export default function ColaboradorAvaliacoes() {
  const navigate = useNavigate();
  
  const [loading, setLoading] = useState(true);
  const [employee, setEmployee] = useState(null);
  const [company, setCompany] = useState(null);
  const [assessments, setAssessments] = useState([]);
  const [error, setError] = useState('');
  const [showHelp, setShowHelp] = useState(false);
  const [isImpersonating, setIsImpersonating] = useState(false);
  const [expandedSections, setExpandedSections] = useState({
    pending: true,
    in_progress: false,
    completed: false
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    setError('');
    
    try {
      const urlParams = new URLSearchParams(window.location.search);
      const impersonate = urlParams.get('impersonate') === 'true';
      const colaboradorId = urlParams.get('colaborador_id');
      
      setIsImpersonating(impersonate);

      let employeeId;
      
      if (impersonate && colaboradorId) {
        // Modo impersonação - verificar permissões do usuário logado
        try {
          const currentUser = await base44.auth.me();
          
          if (!currentUser || (currentUser.user_role !== 'admin' && currentUser.user_role !== 'manager')) {
            setError('Você não tem permissão para visualizar este colaborador.');
            setLoading(false);
            return;
          }
        } catch (err) {
          console.error('impersonate-permission-check-error', err);
          setError('Erro ao verificar permissões.');
          setLoading(false);
          return;
        }
        
        employeeId = colaboradorId;
      } else {
        // Modo normal - verificar sessão leve do colaborador
        const stored = localStorage.getItem('collab_session');
        
        if (!stored) {
          setError('Sua sessão expirou. Acesse novamente com CPF e data de nascimento.');
          setTimeout(() => {
            window.location.href = createPageUrl("Responder");
          }, 2000);
          return;
        }

        try {
          const session = JSON.parse(stored);
          
          // Verificar expiração (1 hora)
          if (session.exp < Date.now()) {
            localStorage.removeItem('collab_session');
            setError('Sua sessão expirou. Acesse novamente com CPF e data de nascimento.');
            setTimeout(() => {
              window.location.href = createPageUrl("Responder");
            }, 2000);
            return;
          }

          employeeId = session.employee_id;
        } catch (e) {
          console.error('collab-session-parse-error', e);
          localStorage.removeItem('collab_session');
          window.location.href = createPageUrl("Responder");
          return;
        }
      }

      const empData = await base44.entities.Employee.filter({ id: employeeId });
      
      if (empData.length === 0) {
        setError('Colaborador não encontrado.');
        setLoading(false);
        return;
      }

      const emp = empData[0];
      
      if (emp.status !== 'active') {
        setError('Este colaborador não está mais ativo.');
        setLoading(false);
        return;
      }

      setEmployee(emp);

      const compData = await base44.entities.Company.filter({ id: emp.company_id });
      if (compData.length > 0) {
        setCompany(compData[0]);
      }

      const allAssessments = await base44.entities.Assessment.filter({ 
        employee_id: employeeId 
      }, '-created_date');
      
      setAssessments(allAssessments);
      setLoading(false);
    } catch (err) {
      console.error('colaborador-avaliacoes-load-error', err);
      setError('Não foi possível carregar. Tente novamente.');
      setLoading(false);
    }
  };

  const toggleSection = (section) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const handleStartAssessment = (assessment) => {
    if (isImpersonating) {
      alert('Ação não disponível no modo visualização.');
      return;
    }
    // Navegar usando createPageUrl com query parameter
    window.location.href = createPageUrl("ResponderAvaliacao") + `?id=${assessment.id}`;
  };

  const handleBackToPanel = () => {
    window.location.href = createPageUrl("Employees");
  };

  const getAssessmentsByStatus = (status) => {
    return assessments.filter(a => {
      if (status === 'pending') return !a.completed_at && Object.keys(a.prima_responses || {}).length === 0;
      if (status === 'in_progress') return !a.completed_at && Object.keys(a.prima_responses || {}).length > 0;
      if (status === 'completed') return !!a.completed_at;
      return false;
    });
  };

  const formatAssessmentTypes = (type) => {
    if (!type) return [];
    return type.split(',').map(t => {
      if (t === 'PHQ-9') return { name: 'PHQ-9', color: 'bg-purple-100 text-purple-800' };
      if (t === 'GAD-7') return { name: 'GAD-7', color: 'bg-blue-100 text-blue-800' };
      if (t === 'PRIMA-EF') return { name: 'PRIMA-EF', color: 'bg-green-100 text-green-800' };
      if (t === 'HSE-IT') return { name: 'HSE-IT', color: 'bg-yellow-100 text-yellow-800' };
      if (t === 'JCQ') return { name: 'JCQ', color: 'bg-orange-100 text-orange-800' };
      return { name: t, color: 'bg-gray-100 text-gray-800' };
    });
  };

  const getEstimatedTime = (types) => {
    if (!types) return '5-8 min';
    const count = types.split(',').length;
    return `${count * 3}-${count * 5} min`;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-gray-100 p-4 flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-purple-600 border-t-transparent rounded-full animate-spin"></div>
          <p className="text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-gray-100 p-4 flex items-center justify-center">
        <Card className="max-w-md w-full">
          <CardContent className="p-6 text-center">
            <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-gray-900 mb-2">Ops!</h2>
            <p className="text-gray-600 mb-4">{error}</p>
            {isImpersonating ? (
              <Button onClick={handleBackToPanel} style={{ backgroundColor: '#5E2C91' }} className="text-white">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar ao Painel
              </Button>
            ) : (
              <Button onClick={() => window.location.href = createPageUrl("Responder")} style={{ backgroundColor: '#5E2C91' }} className="text-white">
                Voltar
              </Button>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  const pendingAssessments = getAssessmentsByStatus('pending');
  const inProgressAssessments = getAssessmentsByStatus('in_progress');
  const completedAssessments = getAssessmentsByStatus('completed');

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-gray-100">
      {isImpersonating && (
        <div className="bg-blue-600 text-white px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Eye className="w-5 h-5" />
            <div>
              <p className="font-semibold">Modo Gestor (somente leitura) – {employee?.name}</p>
              <p className="text-xs text-blue-100">Visualizando exatamente o que este colaborador vê</p>
            </div>
          </div>
          <Button 
            variant="outline" 
            className="bg-white text-blue-600 hover:bg-blue-50"
            onClick={handleBackToPanel}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar ao Painel
          </Button>
        </div>
      )}

      <div className="max-w-4xl mx-auto p-4 md:p-8">
        <div className="text-center mb-8">
          <div className="mb-6">
            <IMentalLogo variant="dark" size="large" className="mx-auto" />
          </div>
          <h1 className="text-3xl font-bold mb-2" style={{ color: '#2E2E2E' }}>
            {isImpersonating ? `Avaliações de ${employee?.name}` : 'Minhas Avaliações'}
          </h1>
          <p className="text-gray-600">
            {isImpersonating 
              ? 'Visualizando as avaliações deste colaborador'
              : 'Suas respostas são confidenciais e ajudam a melhorar o ambiente de trabalho'
            }
          </p>
        </div>

        {!isImpersonating && (
          <Alert className="mb-6 bg-purple-50 border-purple-200">
            <AlertDescription style={{ color: '#5E2C91' }}>
              <p className="font-semibold mb-2">💙 Obrigado por participar!</p>
              <p className="text-sm">
                Leva poucos minutos e suas respostas são anônimas. Você pode pausar e retomar quando quiser.
              </p>
            </AlertDescription>
          </Alert>
        )}

        {(pendingAssessments.length > 0 || inProgressAssessments.length > 0 || completedAssessments.length > 0) ? (
          <>
            {pendingAssessments.length > 0 && (
              <Card className="mb-6 shadow-lg">
                <CardHeader 
                  className="cursor-pointer hover:bg-gray-50 transition-colors"
                  onClick={() => toggleSection('pending')}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Clock className="w-5 h-5 text-orange-600" />
                      <CardTitle className="text-lg">
                        Pendentes ({pendingAssessments.length})
                      </CardTitle>
                    </div>
                    {expandedSections.pending ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                  </div>
                </CardHeader>
                {expandedSections.pending && (
                  <CardContent className="space-y-4">
                    {pendingAssessments.map(assessment => (
                      <Card key={assessment.id} className="border-2 border-orange-200 hover:border-orange-300 transition-colors">
                        <CardContent className="p-4">
                          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                            <div className="flex-1">
                              <h3 className="font-semibold text-lg text-gray-900 mb-2">
                                {assessment.assessment_name || 'Avaliação de Bem-Estar'}
                              </h3>
                              <div className="flex flex-wrap gap-2 mb-3">
                                {formatAssessmentTypes(assessment.assessment_type).map((type, idx) => (
                                  <Badge key={idx} className={type.color}>
                                    {type.name}
                                  </Badge>
                                ))}
                              </div>
                              <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                                <span className="flex items-center gap-1">
                                  <Clock className="w-4 h-4" />
                                  {getEstimatedTime(assessment.assessment_type)}
                                </span>
                                {assessment.due_date && (
                                  <span className="flex items-center gap-1 text-orange-600 font-medium">
                                    Prazo: {format(new Date(assessment.due_date), 'dd/MM/yyyy')}
                                  </span>
                                )}
                              </div>
                            </div>
                            <Button
                              onClick={() => handleStartAssessment(assessment)}
                              disabled={isImpersonating}
                              className="whitespace-nowrap disabled:opacity-50 disabled:cursor-not-allowed text-white"
                              style={{ backgroundColor: '#5E2C91' }}
                            >
                              <PlayCircle className="w-4 h-4 mr-2" />
                              {isImpersonating ? 'Somente Leitura' : 'Começar agora'}
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </CardContent>
                )}
              </Card>
            )}

            {inProgressAssessments.length > 0 && (
              <Card className="mb-6 shadow-lg">
                <CardHeader 
                  className="cursor-pointer hover:bg-gray-50 transition-colors"
                  onClick={() => toggleSection('in_progress')}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <PlayCircle className="w-5 h-5 text-blue-600" />
                      <CardTitle className="text-lg">
                        Em andamento ({inProgressAssessments.length})
                      </CardTitle>
                    </div>
                    {expandedSections.in_progress ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                  </div>
                </CardHeader>
                {expandedSections.in_progress && (
                  <CardContent className="space-y-4">
                    {inProgressAssessments.map(assessment => (
                      <Card key={assessment.id} className="border-2 border-blue-200 hover:border-blue-300 transition-colors">
                        <CardContent className="p-4">
                          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                            <div className="flex-1">
                              <h3 className="font-semibold text-lg text-gray-900 mb-2">
                                {assessment.assessment_name || 'Avaliação de Bem-Estar'}
                              </h3>
                              <div className="flex flex-wrap gap-2 mb-3">
                                {formatAssessmentTypes(assessment.assessment_type).map((type, idx) => (
                                  <Badge key={idx} className={type.color}>
                                    {type.name}
                                  </Badge>
                                ))}
                              </div>
                              <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                                <span className="flex items-center gap-1">
                                  <Clock className="w-4 h-4" />
                                  {getEstimatedTime(assessment.assessment_type)}
                                </span>
                                {assessment.due_date && (
                                  <span className="flex items-center gap-1">
                                    Prazo: {format(new Date(assessment.due_date), 'dd/MM/yyyy')}
                                  </span>
                                )}
                              </div>
                            </div>
                            <Button
                              onClick={() => handleStartAssessment(assessment)}
                              disabled={isImpersonating}
                              className="whitespace-nowrap disabled:opacity-50 disabled:cursor-not-allowed text-white"
                              style={{ backgroundColor: '#5E2C91' }}
                            >
                              <PlayCircle className="w-4 h-4 mr-2" />
                              {isImpersonating ? 'Somente Leitura' : 'Retomar'}
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </CardContent>
                )}
              </Card>
            )}

            {completedAssessments.length > 0 && (
              <Card className="mb-6 shadow-lg">
                <CardHeader 
                  className="cursor-pointer hover:bg-gray-50 transition-colors"
                  onClick={() => toggleSection('completed')}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                      <CardTitle className="text-lg">
                        Concluídas ({completedAssessments.length})
                      </CardTitle>
                    </div>
                    {expandedSections.completed ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                  </div>
                </CardHeader>
                {expandedSections.completed && (
                  <CardContent className="space-y-4">
                    {completedAssessments.map(assessment => (
                      <Card key={assessment.id} className="border-2 border-green-200 bg-green-50">
                        <CardContent className="p-4">
                          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                            <div className="flex-1">
                              <h3 className="font-semibold text-lg text-gray-900 mb-2">
                                {assessment.assessment_name || 'Avaliação de Bem-Estar'}
                              </h3>
                              <div className="flex flex-wrap gap-2 mb-3">
                                {formatAssessmentTypes(assessment.assessment_type).map((type, idx) => (
                                  <Badge key={idx} className={type.color}>
                                    {type.name}
                                  </Badge>
                                ))}
                              </div>
                              <div className="text-sm text-green-700 font-medium">
                                ✓ Enviada em {format(new Date(assessment.completed_at), 'dd/MM/yyyy HH:mm')}
                              </div>
                            </div>
                            <Badge className="bg-green-600 text-white">
                              <CheckCircle className="w-4 h-4 mr-1" />
                              Concluída
                            </Badge>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </CardContent>
                )}
              </Card>
            )}
          </>
        ) : (
          <Card className="border-2 border-dashed border-gray-300">
            <CardContent className="p-12 text-center">
              <Shield className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                Você não tem avaliações ativas no momento.
              </h3>
              <p className="text-gray-500">
                {isImpersonating ? 'Este colaborador não tem avaliações no momento.' : 'Aguarde até que novas avaliações sejam disponibilizadas.'}
              </p>
            </CardContent>
          </Card>
        )}

        {!isImpersonating && (
          <div className="text-center mt-8">
            <Button
              variant="outline"
              onClick={() => setShowHelp(true)}
              style={{ borderColor: '#5E2C91', color: '#5E2C91' }}
            >
              <HelpCircle className="w-4 h-4 mr-2" />
              Como funciona?
            </Button>
          </div>
        )}
      </div>

      <Dialog open={showHelp} onOpenChange={setShowHelp}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Como funciona?</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2">⏱️ Tempo estimado</h4>
              <p className="text-sm text-gray-600">
                Cada avaliação leva de 5 a 15 minutos, dependendo dos questionários.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">💾 Pausar e retomar</h4>
              <p className="text-sm text-gray-600">
                Você pode pausar a qualquer momento e retomar depois de onde parou.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">🔒 Confidencialidade</h4>
              <p className="text-sm text-gray-600">
                Suas respostas são confidenciais e usadas apenas de forma agregada para melhorar o ambiente de trabalho.
              </p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// Exportar configuração para o base44 saber que é pública
ColaboradorAvaliacoes.isPublic = true;
