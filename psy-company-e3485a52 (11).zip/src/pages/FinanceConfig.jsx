import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Navigate } from "react-router-dom";
import FinancePageLayout from "../components/finance/FinancePageLayout";
import { Button } from "@/components/ui/button";
import { Save } from "lucide-react";
import { toast } from "sonner";

export default function FinanceConfig() {
  const [user, setUser] = React.useState(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  if (!user || (user.user_role !== 'admin' && user.user_role !== 'consultoria')) {
    return <Navigate to="/dashboard" />;
  }

  return (
    <FinancePageLayout
      currentPage="FinanceConfig"
      userRole={user.user_role}
      title="Configurações Financeiras"
      subtitle="Regras de cobrança, automações e políticas"
      actions={
        <Button onClick={() => toast.info('Salvamento em desenvolvimento')}>
          <Save className="w-4 h-4 mr-2" />
          Salvar Configurações
        </Button>
      }
    >
      <div className="bg-white rounded-xl p-8 shadow-md text-center">
        <p className="text-gray-500 mb-4">Configurações Financeiras em desenvolvimento</p>
        <p className="text-sm text-gray-400">
          Em breve: regras de juros/multa, política de dunning, automações, modelos de e-mail
        </p>
      </div>
    </FinancePageLayout>
  );
}