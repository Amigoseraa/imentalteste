
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Navigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Building2, Users, Briefcase, DollarSign, Eye, Edit, Download, TrendingUp, Activity, AlertCircle, Calendar, ArrowUp, ArrowDown, FileText, Key, RefreshCw } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
// The DialogTrigger import is kept as it might be used implicitly by other components
// or for consistency if other dialogs use it in a similar pattern.
// However, the explicit usage in the main "Nova Consultoria" button is removed.
import { DialogTrigger } from "@radix-ui/react-dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";
import { format, subMonths, isAfter } from "date-fns";
import { toast } from "sonner";
import ConsultoriaAlertsPanel from "../components/admin-dashboard/ConsultoriaAlertsPanel";
import ConsultoriaStrategicRankings from "../components/admin-dashboard/ConsultoriaStrategicRankings";
import RevenueDistributionChart from "../components/admin-dashboard/RevenueDistributionChart";
import MasterUserInfo from "../components/consultorias/MasterUserInfo";
import { createOrUpdateMasterUser } from "../components/consultorias/CreateMasterUser";
import MasterUserForm from "../components/consultorias/MasterUserForm";
import { validateCPF, cleanCPF, validateEmail, validatePassword, isAdult } from "../components/utils/validators";

export default function Consultorias() {
  const [user, setUser] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [editingConsultoria, setEditingConsultoria] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [periodFilter, setPeriodFilter] = useState('all');
  const [sortColumn, setSortColumn] = useState('nome_fantasia');
  const [sortDirection, setSortDirection] = useState('asc');
  const [formData, setFormData] = useState({
    nome_fantasia: "",
    razao_social: "",
    cnpj: "",
    email_master: "",
    status: "ativo",
    faturamento_modelo: "por_colaborador",
    valor_unitario: 4.90,
    ciclo_faturamento: "mensal"
  });

  const [masterUserData, setMasterUserData] = useState({
    nome: "",
    cpf: "",
    data_nascimento: "",
    email: "",
    senha: "",
    confirmacao_senha: "",
    enviar_boas_vindas: true // This might become less relevant if we just create directly
  });
  const [masterUserErrors, setMasterUserErrors] = useState({});

  const [showMasterInfo, setShowMasterInfo] = useState(false);
  const [selectedConsultoriaForInfo, setSelectedConsultoriaForInfo] = useState(null);

  const queryClient = useQueryClient();

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  const { data: consultorias } = useQuery({
    queryKey: ['consultorias'],
    queryFn: () => base44.entities.Consultoria.list('-created_date'),
    enabled: user?.user_role === 'admin',
    initialData: [],
  });

  const { data: companies } = useQuery({
    queryKey: ['all-companies'],
    queryFn: () => base44.entities.Company.list(),
    enabled: user?.user_role === 'admin',
    initialData: [],
  });

  const { data: employees } = useQuery({
    queryKey: ['all-employees'],
    queryFn: () => base44.entities.Employee.list(),
    enabled: user?.user_role === 'admin',
    initialData: [],
  });

  const { data: assessments } = useQuery({
    queryKey: ['all-assessments'],
    queryFn: () => base44.entities.Assessment.list(),
    enabled: user?.user_role === 'admin',
    initialData: [],
  });

  const { data: faturas } = useQuery({
    queryKey: ['faturas-consultorias'],
    queryFn: () => base44.entities.Fatura.filter({ origem_tipo: 'admin' }),
    enabled: user?.user_role === 'admin',
    initialData: [],
  });

  const validateMasterUser = () => {
    const errors = {};

    // Nome sempre obrigatório
    if (!masterUserData.nome || masterUserData.nome.length < 3) {
      errors.nome = 'Nome deve ter no mínimo 3 caracteres';
    }

    // CPF: obrigatório apenas para criação
    if (!editingConsultoria) {
      const cleanedCPF = cleanCPF(masterUserData.cpf);
      if (!cleanedCPF) {
        errors.cpf = 'CPF é obrigatório';
      } else if (!validateCPF(cleanedCPF)) {
        errors.cpf = 'CPF inválido';
      }
    } else {
      // Na edição, validar apenas se foi preenchido
      if (masterUserData.cpf) {
        const cleanedCPF = cleanCPF(masterUserData.cpf);
        if (cleanedCPF && !validateCPF(cleanedCPF)) {
          errors.cpf = 'CPF inválido';
        }
      }
    }

    // Data de nascimento: obrigatória apenas para criação
    if (!editingConsultoria) {
      if (!masterUserData.data_nascimento) {
        errors.data_nascimento = 'Data de nascimento é obrigatória';
      } else if (!isAdult(masterUserData.data_nascimento)) {
        errors.data_nascimento = 'Usuário deve ser maior de 18 anos';
      }
    } else {
      // Na edição, validar apenas se foi preenchido
      if (masterUserData.data_nascimento && !isAdult(masterUserData.data_nascimento)) {
        errors.data_nascimento = 'Usuário deve ser maior de 18 anos';
      }
    }

    // E-mail sempre obrigatório
    if (!masterUserData.email) {
      errors.email = 'E-mail é obrigatório';
    } else if (!validateEmail(masterUserData.email)) {
      errors.email = 'E-mail inválido';
    }

    // Senha: obrigatória apenas para criação, ou se foi preenchida na edição
    if (!editingConsultoria) {
      if (!masterUserData.senha) {
        errors.senha = 'Senha é obrigatória';
      } else {
        const passwordValidation = validatePassword(masterUserData.senha);
        if (!passwordValidation.valid) {
          errors.senha = passwordValidation.message;
        }
      }

      if (masterUserData.senha !== masterUserData.confirmacao_senha) {
        errors.confirmacao_senha = 'As senhas não coincidem';
      }
    } else {
      // Na edição, validar senha apenas se foi preenchida
      if (masterUserData.senha) {
        const passwordValidation = validatePassword(masterUserData.senha);
        if (!passwordValidation.valid) {
          errors.senha = passwordValidation.message;
        }

        if (masterUserData.senha !== masterUserData.confirmacao_senha) {
          errors.confirmacao_senha = 'As senhas não coincidem';
        }
      }
    }

    setMasterUserErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const createMutation = useMutation({
    mutationFn: async (data) => {
      console.log('Creating consultoria with data:', data);

      // Basic validation
      if (!validateMasterUser()) {
        throw new Error('Preencha corretamente os dados do usuário master.');
      }

      // Validação 1: Verificar CNPJ duplicado
      const cnpjLimpo = data.cnpj.replace(/\D/g, '');
      const consultoriasComMesmoCNPJ = consultorias.filter(c =>
        c.cnpj && cleanCPF(c.cnpj) === cnpjLimpo && c.status === 'ativo'
      );

      if (consultoriasComMesmoCNPJ.length > 0) {
        throw new Error(`CNPJ ${data.cnpj} já está cadastrado para a consultoria "${consultoriasComMesmoCNPJ[0].nome_fantasia}"`);
      }

      // Validação 2: Verificar CPF duplicado do master user
      if (masterUserData.cpf) {
        const cpfLimpo = cleanCPF(masterUserData.cpf);

        const cpfDuplicado = consultorias.find(c =>
          c.status === 'ativo' &&
          c.master_user_data &&
          c.master_user_data.cpf &&
          cleanCPF(c.master_user_data.cpf) === cpfLimpo
        );

        if (cpfDuplicado) {
          throw new Error(`CPF ${masterUserData.cpf} já está cadastrado como usuário master da consultoria "${cpfDuplicado.nome_fantasia}"`);
        }
      }

      // Validação 3: Verificar email duplicado
      if (masterUserData.email) {
        const emailDuplicado = consultorias.find(c =>
          c.status === 'ativo' &&
          c.email_master &&
          c.email_master.toLowerCase() === masterUserData.email.toLowerCase()
        );

        if (emailDuplicado) {
          throw new Error(`Email ${masterUserData.email} já está cadastrado como usuário master da consultoria "${emailDuplicado.nome_fantasia}"`);
        }
      }

      // Criar consultoria PRIMEIRO
      const consultoria = await base44.entities.Consultoria.create(data);
      console.log('Consultoria created:', consultoria);

      // Configurar usuário master DEPOIS
      let masterUserResult = null;
      let masterUserError = null;
      if (masterUserData.nome && masterUserData.email && masterUserData.senha) {
        try {
          masterUserResult = await createOrUpdateMasterUser(
            consultoria,
            masterUserData,
            user.email,
            false // isEdit = false
          );
          console.log('Master user result:', masterUserResult);
        } catch (masterError) {
          console.error('Error creating master user:', masterError);
          masterUserError = masterError.message;
        }
      }

      // Buscar consultoria atualizada para pegar master_user_data salvo
      const consultoriasAtualizadas = await base44.entities.Consultoria.filter({ id: consultoria.id });
      const consultoriaAtualizada = consultoriasAtualizadas[0];

      // Retornar dados completos
      return {
        consultoria: consultoriaAtualizada,
        masterUser: masterUserResult,
        masterUserError
      };
    },
    onSuccess: (result) => {
      console.log('Mutation success:', result);
      queryClient.invalidateQueries({ queryKey: ['consultorias'] });
      setShowDialog(false);
      resetForm();

      if (result.masterUser && result.masterUser.temp_password) {
        toast.success(
          <div className="space-y-2">
            <p className="font-semibold">✅ Consultoria "{result.consultoria.nome_fantasia}" criada com sucesso!</p>
            <p className="text-sm">
              👤 Credenciais do usuário master configuradas:
            </p>
            <div className="text-xs bg-gray-100 p-2 rounded">
              <p><strong>Email:</strong> {masterUserData.email}</p>
              <p><strong>Senha:</strong> {result.masterUser.temp_password}</p>
            </div>
            <p className="text-xs text-green-600 font-semibold">
              ✓ As credenciais estão prontas para uso!
            </p>
          </div>,
          { duration: 10000 }
        );

        // Abrir modal de info automaticamente
        setTimeout(() => {
          setSelectedConsultoriaForInfo(result.consultoria);
          setShowMasterInfo(true);
        }, 500);
      } else if (result.masterUserError) {
        toast.success(`Consultoria "${result.consultoria.nome_fantasia}" criada, mas houve um problema ao configurar o usuário master: ${result.masterUserError}`);
      } else {
        toast.success(`Consultoria "${result.consultoria.nome_fantasia}" criada com sucesso!`);
      }
    },
    onError: (error) => {
      console.error("Error in createMutation:", error);
      toast.error(
        <div>
          <p className="font-semibold">Erro ao criar consultoria</p>
          <p className="text-sm">{error.message || 'Verifique os dados e tente novamente.'}</p>
        </div>,
        { duration: 6000 }
      );
    }
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      console.log('=== UPDATE MUTATION START ===');
      console.log('Consultoria ID:', id);
      console.log('Form data:', data);
      console.log('Master user data from form:', {
        ...masterUserData,
        senha: masterUserData.senha ? '****(presente)' : 'VAZIO',
        confirmacao_senha: masterUserData.confirmacao_senha ? '****(presente)' : 'VAZIO'
      });
      console.log('Editing consultoria:', editingConsultoria?.nome_fantasia);
      
      // Validação 1: Verificar CNPJ duplicado (exceto a própria consultoria)
      if (data.cnpj) {
        const cnpjLimpo = data.cnpj.replace(/\D/g, '');
        const consultoriasComMesmoCNPJ = consultorias.filter(c => 
          c.id !== id &&
          c.cnpj && 
          cleanCPF(c.cnpj) === cnpjLimpo && 
          c.status === 'ativo'
        );
        
        if (consultoriasComMesmoCNPJ.length > 0) {
          throw new Error(`CNPJ ${data.cnpj} já está cadastrado para a consultoria "${consultoriasComMesmoCNPJ[0].nome_fantasia}"`);
        }
      }
      
      // Validação 2: Verificar CPF duplicado do master user (exceto a própria consultoria)
      // Use the effective CPF (form input or existing) for this check.
      const existingMasterUserData = editingConsultoria?.master_user_data;
      const effectiveMasterUserCpfForCheck = masterUserData.cpf ? cleanCPF(masterUserData.cpf) : cleanCPF(existingMasterUserData?.cpf || '');
      if (effectiveMasterUserCpfForCheck) {
        const cpfDuplicado = consultorias.find(c => 
          c.id !== id &&
          c.status === 'ativo' && 
          c.master_user_data && 
          c.master_user_data.cpf &&
          cleanCPF(c.master_user_data.cpf) === effectiveMasterUserCpfForCheck
        );
        
        if (cpfDuplicado) {
          throw new Error(`CPF ${masterUserData.cpf || effectiveMasterUserCpfForCheck} já está cadastrado como usuário master da consultoria "${cpfDuplicado.nome_fantasia}"`);
        }
      }

      // Validação 3: Verificar email duplicado (exceto a própria consultoria)
      // Use the effective email (form input or existing) for this check.
      const effectiveMasterUserEmailForCheck = masterUserData.email ? masterUserData.email.toLowerCase() : (existingMasterUserData?.email || editingConsultoria?.email_master || '').toLowerCase();
      if (effectiveMasterUserEmailForCheck) {
        const emailDuplicado = consultorias.find(c => 
          c.id !== id &&
          c.status === 'ativo' &&
          ((c.email_master && c.email_master.toLowerCase() === effectiveMasterUserEmailForCheck) ||
           (c.master_user_data && c.master_user_data.email && c.master_user_data.email.toLowerCase() === effectiveMasterUserEmailForCheck))
        );
        
        if (emailDuplicado) {
          throw new Error(`Email ${masterUserData.email || effectiveMasterUserEmailForCheck} já está cadastrado como usuário master da consultoria "${emailDuplicado.nome_fantasia}"`);
        }
      }
      
      console.log('🔄 Atualizando consultoria...');
      // Atualizar consultoria PRIMEIRO
      const consultoria = await base44.entities.Consultoria.update(id, data);
      console.log('✅ Consultoria atualizada');

      // Preparar dados do master user para a API, combinando dados do formulário e dados existentes
      // const existingMasterUserData = editingConsultoria?.master_user_data; // Already defined above

      // Determine a senha a ser usada: senha nova do formulário ou senha temporária existente
      const senhaToUse = masterUserData.senha || existingMasterUserData?.senha_temp;
      
      console.log('🔑 Senha analysis:');
      console.log('  - Nova senha (do form):', masterUserData.senha ? 'SIM (****)' : 'VAZIO');
      console.log('  - Senha existente (temp_password):', existingMasterUserData?.senha_temp ? 'SIM (****)' : 'VAZIO');
      console.log('  - Senha final (senhaToUse):', senhaToUse ? 'SIM (****)' : 'VAZIO');
      
      // Verificar se algum campo do usuário master foi alterado na UI ou se está sendo preenchido pela primeira vez
      const masterUserFormValues = {
        nome: masterUserData.nome,
        cpf: masterUserData.cpf,
        data_nascimento: masterUserData.data_nascimento,
        email: masterUserData.email,
        senha: masterUserData.senha, // Senha apenas se preenchida no form
        confirmacao_senha: masterUserData.confirmacao_senha // Confirmação apenas se preenchida no form
      };

      // Check if any field has changed from its original value OR if a new password was provided.
      const anyMasterUserFieldChanged = Object.keys(masterUserFormValues).some(key => {
        if (key === 'senha' || key === 'confirmacao_senha') {
          return !!masterUserFormValues.senha; // A new password was provided in the form
        }

        let formValue = masterUserFormValues[key];
        let existingValue = '';

        if (key === 'email') {
          existingValue = existingMasterUserData?.email || editingConsultoria?.email_master || '';
        } else if (key === 'cpf') {
          existingValue = existingMasterUserData?.cpf || '';
          return cleanCPF(formValue) !== cleanCPF(existingValue); // Compare cleaned CPF values
        } else {
          existingValue = existingMasterUserData?.[key] || '';
        }
        
        return formValue !== existingValue;
      });

      // Also consider it an update if a master user is being created for a consultoria that didn't have one
      const creatingNewMasterUserForExistingConsultoria = !existingMasterUserData && !!masterUserFormValues.email;
      
      const needsMasterUserUpdate = anyMasterUserFieldChanged || creatingNewMasterUserForExistingConsultoria || !existingMasterUserData?.has_credentials;

      console.log('📋 Any master user field changed (incl. new password):', anyMasterUserFieldChanged);
      console.log('📋 Creating new master user for existing consultoria:', creatingNewMasterUserForExistingConsultoria);
      console.log('📋 Master user has no credentials yet:', !existingMasterUserData?.has_credentials);
      console.log('📋 Needs master user update:', needsMasterUserUpdate);
      
      let masterUserResult = null;
      let masterUserError = null;
      
      if (needsMasterUserUpdate) {
        console.log('🔄 Validando e atualizando dados do master user...');
        
        // --- Client-side validation for master user payload ---
        const errors = {};

        // Combine form data with existing data for validation if form field is empty
        const masterDataForValidation = {
            nome: masterUserFormValues.nome || existingMasterUserData?.nome || '',
            cpf: cleanCPF(masterUserFormValues.cpf) || cleanCPF(existingMasterUserData?.cpf || '') || '',
            data_nascimento: masterUserFormValues.data_nascimento || existingMasterUserData?.data_nascimento || '',
            email: masterUserFormValues.email || existingMasterUserData?.email || editingConsultoria?.email_master || '',
            senha: masterUserFormValues.senha, // Use new password from form for validation
            confirmacao_senha: masterUserFormValues.confirmacao_senha // Use new confirmation from form for validation
        };

        // Nome:
        if (masterDataForValidation.nome && masterDataForValidation.nome.length < 3) {
            errors.nome = 'Nome deve ter no mínimo 3 caracteres';
        } else if (creatingNewMasterUserForExistingConsultoria && !masterDataForValidation.nome) {
            errors.nome = 'Nome é obrigatório';
        }

        // CPF:
        if (masterDataForValidation.cpf) {
            if (!validateCPF(masterDataForValidation.cpf)) {
                errors.cpf = 'CPF inválido';
            }
        } else if (creatingNewMasterUserForExistingConsultoria) {
            errors.cpf = 'CPF é obrigatório';
        }

        // Data de nascimento:
        if (masterDataForValidation.data_nascimento && !isAdult(masterDataForValidation.data_nascimento)) {
            errors.data_nascimento = 'Usuário deve ser maior de 18 anos';
        } else if (creatingNewMasterUserForExistingConsultoria && !masterDataForValidation.data_nascimento) {
            errors.data_nascimento = 'Data de nascimento é obrigatória';
        }

        // Email:
        if (!masterDataForValidation.email) {
            errors.email = 'E-mail é obrigatório';
        } else if (!validateEmail(masterDataForValidation.email)) {
            errors.email = 'E-mail inválido';
        }

        // Senha: Validate new password if provided. If not provided but required for new master user, show error.
        if (masterUserFormValues.senha) { // User explicitly typed a new password
            const passwordValidation = validatePassword(masterUserFormValues.senha);
            if (!passwordValidation.valid) {
                errors.senha = passwordValidation.message;
            }
            if (masterUserFormValues.senha !== masterUserFormValues.confirmacao_senha) {
                errors.confirmacao_senha = 'As senhas não coincidem';
            }
        } else if (creatingNewMasterUserForExistingConsultoria && !senhaToUse) {
            // If creating a new master user for an existing consultoria, password is mandatory
            errors.senha = 'Senha é obrigatória para criar um novo usuário master.';
        } else if (!senhaToUse && !existingMasterUserData?.has_credentials) {
            // If we need to update but there's no password (new or old) AND no existing credentials
            errors.senha = 'Senha do usuário master não pode estar vazia.';
        }

        setMasterUserErrors(errors);
        if (Object.keys(errors).length > 0) {
          console.error('❌ Client-side master user validation failed:', errors);
          throw new Error('Preenchimento incorreto dos dados do usuário master.');
        }
        // --- End of client-side validation ---


        try {
          // Construct the final payload for createOrUpdateMasterUser API call
          const payloadForCreateOrUpdateMasterUser = {
            nome: masterDataForValidation.nome,
            cpf: masterDataForValidation.cpf,
            data_nascimento: masterDataForValidation.data_nascimento,
            email: masterDataForValidation.email,
            senha: senhaToUse // Use the determined password (new or existing)
          };

          console.log('📝 Master user payload to API:', {
            ...payloadForCreateOrUpdateMasterUser,
            senha: payloadForCreateOrUpdateMasterUser.senha ? '****(presente)' : 'VAZIO'
          });

          masterUserResult = await createOrUpdateMasterUser(
            consultoria,
            payloadForCreateOrUpdateMasterUser,
            user.email,
            true // isEdit = true
          );
          console.log('✅ Master user updated successfully');
          console.log('✅ Result from createOrUpdateMasterUser:', {
            ...masterUserResult,
            temp_password: masterUserResult?.temp_password ? '****(presente)' : 'VAZIO'
          });
        } catch (masterError) {
          console.error('❌ Error updating master user:', masterError);
          masterUserError = masterError.message;
        }
      }

      console.log('🔄 Buscando consultoria atualizada...');
      // Buscar consultoria atualizada para ter certeza que pegamos os dados mais recentes
      // Isso é crucial porque createOrUpdateMasterUser pode atualizar master_user_data diretamente na consultoria
      const consultoriasAtualizadas = await base44.entities.Consultoria.filter({ id: id });
      const consultoriaAtualizada = consultoriasAtualizadas[0];

      console.log('✅ Consultoria atualizada buscada');
      console.log('✅ Final consultoria data:', consultoriaAtualizada?.nome_fantasia);
      console.log('✅ master_user_data in final consultoria:', consultoriaAtualizada?.master_user_data ? {
        ...consultoriaAtualizada.master_user_data,
        senha: '****(hidden for security)',
        senha_temp: consultoriaAtualizada.master_user_data.senha_temp ? '****(presente)' : 'VAZIO'
      } : 'VAZIO');
      console.log('=== UPDATE MUTATION END ===');

      // Retornar dados completos
      return {
        consultoria: consultoriaAtualizada,
        masterUser: masterUserResult,
        masterUserError
      };
    },
    onSuccess: (result) => {
      console.log('✅ Update mutation success');
      console.log('✅ Final consultoria master_user_data for toast/modal:', result.consultoria?.master_user_data ? {
        ...result.consultoria.master_user_data,
        senha: '****(hidden for security)',
        senha_temp: result.consultoria.master_user_data.senha_temp ? '****(presente)' : 'VAZIO'
      } : 'VAZIO');
      
      queryClient.invalidateQueries({ queryKey: ['consultorias'] });
      setShowDialog(false);
      resetForm();

      if (result.masterUserError) {
        toast.success(`Consultoria "${result.consultoria.nome_fantasia}" atualizada, mas houve um problema ao atualizar o usuário master: ${result.masterUserError}`);
      } else {
        toast.success(
          <div className="space-y-1">
            <p className="font-semibold">✅ Consultoria "{result.consultoria.nome_fantasia}" atualizada com sucesso!</p>
            {result.masterUser && (
              <>
                <p className="text-xs text-green-600">✓ Login do usuário master está ativo</p>
                <p className="text-xs text-gray-600">Clique no ícone 🔑 para ver as credenciais</p>
              </>
            )}
          </div>,
          { duration: 5000 }
        );
        
        // Abrir modal de credenciais após atualização
        setTimeout(() => {
          console.log('📋 Opening master user info modal with consultoria:', result.consultoria.nome_fantasia);
          setSelectedConsultoriaForInfo(result.consultoria);
          setShowMasterInfo(true);
        }, 500);
      }
    },
    onError: (error) => {
      console.error("❌ Error in updateMutation:", error);
      toast.error(error.message || 'Erro ao atualizar consultoria.');
    }
  });

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[1,2,3,4].map(i => (
              <div key={i} className="h-32 bg-gray-200 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!user || user.user_role !== 'admin') {
    return <Navigate to="/" />;
  }

  const formatCnpj = (value) => {
    if (!value) return '';
    value = value.replace(/\D/g, ''); // Remove all non-digit characters
    value = value.slice(0, 14); // Limit to 14 digits

    if (value.length > 12) {
      value = value.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2}).*/, '$1.$2.$3/$4-$5');
    } else if (value.length > 8) {
      value = value.replace(/^(\d{2})(\d{3})(\d{3})(\d{4}).*/, '$1.$2.$3/$4');
    } else if (value.length > 5) {
      value = value.replace(/^(\d{2})(\d{3})(\d{3}).*/, '$1.$2.$3');
    } else if (value.length > 2) {
      value = value.replace(/^(\d{2})(\d{3}).*/, '$1.$2');
    } else if (value.length > 0) {
      value = value.replace(/^(\d{2}).*/, '$1');
    }
    return value;
  };

  const resetForm = () => {
    setFormData({
      nome_fantasia: "",
      razao_social: "",
      cnpj: "",
      email_master: "",
      status: "ativo",
      faturamento_modelo: "por_colaborador",
      valor_unitario: 4.90,
      ciclo_faturamento: "mensal"
    });
    setMasterUserData({
      nome: "",
      cpf: "",
      data_nascimento: "",
      email: "",
      senha: "",
      confirmacao_senha: "",
      enviar_boas_vindas: true
    });
    setMasterUserErrors({});
    setEditingConsultoria(null);
  };

  const handleEdit = (consultoria) => {
    setEditingConsultoria(consultoria);
    setFormData({
      nome_fantasia: consultoria.nome_fantasia,
      razao_social: consultoria.razao_social || "",
      cnpj: consultoria.cnpj,
      email_master: consultoria.email_master,
      status: consultoria.status,
      faturamento_modelo: consultoria.faturamento_modelo || "por_colaborador",
      valor_unitario: consultoria.valor_unitario || 4.90,
      ciclo_faturamento: consultoria.ciclo_faturamento || "mensal"
    });

    // Carregar dados do usuário master se existir
    if (consultoria.master_user_data) {
      const master = consultoria.master_user_data;
      setMasterUserData({
        nome: master.nome || "",
        cpf: master.cpf || "",
        data_nascimento: master.data_nascimento ? format(new Date(master.data_nascimento), 'yyyy-MM-dd') : "",
        email: master.email || consultoria.email_master,
        senha: "", // Não pré-preencher senha por segurança
        confirmacao_senha: "",
        enviar_boas_vindas: false
      });
    } else {
      // Se não tem master_user_data, inicializar com email da consultoria
      setMasterUserData({
        nome: "",
        cpf: "",
        data_nascimento: "",
        email: consultoria.email_master || "",
        senha: "",
        confirmacao_senha: "",
        enviar_boas_vindas: true
      });
    }
    setMasterUserErrors({}); // Clear errors when opening edit dialog
    setShowDialog(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Sincronizar email_master com o email do usuário master
    const dataToSubmit = {
      ...formData,
      email_master: masterUserData.email
    };

    if (editingConsultoria) {
      updateMutation.mutate({ id: editingConsultoria.id, data: dataToSubmit });
    } else {
      createMutation.mutate(dataToSubmit);
    }
  };

  const handleViewDetails = (consultoriaId) => {
    window.location.href = createPageUrl(`ConsultoriaDetail?id=${consultoriaId}`);
  };

  const handleViewAsConsultoria = (consultoria) => {
    // Salvar dados da impersonation no localStorage com estrutura correta
    const impersonationData = {
      type: 'consultoria',
      consultoria_id: consultoria.id,
      consultoria_nome: consultoria.nome_fantasia,
      admin_email: user.email
    };
    
    console.log('Setting impersonation:', impersonationData);
    localStorage.setItem('admin_impersonation', JSON.stringify(impersonationData));

    toast.success(`Visualização ativada como ${consultoria.nome_fantasia}`);

    // Redirecionar para o dashboard da consultoria
    setTimeout(() => {
      window.location.href = createPageUrl('ConsultoriaDashboard');
    }, 500);
  };

  const handleViewMasterUser = (consultoria) => {
    console.log('Opening master user info for:', consultoria);
    console.log('master_user_data:', consultoria.master_user_data);
    setSelectedConsultoriaForInfo(consultoria);
    setShowMasterInfo(true);
  };

  const handleSort = (column) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(column);
      setSortDirection('asc');
    }
  };

  // Cálculos dos KPIs
  const consultoriasAtivas = consultorias.filter(c => c.status === 'ativo');
  const consultoriasInativas = consultorias.filter(c => c.status === 'inativo' || c.status === 'suspenso');
  const totalEmpresas = companies.length;
  const totalColaboradores = employees.filter(e => e.status === 'active').length;

  const currentMonth = format(new Date(), 'yyyy-MM');
  const lastMonth = format(subMonths(new Date(), 1), 'yyyy-MM');
  // const twoMonthsAgo = format(subMonths(new Date(), 2), 'yyyy-MM'); // Not directly used in final outline KPIs.

  // Faturamento
  const faturamentoMesAtual = faturas
    .filter(f => f.competencia === currentMonth && f.status === 'paga')
    .reduce((acc, f) => acc + (f.valor_total || 0), 0);

  const faturamentoMesAnterior = faturas
    .filter(f => f.competencia === lastMonth && f.status === 'paga')
    .reduce((acc, f) => acc + (f.valor_total || 0), 0);

  const faturamentoAnual = faturas
    .filter(f => f.status === 'paga' && f.created_date && new Date(f.created_date).getFullYear() === new Date().getFullYear())
    .reduce((acc, f) => acc + (f.valor_total || 0), 0);

  const crescimentoFaturamento = faturamentoMesAnterior > 0
    ? (((faturamentoMesAtual - faturamentoMesAnterior) / faturamentoMesAnterior) * 100).toFixed(1)
    : 0;

  // Crescimento
  const thirtyDaysAgo = subMonths(new Date(), 1);
  const novasConsultorias = consultorias.filter(c =>
    c.created_date && isAfter(new Date(c.created_date), thirtyDaysAgo)
  ).length;

  const novasEmpresas = companies.filter(c =>
    c.created_date && isAfter(new Date(c.created_date), thirtyDaysAgo)
  ).length;

  const colaboradoresLastMonth = employees.filter(e =>
    e.created_date && new Date(e.created_date) < thirtyDaysAgo
  ).length;

  const crescimentoColaboradores = colaboradoresLastMonth > 0
    ? (((totalColaboradores - colaboradoresLastMonth) / colaboradoresLastMonth) * 100).toFixed(1)
    : 0;

  // Calcular consultorias em expansão (que ganharam empresas no mês)
  const consultoriasEmExpansao = consultorias.filter(c => {
    const newCompaniesCont = companies.filter(comp =>
      comp.consultoria_id === c.id &&
      comp.created_date &&
      isAfter(new Date(comp.created_date), thirtyDaysAgo)
    ).length;
    return newCompaniesCont > 0;
  }).length;

  const percentualExpansao = consultorias.length > 0
    ? ((consultoriasEmExpansao / consultorias.length) * 100).toFixed(0)
    : 0;

  // Ticket médio por consultoria
  const ticketMedio = consultoriasAtivas.length > 0
    ? faturamentoMesAtual / consultoriasAtivas.length
    : 0;

  // MRR (faturas pendentes + pagas do mês)
  const mrr = faturas
    .filter(f => f.competencia === currentMonth && (f.status === 'paga' || f.status === 'pendente'))
    .reduce((acc, f) => acc + (f.valor_total || 0), 0);

  // Consultorias com receita zero
  const consultoriasComReceitaZero = consultorias.filter(c => {
    const faturasConsultoria = faturas.filter(f => f.destino_id === c.id && f.competencia === currentMonth);
    return faturasConsultoria.length === 0 || faturasConsultoria.every(f => (f.valor_total || 0) === 0);
  }).length;

  // Engajamento médio global (removed from top KPIs, but used in table)
  const completedAssessments = assessments.filter(a => a.completed_at);
  // const engajamentoMedio = totalColaboradores > 0
  //   ? ((completedAssessments.length / totalColaboradores) * 100).toFixed(1)
  //   : 0;

  // Média de empresas por consultoria
  const mediaEmpresasPorConsultoria = consultorias.length > 0
    ? (totalEmpresas / consultorias.length).toFixed(1)
    : 0;

  // Média de colaboradores por empresa
  const mediaColaboradoresPorEmpresa = totalEmpresas > 0
    ? (totalColaboradores / totalEmpresas).toFixed(0)
    : 0;

  // Consultorias com atrasos
  const consultoriasComAtrasos = new Set(
    faturas.filter(f => f.status === 'vencida').map(f => f.destino_id)
  ).size;

  // Calcular IM-Score global
  const calculateGlobalIMScore = () => {
    if (completedAssessments.length === 0) return 0;

    const validScores = completedAssessments.filter(a =>
      (a.phq9_score !== undefined && a.phq9_score !== null) ||
      (a.gad7_score !== undefined && a.gad7_score !== null) ||
      (a.prima_score !== undefined && a.prima_score !== null)
    );

    if (validScores.length === 0) return 0;

    let mentalHealthSum = 0;
    let psychosocialSum = 0;
    let mentalHealthCount = 0;
    let psychosocialCount = 0;

    validScores.forEach(a => {
      if ((a.phq9_score !== undefined && a.phq9_score !== null) || (a.gad7_score !== undefined && a.gad7_score !== null)) {
        let mh = 0;
        let count = 0;

        if (a.phq9_score !== undefined && a.phq9_score !== null) {
          mh += ((27 - a.phq9_score) / 27) * 100;
          count++;
        }
        if (a.gad7_score !== undefined && a.gad7_score !== null) {
          mh += ((21 - a.gad7_score) / 21) * 100;
          count++;
        }

        if (count > 0) {
          mentalHealthSum += mh / count;
          mentalHealthCount++;
        }
      }

      if (a.prima_score !== undefined && a.prima_score !== null) {
        psychosocialSum += ((a.prima_score - 1) / 4) * 100;
        psychosocialCount++;
      }
    });

    const avgMentalHealth = mentalHealthCount > 0 ? mentalHealthSum / mentalHealthCount : 0;
    const avgPsychosocial = psychosocialCount > 0 ? psychosocialSum / psychosocialCount : 0;

    let totalWeight = 0;
    let weightedSum = 0;

    if (mentalHealthCount > 0) {
      weightedSum += avgMentalHealth * 0.5;
      totalWeight += 0.5;
    }

    if (psychosocialCount > 0) {
      weightedSum += avgPsychosocial * 0.5;
      totalWeight += 0.5;
    }

    return totalWeight > 0 ? (weightedSum / totalWeight).toFixed(1) : 0;
  };

  const imScoreGlobal = parseFloat(calculateGlobalIMScore());


  // Filtrar consultorias
  let filteredConsultorias = consultorias.filter(c => {
    const searchMatch = c.nome_fantasia.toLowerCase().includes(searchTerm.toLowerCase()) ||
                       c.cnpj.includes(searchTerm);
    const statusMatch = statusFilter === 'all' || c.status === statusFilter;

    let periodMatch = true;
    if (c.created_date) {
      const createdDate = new Date(c.created_date);
      if (periodFilter === '30dias') {
        periodMatch = isAfter(createdDate, thirtyDaysAgo);
      } else if (periodFilter === '90dias') {
        periodMatch = isAfter(createdDate, subMonths(new Date(), 3));
      } else if (periodFilter === 'ano') {
        periodMatch = isAfter(createdDate, subMonths(new Date(), 12));
      }
    }

    return searchMatch && statusMatch && periodMatch;
  });

  // Preparar dados da tabela
  const consultoriaData = filteredConsultorias.map(consultoria => {
    const consultoriaCompanies = companies.filter(c => c.consultoria_id === consultoria.id);
    const consultoriaEmployees = employees.filter(e =>
      consultoriaCompanies.some(c => c.id === e.company_id) && e.status === 'active'
    );
    const consultoriaAssessments = assessments.filter(a =>
      consultoriaCompanies.some(c => c.id === a.company_id)
    );
    const consultoriaCompletedAssessments = consultoriaAssessments.filter(a => a.completed_at);

    const engajamento = consultoriaEmployees.length > 0
      ? ((consultoriaCompletedAssessments.length / consultoriaEmployees.length) * 100).toFixed(1)
      : 0;

    // Calcular IM-Score da consultoria
    let imScore = 0;
    if (consultoriaCompletedAssessments.length > 0) {
      const validScores = consultoriaCompletedAssessments.filter(a =>
        (a.phq9_score !== undefined && a.phq9_score !== null) ||
        (a.gad7_score !== undefined && a.gad7_score !== null) ||
        (a.prima_score !== undefined && a.prima_score !== null)
      );

      if (validScores.length > 0) {
        let mentalHealthSum = 0;
        let psychosocialSum = 0;
        let mentalHealthCount = 0;
        let psychosocialCount = 0;

        validScores.forEach(a => {
          if ((a.phq9_score !== undefined && a.phq9_score !== null) || (a.gad7_score !== undefined && a.gad7_score !== null)) {
            let mh = 0;
            let count = 0;

            if (a.phq9_score !== undefined && a.phq9_score !== null) {
              mh += ((27 - a.phq9_score) / 27) * 100;
              count++;
            }
            if (a.gad7_score !== undefined && a.gad7_score !== null) {
              mh += ((21 - a.gad7_score) / 21) * 100;
              count++;
            }

            if (count > 0) {
              mentalHealthSum += mh / count;
              mentalHealthCount++;
            }
          }

          if (a.prima_score !== undefined && a.prima_score !== null) {
            psychosocialSum += ((a.prima_score - 1) / 4) * 100;
            psychosocialCount++;
          }
        });

        const avgMentalHealth = mentalHealthCount > 0 ? mentalHealthSum / mentalHealthCount : 0;
        const avgPsychosocial = psychosocialCount > 0 ? psychosocialSum / psychosocialCount : 0;

        let totalWeight = 0;
        let weightedSum = 0;

        if (mentalHealthCount > 0) {
          weightedSum += avgMentalHealth * 0.5;
          totalWeight += 0.5;
        }

        if (psychosocialCount > 0) {
          weightedSum += avgPsychosocial * 0.5;
          totalWeight += 0.5;
        }

        imScore = totalWeight > 0 ? (weightedSum / totalWeight).toFixed(1) : 0;
      }
    }

    const faturasConsultoria = faturas.filter(f =>
      f.destino_id === consultoria.id && f.competencia === currentMonth
    );
    const faturamento = faturasConsultoria.reduce((acc, f) => acc + (f.valor_total || 0), 0);

    const hasOverdueInvoice = faturasConsultoria.some(f => f.status === 'vencida');
    const hasPendingInvoice = faturasConsultoria.some(f => f.status === 'pendente');

    const statusFinanceiro = hasOverdueInvoice ? 'atrasado' :
                             hasPendingInvoice ? 'pendente' : 'pago';

    return {
      ...consultoria,
      empresas: consultoriaCompanies.length,
      colaboradores: consultoriaEmployees.length,
      avaliacoes_enviadas: consultoriaAssessments.length,
      engajamento: parseFloat(engajamento),
      imScore: parseFloat(imScore),
      faturamento,
      statusFinanceiro,
      ultimaAtividade: consultoria.updated_date || consultoria.created_date
    };
  });

  // Ordenar
  const sortedData = [...consultoriaData].sort((a, b) => {
    let aVal = a[sortColumn];
    let bVal = b[sortColumn];

    if (sortColumn === 'nome_fantasia' || sortColumn === 'statusFinanceiro' || sortColumn === 'status') {
      aVal = String(aVal).toLowerCase();
      bVal = String(bVal).toLowerCase();
    } else if (sortColumn === 'ultimaAtividade') {
      aVal = new Date(aVal);
      bVal = new Date(bVal);
    }

    if (sortDirection === 'asc') {
      return aVal > bVal ? 1 : -1;
    } else {
      return aVal < bVal ? 1 : -1;
    }
  });

  const getStatusBadge = (status) => {
    const badges = {
      ativo: <Badge className="bg-green-100 text-green-800 border-green-200">🟢 Ativo</Badge>,
      inativo: <Badge className="bg-gray-100 text-gray-800 border-gray-200">⚪ Inativo</Badge>,
      suspenso: <Badge className="bg-red-100 text-red-800 border-red-200">🔴 Suspenso</Badge>
    };
    return badges[status] || badges.inativo;
  };

  const getStatusFinanceiroBadge = (status) => {
    const badges = {
      pago: <span className="font-semibold text-green-600">🟢 Pago</span>,
      pendente: <span className="font-semibold text-yellow-600">🟠 Pendente</span>,
      atrasado: <span className="font-semibold text-red-600">🔴 Atrasado</span>
    };
    return badges[status] || badges.pago;
  };

  const getIMScoreColor = (score) => {
    if (score >= 70) return 'text-green-600';
    if (score >= 50) return 'text-yellow-600';
    return 'text-red-600';
  };

  const TrendIndicator = ({ value, inverse = false }) => {
    const numericValue = parseFloat(value);
    if (isNaN(numericValue) || numericValue === 0) return <span className="text-xs text-gray-500">—</span>;

    const isPositive = inverse ? numericValue < 0 : numericValue > 0;
    const isNegative = inverse ? numericValue > 0 : numericValue < 0;

    if (isPositive) {
      return (
        <span className="flex items-center gap-1 text-green-600 text-xs font-semibold">
          <ArrowUp className="w-3 h-3" />
          {Math.abs(numericValue)}%
        </span>
      );
    } else if (isNegative) {
      return (
        <span className="flex items-center gap-1 text-red-600 text-xs font-semibold">
          <ArrowDown className="w-3 h-3" />
          {Math.abs(numericValue)}%
        </span>
      );
    }
    return <span className="text-xs text-gray-500">—</span>;
  };

  return (
    <TooltipProvider>
      <div className="p-4 md:p-8 min-h-screen" style={{ backgroundColor: '#F8F6FB' }}>
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold" style={{ color: '#2E2E2E' }}>
              Gestão de Consultorias
            </h1>
            <p className="text-gray-500 mt-2">
              Gerencie as consultorias parceiras, visualize indicadores de uso, performance, engajamento e faturamento
            </p>
          </div>
          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={() => toast.info('Funcionalidade em desenvolvimento')}
              style={{ borderColor: '#4B2672', color: '#4B2672' }}
            >
              <Download className="w-4 h-4 mr-2" />
              Exportar
            </Button>
            {/* The button now directly triggers the dialog state */}
            <Button
              onClick={() => setShowDialog(true)}
              className="text-white shadow-lg hover:shadow-xl transition-all"
              style={{
                background: 'linear-gradient(135deg, #4B2672 0%, #6B36B4 100%)'
              }}
            >
              <Plus className="w-4 h-4 mr-2" />
              Nova Consultoria
            </Button>
          </div>
        </div>

        {/* Indicadores de Crescimento e Expansão */}
        <div className="my-6">
          <h2 className="text-lg font-semibold mb-4" style={{ color: '#2E2E2E' }}>
            📈 Crescimento e Expansão (30 dias)
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Tooltip>
              <TooltipTrigger asChild>
                <Card className="shadow-md hover:shadow-xl transition-all cursor-help">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                      <Building2 className="w-4 h-4" style={{ color: '#4B2672' }} />
                      Novas Consultorias
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-baseline justify-between">
                      <p className="text-4xl font-bold" style={{ color: '#4B2672' }}>
                        +{novasConsultorias}
                      </p>
                      <TrendIndicator value={((novasConsultorias / Math.max(consultorias.length - novasConsultorias, 1)) * 100).toFixed(1)} />
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      {consultorias.length} total
                    </p>
                  </CardContent>
                </Card>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-xs max-w-xs">Novas consultorias cadastradas nos últimos 30 dias</p>
              </TooltipContent>
            </Tooltip>

            <Tooltip>
              <TooltipTrigger asChild>
                <Card className="shadow-md hover:shadow-xl transition-all cursor-help">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                      <Briefcase className="w-4 h-4 text-blue-600" />
                      Novas Empresas
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-baseline justify-between">
                      <p className="text-4xl font-bold text-blue-600">
                        +{novasEmpresas}
                      </p>
                      <TrendIndicator value={((novasEmpresas / Math.max(totalEmpresas - novasEmpresas, 1)) * 100).toFixed(1)} />
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      {totalEmpresas} total
                    </p>
                  </CardContent>
                </Card>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-xs max-w-xs">Empresas cadastradas pelas consultorias nos últimos 30 dias</p>
              </TooltipContent>
            </Tooltip>

            <Tooltip>
              <TooltipTrigger asChild>
                <Card className="shadow-md hover:shadow-xl transition-all cursor-help">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                      <TrendingUp className="w-4 h-4" style={{ color: '#FFD84D' }} />
                      Consultorias em Expansão
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-baseline justify-between">
                      <p className="text-4xl font-bold" style={{ color: '#FFD84D' }}>
                        {percentualExpansao}%
                      </p>
                      {/* No direct trend for this KPI currently, could add later if needed */}
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      {consultoriasEmExpansao} de {consultorias.length}
                    </p>
                  </CardContent>
                </Card>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-xs max-w-xs">Percentual de consultorias que adicionaram novas empresas neste mês</p>
              </TooltipContent>
            </Tooltip>

            <Tooltip>
              <TooltipTrigger asChild>
                <Card className="shadow-md hover:shadow-xl transition-all cursor-help">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                      <Users className="w-4 h-4 text-green-600" />
                      Crescimento de Colaboradores
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-baseline justify-between">
                      <p className="text-4xl font-bold text-green-600">
                        +{crescimentoColaboradores}%
                      </p>
                      <TrendIndicator value={crescimentoColaboradores} />
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      {totalColaboradores.toLocaleString('pt-BR')} total
                    </p>
                  </CardContent>
                </Card>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-xs max-w-xs">Variação mensal da base total de colaboradores cadastrados</p>
              </TooltipContent>
            </Tooltip>
          </div>
        </div>

        {/* Indicadores de Receita e Monetização */}
        <div className="my-6">
          <h2 className="text-lg font-semibold mb-4" style={{ color: '#2E2E2E' }}>
            💰 Receita e Monetização
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Tooltip>
              <TooltipTrigger asChild>
                <Card className="shadow-md hover:shadow-xl transition-all cursor-help">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                      <DollarSign className="w-4 h-4 text-green-600" />
                      Faturamento Total (Mês)
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-baseline justify-between">
                      <p className="text-4xl font-bold text-green-600">
                        {faturamentoMesAtual.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 0 })}
                      </p>
                      <TrendIndicator value={crescimentoFaturamento} />
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      vs mês anterior
                    </p>
                  </CardContent>
                </Card>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-xs max-w-xs">Receita total somada de todas as consultorias no mês corrente</p>
              </TooltipContent>
            </Tooltip>

            <Tooltip>
              <TooltipTrigger asChild>
                <Card className="shadow-md hover:shadow-xl transition-all cursor-help">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                      <TrendingUp className="w-4 h-4" style={{ color: '#4B2672' }} />
                      Receita Anual Acumulada
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-4xl font-bold" style={{ color: '#4B2672' }}>
                      {faturamentoAnual.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 0 })}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      Ano {new Date().getFullYear()}
                    </p>
                  </CardContent>
                </Card>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-xs max-w-xs">Receita total acumulada no ano corrente</p>
              </TooltipContent>
            </Tooltip>

            <Tooltip>
              <TooltipTrigger asChild>
                <Card className="shadow-md hover:shadow-xl transition-all cursor-help">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                      <Activity className="w-4 h-4" style={{ color: '#A57CE0' }} />
                      Ticket Médio por Consultoria
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-4xl font-bold" style={{ color: '#A57CE0' }}>
                      {ticketMedio.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 0 })}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      Receita média mensal
                    </p>
                  </CardContent>
                </Card>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-xs max-w-xs">Receita média por consultoria ativa no mês</p>
              </TooltipContent>
            </Tooltip>

            <Tooltip>
              <TooltipTrigger asChild>
                <Card className="shadow-md hover:shadow-xl transition-all cursor-help">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                      <DollarSign className="w-4 h-4" style={{ color: '#FFD84D' }} />
                      MRR (Receita Recorrente)
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-4xl font-bold" style={{ color: '#FFD84D' }}>
                      {mrr.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 0 })}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      Faturamento garantido
                    </p>
                  </CardContent>
                </Card>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-xs max-w-xs">Receita mensal recorrente (faturas pagas + pendentes)</p>
              </TooltipContent>
            </Tooltip>
          </div>
        </div>

        {/* Indicadores de Operação e Performance */}
        <div className="my-6">
          <h2 className="text-lg font-semibold mb-4" style={{ color: '#2E2E2E' }}>
            ⚙️ Operação e Performance
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Tooltip>
              <TooltipTrigger asChild>
                <Card className="shadow-md hover:shadow-xl transition-all cursor-help">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                      <Activity className="w-4 h-4 text-purple-600" />
                      Consultorias Ativas
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-4xl font-bold text-purple-600">
                      {((consultoriasAtivas.length / Math.max(consultorias.length, 1)) * 100).toFixed(0)}%
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      {consultoriasAtivas.length} de {consultorias.length}
                    </p>
                  </CardContent>
                </Card>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-xs max-w-xs">Percentual de consultorias com status ativo</p>
              </TooltipContent>
            </Tooltip>

            <Tooltip>
              <TooltipTrigger asChild>
                <Card className="shadow-md hover:shadow-xl transition-all cursor-help">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                      <Briefcase className="w-4 h-4 text-indigo-600" />
                      Média Empresas/Consultoria
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-4xl font-bold text-indigo-600">
                      {mediaEmpresasPorConsultoria}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      Empresas por consultoria
                    </p>
                  </CardContent>
                </Card>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-xs max-w-xs">Número médio de empresas gerenciadas por consultoria</p>
              </TooltipContent>
            </Tooltip>

            <Tooltip>
              <TooltipTrigger asChild>
                <Card className="shadow-md hover:shadow-xl transition-all cursor-help">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                      <Users className="w-4 h-4 text-cyan-600" />
                      Média Colaboradores/Empresa
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-4xl font-bold text-cyan-600">
                      {mediaColaboradoresPorEmpresa}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      Tamanho médio das empresas
                    </p>
                  </CardContent>
                </Card>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-xs max-w-xs">Número médio de colaboradores por empresa vinculada</p>
              </TooltipContent>
            </Tooltip>

            <Tooltip>
              <TooltipTrigger asChild>
                <Card className="shadow-md hover:shadow-xl transition-all cursor-help">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-red-600" />
                      Consultorias com Atrasos
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-4xl font-bold text-red-600">
                      {consultoriasComAtrasos}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      Com faturas vencidas
                    </p>
                  </CardContent>
                </Card>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-xs max-w-xs">Número de consultorias com faturas em atraso</p>
              </TooltipContent>
            </Tooltip>
          </div>
        </div>

        {/* Filtros */}
        <Card className="shadow-md mt-6">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Input
                placeholder="Buscar por nome ou CNPJ..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filtrar por status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os status</SelectItem>
                  <SelectItem value="ativo">Ativas</SelectItem>
                  <SelectItem value="inativo">Inativas</SelectItem>
                  <SelectItem value="suspenso">Suspensas</SelectItem>
                </SelectContent>
              </Select>
              <Select value={periodFilter} onValueChange={setPeriodFilter}>
                <SelectTrigger>
                  <Calendar className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="Período" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todo período</SelectItem>
                  <SelectItem value="30dias">Últimos 30 dias</SelectItem>
                  <SelectItem value="90dias">Último trimestre</SelectItem>
                  <SelectItem value="ano">Ano atual</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Tabela de Consultorias - Largura Total */}
        <Card className="shadow-md mt-6">
          <CardHeader>
            <CardTitle>Consultorias Cadastradas ({sortedData.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50">
                    <TableHead className="cursor-pointer" onClick={() => handleSort('nome_fantasia')}>
                      Consultoria {sortColumn === 'nome_fantasia' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </TableHead>
                    <TableHead className="text-center cursor-pointer" onClick={() => handleSort('empresas')}>
                      Empresas {sortColumn === 'empresas' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </TableHead>
                    <TableHead className="text-center cursor-pointer" onClick={() => handleSort('colaboradores')}>
                      Colaboradores {sortColumn === 'colaboradores' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </TableHead>
                    <TableHead className="text-center cursor-pointer" onClick={() => handleSort('avaliacoes_enviadas')}>
                      Avaliações {sortColumn === 'avaliacoes_enviadas' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </TableHead>
                    <TableHead className="text-center cursor-pointer" onClick={() => handleSort('engajamento')}>
                      Engajamento {sortColumn === 'engajamento' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </TableHead>
                    <TableHead className="text-center cursor-pointer" onClick={() => handleSort('imScore')}>
                      IM-Score {sortColumn === 'imScore' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </TableHead>
                    <TableHead className="text-center cursor-pointer" onClick={() => handleSort('faturamento')}>
                      Faturamento {sortColumn === 'faturamento' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </TableHead>
                    <TableHead className="text-center">Status Financeiro</TableHead>
                    <TableHead className="text-center">Status</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sortedData.map((consultoria) => (
                    <TableRow
                      key={consultoria.id}
                      className="hover:bg-gray-50 transition-colors"
                    >
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Building2 className="w-4 h-4 text-gray-400" />
                          <div>
                            <p className="font-semibold">{consultoria.nome_fantasia}</p>
                            <p className="text-xs text-gray-500">{consultoria.cnpj}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="text-center font-semibold">
                        {consultoria.empresas}
                      </TableCell>
                      <TableCell className="text-center font-semibold">
                        {consultoria.colaboradores.toLocaleString('pt-BR')}
                      </TableCell>
                      <TableCell className="text-center font-semibold">
                        {consultoria.avaliacoes_enviadas.toLocaleString('pt-BR')}
                      </TableCell>
                      <TableCell className="text-center">
                        <span className={`font-semibold ${
                          consultoria.engajamento >= 75 ? 'text-green-600' :
                          consultoria.engajamento >= 50 ? 'text-yellow-600' :
                          'text-red-600'
                        }`}>
                          {consultoria.engajamento}%
                        </span>
                      </TableCell>
                      <TableCell className="text-center">
                        <span className={`font-semibold ${getIMScoreColor(consultoria.imScore)}`}>
                          {consultoria.imScore || '—'}
                        </span>
                      </TableCell>
                      <TableCell className="text-center font-semibold text-green-600">
                        {consultoria.faturamento.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 0 })}
                      </TableCell>
                      <TableCell className="text-center text-sm">
                        {getStatusFinanceiroBadge(consultoria.statusFinanceiro)}
                      </TableCell>
                      <TableCell className="text-center">
                        {getStatusBadge(consultoria.status)}
                      </TableCell>
                      <TableCell className="text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex justify-end gap-2">
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleViewMasterUser(consultoria)}
                                title="Ver Usuário Master"
                              >
                                <Key className="w-4 h-4 text-gray-600" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p className="text-xs">Ver informações do usuário master</p>
                            </TooltipContent>
                          </Tooltip>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleViewAsConsultoria(consultoria)}
                                className="text-white hover:bg-purple-700"
                                style={{ backgroundColor: '#4B2672' }}
                                title="Ver como Consultoria"
                              >
                                <Eye className="w-4 h-4" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p className="text-xs">Entrar no modo de visualização da consultoria</p>
                            </TooltipContent>
                          </Tooltip>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleViewDetails(consultoria.id)}
                                title="Ver detalhes"
                              >
                                <FileText className="w-4 h-4 text-gray-600" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p className="text-xs">Ver detalhes da consultoria</p>
                              </TooltipContent>
                          </Tooltip>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleEdit(consultoria);
                                }}
                                title="Editar"
                              >
                                <Edit className="w-4 h-4 text-gray-600" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p className="text-xs">Editar informações da consultoria</p>
                              </TooltipContent>
                          </Tooltip>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Alertas Inteligentes - Abaixo da Tabela */}
        <div className="mt-6">
          <ConsultoriaAlertsPanel
            consultoriaData={sortedData}
            faturas={faturas}
            currentMonth={currentMonth}
            imScoreGlobal={imScoreGlobal}
            totalColaboradores={totalColaboradores}
            consultoriasComReceitaZero={consultoriasComReceitaZero}
            consultoriasComAtrasos={consultoriasComAtrasos}
          />
        </div>

        {/* Rankings Estratégicos */}
        <ConsultoriaStrategicRankings
          consultoriaData={sortedData}
          faturas={faturas}
          currentMonth={currentMonth}
        />

        {/* Distribuição de Receita */}
        <RevenueDistributionChart
          consultoriaData={sortedData}
          totalRevenue={faturamentoMesAtual}
        />
      </div>

      {/* Dialog de Nova/Editar Consultoria - moved outside main content div */}
      <Dialog open={showDialog} onOpenChange={(open) => {
        setShowDialog(open);
        if (!open) resetForm();
      }}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingConsultoria ? 'Editar Consultoria' : 'Nova Consultoria'}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Dados da Consultoria */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold" style={{ color: '#2E2E2E' }}>
                🏢 Dados da Consultoria
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="nome_fantasia">Nome Fantasia *</Label>
                  <Input
                    id="nome_fantasia"
                    value={formData.nome_fantasia}
                    onChange={(e) => setFormData({...formData, nome_fantasia: e.target.value})}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="razao_social">Razão Social</Label>
                  <Input
                    id="razao_social"
                    value={formData.razao_social}
                    onChange={(e) => setFormData({...formData, razao_social: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="cnpj">CNPJ *</Label>
                  <Input
                    id="cnpj"
                    value={formatCnpj(formData.cnpj)}
                    onChange={(e) => setFormData({...formData, cnpj: e.target.value})}
                    placeholder="00.000.000/0000-00"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="status">Status</Label>
                  <Select
                    value={formData.status}
                    onValueChange={(value) => setFormData({...formData, status: value})}
                  >
                    <SelectTrigger>
                        <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ativo">Ativo</SelectItem>
                      <SelectItem value="inativo">Inativo</SelectItem>
                      <SelectItem value="suspenso">Suspenso</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="border-t pt-4">
                <h3 className="font-semibold mb-3" style={{ color: '#2E2E2E' }}>
                  Configuração de Faturamento
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="faturamento_modelo">Modelo</Label>
                    <Select
                      value={formData.faturamento_modelo}
                      onValueChange={(value) => setFormData({...formData, faturamento_modelo: value})}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="por_colaborador">Por Colaborador</SelectItem>
                        <SelectItem value="por_empresa">Por Empresa</SelectItem>
                        <SelectItem value="plano_fixo">Plano Fixo</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="valor_unitario">Valor Unitário</Label>
                    <Input
                      id="valor_unitario"
                      type="number"
                      step="0.01"
                      value={formData.valor_unitario}
                      onChange={(e) => setFormData({...formData, valor_unitario: parseFloat(e.target.value)})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="ciclo_faturamento">Ciclo</Label>
                    <Select
                      value={formData.ciclo_faturamento}
                      onValueChange={(value) => setFormData({...formData, ciclo_faturamento: value})}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="mensal">Mensal</SelectItem>
                        <SelectItem value="trimestral">Trimestral</SelectItem>
                        <SelectItem value="anual">Anual</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            </div>

            {/* Dados do Usuário Master */}
            <MasterUserForm
              formData={masterUserData}
              onChange={setMasterUserData}
              errors={masterUserErrors}
              setErrors={setMasterUserErrors}
              isEdit={!!editingConsultoria}
            />

            {/* Botões */}
            <div className="flex justify-end gap-3 pt-4 border-t">
              <Button type="button" variant="outline" onClick={() => setShowDialog(false)}>
                Cancelar
              </Button>
              <Button
                type="submit"
                className="text-white"
                style={{ backgroundColor: '#4B2672' }}
                disabled={createMutation.isPending || updateMutation.isPending}
              >
                {(createMutation.isPending || updateMutation.isPending) ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    {editingConsultoria ? 'Atualizando...' : 'Criando...'}
                  </>
                ) : (
                  <>
                    {editingConsultoria ? 'Atualizar Consultoria' : 'Criar Consultoria'}
                  </>
                )}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Dialog de Info do Master User */}
      {showMasterInfo && selectedConsultoriaForInfo && (
        <MasterUserInfo
          consultoriaId={selectedConsultoriaForInfo.id}
          masterUserData={selectedConsultoriaForInfo.master_user_data}
          onClose={() => {
            setShowMasterInfo(false);
            setSelectedConsultoriaForInfo(null);
            // Recarregar dados para garantir que estão atualizados
            queryClient.invalidateQueries({ queryKey: ['consultorias'] });
          }}
        />
      )}
    </TooltipProvider>
  );
}
