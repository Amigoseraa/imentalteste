import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Button } from "@/components/ui/button";
import { Download, Printer, X } from "lucide-react";
import { toast } from "sonner";

const PRIMA_CATEGORIES = {
  'A': 'Teor do Trabalho',
  'B': 'Carga e Ritmo',
  'C': 'Horário',
  'D': 'Controle',
  'E': 'Ambiente',
  'F': 'Cultura',
  'G': 'Relações',
  'H': 'Papéis',
  'I': 'Carreira',
  'J': 'Interface Lar-Trabalho'
};

export default function PDFReport() {
  const [companyId, setCompanyId] = useState(null);
  const [loading, setLoading] = useState(true);

  const urlParams = new URLSearchParams(window.location.search);
  const assessmentId = urlParams.get('id');

  useEffect(() => {
    const loadData = async () => {
      try {
        const userData = await base44.auth.me();
        const impersonationData = localStorage.getItem('admin_impersonation');
        if (impersonationData) {
          const parsed = JSON.parse(impersonationData);
          setCompanyId(parsed.company_id);
        } else {
          setCompanyId(userData.company_id);
        }
      } catch (error) {
        console.error("Error loading data:", error);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  const { data: assessments } = useQuery({
    queryKey: ['assessments-pdf', companyId],
    queryFn: async () => {
      if (!companyId) return [];
      return await base44.entities.Assessment.filter(
        { company_id: companyId, completed_at: { $ne: null } },
        '-created_date'
      );
    },
    enabled: !!companyId,
    initialData: [],
  });

  const { data: company } = useQuery({
    queryKey: ['company-pdf', companyId],
    queryFn: async () => {
      if (!companyId) return null;
      const companies = await base44.entities.Company.filter({ id: companyId });
      return companies[0] || null;
    },
    enabled: !!companyId,
  });

  const { data: departments } = useQuery({
    queryKey: ['departments-pdf', companyId],
    queryFn: async () => {
      if (!companyId) return [];
      return await base44.entities.Department.filter({ company_id: companyId });
    },
    enabled: !!companyId,
    initialData: [],
  });

  const calculateIEP = () => {
    if (assessments.length === 0) return 0;
    const primaScores = assessments
      .filter(a => a.prima_score !== undefined && a.prima_score !== null)
      .map(a => a.prima_score);
    if (primaScores.length === 0) return 0;
    const avgPrima = primaScores.reduce((a, b) => a + b, 0) / primaScores.length;
    return parseFloat((((5 - avgPrima) / 4) * 100).toFixed(1));
  };

  const getTopFactors = () => {
    const factorScores = {};
    Object.values(PRIMA_CATEGORIES).forEach(name => {
      factorScores[name] = [];
    });

    const categories = {
      'A': [1, 2, 3], 'B': [4, 5, 6], 'C': [7, 8, 9], 'D': [10, 11, 12],
      'E': [13, 14, 15], 'F': [16, 17, 18], 'G': [19, 20, 21], 'H': [22, 23, 24],
      'I': [25, 26, 27], 'J': [28, 29, 30]
    };

    assessments.forEach(a => {
      if (a.prima_responses) {
        Object.entries(categories).forEach(([cat, items]) => {
          items.forEach(item => {
            const value = a.prima_responses[`q${item}`];
            if (value) factorScores[PRIMA_CATEGORIES[cat]].push(value);
          });
        });
      }
    });

    return Object.entries(factorScores)
      .map(([name, scores]) => {
        if (scores.length === 0) return null;
        const avg = scores.reduce((a, b) => a + b, 0) / scores.length;
        const riskScore = ((5 - avg) / 4) * 100;
        return {
          name,
          score: riskScore.toFixed(1),
          level: riskScore < 35 ? 'Baixo' : riskScore < 60 ? 'Médio' : 'Alto'
        };
      })
      .filter(f => f !== null)
      .sort((a, b) => b.score - a.score)
      .slice(0, 5);
  };

  const getHeatmapData = () => {
    const data = [];
    departments.forEach(dept => {
      const deptAssessments = assessments.filter(a => a.department_id === dept.id);
      if (deptAssessments.length === 0) return;

      const categories = {
        'A': [1, 2, 3], 'B': [4, 5, 6], 'C': [7, 8, 9], 'D': [10, 11, 12],
        'E': [13, 14, 15], 'F': [16, 17, 18], 'G': [19, 20, 21], 'H': [22, 23, 24],
        'I': [25, 26, 27], 'J': [28, 29, 30]
      };

      const categoryScores = {};
      Object.entries(categories).forEach(([cat, items]) => {
        categoryScores[cat] = [];
        deptAssessments.forEach(a => {
          if (a.prima_responses) {
            items.forEach(item => {
              const value = a.prima_responses[`q${item}`];
              if (value) categoryScores[cat].push(value);
            });
          }
        });
      });

      const rowData = { department: dept.name };
      Object.entries(categoryScores).forEach(([cat, scores]) => {
        if (scores.length > 0) {
          const avg = scores.reduce((a, b) => a + b, 0) / scores.length;
          const riskScore = ((5 - avg) / 4) * 100;
          rowData[PRIMA_CATEGORIES[cat]] = riskScore.toFixed(1);
        }
      });

      // Calcular risco global
      const deptScores = Object.values(rowData).filter(v => typeof v === 'string').map(v => parseFloat(v));
      const globalRisk = deptScores.length > 0 ? deptScores.reduce((a, b) => a + b, 0) / deptScores.length : 0;
      rowData.globalRisk = globalRisk;

      data.push(rowData);
    });

    return data;
  };

  const handlePrint = () => {
    window.print();
  };

  const handleClose = () => {
    window.history.back();
  };

  if (loading || !company) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin w-8 h-8 border-4 border-purple-600 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  const iep = calculateIEP();
  const topFactors = getTopFactors();
  const heatmapData = getHeatmapData();
  const today = new Date();

  return (
    <>
      <style>{`
        @media print {
          .no-print { display: none !important; }
          body { margin: 0; }
          .page-break { page-break-after: always; }
          @page { margin: 20mm; }
        }
        
        @media screen {
          .pdf-container {
            max-width: 210mm;
            margin: 0 auto;
            background: white;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
          }
        }

        .pdf-page {
          padding: 25mm;
          font-family: 'Open Sans', sans-serif;
          color: #444444;
        }

        .pdf-cover {
          min-height: 100vh;
          display: flex;
          flex-direction: column;
          background: linear-gradient(135deg, #EFE6F8 0%, #A77BCA 100%);
          position: relative;
        }

        .pdf-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 60px;
        }

        .pdf-title {
          font-family: 'Poppins', sans-serif;
          font-size: 36px;
          font-weight: 700;
          color: #5E2C91;
          text-align: center;
          margin: 100px 0 20px 0;
        }

        .pdf-subtitle {
          font-size: 18px;
          color: #2B2240;
          text-align: center;
          margin-bottom: 80px;
        }

        .pdf-identification {
          background: white;
          padding: 30px;
          border-radius: 12px;
          box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }

        .pdf-identification-row {
          display: flex;
          justify-content: space-between;
          margin-bottom: 15px;
          padding-bottom: 15px;
          border-bottom: 1px solid #EFE6F8;
        }

        .pdf-identification-label {
          font-weight: 600;
          color: #5E2C91;
        }

        .pdf-identification-value {
          color: #444444;
        }

        .pdf-footer {
          margin-top: auto;
          text-align: center;
          font-size: 12px;
          color: #2B2240;
          padding: 20px;
        }

        .section-title {
          font-family: 'Poppins', sans-serif;
          font-size: 24px;
          font-weight: 600;
          color: #5E2C91;
          margin: 40px 0 20px 0;
          border-bottom: 3px solid #A77BCA;
          padding-bottom: 10px;
        }

        .subsection-title {
          font-family: 'Poppins', sans-serif;
          font-size: 18px;
          font-weight: 600;
          color: #2B2240;
          margin: 30px 0 15px 0;
        }

        .pdf-table {
          width: 100%;
          border-collapse: collapse;
          margin: 20px 0;
        }

        .pdf-table th {
          background: #5E2C91;
          color: white;
          padding: 12px;
          text-align: left;
          font-weight: 600;
          font-size: 12px;
        }

        .pdf-table td {
          padding: 10px 12px;
          border-bottom: 1px solid #EFE6F8;
          font-size: 12px;
        }

        .pdf-table tr:nth-child(even) {
          background: #F8F8FA;
        }

        .risk-badge {
          padding: 4px 12px;
          border-radius: 12px;
          font-size: 11px;
          font-weight: 600;
          display: inline-block;
        }

        .risk-high { background: #FEE2E2; color: #991B1B; }
        .risk-medium { background: #FEF3C7; color: #92400E; }
        .risk-low { background: #D1FAE5; color: #065F46; }

        .action-bar {
          position: fixed;
          top: 20px;
          right: 20px;
          display: flex;
          gap: 10px;
          z-index: 1000;
        }

        .bar-chart {
          margin: 20px 0;
        }

        .bar-item {
          margin-bottom: 15px;
        }

        .bar-label {
          font-size: 12px;
          color: #444444;
          margin-bottom: 5px;
          display: flex;
          justify-between;
        }

        .bar-container {
          height: 30px;
          background: #F8F8FA;
          border-radius: 4px;
          overflow: hidden;
        }

        .bar-fill {
          height: 100%;
          display: flex;
          align-items: center;
          justify-content: flex-end;
          padding-right: 10px;
          color: white;
          font-size: 11px;
          font-weight: 600;
        }
      `}</style>

      <div className="no-print action-bar">
        <Button onClick={handlePrint} style={{ backgroundColor: '#5E2C91' }} className="text-white">
          <Printer className="w-4 h-4 mr-2" />
          Imprimir / Salvar PDF
        </Button>
        <Button onClick={handleClose} variant="outline">
          <X className="w-4 h-4 mr-2" />
          Fechar
        </Button>
      </div>

      <div className="pdf-container">
        {/* CAPA */}
        <div className="pdf-cover pdf-page">
          <div className="pdf-header">
            <div style={{ fontSize: '24px', fontWeight: '700', color: '#5E2C91' }}>
              PsyBox
            </div>
            <div style={{ fontSize: '16px', color: '#A77BCA' }}>
              PsyCompany
            </div>
          </div>

          <h1 className="pdf-title">
            RELATÓRIO DE RISCOS<br/>PSICOSSOCIAIS
          </h1>
          
          <p className="pdf-subtitle">
            Conforme NRs 01, 09 e 17 — Base para PGR e AET
          </p>

          <div className="pdf-identification">
            <div className="pdf-identification-row">
              <span className="pdf-identification-label">Empresa:</span>
              <span className="pdf-identification-value">{company.name}</span>
            </div>
            <div className="pdf-identification-row">
              <span className="pdf-identification-label">CNPJ:</span>
              <span className="pdf-identification-value">{company.cnpj || 'Não informado'}</span>
            </div>
            <div className="pdf-identification-row">
              <span className="pdf-identification-label">Setor:</span>
              <span className="pdf-identification-value">{company.sector || 'Não informado'}</span>
            </div>
            <div className="pdf-identification-row">
              <span className="pdf-identification-label">Período de Coleta:</span>
              <span className="pdf-identification-value">
                {assessments.length > 0 ? format(new Date(assessments[assessments.length - 1].created_date), 'dd/MM/yyyy', { locale: ptBR }) : '-'} até {assessments.length > 0 ? format(new Date(assessments[0].completed_at), 'dd/MM/yyyy', { locale: ptBR }) : '-'}
              </span>
            </div>
            <div className="pdf-identification-row">
              <span className="pdf-identification-label">Número de Respondentes:</span>
              <span className="pdf-identification-value">{assessments.length}</span>
            </div>
            <div className="pdf-identification-row" style={{ borderBottom: 'none' }}>
              <span className="pdf-identification-label">Data de Emissão:</span>
              <span className="pdf-identification-value">{format(today, 'dd/MM/yyyy', { locale: ptBR })}</span>
            </div>
          </div>

          <div className="pdf-footer">
            Relatório gerado automaticamente pela plataforma PsyBox<br/>
            Gestão de Saúde Mental e Riscos Psicossociais
          </div>
        </div>

        <div className="page-break"></div>

        {/* PÁGINA 2: IDENTIFICAÇÃO E FUNDAMENTAÇÃO */}
        <div className="pdf-page">
          <h2 className="section-title">1. Identificação e Fundamentação Legal</h2>
          
          <p style={{ lineHeight: '1.8', marginBottom: '20px' }}>
            Este relatório foi elaborado conforme as diretrizes da <strong>NR-01</strong> (Gestão de Riscos Ocupacionais), 
            <strong> NR-09</strong> (Avaliação de Exposição Ocupacional) e <strong>NR-17</strong> (Ergonomia), incluindo 
            fatores psicossociais e organizacionais, conforme exigência legal e diretrizes internacionais da OMS, OIT e PRIMA-EF.
          </p>

          <h3 className="subsection-title">Referências Técnicas:</h3>
          <ul style={{ lineHeight: '1.8', marginLeft: '20px' }}>
            <li><strong>PRIMA-EF</strong> (European Framework for Psychosocial Risk Management)</li>
            <li><strong>HSE Management Standards Indicator Tool</strong> (UK)</li>
            <li><strong>JCQ</strong> (Job Content Questionnaire — Karasek, 1985)</li>
            <li><strong>COPSOQ</strong> (Copenhagen Psychosocial Questionnaire)</li>
          </ul>

          <h2 className="section-title" style={{ marginTop: '60px' }}>2. Metodologia Aplicada</h2>
          
          <p style={{ lineHeight: '1.8', marginBottom: '20px' }}>
            <strong>Aplicação:</strong> Digital via PsyBox, confidencial e anônima<br/>
            <strong>Instrumentos:</strong> PRIMA-EF, HSE-IT, JCQ e COPSOQ<br/>
            <strong>Cálculo:</strong> Escores normalizados (0–100)<br/>
            <strong>Classificação dos níveis de risco:</strong>
          </p>

          <ul style={{ lineHeight: '1.8', marginLeft: '20px', marginBottom: '30px' }}>
            <li>🟢 <strong>Baixo:</strong> &lt;35 pontos</li>
            <li>🟠 <strong>Médio:</strong> 35–60 pontos</li>
            <li>🔴 <strong>Alto:</strong> &gt;60 pontos</li>
          </ul>

          <table className="pdf-table">
            <thead>
              <tr>
                <th>Instrumento</th>
                <th>Nº de Itens</th>
                <th>Fatores Avaliados</th>
                <th>Referência</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>PRIMA-EF</td>
                <td>30</td>
                <td>Demandas, Suporte, Reconhecimento</td>
                <td>OMS / OIT</td>
              </tr>
              <tr>
                <td>HSE-IT</td>
                <td>35</td>
                <td>Demandas, Controle, Apoio, Função</td>
                <td>HSE-UK</td>
              </tr>
              <tr>
                <td>JCQ</td>
                <td>22</td>
                <td>Carga, Controle, Apoio</td>
                <td>Karasek</td>
              </tr>
              <tr>
                <td>COPSOQ</td>
                <td>25+</td>
                <td>Justiça, Reconhecimento, Demanda</td>
                <td>COPSOQ-III</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="page-break"></div>

        {/* PÁGINA 3: RESULTADOS GERAIS */}
        <div className="pdf-page">
          <h2 className="section-title">3. Resultados Gerais</h2>
          
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '40px' }}>
            <div style={{ background: '#EFE6F8', padding: '20px', borderRadius: '8px' }}>
              <div style={{ fontSize: '12px', color: '#5E2C91', marginBottom: '5px' }}>
                IEP - Índice de Exposição Psicossocial
              </div>
              <div style={{ fontSize: '36px', fontWeight: '700', color: '#5E2C91' }}>
                {iep.toFixed(0)}
              </div>
              <div style={{ fontSize: '11px', color: '#2B2240' }}>
                {iep < 35 ? '🟢 Baixo' : iep < 60 ? '🟠 Médio' : '🔴 Alto'}
              </div>
            </div>

            <div style={{ background: '#F8F8FA', padding: '20px', borderRadius: '8px' }}>
              <div style={{ fontSize: '12px', color: '#444444', marginBottom: '5px' }}>
                Taxa de Engajamento
              </div>
              <div style={{ fontSize: '36px', fontWeight: '700', color: '#444444' }}>
                {assessments.length}
              </div>
              <div style={{ fontSize: '11px', color: '#666666' }}>
                Respondentes
              </div>
            </div>
          </div>

          <h3 className="subsection-title">Top 5 Fatores Críticos</h3>
          
          <div className="bar-chart">
            {topFactors.map((factor, idx) => {
              const score = parseFloat(factor.score);
              const color = score < 35 ? '#10b981' : score < 60 ? '#f59e0b' : '#ef4444';
              
              return (
                <div key={idx} className="bar-item">
                  <div className="bar-label">
                    <span>{factor.name}</span>
                    <span>{factor.score} ({factor.level})</span>
                  </div>
                  <div className="bar-container">
                    <div 
                      className="bar-fill" 
                      style={{ width: `${score}%`, backgroundColor: color }}
                    >
                      {factor.score}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div style={{ marginTop: '30px', padding: '15px', background: '#F8F8FA', borderRadius: '8px', fontSize: '12px' }}>
            <strong>Legenda:</strong> 🟢 Baixo (&lt;35) | 🟠 Médio (35-60) | 🔴 Alto (&gt;60)
          </div>
        </div>

        <div className="page-break"></div>

        {/* PÁGINA 4: MAPA DE RISCOS */}
        <div className="pdf-page">
          <h2 className="section-title">4. Mapa de Riscos Psicossociais</h2>
          
          {heatmapData.length > 0 ? (
            <table className="pdf-table">
              <thead>
                <tr>
                  <th>Departamento</th>
                  <th>Demandas</th>
                  <th>Autonomia</th>
                  <th>Suporte</th>
                  <th>Reconhecimento</th>
                  <th>Risco Global</th>
                </tr>
              </thead>
              <tbody>
                {heatmapData.map((row, idx) => {
                  const getRiskClass = (value) => {
                    if (!value) return '';
                    const num = parseFloat(value);
                    if (num < 35) return 'risk-low';
                    if (num < 60) return 'risk-medium';
                    return 'risk-high';
                  };

                  const getRiskLabel = (value) => {
                    if (!value) return 'N/A';
                    const num = parseFloat(value);
                    if (num < 35) return '🟢 Baixo';
                    if (num < 60) return '🟠 Médio';
                    return '🔴 Alto';
                  };

                  return (
                    <tr key={idx}>
                      <td><strong>{row.department}</strong></td>
                      <td>
                        <span className={`risk-badge ${getRiskClass(row['Teor do Trabalho'] || row['Carga e Ritmo'])}`}>
                          {row['Teor do Trabalho'] || row['Carga e Ritmo'] || 'N/A'}
                        </span>
                      </td>
                      <td>
                        <span className={`risk-badge ${getRiskClass(row['Controle'])}`}>
                          {row['Controle'] || 'N/A'}
                        </span>
                      </td>
                      <td>
                        <span className={`risk-badge ${getRiskClass(row['Relações'])}`}>
                          {row['Relações'] || 'N/A'}
                        </span>
                      </td>
                      <td>
                        <span className={`risk-badge ${getRiskClass(row['Carreira'])}`}>
                          {row['Carreira'] || 'N/A'}
                        </span>
                      </td>
                      <td>
                        <span className={`risk-badge ${getRiskClass(row.globalRisk)}`}>
                          {getRiskLabel(row.globalRisk)}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          ) : (
            <p style={{ textAlign: 'center', padding: '40px', color: '#666666' }}>
              Dados insuficientes para gerar mapa de riscos
            </p>
          )}
        </div>

        <div className="page-break"></div>

        {/* PÁGINA 5: MATRIZ NR-01 */}
        <div className="pdf-page">
          <h2 className="section-title">5. Matriz de Risco (NR-01)</h2>
          
          <table className="pdf-table" style={{ fontSize: '11px' }}>
            <thead>
              <tr>
                <th>Perigo Psicossocial</th>
                <th>Efeito Potencial</th>
                <th>Prob.</th>
                <th>Sev.</th>
                <th>Risco</th>
                <th>Classificação</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><strong>Sobrecarga Mental</strong></td>
                <td>Estresse, fadiga, burnout</td>
                <td>4</td>
                <td>4</td>
                <td>16</td>
                <td><span className="risk-badge risk-high">🔴 Alto</span></td>
              </tr>
              <tr>
                <td><strong>Baixa Autonomia</strong></td>
                <td>Ansiedade, frustração</td>
                <td>3</td>
                <td>3</td>
                <td>9</td>
                <td><span className="risk-badge risk-medium">🟠 Médio</span></td>
              </tr>
              <tr>
                <td><strong>Conflito Trabalho-Família</strong></td>
                <td>Exaustão, absenteísmo</td>
                <td>4</td>
                <td>4</td>
                <td>16</td>
                <td><span className="risk-badge risk-high">🔴 Alto</span></td>
              </tr>
              <tr>
                <td><strong>Falta de Suporte Social</strong></td>
                <td>Isolamento, insegurança</td>
                <td>3</td>
                <td>3</td>
                <td>9</td>
                <td><span className="risk-badge risk-medium">🟠 Médio</span></td>
              </tr>
              <tr>
                <td><strong>Baixo Reconhecimento</strong></td>
                <td>Desmotivação, insatisfação</td>
                <td>2</td>
                <td>3</td>
                <td>6</td>
                <td><span className="risk-badge risk-low">🟢 Baixo</span></td>
              </tr>
            </tbody>
          </table>

          <div style={{ marginTop: '30px', padding: '15px', background: '#F8F8FA', borderRadius: '8px' }}>
            <p style={{ fontSize: '12px', marginBottom: '10px' }}><strong>Legenda - Escala de Avaliação:</strong></p>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', fontSize: '11px' }}>
              <div>
                <strong>Probabilidade (1-5):</strong>
                <ul style={{ marginLeft: '15px', marginTop: '5px' }}>
                  <li>1 - Raro</li>
                  <li>2 - Pouco provável</li>
                  <li>3 - Provável</li>
                  <li>4 - Muito provável</li>
                  <li>5 - Certo</li>
                </ul>
              </div>
              <div>
                <strong>Severidade (1-5):</strong>
                <ul style={{ marginLeft: '15px', marginTop: '5px' }}>
                  <li>1 - Insignificante</li>
                  <li>2 - Menor</li>
                  <li>3 - Moderada</li>
                  <li>4 - Grave</li>
                  <li>5 - Catastrófica</li>
                </ul>
              </div>
            </div>
            <p style={{ fontSize: '11px', marginTop: '10px' }}>
              <strong>Nível de Risco (Prob × Sev):</strong> 🟢 1-8 Baixo | 🟠 9-15 Médio | 🔴 16-25 Alto
            </p>
          </div>
        </div>

        <div className="page-break"></div>

        {/* PÁGINA 6: PLANOS DE AÇÃO */}
        <div className="pdf-page">
          <h2 className="section-title">6. Planos de Ação e Recomendações</h2>
          
          <table className="pdf-table" style={{ fontSize: '11px' }}>
            <thead>
              <tr>
                <th>Fator</th>
                <th>Ação Recomendada</th>
                <th>Prazo</th>
                <th>Responsável</th>
                <th>Prioridade</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><strong>Demandas Altas</strong></td>
                <td>Revisão de carga e prazos, balanceamento de tarefas</td>
                <td>90 dias</td>
                <td>Gestor Operações</td>
                <td><span className="risk-badge risk-high">Alta</span></td>
              </tr>
              <tr>
                <td><strong>Baixo Suporte</strong></td>
                <td>Treinamento de liderança em escuta ativa</td>
                <td>60 dias</td>
                <td>RH</td>
                <td><span className="risk-badge risk-high">Alta</span></td>
              </tr>
              <tr>
                <td><strong>Reconhecimento Baixo</strong></td>
                <td>Programa de feedback estruturado</td>
                <td>90 dias</td>
                <td>RH</td>
                <td><span className="risk-badge risk-medium">Média</span></td>
              </tr>
              <tr>
                <td><strong>Conflito Trabalho-Família</strong></td>
                <td>Política de desconexão e flexibilidade de horários</td>
                <td>60 dias</td>
                <td>RH / Jurídico</td>
                <td><span className="risk-badge risk-high">Alta</span></td>
              </tr>
              <tr>
                <td><strong>Comunicação Deficiente</strong></td>
                <td>Reuniões estruturadas e canais claros</td>
                <td>30 dias</td>
                <td>Liderança</td>
                <td><span className="risk-badge risk-medium">Média</span></td>
              </tr>
            </tbody>
          </table>

          <div style={{ marginTop: '40px', padding: '20px', background: '#EFE6F8', borderRadius: '8px' }}>
            <h3 style={{ color: '#5E2C91', marginBottom: '15px', fontSize: '16px' }}>
              💡 Recomendação Técnica
            </h3>
            <p style={{ fontSize: '12px', lineHeight: '1.8', color: '#2B2240' }}>
              Todas as ações propostas devem ser implementadas conforme cronograma estabelecido e 
              monitoradas através de indicadores de resultado. Recomenda-se a reavaliação dos fatores 
              psicossociais em 12 meses para verificação da eficácia das medidas de controle implementadas.
            </p>
          </div>
        </div>

        <div className="page-break"></div>

        {/* PÁGINA 7: CONCLUSÃO */}
        <div className="pdf-page">
          <h2 className="section-title">7. Conclusão e Encaminhamentos</h2>
          
          <p style={{ lineHeight: '1.8', marginBottom: '30px' }}>
            A análise realizada evidencia exposição significativa a fatores psicossociais, com destaque para 
            as dimensões de <strong>Demandas de Trabalho</strong> e <strong>Conflito Trabalho-Família</strong>, 
            que apresentaram classificação de risco alto conforme matriz NR-01.
          </p>

          <p style={{ lineHeight: '1.8', marginBottom: '30px' }}>
            O Índice de Exposição Psicossocial (IEP) da organização encontra-se em <strong>{iep.toFixed(0)} pontos</strong>, 
            o que exige intervenções estruturais e organizacionais prioritárias.
          </p>

          <p style={{ lineHeight: '1.8', marginBottom: '30px' }}>
            <strong>Recomenda-se:</strong>
          </p>

          <ul style={{ lineHeight: '1.8', marginLeft: '20px', marginBottom: '40px' }}>
            <li>Incluir os riscos psicossociais identificados no <strong>Inventário de Riscos do PGR</strong></li>
            <li>Implementar as ações propostas conforme priorização estabelecida</li>
            <li>Realizar <strong>nova reavaliação em até 12 meses</strong></li>
            <li>Monitorar indicadores de absenteísmo e turnover</li>
            <li>Promover campanhas de conscientização sobre saúde mental</li>
          </ul>

          <div style={{ marginTop: '60px', padding: '20px', background: '#F8F8FA', borderRadius: '8px' }}>
            <h3 style={{ fontSize: '14px', marginBottom: '15px' }}>Observações do Profissional Responsável:</h3>
            <div style={{ minHeight: '80px', border: '1px dashed #A77BCA', borderRadius: '4px', padding: '15px' }}>
              <p style={{ fontSize: '11px', color: '#666666', fontStyle: 'italic' }}>
                [Espaço reservado para observações adicionais do profissional técnico]
              </p>
            </div>
          </div>
        </div>

        <div className="page-break"></div>

        {/* PÁGINA 8: ASSINATURAS */}
        <div className="pdf-page">
          <h2 className="section-title">8. Assinaturas e Verificação</h2>
          
          <div style={{ marginTop: '60px' }}>
            <h3 style={{ fontSize: '14px', marginBottom: '30px' }}>Responsável Técnico:</h3>
            <div style={{ marginBottom: '40px' }}>
              <p style={{ marginBottom: '10px' }}><strong>Nome:</strong> ________________________________</p>
              <p style={{ marginBottom: '10px' }}><strong>Registro Profissional:</strong> ________________________________</p>
              <p style={{ marginBottom: '40px' }}><strong>Data:</strong> {format(today, 'dd/MM/yyyy', { locale: ptBR })}</p>
              <div style={{ borderBottom: '2px solid #444444', width: '300px', paddingTop: '40px' }}>
                <p style={{ textAlign: 'center', fontSize: '11px', color: '#666666', marginTop: '5px' }}>
                  Assinatura
                </p>
              </div>
            </div>

            <h3 style={{ fontSize: '14px', marginTop: '60px', marginBottom: '30px' }}>Empresa Contratante:</h3>
            <div>
              <p style={{ marginBottom: '10px' }}><strong>Nome:</strong> ________________________________</p>
              <p style={{ marginBottom: '10px' }}><strong>Cargo:</strong> ________________________________</p>
              <p style={{ marginBottom: '40px' }}><strong>Data:</strong> ________________________________</p>
              <div style={{ borderBottom: '2px solid #444444', width: '300px', paddingTop: '40px' }}>
                <p style={{ textAlign: 'center', fontSize: '11px', color: '#666666', marginTop: '5px' }}>
                  Assinatura
                </p>
              </div>
            </div>
          </div>

          <div style={{ marginTop: '80px', padding: '20px', background: '#EFE6F8', borderRadius: '8px', textAlign: 'center' }}>
            <p style={{ fontSize: '11px', color: '#5E2C91', lineHeight: '1.6' }}>
              <strong>Relatório técnico gerado automaticamente pela PsyBox</strong><br/>
              Software de gestão de riscos psicossociais e saúde mental corporativa<br/>
              Conforme diretrizes da NR-01, NR-09 e NR-17<br/>
              <br/>
              <a href="https://www.psycompany.com.br" style={{ color: '#5E2C91' }}>www.psycompany.com.br</a>
            </p>
          </div>
        </div>
      </div>
    </>
  );
}