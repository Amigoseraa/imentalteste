import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Navigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Trash2, AlertTriangle, CheckCircle, Download, RefreshCw } from "lucide-react";
import { toast } from "sonner";
import { detectMockData, clearLocalCaches } from "../components/utils/kpiService";

export default function DataReset() {
  const [user, setUser] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const [showDialog, setShowDialog] = React.useState(false);
  const [confirmText, setConfirmText] = useState('');
  const [createBackup, setCreateBackup] = useState(true);
  const [step, setStep] = useState(1);

  const queryClient = useQueryClient();

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  const { data: mockDetection } = useQuery({
    queryKey: ['mock-detection'],
    queryFn: detectMockData,
    enabled: user?.user_role === 'admin',
  });

  const resetMutation = useMutation({
    mutationFn: async () => {
      // Ordem importa! Deletar nas dependências inversas
      const entitiesToClear = [
        'Pagamento',
        'DunningLog',
        'Fatura',
        'Recebivel',
        'FinanceSnapshot',
        'ContratoEmpresa',
        'ContratoConsultoria',
        'Assessment',
        'Action',
        'Employee',
        'GHE',
        'Department',
        'Company',
        'Consultoria',
        'AuditLog'
      ];
      
      for (const entityName of entitiesToClear) {
        try {
          const records = await base44.entities[entityName].list();
          for (const record of records) {
            await base44.entities[entityName].delete(record.id);
          }
        } catch (error) {
          console.error(`Error clearing ${entityName}:`, error);
        }
      }
      
      // Limpar caches locais
      clearLocalCaches();
      
      return { success: true };
    },
    onSuccess: () => {
      queryClient.invalidateQueries();
      toast.success('🎉 Reset completo! Sistema zerado e pronto para novos cadastros.');
      setShowDialog(false);
      setStep(1);
      setConfirmText('');
      
      setTimeout(() => {
        window.location.href = '/';
      }, 2000);
    },
    onError: (error) => {
      toast.error(`Erro ao executar reset: ${error.message}`);
    }
  });

  if (loading) {
    return (
      <div className="p-8 flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2" style={{ borderColor: '#4B2672' }}></div>
      </div>
    );
  }

  if (!user || user.user_role !== 'admin') {
    return <Navigate to="/" />;
  }

  const canProceed = confirmText === 'RESET-IMENTAL';

  return (
    <div className="p-4 md:p-8 min-h-screen" style={{ backgroundColor: '#F8F6FB' }}>
      <div className="max-w-4xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold" style={{ color: '#2E2E2E' }}>
            Reset de Dados do Sistema
          </h1>
          <p className="text-gray-600 mt-2">
            Ferramenta exclusiva para Admin iMental - apaga dados operacionais para testes do zero
          </p>
        </div>

        {/* Mock Detection */}
        {mockDetection && mockDetection.length > 0 && (
          <Alert className="border-yellow-200 bg-yellow-50">
            <AlertTriangle className="h-4 w-4 text-yellow-600" />
            <AlertDescription className="text-yellow-800">
              <p className="font-semibold mb-2">⚠️ Detectados {mockDetection.length} registros suspeitos de mock/demo:</p>
              <ul className="list-disc list-inside space-y-1">
                {mockDetection.slice(0, 5).map((item, idx) => (
                  <li key={idx} className="text-sm">
                    {item.type}: {item.name}
                  </li>
                ))}
              </ul>
              {mockDetection.length > 5 && (
                <p className="text-sm mt-2">... e mais {mockDetection.length - 5} registros</p>
              )}
            </AlertDescription>
          </Alert>
        )}

        <Card className="border-2 border-red-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-700">
              <Trash2 className="w-5 h-5" />
              Zona de Perigo
            </CardTitle>
            <CardDescription>
              Esta ação é IRREVERSÍVEL e apagará todos os dados operacionais do sistema
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-3">
              <h3 className="font-semibold text-gray-900">O que será apagado:</h3>
              <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                <li>Todas as Consultorias e Empresas cadastradas</li>
                <li>Departamentos, GHEs e Colaboradores</li>
                <li>Avaliações enviadas e respostas</li>
                <li>Faturas, Contratos e Pagamentos</li>
                <li>Logs e snapshots financeiros</li>
                <li>Histórico de auditoria</li>
              </ul>
            </div>

            <div className="space-y-3">
              <h3 className="font-semibold text-gray-900">O que será mantido:</h3>
              <ul className="list-disc list-inside space-y-1 text-sm text-green-700">
                <li>Usuários Administradores iMental</li>
                <li>Configurações de branding</li>
                <li>Feature flags do sistema</li>
                <li>Planos e configurações globais</li>
              </ul>
            </div>

            <Alert>
              <CheckCircle className="h-4 w-4" />
              <AlertDescription>
                Após o reset, todos os dashboards voltarão ao estado zero com mensagens "Aguardando dados". 
                Você poderá começar cadastros do zero para testes completos.
              </AlertDescription>
            </Alert>

            <div className="pt-4 border-t">
              <Button
                onClick={() => setShowDialog(true)}
                variant="destructive"
                size="lg"
                className="w-full"
              >
                <Trash2 className="w-5 h-5 mr-2" />
                Iniciar Reset do Sistema
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Dialog de Confirmação */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-700">
              <AlertTriangle className="w-5 h-5" />
              Confirmar Reset
            </DialogTitle>
            <DialogDescription>
              Esta ação não pode ser desfeita. Digite <strong>RESET-IMENTAL</strong> para confirmar.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            {step === 1 && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="confirm">Digite RESET-IMENTAL para continuar</Label>
                  <Input
                    id="confirm"
                    value={confirmText}
                    onChange={(e) => setConfirmText(e.target.value)}
                    placeholder="RESET-IMENTAL"
                    className="font-mono"
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="backup"
                    checked={createBackup}
                    onCheckedChange={setCreateBackup}
                  />
                  <Label htmlFor="backup" className="text-sm">
                    Criar backup antes do reset (recomendado)
                  </Label>
                </div>

                <Alert className="bg-red-50 border-red-200">
                  <AlertTriangle className="h-4 w-4 text-red-600" />
                  <AlertDescription className="text-red-800 text-sm">
                    Todos os dados de consultorias, empresas, colaboradores, avaliações e faturamento serão permanentemente apagados.
                  </AlertDescription>
                </Alert>
              </>
            )}
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowDialog(false);
                setStep(1);
                setConfirmText('');
              }}
              disabled={resetMutation.isPending}
            >
              Cancelar
            </Button>
            <Button
              variant="destructive"
              onClick={() => resetMutation.mutate()}
              disabled={!canProceed || resetMutation.isPending}
            >
              {resetMutation.isPending ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Executando Reset...
                </>
              ) : (
                <>
                  <Trash2 className="w-4 h-4 mr-2" />
                  Confirmar Reset
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}