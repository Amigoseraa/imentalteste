import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Navigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Edit, Trash2, Star, Package, CheckCircle, XCircle } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { getEffectiveContext } from "../components/utils/impersonationContext";

export default function Planos() {
  const [user, setUser] = React.useState(null);
  const [context, setContext] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [editingPlano, setEditingPlano] = useState(null);
  const [formData, setFormData] = useState({
    nome: "",
    descricao: "",
    valor_base: 0,
    limite_empresas: 10,
    limite_colaboradores: 100,
    limite_avaliacoes: 1000,
    faturamento_modelo_padrao: "por_colaborador",
    percentual_repasse: 30,
    modulo_questionarios: true,
    modulo_biblioteca: true,
    modulo_denuncias: false,
    recursos: [],
    status: "ativo",
    destaque: false
  });

  const queryClient = useQueryClient();

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
        
        const effectiveContext = getEffectiveContext(userData);
        setContext(effectiveContext);
        
        console.log('=== Planos Page ===');
        console.log('Context:', effectiveContext);
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  const { data: planos } = useQuery({
    queryKey: ['planos', context?.consultoria_id],
    queryFn: async () => {
      // Admin vê todos os planos (consultoria_id = null) + planos de todas consultorias
      if (context?.original_role === 'admin' && !context?.is_impersonating) {
        return await base44.entities.PlanoConsultoria.list('-created_date');
      }
      
      // Consultoria vê apenas seus planos + planos globais (null)
      if (context?.consultoria_id) {
        const allPlanos = await base44.entities.PlanoConsultoria.list('-created_date');
        return allPlanos.filter(p => 
          p.consultoria_id === context.consultoria_id || 
          p.consultoria_id === null
        );
      }
      
      return [];
    },
    enabled: !!context,
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => {
      const dataToSave = {
        ...data,
        consultoria_id: context?.role === 'consultoria' ? context.consultoria_id : null
      };
      return base44.entities.PlanoConsultoria.create(dataToSave);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['planos'] });
      setShowDialog(false);
      resetForm();
      toast.success('Plano criado com sucesso!');
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.PlanoConsultoria.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['planos'] });
      setShowDialog(false);
      resetForm();
      toast.success('Plano atualizado!');
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.PlanoConsultoria.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['planos'] });
      toast.success('Plano removido');
    },
  });

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="grid grid-cols-3 gap-6">
            {[1,2,3].map(i => (
              <div key={i} className="h-64 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!user || !context) {
    return <Navigate to="/" />;
  }

  // Permitir acesso para admin e consultoria
  const canAccess = context.original_role === 'admin' || context.role === 'consultoria';
  
  if (!canAccess) {
    return <Navigate to="/" />;
  }

  const resetForm = () => {
    setFormData({
      nome: "",
      descricao: "",
      valor_base: 0,
      limite_empresas: 10,
      limite_colaboradores: 100,
      limite_avaliacoes: 1000,
      faturamento_modelo_padrao: "por_colaborador",
      percentual_repasse: 30,
      modulo_questionarios: true,
      modulo_biblioteca: true,
      modulo_denuncias: false,
      recursos: [],
      status: "ativo",
      destaque: false
    });
    setEditingPlano(null);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingPlano) {
      updateMutation.mutate({ id: editingPlano.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleEdit = (plano) => {
    setEditingPlano(plano);
    setFormData({
      nome: plano.nome,
      descricao: plano.descricao || "",
      valor_base: plano.valor_base,
      limite_empresas: plano.limite_empresas || 10,
      limite_colaboradores: plano.limite_colaboradores || 100,
      limite_avaliacoes: plano.limite_avaliacoes || 1000,
      faturamento_modelo_padrao: plano.faturamento_modelo_padrao || "por_colaborador",
      percentual_repasse: plano.percentual_repasse || 30,
      modulo_questionarios: plano.modulo_questionarios !== false,
      modulo_biblioteca: plano.modulo_biblioteca !== false,
      modulo_denuncias: plano.modulo_denuncias || false,
      recursos: plano.recursos || [],
      status: plano.status || "ativo",
      destaque: plano.destaque || false
    });
    setShowDialog(true);
  };

  const canEditPlano = (plano) => {
    // Admin pode editar todos
    if (context.original_role === 'admin' && !context.is_impersonating) {
      return true;
    }
    
    // Consultoria só pode editar seus próprios planos
    if (context.role === 'consultoria') {
      return plano.consultoria_id === context.consultoria_id;
    }
    
    return false;
  };

  return (
    <div className="p-4 md:p-8 min-h-screen" style={{ backgroundColor: '#F8F6FB' }}>
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold" style={{ color: '#2E2E2E' }}>Gestão de Planos</h1>
            <p className="text-gray-600 mt-2">
              {context.role === 'consultoria' 
                ? 'Configure os planos para suas empresas clientes'
                : 'Configure os planos disponíveis para as consultorias'
              }
            </p>
          </div>
          <Dialog open={showDialog} onOpenChange={(open) => {
            setShowDialog(open);
            if (!open) resetForm();
          }}>
            <Button
              onClick={() => setShowDialog(true)}
              className="text-white"
              style={{ backgroundColor: '#4B2672' }}
            >
              <Plus className="w-4 h-4 mr-2" />
              Novo Plano
            </Button>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingPlano ? 'Editar Plano' : 'Novo Plano'}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="nome">Nome do Plano *</Label>
                    <Input
                      id="nome"
                      value={formData.nome}
                      onChange={(e) => setFormData({...formData, nome: e.target.value})}
                      placeholder="Ex: Starter, Pro, Enterprise"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="valor_base">Valor Base Mensal (R$) *</Label>
                    <Input
                      id="valor_base"
                      type="number"
                      step="0.01"
                      value={formData.valor_base}
                      onChange={(e) => setFormData({...formData, valor_base: parseFloat(e.target.value)})}
                      required
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="descricao">Descrição</Label>
                  <Textarea
                    id="descricao"
                    value={formData.descricao}
                    onChange={(e) => setFormData({...formData, descricao: e.target.value})}
                    placeholder="Descrição detalhada do plano"
                    rows={3}
                  />
                </div>

                {/* Módulos Disponíveis */}
                <div className="border rounded-lg p-4" style={{ backgroundColor: '#F8F6FB' }}>
                  <h3 className="font-semibold mb-3" style={{ color: '#2E2E2E' }}>
                    Módulos Incluídos
                  </h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-white rounded-lg">
                      <div className="flex items-center gap-3">
                        <Checkbox
                          id="modulo_questionarios"
                          checked={formData.modulo_questionarios}
                          onCheckedChange={(checked) => setFormData({...formData, modulo_questionarios: checked})}
                        />
                        <Label htmlFor="modulo_questionarios" className="cursor-pointer">
                          <div>
                            <p className="font-medium">Questionários e Avaliações</p>
                            <p className="text-xs text-gray-500">PHQ-9, GAD-7, PRIMA-EF e outros</p>
                          </div>
                        </Label>
                      </div>
                      {formData.modulo_questionarios && <CheckCircle className="w-5 h-5 text-green-600" />}
                    </div>

                    <div className="flex items-center justify-between p-3 bg-white rounded-lg">
                      <div className="flex items-center gap-3">
                        <Checkbox
                          id="modulo_biblioteca"
                          checked={formData.modulo_biblioteca}
                          onCheckedChange={(checked) => setFormData({...formData, modulo_biblioteca: checked})}
                        />
                        <Label htmlFor="modulo_biblioteca" className="cursor-pointer">
                          <div>
                            <p className="font-medium">Biblioteca de Conteúdos</p>
                            <p className="text-xs text-gray-500">Vídeos, e-books e cursos</p>
                          </div>
                        </Label>
                      </div>
                      {formData.modulo_biblioteca && <CheckCircle className="w-5 h-5 text-green-600" />}
                    </div>

                    <div className="flex items-center justify-between p-3 bg-white rounded-lg">
                      <div className="flex items-center gap-3">
                        <Checkbox
                          id="modulo_denuncias"
                          checked={formData.modulo_denuncias}
                          onCheckedChange={(checked) => setFormData({...formData, modulo_denuncias: checked})}
                        />
                        <Label htmlFor="modulo_denuncias" className="cursor-pointer">
                          <div>
                            <p className="font-medium">Canal de Denúncias</p>
                            <p className="text-xs text-gray-500">Gestão de denúncias internas</p>
                          </div>
                        </Label>
                      </div>
                      {formData.modulo_denuncias && <CheckCircle className="w-5 h-5 text-green-600" />}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="limite_empresas">Limite de Empresas</Label>
                    <Input
                      id="limite_empresas"
                      type="number"
                      value={formData.limite_empresas}
                      onChange={(e) => setFormData({...formData, limite_empresas: parseInt(e.target.value)})}
                    />
                    <p className="text-xs text-gray-500 mt-1">-1 = ilimitado</p>
                  </div>
                  <div>
                    <Label htmlFor="limite_colaboradores">Limite de Colaboradores</Label>
                    <Input
                      id="limite_colaboradores"
                      type="number"
                      value={formData.limite_colaboradores}
                      onChange={(e) => setFormData({...formData, limite_colaboradores: parseInt(e.target.value)})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="limite_avaliacoes">Limite de Avaliações/mês</Label>
                    <Input
                      id="limite_avaliacoes"
                      type="number"
                      value={formData.limite_avaliacoes}
                      onChange={(e) => setFormData({...formData, limite_avaliacoes: parseInt(e.target.value)})}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="faturamento_modelo">Modelo de Faturamento</Label>
                    <Select
                      value={formData.faturamento_modelo_padrao}
                      onValueChange={(value) => setFormData({...formData, faturamento_modelo_padrao: value})}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="por_colaborador">Por Colaborador</SelectItem>
                        <SelectItem value="por_empresa">Por Empresa</SelectItem>
                        <SelectItem value="plano_fixo">Plano Fixo</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {context.original_role === 'admin' && !context.is_impersonating && (
                    <div>
                      <Label htmlFor="percentual_repasse">Percentual Repasse iMental (%)</Label>
                      <Input
                        id="percentual_repasse"
                        type="number"
                        step="0.1"
                        value={formData.percentual_repasse}
                        onChange={(e) => setFormData({...formData, percentual_repasse: parseFloat(e.target.value)})}
                      />
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between p-4 rounded-lg" style={{ backgroundColor: '#F8F6FB' }}>
                  <div>
                    <Label htmlFor="destaque">Plano em Destaque</Label>
                    <p className="text-xs text-gray-600">Será destacado para novas empresas</p>
                  </div>
                  <Switch
                    id="destaque"
                    checked={formData.destaque}
                    onCheckedChange={(checked) => setFormData({...formData, destaque: checked})}
                  />
                </div>

                <div className="flex justify-end gap-3 pt-4 border-t">
                  <Button type="button" variant="outline" onClick={() => setShowDialog(false)}>
                    Cancelar
                  </Button>
                  <Button type="submit" className="text-white" style={{ backgroundColor: '#4B2672' }}>
                    {editingPlano ? 'Salvar' : 'Criar Plano'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {planos.map((plano) => (
            <Card 
              key={plano.id} 
              className={`shadow-md hover:shadow-xl transition-all relative ${
                plano.destaque ? 'ring-2 ring-yellow-400' : ''
              }`}
            >
              {plano.destaque && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-yellow-400 text-gray-900">
                    <Star className="w-3 h-3 mr-1" />
                    Recomendado
                  </Badge>
                </div>
              )}
              
              {plano.consultoria_id === null && context.role === 'consultoria' && (
                <div className="absolute -top-3 right-4">
                  <Badge className="bg-blue-100 text-blue-800">
                    Plano Global
                  </Badge>
                </div>
              )}
              
              <CardHeader>
                <div className="flex items-center justify-between">
                  <Package className="w-6 h-6" style={{ color: '#4B2672' }} />
                  <Badge className={plano.status === 'ativo' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                    {plano.status}
                  </Badge>
                </div>
                <CardTitle className="text-2xl mt-4">{plano.nome}</CardTitle>
                <div className="text-3xl font-bold mt-2" style={{ color: '#4B2672' }}>
                  R$ {plano.valor_base.toFixed(2)}
                  <span className="text-sm font-normal text-gray-600">/mês</span>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {plano.descricao && (
                  <p className="text-sm text-gray-600">{plano.descricao}</p>
                )}
                
                {/* Módulos */}
                <div className="border-t pt-3 space-y-2">
                  <p className="text-xs font-semibold text-gray-600 mb-2">MÓDULOS INCLUÍDOS</p>
                  <div className="flex items-center gap-2 text-sm">
                    {plano.modulo_questionarios ? (
                      <CheckCircle className="w-4 h-4 text-green-600" />
                    ) : (
                      <XCircle className="w-4 h-4 text-gray-300" />
                    )}
                    <span className={plano.modulo_questionarios ? 'text-gray-700' : 'text-gray-400'}>
                      Questionários
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    {plano.modulo_biblioteca ? (
                      <CheckCircle className="w-4 h-4 text-green-600" />
                    ) : (
                      <XCircle className="w-4 h-4 text-gray-300" />
                    )}
                    <span className={plano.modulo_biblioteca ? 'text-gray-700' : 'text-gray-400'}>
                      Biblioteca
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    {plano.modulo_denuncias ? (
                      <CheckCircle className="w-4 h-4 text-green-600" />
                    ) : (
                      <XCircle className="w-4 h-4 text-gray-300" />
                    )}
                    <span className={plano.modulo_denuncias ? 'text-gray-700' : 'text-gray-400'}>
                      Canal de Denúncias
                    </span>
                  </div>
                </div>

                <div className="space-y-2 text-sm border-t pt-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Empresas:</span>
                    <span className="font-semibold">
                      {plano.limite_empresas === -1 ? 'Ilimitado' : plano.limite_empresas}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Colaboradores:</span>
                    <span className="font-semibold">
                      {plano.limite_colaboradores === -1 ? 'Ilimitado' : plano.limite_colaboradores}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Avaliações/mês:</span>
                    <span className="font-semibold">
                      {plano.limite_avaliacoes === -1 ? 'Ilimitado' : plano.limite_avaliacoes}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Modelo:</span>
                    <span className="font-semibold capitalize">
                      {plano.faturamento_modelo_padrao?.replace('_', ' ')}
                    </span>
                  </div>
                  {context.original_role === 'admin' && !context.is_impersonating && (
                    <div className="flex justify-between">
                      <span className="text-gray-600">Repasse iMental:</span>
                      <span className="font-semibold">{plano.percentual_repasse}%</span>
                    </div>
                  )}
                </div>

                {canEditPlano(plano) && (
                  <div className="flex gap-2 pt-4 border-t">
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="flex-1"
                      onClick={() => handleEdit(plano)}
                    >
                      <Edit className="w-3 h-3 mr-1" />
                      Editar
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-red-600 hover:text-red-700"
                      onClick={() => {
                        if (confirm(`Excluir plano ${plano.nome}?`)) {
                          deleteMutation.mutate(plano.id);
                        }
                      }}
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {planos.length === 0 && (
          <Card className="border-2 border-dashed">
            <CardContent className="flex flex-col items-center justify-center py-16">
              <Package className="w-16 h-16 text-gray-300 mb-4" />
              <p className="text-gray-500 font-medium">Nenhum plano cadastrado</p>
              <p className="text-sm text-gray-400 mt-2">
                Clique em "Novo Plano" para começar
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}