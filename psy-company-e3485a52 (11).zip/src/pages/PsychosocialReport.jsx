
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Navigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowLeft, 
  Download,
  FileText,
  Brain,
  AlertCircle,
  Building2,
  Calendar,
  Filter
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import ExecutiveSummary from "../components/psychosocial-report/ExecutiveSummary";
import FactorsHeatmap from "../components/psychosocial-report/FactorsHeatmap";
import NR01Matrix from "../components/psychosocial-report/NR01Matrix";
import ActionPlans from "../components/psychosocial-report/ActionPlans";

export default function PsychosocialReport() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [companyId, setCompanyId] = useState(null);
  const [selectedDepartment, setSelectedDepartment] = useState('all');
  const [selectedPeriod, setSelectedPeriod] = useState('all');
  const [selectedFactor, setSelectedFactor] = useState('all');
  const [selectedRiskLevel, setSelectedRiskLevel] = useState('all');

  const urlParams = new URLSearchParams(window.location.search);
  const assessmentId = urlParams.get('id');

  useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
        
        const impersonationData = localStorage.getItem('admin_impersonation');
        if (impersonationData) {
          const parsed = JSON.parse(impersonationData);
          setCompanyId(parsed.company_id);
        } else {
          setCompanyId(userData.company_id);
        }
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  const { data: assessments } = useQuery({
    queryKey: ['assessments-psychosocial', companyId],
    queryFn: async () => {
      if (!companyId) return [];
      return await base44.entities.Assessment.filter(
        { company_id: companyId, completed_at: { $ne: null } },
        '-created_date'
      );
    },
    enabled: !!companyId,
    initialData: [],
  });

  const { data: employees } = useQuery({
    queryKey: ['employees', companyId],
    queryFn: async () => {
      if (!companyId) return [];
      return await base44.entities.Employee.filter({ 
        company_id: companyId,
        status: 'active'
      });
    },
    enabled: !!companyId,
    initialData: [],
  });

  const { data: departments } = useQuery({
    queryKey: ['departments', companyId],
    queryFn: async () => {
      if (!companyId) return [];
      return await base44.entities.Department.filter({ company_id: companyId });
    },
    enabled: !!companyId,
    initialData: [],
  });

  const { data: company } = useQuery({
    queryKey: ['company', companyId],
    queryFn: async () => {
      if (!companyId) return null;
      const companies = await base44.entities.Company.filter({ id: companyId });
      return companies[0] || null;
    },
    enabled: !!companyId,
  });

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[1,2,3,4].map(i => (
              <div key={i} className="h-32 bg-gray-200 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" />;
  }

  if (!companyId) {
    return (
      <div className="p-8">
        <Card className="border-2 border-yellow-200 bg-yellow-50">
          <CardContent className="p-6">
            <p className="text-yellow-800 font-medium">
              Sua conta não está vinculada a nenhuma empresa.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Filtrar assessments
  let filteredAssessments = assessments;

  if (selectedDepartment !== 'all') {
    filteredAssessments = filteredAssessments.filter(a => a.department_id === selectedDepartment);
  }

  if (selectedPeriod !== 'all') {
    const now = new Date();
    filteredAssessments = filteredAssessments.filter(a => {
      const completedDate = new Date(a.completed_at);
      const diffDays = (now - completedDate) / (1000 * 60 * 60 * 24);
      
      if (selectedPeriod === '30days') return diffDays <= 30;
      if (selectedPeriod === '90days') return diffDays <= 90;
      if (selectedPeriod === '180days') return diffDays <= 180;
      return true;
    });
  }

  const handleExportPGR = () => {
    const reportUrl = `/PDFReport?id=${assessmentId || 'all'}`;
    window.open(reportUrl, '_blank');
  };

  const handleExportExecutive = () => {
    const reportUrl = `/ExecutiveReport?id=${assessmentId || 'all'}`;
    window.open(reportUrl, '_blank');
  };

  const handleExportExcel = () => {
    toast.success('Exportação Excel em preparação', {
      description: 'Planilha AET será gerada com fatores e classificações'
    });
  };

  const handleExportCSV = () => {
    toast.success('Exportação CSV em preparação', {
      description: 'Dados serão exportados para integração BI'
    });
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#F8F8FA' }}>
      <div className="p-4 md:p-8 max-w-[1800px] mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <Button 
              variant="ghost" 
              onClick={() => window.history.back()}
              className="mb-4"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar
            </Button>
            <h1 className="text-3xl font-bold" style={{ color: '#2B2240' }}>
              Relatório de Riscos Psicossociais
            </h1>
            <p className="text-gray-600 mt-2">
              Análise consolidada dos fatores psicossociais conforme PRIMA-EF, HSE-IT, JCQ e NR-01
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            <Button variant="outline" onClick={handleExportExecutive}>
              <FileText className="w-4 h-4 mr-2" />
              Exportar Executivo (2 pág)
            </Button>
            <Button variant="outline" onClick={handleExportPGR}>
              <FileText className="w-4 h-4 mr-2" />
              Exportar PDF (PGR)
            </Button>
            <Button variant="outline" onClick={handleExportExcel}>
              <Download className="w-4 h-4 mr-2" />
              Exportar Excel (AET)
            </Button>
            <Button variant="outline" onClick={handleExportCSV}>
              <Download className="w-4 h-4 mr-2" />
              Exportar CSV (BI)
            </Button>
          </div>
        </div>

        {/* Filtros */}
        <Card className="shadow-md">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-gray-500" />
                <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                  <SelectTrigger>
                    <SelectValue placeholder="Departamento" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os departamentos</SelectItem>
                    {departments.map(dept => (
                      <SelectItem key={dept.id} value={dept.id}>
                        {dept.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                <SelectTrigger>
                  <SelectValue placeholder="Período" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todo período</SelectItem>
                  <SelectItem value="30days">Últimos 30 dias</SelectItem>
                  <SelectItem value="90days">Últimos 90 dias</SelectItem>
                  <SelectItem value="180days">Últimos 6 meses</SelectItem>
                </SelectContent>
              </Select>

              <Select value={selectedFactor} onValueChange={setSelectedFactor}>
                <SelectTrigger>
                  <SelectValue placeholder="Fator" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os fatores</SelectItem>
                  <SelectItem value="demands">Demandas</SelectItem>
                  <SelectItem value="control">Controle/Autonomia</SelectItem>
                  <SelectItem value="support">Suporte Social</SelectItem>
                  <SelectItem value="recognition">Reconhecimento</SelectItem>
                  <SelectItem value="conflict">Conflito Trabalho-Família</SelectItem>
                  <SelectItem value="communication">Comunicação</SelectItem>
                </SelectContent>
              </Select>

              <Select value={selectedRiskLevel} onValueChange={setSelectedRiskLevel}>
                <SelectTrigger>
                  <SelectValue placeholder="Nível de Risco" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os níveis</SelectItem>
                  <SelectItem value="high">🔴 Alto</SelectItem>
                  <SelectItem value="medium">🟠 Médio</SelectItem>
                  <SelectItem value="low">🟢 Baixo</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* BLOCO 1: Resumo Executivo */}
        <ExecutiveSummary 
          assessments={filteredAssessments}
          departments={departments}
          company={company}
        />

        {/* BLOCO 2: Mapa de Fatores */}
        <FactorsHeatmap 
          assessments={filteredAssessments}
          departments={departments}
        />

        {/* BLOCO 3: Matriz NR-01 */}
        <NR01Matrix 
          assessments={filteredAssessments}
          departments={departments}
        />

        {/* BLOCO 4: Planos de Ação */}
        <ActionPlans 
          assessments={filteredAssessments}
          departments={departments}
          companyId={companyId}
        />

        {/* Rodapé normativo */}
        <Card className="border-2" style={{ borderColor: '#A77BCA', backgroundColor: '#EFE6F8' }}>
          <CardContent className="p-6">
            <p className="text-sm" style={{ color: '#5E2C91' }}>
              <strong>📘 Nota Técnica:</strong> Este relatório integra o processo de gerenciamento de riscos ocupacionais conforme NR-01, 
              com foco em fatores psicossociais e organizacionais. Os dados apresentados são agregados e anônimos, 
              respeitando a privacidade dos colaboradores e as diretrizes éticas da profissão.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
