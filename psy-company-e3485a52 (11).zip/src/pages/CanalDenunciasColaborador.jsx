import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  ShieldAlert,
  MessageCircle,
  User,
  UserX,
  Lock,
  Send,
  Paperclip,
  Shield,
  ChevronRight,
  Eye,
  Clock,
  CheckCircle,
  Info
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function CanalDenunciasColaborador() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [employee, setEmployee] = useState(null);
  const [company, setCompany] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showNewDenuncia, setShowNewDenuncia] = useState(false);
  const [tipoDenuncia, setTipoDenuncia] = useState(null); // 'anonima' ou 'identificada'
  const [step, setStep] = useState(1); // 1: tipo, 2: formulário

  // Form state
  const [categoria, setCategoria] = useState("");
  const [descricao, setDescricao] = useState("");
  const [uploadingFile, setUploadingFile] = useState(false);

  React.useEffect(() => {
    const loadUserData = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);

        if (userData.employee_id) {
          const empData = await base44.entities.Employee.filter({ 
            id: userData.employee_id 
          });
          if (empData.length > 0) {
            setEmployee(empData[0]);
            
            const compData = await base44.entities.Company.filter({ 
              id: empData[0].company_id 
            });
            if (compData.length > 0) {
              setCompany(compData[0]);
            }
          }
        }
      } catch (error) {
        console.error("Error loading user data:", error);
        toast.error("Erro ao carregar dados do usuário");
      } finally {
        setLoading(false);
      }
    };
    loadUserData();
  }, []);

  // Buscar denúncias do colaborador
  const { data: minhasDenuncias = [] } = useQuery({
    queryKey: ['minhas-denuncias', employee?.id],
    queryFn: () => base44.entities.Denuncia.filter({ colaborador_id: employee?.id }),
    enabled: !!employee && !loading,
    initialData: [],
  });

  // Criar denúncia
  const createDenunciaMutation = useMutation({
    mutationFn: async (data) => {
      if (!categoria) throw new Error("Selecione uma categoria");
      if (!descricao.trim()) throw new Error("Descreva a situação");
      if (!company) throw new Error("Empresa não encontrada");

      const protocolo = `DEN-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
      
      const denunciaData = {
        empresa_id: company.id,
        consultoria_id: company.consultoria_id,
        colaborador_id: tipoDenuncia === 'identificada' ? employee?.id : null,
        colaborador_nome: tipoDenuncia === 'identificada' ? employee?.name : null,
        anonimo: tipoDenuncia === 'anonima',
        protocolo,
        categoria,
        descricao_inicial: descricao,
        status: 'aberto',
        ultima_mensagem_em: new Date().toISOString(),
        mensagens_nao_lidas_empresa: 1,
        mensagens_nao_lidas_colaborador: 0
      };

      const denuncia = await base44.entities.Denuncia.create(denunciaData);

      // Criar primeira mensagem
      await base44.entities.MensagemDenuncia.create({
        denuncia_id: denuncia.id,
        autor_tipo: 'colaborador',
        autor_id: tipoDenuncia === 'identificada' ? employee?.id : 'anonimo',
        autor_nome: tipoDenuncia === 'identificada' ? employee?.name : 'Anônimo',
        mensagem: descricao,
        anexos: []
      });

      // Enviar notificação por email para empresa (opcional)
      try {
        const responsaveis = await base44.entities.User.filter({ 
          company_id: company.id,
          role: 'manager'
        });
        
        if (responsaveis.length > 0) {
          await base44.integrations.Core.SendEmail({
            to: responsaveis[0].email,
            subject: `Nova Denúncia Recebida - ${protocolo}`,
            body: `Uma nova denúncia foi recebida no Canal de Denúncias.\n\nProtocolo: ${protocolo}\nCategoria: ${categoria}\nTipo: ${tipoDenuncia === 'anonima' ? 'Anônima' : 'Identificada'}\n\nAcesse o sistema para visualizar e responder.`
          });
        }
      } catch (emailError) {
        console.error("Error sending email:", emailError);
      }

      return denuncia;
    },
    onSuccess: (denuncia) => {
      toast.success(`Denúncia enviada! Protocolo: ${denuncia.protocolo}`);
      queryClient.invalidateQueries({ queryKey: ['minhas-denuncias'] });
      setShowNewDenuncia(false);
      setTipoDenuncia(null);
      setStep(1);
      setCategoria("");
      setDescricao("");
      
      // Navegar para visualizar a denúncia
      navigate(createPageUrl(`DenunciaChat?id=${denuncia.id}`));
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao enviar denúncia");
    }
  });

  const handleSubmit = () => {
    createDenunciaMutation.mutate();
  };

  const getCategoriaLabel = (cat) => {
    const labels = {
      assedio_moral: "Assédio Moral",
      assedio_sexual: "Assédio Sexual",
      discriminacao: "Discriminação",
      conduta_indevida: "Conduta Indevida",
      outros: "Outros"
    };
    return labels[cat] || cat;
  };

  const getStatusBadge = (status) => {
    const badges = {
      aberto: <Badge className="bg-yellow-100 text-yellow-800"><Clock className="w-3 h-3 mr-1" />Aberto</Badge>,
      em_resposta: <Badge className="bg-blue-100 text-blue-800"><MessageCircle className="w-3 h-3 mr-1" />Em Resposta</Badge>,
      finalizado: <Badge className="bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" />Finalizado</Badge>
    };
    return badges[status] || status;
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#F8F6FB' }}>
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 mx-auto mb-4" style={{ borderColor: '#4B2672' }}></div>
          <p className="text-sm text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  if (!company?.canal_denuncias_ativo) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6" style={{ backgroundColor: '#F8F6FB' }}>
        <Card className="max-w-md">
          <CardContent className="pt-6 text-center">
            <ShieldAlert className="w-16 h-16 mx-auto mb-4 text-gray-400" />
            <h2 className="text-xl font-semibold mb-2">Módulo Não Disponível</h2>
            <p className="text-gray-600 mb-4">
              O Canal de Denúncias não está ativo para sua empresa.
            </p>
            <Button onClick={() => navigate(createPageUrl('ColaboradorAvaliacoes'))} variant="outline">
              Voltar
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6" style={{ backgroundColor: '#F8F6FB' }}>
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl" style={{ backgroundColor: '#4CAF50' }}>
              <ShieldAlert className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold" style={{ color: '#4B2672' }}>Canal de Denúncias</h1>
              <p className="text-sm text-gray-600">Ambiente seguro e confidencial</p>
            </div>
          </div>
          <Button
            onClick={() => setShowNewDenuncia(true)}
            style={{ backgroundColor: '#4CAF50' }}
            className="text-white hover:opacity-90"
          >
            <ShieldAlert className="w-4 h-4 mr-2" />
            Nova Denúncia
          </Button>
        </div>

        {/* Info Alert */}
        <Alert className="mb-6 border-green-200 bg-green-50">
          <Lock className="w-4 h-4 text-green-600" />
          <AlertDescription className="text-green-800">
            <strong>Confidencialidade Garantida:</strong> Este canal é seguro e suas informações são tratadas com total sigilo.
            Você pode escolher se identificar ou permanecer anônimo.
          </AlertDescription>
        </Alert>

        {/* Denúncias */}
        {minhasDenuncias.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <ShieldAlert className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <h3 className="text-lg font-semibold mb-2 text-gray-700">Nenhuma denúncia registrada</h3>
              <p className="text-gray-500 mb-4">
                Quando você registrar uma denúncia, ela aparecerá aqui.
              </p>
              <Button
                onClick={() => setShowNewDenuncia(true)}
                variant="outline"
                style={{ borderColor: '#4CAF50', color: '#4CAF50' }}
              >
                Fazer Primeira Denúncia
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4">
            {minhasDenuncias.map((denuncia) => (
              <Card
                key={denuncia.id}
                className="cursor-pointer hover:shadow-lg transition-all duration-200"
                onClick={() => navigate(createPageUrl(`DenunciaChat?id=${denuncia.id}`))}
              >
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <span className="text-sm font-mono font-semibold" style={{ color: '#4B2672' }}>
                          {denuncia.protocolo}
                        </span>
                        {getStatusBadge(denuncia.status)}
                        {denuncia.anonimo && (
                          <Badge variant="outline" className="bg-gray-50">
                            <UserX className="w-3 h-3 mr-1" />
                            Anônima
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-600 mb-3">
                        <Clock className="w-4 h-4" />
                        {format(new Date(denuncia.created_date), "dd 'de' MMMM 'de' yyyy 'às' HH:mm", { locale: ptBR })}
                      </div>
                      <div className="mb-2">
                        <Badge variant="outline">
                          {getCategoriaLabel(denuncia.categoria)}
                        </Badge>
                      </div>
                      <p className="text-gray-700 line-clamp-2">
                        {denuncia.descricao_inicial}
                      </p>
                    </div>
                    <div className="text-right ml-4">
                      {denuncia.mensagens_nao_lidas_colaborador > 0 && (
                        <Badge className="bg-red-500 text-white mb-2">
                          {denuncia.mensagens_nao_lidas_colaborador} nova{denuncia.mensagens_nao_lidas_colaborador > 1 ? 's' : ''}
                        </Badge>
                      )}
                      <ChevronRight className="w-5 h-5 text-gray-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Dialog Nova Denúncia */}
        <Dialog open={showNewDenuncia} onOpenChange={(open) => {
          setShowNewDenuncia(open);
          if (!open) {
            setTipoDenuncia(null);
            setStep(1);
            setCategoria("");
            setDescricao("");
          }
        }}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <ShieldAlert className="w-5 h-5" style={{ color: '#4CAF50' }} />
                Nova Denúncia
              </DialogTitle>
              <DialogDescription>
                {step === 1 
                  ? "Escolha como deseja fazer a denúncia" 
                  : "Descreva a situação detalhadamente"
                }
              </DialogDescription>
            </DialogHeader>

            {step === 1 && (
              <div className="space-y-4 py-4">
                <Alert className="border-blue-200 bg-blue-50">
                  <Info className="w-4 h-4 text-blue-600" />
                  <AlertDescription className="text-blue-800 text-sm">
                    Suas informações serão tratadas com confidencialidade. Escolha a opção que deixa você mais confortável.
                  </AlertDescription>
                </Alert>

                <div className="grid gap-4">
                  <Card
                    className="cursor-pointer hover:shadow-lg transition-all duration-200 border-2"
                    style={{ borderColor: tipoDenuncia === 'anonima' ? '#4CAF50' : '#e5e7eb' }}
                    onClick={() => {
                      setTipoDenuncia('anonima');
                      setStep(2);
                    }}
                  >
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <div className="p-3 rounded-lg bg-gray-100">
                          <UserX className="w-6 h-6 text-gray-600" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-lg mb-2">Denúncia Anônima</h3>
                          <p className="text-sm text-gray-600">
                            Sua identidade não será revelada. Ideal para situações sensíveis onde você prefere
                            manter total privacidade.
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card
                    className="cursor-pointer hover:shadow-lg transition-all duration-200 border-2"
                    style={{ borderColor: tipoDenuncia === 'identificada' ? '#4CAF50' : '#e5e7eb' }}
                    onClick={() => {
                      setTipoDenuncia('identificada');
                      setStep(2);
                    }}
                  >
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <div className="p-3 rounded-lg bg-gray-100">
                          <User className="w-6 h-6 text-gray-600" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-lg mb-2">Denúncia Identificada</h3>
                          <p className="text-sm text-gray-600">
                            Você se identifica na denúncia. Permite um acompanhamento mais próximo e respostas
                            diretas da empresa.
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-4 py-4">
                <Alert className={tipoDenuncia === 'anonima' ? "border-gray-200 bg-gray-50" : "border-blue-200 bg-blue-50"}>
                  <Shield className="w-4 h-4" style={{ color: tipoDenuncia === 'anonima' ? '#666' : '#4CAF50' }} />
                  <AlertDescription style={{ color: tipoDenuncia === 'anonima' ? '#666' : '#4CAF50' }}>
                    {tipoDenuncia === 'anonima' 
                      ? "Denúncia Anônima - Sua identidade será protegida"
                      : `Denúncia Identificada - Você será identificado como: ${employee?.name}`
                    }
                  </AlertDescription>
                </Alert>

                <div>
                  <Label>Categoria *</Label>
                  <Select value={categoria} onValueChange={setCategoria}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a categoria" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="assedio_moral">Assédio Moral</SelectItem>
                      <SelectItem value="assedio_sexual">Assédio Sexual</SelectItem>
                      <SelectItem value="discriminacao">Discriminação</SelectItem>
                      <SelectItem value="conduta_indevida">Conduta Indevida</SelectItem>
                      <SelectItem value="outros">Outros</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Descrição da Situação *</Label>
                  <Textarea
                    placeholder="Descreva o que aconteceu de forma detalhada..."
                    value={descricao}
                    onChange={(e) => setDescricao(e.target.value)}
                    rows={8}
                    className="resize-none"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Seja específico sobre datas, locais e pessoas envolvidas (se possível)
                  </p>
                </div>

                <div className="flex gap-3 pt-4">
                  <Button
                    variant="outline"
                    onClick={() => setStep(1)}
                    className="flex-1"
                  >
                    Voltar
                  </Button>
                  <Button
                    onClick={handleSubmit}
                    disabled={!categoria || !descricao.trim() || createDenunciaMutation.isPending}
                    className="flex-1"
                    style={{ backgroundColor: '#4CAF50' }}
                  >
                    {createDenunciaMutation.isPending ? (
                      <>Enviando...</>
                    ) : (
                      <>
                        <Send className="w-4 h-4 mr-2" />
                        Enviar Denúncia
                      </>
                    )}
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}