import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Navigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Brain, 
  AlertTriangle, 
  Download,
  Calendar,
  Filter,
  FileText,
  ArrowRight
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import MentalHealthDashboard from "../components/reports/MentalHealthDashboard";
import PsychosocialRisksDashboard from "../components/reports/PsychosocialRisksDashboard";

export default function Reports() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [companyId, setCompanyId] = useState(null);
  const [activeTab, setActiveTab] = useState('mental-health');
  const [selectedDepartment, setSelectedDepartment] = useState('all');
  const [selectedPeriod, setSelectedPeriod] = useState('all');

  useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
        
        const impersonationData = localStorage.getItem('admin_impersonation');
        if (impersonationData) {
          const parsed = JSON.parse(impersonationData);
          setCompanyId(parsed.company_id);
        } else {
          setCompanyId(userData.company_id);
        }
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  const { data: assessments } = useQuery({
    queryKey: ['assessments', companyId],
    queryFn: async () => {
      if (!companyId) return [];
      return await base44.entities.Assessment.filter(
        { company_id: companyId, completed_at: { $ne: null } },
        '-created_date'
      );
    },
    enabled: !!companyId,
    initialData: [],
  });

  const { data: employees } = useQuery({
    queryKey: ['employees', companyId],
    queryFn: async () => {
      if (!companyId) return [];
      return await base44.entities.Employee.filter({ 
        company_id: companyId,
        status: 'active'
      });
    },
    enabled: !!companyId,
    initialData: [],
  });

  const { data: departments } = useQuery({
    queryKey: ['departments', companyId],
    queryFn: async () => {
      if (!companyId) return [];
      return await base44.entities.Department.filter({ company_id: companyId });
    },
    enabled: !!companyId,
    initialData: [],
  });

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[1,2,3,4].map(i => (
              <div key={i} className="h-32 bg-gray-200 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" />;
  }

  if (!companyId) {
    return (
      <div className="p-8">
        <Card className="border-2 border-yellow-200 bg-yellow-50">
          <CardContent className="p-6">
            <p className="text-yellow-800 font-medium">
              Sua conta não está vinculada a nenhuma empresa. Entre em contato com o administrador.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Filtrar assessments baseado nos filtros
  let filteredAssessments = assessments;

  if (selectedDepartment !== 'all') {
    filteredAssessments = filteredAssessments.filter(a => a.department_id === selectedDepartment);
  }

  if (selectedPeriod !== 'all') {
    const now = new Date();
    filteredAssessments = filteredAssessments.filter(a => {
      const completedDate = new Date(a.completed_at);
      const diffDays = (now - completedDate) / (1000 * 60 * 60 * 24);
      
      if (selectedPeriod === '7days') return diffDays <= 7;
      if (selectedPeriod === '30days') return diffDays <= 30;
      if (selectedPeriod === '90days') return diffDays <= 90;
      if (selectedPeriod === '180days') return diffDays <= 180;
      return true;
    });
  }

  return (
    <div className="p-4 md:p-8 min-h-screen" style={{ backgroundColor: '#F8F8FA' }}>
      <div className="max-w-[1600px] mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold" style={{ color: '#2B2240' }}>
              Relatórios Inteligentes
            </h1>
            <p className="text-gray-500 mt-2">
              Análise consolidada de saúde mental e riscos psicossociais
            </p>
          </div>
          <Button 
            variant="outline"
            className="gap-2"
            onClick={() => {
              window.location.href = '/PsychosocialReport';
            }}
            style={{ borderColor: '#5E2C91', color: '#5E2C91' }}
          >
            <FileText className="w-4 h-4" />
            Relatório Técnico NR-01
            <ArrowRight className="w-4 h-4" />
          </Button>
        </div>

        {/* Destaque do Relatório Técnico */}
        <Card className="shadow-lg border-2" style={{ borderColor: '#A77BCA', backgroundColor: '#F8F8FA' }}>
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-xl" style={{ backgroundColor: '#EFE6F8' }}>
                  <FileText className="w-8 h-8" style={{ color: '#5E2C91' }} />
                </div>
                <div>
                  <h3 className="font-bold text-lg" style={{ color: '#5E2C91' }}>
                    Relatório Técnico de Riscos Psicossociais
                  </h3>
                  <p className="text-sm text-gray-600 mt-1">
                    Análise completa com Matriz NR-01, Heatmap de Fatores, Planos de Ação e exportações PDF/Excel para PGR e AET
                  </p>
                  <div className="flex flex-wrap gap-2 mt-3">
                    <span className="text-xs px-2 py-1 rounded-full bg-green-100 text-green-800">
                      ✓ Matriz NR-01
                    </span>
                    <span className="text-xs px-2 py-1 rounded-full bg-blue-100 text-blue-800">
                      ✓ PRIMA-EF, HSE-IT, JCQ
                    </span>
                    <span className="text-xs px-2 py-1 rounded-full bg-purple-100 text-purple-800">
                      ✓ Planos de Ação
                    </span>
                    <span className="text-xs px-2 py-1 rounded-full bg-orange-100 text-orange-800">
                      ✓ Exportação PDF
                    </span>
                  </div>
                </div>
              </div>
              <Button 
                onClick={() => window.location.href = '/PsychosocialReport'}
                className="text-white whitespace-nowrap"
                style={{ backgroundColor: '#5E2C91' }}
              >
                Acessar Relatório
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Toggle de Dashboard */}
        <Card className="shadow-md">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
              <div className="flex gap-2">
                <Button
                  variant={activeTab === 'mental-health' ? 'default' : 'outline'}
                  onClick={() => setActiveTab('mental-health')}
                  className={activeTab === 'mental-health' ? 'text-white' : ''}
                  style={activeTab === 'mental-health' ? { backgroundColor: '#5E2C91' } : {}}
                >
                  <Brain className="w-4 h-4 mr-2" />
                  Saúde Mental
                </Button>
                <Button
                  variant={activeTab === 'psychosocial' ? 'default' : 'outline'}
                  onClick={() => setActiveTab('psychosocial')}
                  className={activeTab === 'psychosocial' ? 'text-white' : ''}
                  style={activeTab === 'psychosocial' ? { backgroundColor: '#5E2C91' } : {}}
                >
                  <AlertTriangle className="w-4 h-4 mr-2" />
                  Riscos Psicossociais
                </Button>
              </div>

              <div className="flex flex-wrap gap-3">
                <div className="flex items-center gap-2">
                  <Filter className="w-4 h-4 text-gray-500" />
                  <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                    <SelectTrigger className="w-48">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos os departamentos</SelectItem>
                      {departments.map(dept => (
                        <SelectItem key={dept.id} value={dept.id}>
                          {dept.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-gray-500" />
                  <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                    <SelectTrigger className="w-48">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todo período</SelectItem>
                      <SelectItem value="7days">Últimos 7 dias</SelectItem>
                      <SelectItem value="30days">Últimos 30 dias</SelectItem>
                      <SelectItem value="90days">Últimos 90 dias</SelectItem>
                      <SelectItem value="180days">Últimos 6 meses</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Dashboard Content */}
        {activeTab === 'mental-health' ? (
          <MentalHealthDashboard
            assessments={filteredAssessments}
            employees={employees}
            departments={departments}
          />
        ) : (
          <PsychosocialRisksDashboard
            assessments={filteredAssessments}
            employees={employees}
            departments={departments}
          />
        )}
      </div>
    </div>
  );
}