
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate, Navigate } from "react-router-dom"; // Added Navigate
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Upload, Video, FileText, Save, Eye, X } from "lucide-react";
import { toast } from "sonner";

export default function MediaItemCreate() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  // NEW: State for user and loading
  const [user, setUser] = React.useState(null);
  const [loading, setLoading] = React.useState(true);

  const [step, setStep] = useState(1); // 1: Tipo, 2: Metadados, 3: Visibilidade
  
  const [formData, setFormData] = useState({
    type: "video",
    title: "",
    description: "",
    cover_url: "",
    duration_sec: 0,
    pages: 0,
    provider: "vimeo",
    provider_ref: "",
    file_url: "",
    tags: [],
    categories: [],
    visibility: "neutral",
    consultoria_id: null,
    company_id: null,
    status: "draft"
  });

  const [tagInput, setTagInput] = useState("");
  const [categoryInput, setCategoryInput] = useState("");
  const [uploadingCover, setUploadingCover] = useState(false);
  const [uploadingFile, setUploadingFile] = useState(false);

  // NEW: Effect to load user data and check permissions
  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
      } catch (error) {
        console.error("Error loading user:", error);
        // If there's an error loading user, assume not logged in or unauthorized
        setUser(null); 
      } finally {
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  const { data: consultorias = [] } = useQuery({
    queryKey: ['consultorias-active'],
    queryFn: () => base44.entities.Consultoria.filter({ status: 'ativo' }),
    initialData: [],
    enabled: !loading && user?.role === 'admin' // Only fetch if not loading and is admin
  });

  const { data: companies = [] } = useQuery({
    queryKey: ['companies-all'],
    queryFn: () => base44.entities.Company.list(),
    initialData: [],
    enabled: !loading && user?.role === 'admin' // Only fetch if not loading and is admin
  });

  const createMutation = useMutation({
    mutationFn: async (data) => {
      // Validações
      if (!data.title) throw new Error("Título é obrigatório");
      if (data.type === 'video' && !data.provider_ref) throw new Error("URL do vídeo é obrigatória");
      if (data.type === 'ebook' && !data.file_url) throw new Error("Arquivo do e-book é obrigatório");
      if (data.visibility === 'consultoria' && !data.consultoria_id) throw new Error("Selecione uma consultoria");
      if (data.visibility === 'empresa' && !data.company_id) throw new Error("Selecione uma empresa");
      
      // Extrair duração do Vimeo se possível
      if (data.type === 'video' && data.provider === 'vimeo' && data.provider_ref) {
        // Aqui você pode fazer uma chamada à API do Vimeo para pegar metadados
        // Por enquanto, deixar o usuário preencher manualmente
      }
      
      const payload = { ...data };
      if (data.status === 'published') {
        payload.published_at = new Date().toISOString();
      }
      
      return base44.entities.MediaItem.create(payload);
    },
    onSuccess: () => {
      toast.success("Conteúdo criado com sucesso!");
      queryClient.invalidateQueries({ queryKey: ['media-items-admin'] });
      navigate('/MediaLibraryAdmin');
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao criar conteúdo");
    }
  });

  const handleUploadCover = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setUploadingCover(true);
    try {
      const result = await base44.integrations.Core.UploadFile({ file });
      setFormData({ ...formData, cover_url: result.file_url });
      toast.success("Capa enviada com sucesso!");
    } catch (error) {
      toast.error("Erro ao enviar capa");
    } finally {
      setUploadingCover(false);
    }
  };

  const handleUploadFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setUploadingFile(true);
    try {
      const result = await base44.integrations.Core.UploadFile({ file });
      setFormData({ ...formData, file_url: result.file_url });
      toast.success("Arquivo enviado com sucesso!");
    } catch (error) {
      toast.error("Erro ao enviar arquivo");
    } finally {
      setUploadingFile(false);
    }
  };

  const handleAddTag = () => {
    if (tagInput.trim() && !formData.tags.includes(tagInput.trim())) {
      setFormData({
        ...formData,
        tags: [...formData.tags, tagInput.trim()]
      });
      setTagInput("");
    }
  };

  const handleRemoveTag = (tag) => {
    setFormData({
      ...formData,
      tags: formData.tags.filter(t => t !== tag)
    });
  };

  const handleAddCategory = () => {
    if (categoryInput.trim() && !formData.categories.includes(categoryInput.trim())) {
      setFormData({
        ...formData,
        categories: [...formData.categories, categoryInput.trim()]
      });
      setCategoryInput("");
    }
  };

  const handleRemoveCategory = (cat) => {
    setFormData({
      ...formData,
      categories: formData.categories.filter(c => c !== cat)
    });
  };

  const handleSubmit = (publish = false) => {
    createMutation.mutate({
      ...formData,
      status: publish ? 'published' : 'draft'
    });
  };

  // NEW: Check if loading
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#F8F6FB' }}>
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 mx-auto mb-4" style={{ borderColor: '#4B2672' }}></div>
          <p className="text-sm text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  // NEW: Check for admin role
  if (!user || user.role !== 'admin') {
    return <Navigate to="/MediaLibraryColaborador" replace />;
  }

  return (
    <div className="p-4 md:p-8" style={{ backgroundColor: '#F8F6FB' }}>
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            onClick={() => navigate('/MediaLibraryAdmin')}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar
          </Button>
          <div>
            <h1 className="text-3xl font-bold" style={{ color: '#2E2E2E' }}>
              Novo Conteúdo
            </h1>
            <p className="text-gray-600 mt-1">
              Adicione vídeos ou e-books à biblioteca
            </p>
          </div>
        </div>

        {/* Steps */}
        <div className="flex items-center justify-center gap-4">
          <div className={`flex items-center gap-2 ${step >= 1 ? 'text-purple-600' : 'text-gray-400'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 1 ? 'bg-purple-600 text-white' : 'bg-gray-200'}`}>
              1
            </div>
            <span className="text-sm font-medium">Tipo & Metadados</span>
          </div>
          <div className="w-12 h-0.5 bg-gray-300" />
          <div className={`flex items-center gap-2 ${step >= 2 ? 'text-purple-600' : 'text-gray-400'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 2 ? 'bg-purple-600 text-white' : 'bg-gray-200'}`}>
              2
            </div>
            <span className="text-sm font-medium">Visibilidade</span>
          </div>
        </div>

        {/* Step 1: Tipo e Metadados */}
        {step === 1 && (
          <Card className="shadow-md">
            <CardHeader>
              <CardTitle>Informações Básicas</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Tipo */}
              <div>
                <Label>Tipo de Conteúdo *</Label>
                <div className="grid grid-cols-2 gap-4 mt-2">
                  <button
                    onClick={() => setFormData({ ...formData, type: 'video' })}
                    className={`p-6 border-2 rounded-lg flex flex-col items-center gap-2 transition-all ${
                      formData.type === 'video' 
                        ? 'border-purple-600 bg-purple-50' 
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <Video className="w-8 h-8" style={{ color: formData.type === 'video' ? '#4B2672' : '#6B7280' }} />
                    <span className="font-medium">Vídeo</span>
                  </button>
                  <button
                    onClick={() => setFormData({ ...formData, type: 'ebook' })}
                    className={`p-6 border-2 rounded-lg flex flex-col items-center gap-2 transition-all ${
                      formData.type === 'ebook' 
                        ? 'border-purple-600 bg-purple-50' 
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <FileText className="w-8 h-8" style={{ color: formData.type === 'ebook' ? '#4B2672' : '#6B7280' }} />
                    <span className="font-medium">E-book</span>
                  </button>
                </div>
              </div>

              {/* Título */}
              <div>
                <Label htmlFor="title">Título *</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="Ex: Como lidar com ansiedade no trabalho"
                />
              </div>

              {/* Descrição */}
              <div>
                <Label htmlFor="description">Descrição</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Descreva o conteúdo..."
                  rows={4}
                />
              </div>

              {/* Capa */}
              <div>
                <Label>Imagem de Capa</Label>
                <div className="mt-2">
                  {formData.cover_url ? (
                    <div className="relative w-full aspect-video rounded-lg overflow-hidden border">
                      <img src={formData.cover_url} alt="Capa" className="w-full h-full object-cover" />
                      <Button
                        size="sm"
                        variant="destructive"
                        className="absolute top-2 right-2"
                        onClick={() => setFormData({ ...formData, cover_url: "" })}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  ) : (
                    <label className="w-full aspect-video border-2 border-dashed rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-purple-600 transition-colors">
                      <Upload className="w-8 h-8 text-gray-400 mb-2" />
                      <span className="text-sm text-gray-600">Clique para enviar imagem</span>
                      <span className="text-xs text-gray-400 mt-1">16:9 recomendado</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleUploadCover}
                        disabled={uploadingCover}
                        className="hidden"
                      />
                    </label>
                  )}
                </div>
              </div>

              {/* Campos específicos por tipo */}
              {formData.type === 'video' && (
                <>
                  <div>
                    <Label htmlFor="provider">Provedor</Label>
                    <Select
                      value={formData.provider}
                      onValueChange={(value) => setFormData({ ...formData, provider: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="vimeo">Vimeo</SelectItem>
                        <SelectItem value="url">URL Direta</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="provider_ref">
                      {formData.provider === 'vimeo' ? 'URL do Vimeo *' : 'URL do Vídeo *'}
                    </Label>
                    <Input
                      id="provider_ref"
                      value={formData.provider_ref}
                      onChange={(e) => setFormData({ ...formData, provider_ref: e.target.value })}
                      placeholder={formData.provider === 'vimeo' 
                        ? "https://vimeo.com/1107764573/ebe277b06b?fl=ip&fe=ec"
                        : "https://..."}
                    />
                    {formData.provider === 'vimeo' && (
                      <p className="text-xs text-gray-500 mt-1">
                        Cole a URL completa do Vimeo (incluindo o hash de privacidade se houver)
                      </p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="duration">Duração (minutos)</Label>
                    <Input
                      id="duration"
                      type="number"
                      value={formData.duration_sec ? Math.floor(formData.duration_sec / 60) : 0}
                      onChange={(e) => setFormData({ ...formData, duration_sec: parseInt(e.target.value) * 60 })}
                      placeholder="Ex: 15"
                    />
                  </div>
                </>
              )}

              {formData.type === 'ebook' && (
                <>
                  <div>
                    <Label>Arquivo PDF *</Label>
                    <div className="mt-2">
                      {formData.file_url ? (
                        <div className="flex items-center gap-2 p-4 bg-green-50 border border-green-200 rounded-lg">
                          <FileText className="w-5 h-5 text-green-600" />
                          <span className="text-sm text-green-800 flex-1">Arquivo enviado</span>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => setFormData({ ...formData, file_url: "" })}
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                      ) : (
                        <label className="w-full p-6 border-2 border-dashed rounded-lg flex flex-col items-center cursor-pointer hover:border-purple-600 transition-colors">
                          <Upload className="w-8 h-8 text-gray-400 mb-2" />
                          <span className="text-sm text-gray-600">Clique para enviar PDF</span>
                          <input
                            type="file"
                            accept=".pdf"
                            onChange={handleUploadFile}
                            disabled={uploadingFile}
                            className="hidden"
                          />
                        </label>
                      )}
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="pages">Número de Páginas</Label>
                    <Input
                      id="pages"
                      type="number"
                      value={formData.pages}
                      onChange={(e) => setFormData({ ...formData, pages: parseInt(e.target.value) })}
                      placeholder="Ex: 25"
                    />
                  </div>
                </>
              )}

              {/* Tags */}
              <div>
                <Label>Tags</Label>
                <div className="flex gap-2 mt-2">
                  <Input
                    value={tagInput}
                    onChange={(e) => setTagInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddTag())}
                    placeholder="Ex: ansiedade, estresse, burnout..."
                  />
                  <Button type="button" onClick={handleAddTag}>Adicionar</Button>
                </div>
                {formData.tags.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-3">
                    {formData.tags.map((tag, idx) => (
                      <Badge key={idx} variant="secondary" className="flex items-center gap-1">
                        {tag}
                        <button onClick={() => handleRemoveTag(tag)}>
                          <X className="w-3 h-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                )}
              </div>

              {/* Categorias */}
              <div>
                <Label>Categorias</Label>
                <div className="flex gap-2 mt-2">
                  <Input
                    value={categoryInput}
                    onChange={(e) => setCategoryInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddCategory())}
                    placeholder="Ex: Saúde Mental, Liderança..."
                  />
                  <Button type="button" onClick={handleAddCategory}>Adicionar</Button>
                </div>
                {formData.categories.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-3">
                    {formData.categories.map((cat, idx) => (
                      <Badge key={idx} variant="outline" className="flex items-center gap-1">
                        {cat}
                        <button onClick={() => handleRemoveCategory(cat)}>
                          <X className="w-3 h-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex justify-end">
                <Button onClick={() => setStep(2)} style={{ backgroundColor: '#4B2672', color: 'white' }}>
                  Próximo: Visibilidade
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Step 2: Visibilidade */}
        {step === 2 && (
          <Card className="shadow-md">
            <CardHeader>
              <CardTitle>Configurar Visibilidade</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label>Escopo de Acesso *</Label>
                <Select
                  value={formData.visibility}
                  onValueChange={(value) => setFormData({ 
                    ...formData, 
                    visibility: value,
                    consultoria_id: null,
                    company_id: null
                  })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="neutral">🌍 Neutro (visível para todos)</SelectItem>
                    <SelectItem value="mednet">⭐ MedNet (clientes premium)</SelectItem>
                    <SelectItem value="consultoria">🏢 Específico de Consultoria</SelectItem>
                    <SelectItem value="empresa">🏭 Específico de Empresa</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-gray-500 mt-2">
                  {formData.visibility === 'neutral' && 'Conteúdo visível para qualquer cliente'}
                  {formData.visibility === 'mednet' && 'Visível apenas para clientes com acesso MedNet'}
                  {formData.visibility === 'consultoria' && 'Visível apenas para empresas da consultoria selecionada'}
                  {formData.visibility === 'empresa' && 'Visível apenas para a empresa selecionada'}
                </p>
              </div>

              {formData.visibility === 'consultoria' && (
                <div>
                  <Label>Selecionar Consultoria *</Label>
                  <Select
                    value={formData.consultoria_id || ""}
                    onValueChange={(value) => setFormData({ ...formData, consultoria_id: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Escolha uma consultoria..." />
                    </SelectTrigger>
                    <SelectContent>
                      {consultorias.map(c => (
                        <SelectItem key={c.id} value={c.id}>{c.nome_fantasia}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {formData.visibility === 'empresa' && (
                <div>
                  <Label>Selecionar Empresa *</Label>
                  <Select
                    value={formData.company_id || ""}
                    onValueChange={(value) => setFormData({ ...formData, company_id: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Escolha uma empresa..." />
                    </SelectTrigger>
                    <SelectContent>
                      {companies.map(c => (
                        <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="flex justify-between pt-4 border-t">
                <Button variant="outline" onClick={() => setStep(1)}>
                  Voltar
                </Button>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    onClick={() => handleSubmit(false)}
                    disabled={createMutation.isPending}
                  >
                    <Save className="w-4 h-4 mr-2" />
                    Salvar Rascunho
                  </Button>
                  <Button
                    onClick={() => handleSubmit(true)}
                    disabled={createMutation.isPending}
                    style={{ backgroundColor: '#4B2672', color: 'white' }}
                  >
                    <Eye className="w-4 h-4 mr-2" />
                    Publicar Agora
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
