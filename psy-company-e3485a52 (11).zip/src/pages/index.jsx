import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Companies from "./Companies";

import Assessments from "./Assessments";

import Departments from "./Departments";

import Settings from "./Settings";

import AdminDashboard from "./AdminDashboard";

import Employees from "./Employees";

import Respond from "./Respond";

import CollaboratorPortal from "./CollaboratorPortal";

import Responder from "./Responder";

import ColaboradorAvaliacoes from "./ColaboradorAvaliacoes";

import ResponderAvaliacao from "./ResponderAvaliacao";

import LandingPage from "./LandingPage";

import Error403 from "./Error403";

import PostLogin from "./PostLogin";

import AssessmentReport from "./AssessmentReport";

import Reports from "./Reports";

import PsychosocialReport from "./PsychosocialReport";

import PDFReport from "./PDFReport";

import ExecutiveReport from "./ExecutiveReport";

import Consultorias from "./Consultorias";

import Personalizacao from "./Personalizacao";

import ConsultoriaDashboard from "./ConsultoriaDashboard";

import Planos from "./Planos";

import FaturamentoAdmin from "./FaturamentoAdmin";

import ConsultoriaDetail from "./ConsultoriaDetail";

import FaturamentoConsultoria from "./FaturamentoConsultoria";

import AdminBilling from "./AdminBilling";

import FinanceOverview from "./FinanceOverview";

import FinanceReceitas from "./FinanceReceitas";

import FinanceRecebiveis from "./FinanceRecebiveis";

import FinanceCobranca from "./FinanceCobranca";

import FinanceForecast from "./FinanceForecast";

import FinanceClientes from "./FinanceClientes";

import FinanceClienteDetail from "./FinanceClienteDetail";

import FinanceRelatorios from "./FinanceRelatorios";

import FinanceConfig from "./FinanceConfig";

import SystemDiagnostics from "./SystemDiagnostics";

import DataReset from "./DataReset";

import ActivateConsultoriaMaster from "./ActivateConsultoriaMaster";

import GHE from "./GHE";

import Error404 from "./Error404";

import MediaLibraryAdmin from "./MediaLibraryAdmin";

import MediaItemCreate from "./MediaItemCreate";

import MediaItemEdit from "./MediaItemEdit";

import MediaLibraryColaborador from "./MediaLibraryColaborador";

import MediaPlayer from "./MediaPlayer";

import CanalDenunciasColaborador from "./CanalDenunciasColaborador";

import DenunciaChat from "./DenunciaChat";

import CanalDenunciasEmpresa from "./CanalDenunciasEmpresa";

import TestMasterUser from "./TestMasterUser";

import ActivateMasterUser from "./ActivateMasterUser";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Companies: Companies,
    
    Assessments: Assessments,
    
    Departments: Departments,
    
    Settings: Settings,
    
    AdminDashboard: AdminDashboard,
    
    Employees: Employees,
    
    Respond: Respond,
    
    CollaboratorPortal: CollaboratorPortal,
    
    Responder: Responder,
    
    ColaboradorAvaliacoes: ColaboradorAvaliacoes,
    
    ResponderAvaliacao: ResponderAvaliacao,
    
    LandingPage: LandingPage,
    
    Error403: Error403,
    
    PostLogin: PostLogin,
    
    AssessmentReport: AssessmentReport,
    
    Reports: Reports,
    
    PsychosocialReport: PsychosocialReport,
    
    PDFReport: PDFReport,
    
    ExecutiveReport: ExecutiveReport,
    
    Consultorias: Consultorias,
    
    Personalizacao: Personalizacao,
    
    ConsultoriaDashboard: ConsultoriaDashboard,
    
    Planos: Planos,
    
    FaturamentoAdmin: FaturamentoAdmin,
    
    ConsultoriaDetail: ConsultoriaDetail,
    
    FaturamentoConsultoria: FaturamentoConsultoria,
    
    AdminBilling: AdminBilling,
    
    FinanceOverview: FinanceOverview,
    
    FinanceReceitas: FinanceReceitas,
    
    FinanceRecebiveis: FinanceRecebiveis,
    
    FinanceCobranca: FinanceCobranca,
    
    FinanceForecast: FinanceForecast,
    
    FinanceClientes: FinanceClientes,
    
    FinanceClienteDetail: FinanceClienteDetail,
    
    FinanceRelatorios: FinanceRelatorios,
    
    FinanceConfig: FinanceConfig,
    
    SystemDiagnostics: SystemDiagnostics,
    
    DataReset: DataReset,
    
    ActivateConsultoriaMaster: ActivateConsultoriaMaster,
    
    GHE: GHE,
    
    Error404: Error404,
    
    MediaLibraryAdmin: MediaLibraryAdmin,
    
    MediaItemCreate: MediaItemCreate,
    
    MediaItemEdit: MediaItemEdit,
    
    MediaLibraryColaborador: MediaLibraryColaborador,
    
    MediaPlayer: MediaPlayer,
    
    CanalDenunciasColaborador: CanalDenunciasColaborador,
    
    DenunciaChat: DenunciaChat,
    
    CanalDenunciasEmpresa: CanalDenunciasEmpresa,
    
    TestMasterUser: TestMasterUser,
    
    ActivateMasterUser: ActivateMasterUser,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Companies" element={<Companies />} />
                
                <Route path="/Assessments" element={<Assessments />} />
                
                <Route path="/Departments" element={<Departments />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/AdminDashboard" element={<AdminDashboard />} />
                
                <Route path="/Employees" element={<Employees />} />
                
                <Route path="/Respond" element={<Respond />} />
                
                <Route path="/CollaboratorPortal" element={<CollaboratorPortal />} />
                
                <Route path="/Responder" element={<Responder />} />
                
                <Route path="/ColaboradorAvaliacoes" element={<ColaboradorAvaliacoes />} />
                
                <Route path="/ResponderAvaliacao" element={<ResponderAvaliacao />} />
                
                <Route path="/LandingPage" element={<LandingPage />} />
                
                <Route path="/Error403" element={<Error403 />} />
                
                <Route path="/PostLogin" element={<PostLogin />} />
                
                <Route path="/AssessmentReport" element={<AssessmentReport />} />
                
                <Route path="/Reports" element={<Reports />} />
                
                <Route path="/PsychosocialReport" element={<PsychosocialReport />} />
                
                <Route path="/PDFReport" element={<PDFReport />} />
                
                <Route path="/ExecutiveReport" element={<ExecutiveReport />} />
                
                <Route path="/Consultorias" element={<Consultorias />} />
                
                <Route path="/Personalizacao" element={<Personalizacao />} />
                
                <Route path="/ConsultoriaDashboard" element={<ConsultoriaDashboard />} />
                
                <Route path="/Planos" element={<Planos />} />
                
                <Route path="/FaturamentoAdmin" element={<FaturamentoAdmin />} />
                
                <Route path="/ConsultoriaDetail" element={<ConsultoriaDetail />} />
                
                <Route path="/FaturamentoConsultoria" element={<FaturamentoConsultoria />} />
                
                <Route path="/AdminBilling" element={<AdminBilling />} />
                
                <Route path="/FinanceOverview" element={<FinanceOverview />} />
                
                <Route path="/FinanceReceitas" element={<FinanceReceitas />} />
                
                <Route path="/FinanceRecebiveis" element={<FinanceRecebiveis />} />
                
                <Route path="/FinanceCobranca" element={<FinanceCobranca />} />
                
                <Route path="/FinanceForecast" element={<FinanceForecast />} />
                
                <Route path="/FinanceClientes" element={<FinanceClientes />} />
                
                <Route path="/FinanceClienteDetail" element={<FinanceClienteDetail />} />
                
                <Route path="/FinanceRelatorios" element={<FinanceRelatorios />} />
                
                <Route path="/FinanceConfig" element={<FinanceConfig />} />
                
                <Route path="/SystemDiagnostics" element={<SystemDiagnostics />} />
                
                <Route path="/DataReset" element={<DataReset />} />
                
                <Route path="/ActivateConsultoriaMaster" element={<ActivateConsultoriaMaster />} />
                
                <Route path="/GHE" element={<GHE />} />
                
                <Route path="/Error404" element={<Error404 />} />
                
                <Route path="/MediaLibraryAdmin" element={<MediaLibraryAdmin />} />
                
                <Route path="/MediaItemCreate" element={<MediaItemCreate />} />
                
                <Route path="/MediaItemEdit" element={<MediaItemEdit />} />
                
                <Route path="/MediaLibraryColaborador" element={<MediaLibraryColaborador />} />
                
                <Route path="/MediaPlayer" element={<MediaPlayer />} />
                
                <Route path="/CanalDenunciasColaborador" element={<CanalDenunciasColaborador />} />
                
                <Route path="/DenunciaChat" element={<DenunciaChat />} />
                
                <Route path="/CanalDenunciasEmpresa" element={<CanalDenunciasEmpresa />} />
                
                <Route path="/TestMasterUser" element={<TestMasterUser />} />
                
                <Route path="/ActivateMasterUser" element={<ActivateMasterUser />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}