
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Navigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Building, Users, Briefcase, Eye, Edit, Package, CheckCircle, X } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import PageHeader from "../components/common/PageHeader";
import { getEffectiveContext } from "../components/utils/impersonationContext";

export default function Companies() {
  const [user, setUser] = React.useState(null);
  const [context, setContext] = React.useState(null); // Existing state for effective context
  const [consultoriaId, setConsultoriaId] = React.useState(null); // New state for consultoria_id from context
  const [loading, setLoading] = React.useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [editingCompany, setEditingCompany] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [formData, setFormData] = useState({
    name: "",
    cnpj: "",
    sector: "",
    contact_email: "",
    status: "active",
    plano_id: "", // New field for plan ID
    plano_empresa: "Starter", // Retained for display purposes, but derived from plano_id
    faturamento_modelo: "por_colaborador",
    valor_unitario: 4.90,
    ciclo_faturamento: "mensal",
    permite_personalizacao: true,
    usa_branding_consultoria: false,
    formularios_ativos: true, // New module field
    biblioteca_videos_ativa: true, // New module field
    canal_denuncias_ativo: false // New module field
  });

  const queryClient = useQueryClient();

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
        
        // Usar getEffectiveContext para determinar o contexto efetivo
        const effectiveContext = getEffectiveContext(userData);
        setContext(effectiveContext);
        setConsultoriaId(effectiveContext.consultoria_id); // Set the new consultoriaId state
        
        console.log('=== Companies Page Context ===');
        console.log('Effective context:', effectiveContext);
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  const { data: planos = [] } = useQuery({
    queryKey: ['planos', consultoriaId],
    queryFn: async () => {
      if (!consultoriaId) return [];
      // Buscar planos da consultoria + planos globais (admin)
      const allPlanos = await base44.entities.PlanoConsultoria.list();
      return allPlanos.filter(p => 
        p.status === 'ativo' && 
        (p.consultoria_id === consultoriaId || !p.consultoria_id)
      );
    },
    enabled: !!consultoriaId,
    initialData: [],
  });

  const { data: companies } = useQuery({
    queryKey: ['companies', consultoriaId], // Use consultoriaId from state
    queryFn: async () => {
      if (!consultoriaId) {
        console.log('⚠️ No consultoria_id in context');
        return [];
      }
      console.log('Fetching companies for consultoria:', consultoriaId);
      return await base44.entities.Company.filter({ consultoria_id: consultoriaId });
    },
    enabled: !!consultoriaId, // Enable only if consultoriaId is present in state
    initialData: [],
  });

  const { data: employees = [] } = useQuery({
    queryKey: ['all-employees'],
    queryFn: () => base44.entities.Employee.list(),
    initialData: [],
  });

  const { data: assessments = [] } = useQuery({
    queryKey: ['all-assessments'],
    queryFn: () => base44.entities.Assessment.list(),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => {
      // Add consultoria_id from context to the new company data
      const dataWithContext = {
        ...data,
        consultoria_id: consultoriaId // Use consultoriaId from state
      };
      console.log('Creating company with data:', dataWithContext);
      return base44.entities.Company.create(dataWithContext);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['companies'] });
      setShowDialog(false);
      resetForm();
      toast.success('Empresa criada com sucesso!');
    },
    onError: (error) => {
      toast.error('Erro ao criar empresa: ' + error.message);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Company.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['companies'] });
      setShowDialog(false);
      resetForm();
      toast.success('Empresa atualizada com sucesso!');
    },
    onError: (error) => {
      toast.error('Erro ao atualizar empresa: ' + error.message);
    },
  });

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1,2,3].map(i => (
              <div key={i} className="h-32 bg-gray-200 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!user || !context) {
    return <Navigate to="/" />;
  }

  // Permitir acesso se for admin (com ou sem impersonation) ou consultoria
  const canAccess = context.original_role === 'admin' || context.role === 'consultoria';
  
  if (!canAccess) {
    return <Navigate to="/" />;
  }

  if (!consultoriaId) { // Check consultoriaId from the state
    return (
      <div className="p-8">
        <Card className="border-2 border-yellow-200 bg-yellow-50">
          <CardContent className="p-6">
            <p className="text-yellow-800 font-medium">
              Selecione uma consultoria para visualizar suas empresas.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const formatCnpj = (value) => {
    if (!value) return '';
    value = value.replace(/\D/g, '');
    value = value.slice(0, 14);

    if (value.length > 12) {
      value = value.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2}).*/, '$1.$2.$3/$4-$5');
    } else if (value.length > 8) {
      value = value.replace(/^(\d{2})(\d{3})(\d{3})(\d{4}).*/, '$1.$2.$3/$4');
    } else if (value.length > 5) {
      value = value.replace(/^(\d{2})(\d{3})(\d{3}).*/, '$1.$2.$3');
    } else if (value.length > 2) {
      value = value.replace(/^(\d{2})(\d{3}).*/, '$1.$2');
    }
    return value;
  };

  const resetForm = () => {
    setFormData({
      name: "",
      cnpj: "",
      sector: "",
      contact_email: "",
      status: "active",
      plano_id: "",
      plano_empresa: "Starter",
      faturamento_modelo: "por_colaborador",
      valor_unitario: 4.90,
      ciclo_faturamento: "mensal",
      permite_personalizacao: true,
      usa_branding_consultoria: false,
      formularios_ativos: true,
      biblioteca_videos_ativa: true,
      canal_denuncias_ativo: false
    });
    setEditingCompany(null);
  };

  const handlePlanoChange = (planoId) => {
    const plano = planos.find(p => p.id === planoId);
    
    if (plano) {
      setFormData(prev => ({
        ...prev,
        plano_id: planoId,
        plano_empresa: plano.nome,
        formularios_ativos: plano.modulo_questionarios !== false, // Default to true if not explicitly false
        biblioteca_videos_ativa: plano.modulo_biblioteca !== false, // Default to true if not explicitly false
        canal_denuncias_ativo: plano.modulo_denuncias === true // Default to false if not explicitly true
      }));
    } else {
      // If no plan is selected or plan not found, reset to default state for modules
      setFormData(prev => ({
        ...prev,
        plano_id: planoId,
        plano_empresa: "Starter", // Fallback name
        formularios_ativos: true,
        biblioteca_videos_ativa: true,
        canal_denuncias_ativo: false
      }));
    }
  };

  const handleEdit = (company) => {
    setEditingCompany(company);
    setFormData({
      name: company.name,
      cnpj: company.cnpj,
      sector: company.sector || "",
      contact_email: company.contact_email || "",
      status: company.status,
      plano_id: company.plano_id || "", // Populate plano_id
      plano_empresa: company.plano_empresa || "Starter",
      faturamento_modelo: company.faturamento_modelo || "por_colaborador",
      valor_unitario: company.valor_unitario || 4.90,
      ciclo_faturamento: company.ciclo_faturamento || "mensal",
      permite_personalizacao: company.permite_personalizacao !== false,
      usa_branding_consultoria: company.usa_branding_consultoria || false,
      formularios_ativos: company.formularios_ativos !== false, // Populate module fields
      biblioteca_videos_ativa: company.biblioteca_videos_ativa !== false,
      canal_denuncias_ativo: company.canal_denuncias_ativo === true
    });
    setShowDialog(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // The consultoria_id is now added within the createMutationFn or implicitly handled for updates

    if (editingCompany) {
      updateMutation.mutate({ id: editingCompany.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleViewDetails = (company) => {
    console.log('=== handleViewDetails ===');
    console.log('Company:', company);
    console.log('Current consultoriaId:', context?.consultoria_id);
    
    // Salvar impersonation de empresa
    const impersonationData = {
      type: 'empresa',
      consultoria_id: context?.consultoria_id,
      consultoria_nome: context?.consultoria_name || context?.name || '', // Attempt to get consultoria name from context
      company_id: company.id,
      company_nome: company.name,
      employee_id: null,
      employee_nome: null
    };
    
    console.log('Setting empresa impersonation:', impersonationData);
    localStorage.setItem('admin_impersonation', JSON.stringify(impersonationData));
    
    toast.success(`Visualizando como: ${company.name}`);
    
    // Redirecionar para o dashboard da empresa
    setTimeout(() => {
      window.location.href = createPageUrl('Dashboard');
    }, 500);
  };

  const filteredCompanies = companies.filter(c => {
    const searchMatch = c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                       c.cnpj.includes(searchTerm);
    const statusMatch = statusFilter === 'all' || c.status === statusFilter;
    return searchMatch && statusMatch;
  });

  const companyStats = filteredCompanies.map(company => {
    const companyEmployees = employees.filter(e => e.company_id === company.id && e.status === 'active');
    const companyAssessments = assessments.filter(a => a.company_id === company.id);
    const completedAssessments = companyAssessments.filter(a => a.completed_at);
    const engajamento = companyEmployees.length > 0 
      ? ((completedAssessments.length / companyEmployees.length) * 100).toFixed(1) 
      : 0;

    return {
      ...company,
      colaboradores: companyEmployees.length,
      avaliacoes: companyAssessments.length,
      engajamento: parseFloat(engajamento)
    };
  });

  const totalEmpresas = filteredCompanies.length;
  const empresasAtivas = filteredCompanies.filter(c => c.status === 'active').length;
  const totalColaboradores = companyStats.reduce((acc, c) => acc + c.colaboradores, 0);
  const mediaColaboradores = totalEmpresas > 0 ? (totalColaboradores / totalEmpresas).toFixed(0) : 0;

  const breadcrumbs = [
    { label: "iMental" },
    { label: "Empresas" }
  ];

  return (
    <div className="p-4 md:p-8 min-h-screen" style={{ backgroundColor: '#F8F6FB' }}>
      <div className="max-w-[1800px] mx-auto space-y-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
          <PageHeader
            title="Empresas"
            description="Gerencie as empresas vinculadas à consultoria"
            breadcrumbs={breadcrumbs}
            showBack={false}
          />
          <Button
            onClick={() => setShowDialog(true)}
            className="text-white shadow-lg hover:shadow-xl transition-all"
            style={{
              background: 'linear-gradient(135deg, #4B2672 0%, #6B36B4 100%)'
            }}
          >
            <Plus className="w-4 h-4 mr-2" />
            Nova Empresa
          </Button>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="shadow-md">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                <Building className="w-4 h-4" style={{ color: '#4B2672' }} />
                Total de Empresas
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold" style={{ color: '#4B2672' }}>
                {totalEmpresas}
              </p>
            </CardContent>
          </Card>

          <Card className="shadow-md">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                <Building className="w-4 h-4 text-green-600" />
                Empresas Ativas
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold text-green-600">
                {empresasAtivas}
              </p>
            </CardContent>
          </Card>

          <Card className="shadow-md">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                <Users className="w-4 h-4 text-blue-600" />
                Total de Colaboradores
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold text-blue-600">
                {totalColaboradores}
              </p>
            </CardContent>
          </Card>

          <Card className="shadow-md">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                <Briefcase className="w-4 h-4 text-purple-600" />
                Média de Colaboradores
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold text-purple-600">
                {mediaColaboradores}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Filtros */}
        <Card className="shadow-md">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Input
                placeholder="Buscar por nome ou CNPJ..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filtrar por status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os status</SelectItem>
                  <SelectItem value="active">Ativas</SelectItem>
                  <SelectItem value="inactive">Inativas</SelectItem>
                  <SelectItem value="suspended">Suspensas</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Tabela */}
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle>Empresas Cadastradas ({companyStats.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50">
                    <TableHead>Empresa</TableHead>
                    <TableHead className="text-center">Colaboradores</TableHead>
                    <TableHead className="text-center">Avaliações</TableHead>
                    <TableHead className="text-center">Engajamento</TableHead>
                    <TableHead className="text-center">Status</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {companyStats.map((company) => (
                    <TableRow key={company.id} className="hover:bg-gray-50">
                      <TableCell>
                        <div>
                          <p className="font-semibold">{company.name}</p>
                          <p className="text-xs text-gray-500">{company.cnpj}</p>
                        </div>
                      </TableCell>
                      <TableCell className="text-center font-semibold">
                        {company.colaboradores}
                      </TableCell>
                      <TableCell className="text-center font-semibold">
                        {company.avaliacoes}
                      </TableCell>
                      <TableCell className="text-center">
                        <span className={`font-semibold ${
                          company.engajamento >= 75 ? 'text-green-600' :
                          company.engajamento >= 50 ? 'text-yellow-600' :
                          'text-red-600'
                        }`}>
                          {company.engajamento}%
                        </span>
                      </TableCell>
                      <TableCell className="text-center">
                        {company.status === 'active' && (
                          <Badge className="bg-green-100 text-green-800">Ativa</Badge>
                        )}
                        {company.status === 'inactive' && (
                          <Badge className="bg-gray-100 text-gray-800">Inativa</Badge>
                        )}
                        {company.status === 'suspended' && (
                          <Badge className="bg-red-100 text-red-800">Suspensa</Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleViewDetails(company)}
                            title="Ver detalhes"
                          >
                            <Eye className="w-4 h-4 text-gray-600" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleEdit(company)}
                            title="Editar"
                          >
                            <Edit className="w-4 h-4 text-gray-600" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Dialog de Nova/Editar Empresa */}
        <Dialog open={showDialog} onOpenChange={(open) => {
          setShowDialog(open);
          if (!open) resetForm();
        }}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingCompany ? 'Editar Empresa' : 'Nova Empresa'}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Nome da Empresa *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="cnpj">CNPJ *</Label>
                  <Input
                    id="cnpj"
                    value={formatCnpj(formData.cnpj)}
                    onChange={(e) => setFormData({...formData, cnpj: e.target.value})}
                    placeholder="00.000.000/0000-00"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="sector">Setor</Label>
                  <Input
                    id="sector"
                    value={formData.sector}
                    onChange={(e) => setFormData({...formData, sector: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="contact_email">E-mail de Contato</Label>
                  <Input
                    id="contact_email"
                    type="email"
                    value={formData.contact_email}
                    onChange={(e) => setFormData({...formData, contact_email: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="status">Status</Label>
                  <Select value={formData.status} onValueChange={(value) => setFormData({...formData, status: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Ativa</SelectItem>
                      <SelectItem value="inactive">Inativa</SelectItem>
                      <SelectItem value="suspended">Suspensa</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="plano">Plano *</Label>
                  <Select 
                    value={formData.plano_id} 
                    onValueChange={handlePlanoChange}
                    required
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione um plano" />
                    </SelectTrigger>
                    <SelectContent>
                      {planos.map(plano => (
                        <SelectItem key={plano.id} value={plano.id}>
                          {plano.nome} - R$ {plano.valor_base ? plano.valor_base.toFixed(2) : '0.00'}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Módulos Incluídos (readonly baseado no plano) */}
              {formData.plano_id && (
                <div className="p-4 bg-gray-50 rounded-lg">
                  <h3 className="font-semibold mb-3 flex items-center gap-2">
                    <Package className="w-4 h-4" />
                    Módulos Incluídos no Plano
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div className={`p-3 rounded border ${formData.formularios_ativos ? 'bg-green-50 border-green-200' : 'bg-gray-100 border-gray-300'}`}>
                      <div className="flex items-center gap-2">
                        {formData.formularios_ativos ? (
                          <CheckCircle className="w-4 h-4 text-green-600" />
                        ) : (
                          <X className="w-4 h-4 text-gray-400" />
                        )}
                        <span className="text-sm font-medium">Questionários</span>
                      </div>
                    </div>
                    <div className={`p-3 rounded border ${formData.biblioteca_videos_ativa ? 'bg-green-50 border-green-200' : 'bg-gray-100 border-gray-300'}`}>
                      <div className="flex items-center gap-2">
                        {formData.biblioteca_videos_ativa ? (
                          <CheckCircle className="w-4 h-4 text-green-600" />
                        ) : (
                          <X className="w-4 h-4 text-gray-400" />
                        )}
                        <span className="text-sm font-medium">Biblioteca</span>
                      </div>
                    </div>
                    <div className={`p-3 rounded border ${formData.canal_denuncias_ativo ? 'bg-green-50 border-green-200' : 'bg-gray-100 border-gray-300'}`}>
                      <div className="flex items-center gap-2">
                        {formData.canal_denuncias_ativo ? (
                          <CheckCircle className="w-4 h-4 text-green-600" />
                        ) : (
                          <X className="w-4 h-4 text-gray-400" />
                        )}
                        <span className="text-sm font-medium">Denúncias</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div className="flex justify-end gap-3 pt-4 border-t">
                <Button type="button" variant="outline" onClick={() => setShowDialog(false)}>
                  Cancelar
                </Button>
                <Button type="submit" className="text-white" style={{ backgroundColor: '#4B2672' }}>
                  {editingCompany ? 'Atualizar' : 'Criar'} Empresa
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
