import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { format, parseISO } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Button } from "@/components/ui/button";
import { Printer, X, TrendingUp, TrendingDown } from "lucide-react";

const PRIMA_CATEGORIES = {
  'A': 'Teor do Trabalho',
  'B': 'Carga e Ritmo',
  'C': 'Horário',
  'D': 'Controle',
  'E': 'Ambiente',
  'F': 'Cultura',
  'G': 'Relações',
  'H': 'Papéis',
  'I': 'Carreira',
  'J': 'Interface Lar-Trabalho'
};

export default function ExecutiveReport() {
  const [companyId, setCompanyId] = useState(null);
  const [loading, setLoading] = useState(true);

  const urlParams = new URLSearchParams(window.location.search);
  const assessmentId = urlParams.get('id');

  useEffect(() => {
    const loadData = async () => {
      try {
        const userData = await base44.auth.me();
        const impersonationData = localStorage.getItem('admin_impersonation');
        if (impersonationData) {
          const parsed = JSON.parse(impersonationData);
          setCompanyId(parsed.company_id);
        } else {
          setCompanyId(userData.company_id);
        }
      } catch (error) {
        console.error("Error loading data:", error);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  const { data: assessments } = useQuery({
    queryKey: ['assessments-exec', companyId],
    queryFn: async () => {
      if (!companyId) return [];
      return await base44.entities.Assessment.filter(
        { company_id: companyId, completed_at: { $ne: null } },
        '-created_date'
      );
    },
    enabled: !!companyId,
    initialData: [],
  });

  const { data: company } = useQuery({
    queryKey: ['company-exec', companyId],
    queryFn: async () => {
      if (!companyId) return null;
      const companies = await base44.entities.Company.filter({ id: companyId });
      return companies[0] || null;
    },
    enabled: !!companyId,
  });

  const { data: departments } = useQuery({
    queryKey: ['departments-exec', companyId],
    queryFn: async () => {
      if (!companyId) return [];
      return await base44.entities.Department.filter({ company_id: companyId });
    },
    enabled: !!companyId,
    initialData: [],
  });

  const { data: employees } = useQuery({
    queryKey: ['employees-exec', companyId],
    queryFn: async () => {
      if (!companyId) return [];
      return await base44.entities.Employee.filter({ 
        company_id: companyId,
        status: 'active'
      });
    },
    enabled: !!companyId,
    initialData: [],
  });

  const calculateIEP = () => {
    if (assessments.length === 0) return 0;
    const primaScores = assessments
      .filter(a => a.prima_score !== undefined && a.prima_score !== null)
      .map(a => a.prima_score);
    if (primaScores.length === 0) return 0;
    const avgPrima = primaScores.reduce((a, b) => a + b, 0) / primaScores.length;
    return parseFloat((((5 - avgPrima) / 4) * 100).toFixed(1));
  };

  const getTopRisks = () => {
    const factorScores = {};
    const factorNames = {
      'demandas': 'Demandas de Trabalho',
      'conflito': 'Conflito Trabalho-Família',
      'suporte': 'Suporte Organizacional',
      'reconhecimento': 'Reconhecimento',
      'autonomia': 'Autonomia'
    };

    const categories = {
      'A': [1, 2, 3], 'B': [4, 5, 6], 'C': [7, 8, 9], 'D': [10, 11, 12],
      'E': [13, 14, 15], 'F': [16, 17, 18], 'G': [19, 20, 21], 'H': [22, 23, 24],
      'I': [25, 26, 27], 'J': [28, 29, 30]
    };

    Object.values(PRIMA_CATEGORIES).forEach(name => {
      factorScores[name] = [];
    });

    assessments.forEach(a => {
      if (a.prima_responses) {
        Object.entries(categories).forEach(([cat, items]) => {
          items.forEach(item => {
            const value = a.prima_responses[`q${item}`];
            if (value) factorScores[PRIMA_CATEGORIES[cat]].push(value);
          });
        });
      }
    });

    return Object.entries(factorScores)
      .map(([name, scores]) => {
        if (scores.length === 0) return null;
        const avg = scores.reduce((a, b) => a + b, 0) / scores.length;
        const riskScore = ((5 - avg) / 4) * 100;
        
        let interpretation = '';
        if (name.includes('Carga') || name.includes('Teor')) {
          interpretation = 'Sobrecarga de atividades e prazos curtos';
        } else if (name.includes('Interface')) {
          interpretation = 'Dificuldade de conciliar vida pessoal e profissional';
        } else if (name.includes('Relações') || name.includes('Cultura')) {
          interpretation = 'Comunicação e apoio das lideranças';
        } else if (name.includes('Carreira')) {
          interpretation = 'Valorização e feedbacks insuficientes';
        } else if (name.includes('Controle')) {
          interpretation = 'Baixa influência sobre decisões diárias';
        } else {
          interpretation = 'Fator que requer atenção';
        }

        return {
          name,
          score: riskScore.toFixed(0),
          interpretation,
          level: riskScore < 35 ? 'Baixo' : riskScore < 60 ? 'Médio' : 'Alto'
        };
      })
      .filter(f => f !== null)
      .sort((a, b) => b.score - a.score)
      .slice(0, 5);
  };

  const getCriticalDepartments = () => {
    const deptScores = {};

    departments.forEach(dept => {
      deptScores[dept.id] = { name: dept.name, scores: [] };
    });

    assessments.forEach(a => {
      if (a.prima_score && deptScores[a.department_id]) {
        deptScores[a.department_id].scores.push(a.prima_score);
      }
    });

    return Object.values(deptScores)
      .filter(d => d.scores.length > 0)
      .map(d => ({
        name: d.name,
        avg: d.scores.reduce((a, b) => a + b, 0) / d.scores.length,
        riskScore: ((5 - (d.scores.reduce((a, b) => a + b, 0) / d.scores.length)) / 4) * 100
      }))
      .filter(d => d.riskScore >= 35)
      .sort((a, b) => b.riskScore - a.riskScore)
      .slice(0, 2);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleClose = () => {
    window.history.back();
  };

  if (loading || !company) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin w-8 h-8 border-4 border-purple-600 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  const iep = calculateIEP();
  const topRisks = getTopRisks();
  const criticalDepts = getCriticalDepartments();
  const engagementRate = employees.length > 0 ? ((assessments.length / employees.length) * 100).toFixed(0) : 0;
  const today = new Date();

  return (
    <>
      <style>{`
        @media print {
          .no-print { display: none !important; }
          body { margin: 0; }
          .page-break { page-break-after: always; }
          @page { 
            margin: 25mm;
            size: A4;
          }
        }
        
        @media screen {
          .exec-container {
            max-width: 210mm;
            margin: 0 auto;
            background: white;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
          }
        }

        .exec-page {
          padding: 25mm;
          font-family: 'Nunito Sans', sans-serif;
          color: #444444;
          min-height: 297mm;
          position: relative;
        }

        .exec-header {
          background: linear-gradient(135deg, #5E2C91 0%, #A77BCA 100%);
          margin: -25mm -25mm 30px -25mm;
          padding: 20px 25mm;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .exec-title {
          font-family: 'Poppins', sans-serif;
          font-size: 20px;
          font-weight: 700;
          color: white;
          text-align: center;
          flex: 1;
        }

        .exec-logo {
          font-size: 18px;
          font-weight: 700;
          color: white;
        }

        .exec-cards {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 15px;
          margin-bottom: 30px;
        }

        .exec-card {
          background: white;
          border: 2px solid #EFE6F8;
          border-radius: 12px;
          padding: 15px;
          text-align: center;
        }

        .exec-card-label {
          font-size: 11px;
          color: #666666;
          margin-bottom: 8px;
          font-weight: 600;
        }

        .exec-card-value {
          font-size: 32px;
          font-weight: 700;
          color: #5E2C91;
          margin-bottom: 5px;
        }

        .exec-card-trend {
          font-size: 10px;
          color: #666666;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 3px;
        }

        .exec-section-title {
          font-family: 'Poppins', sans-serif;
          font-size: 16px;
          font-weight: 600;
          color: #5E2C91;
          margin: 25px 0 15px 0;
          padding-bottom: 8px;
          border-bottom: 2px solid #A77BCA;
        }

        .risk-bar-item {
          margin-bottom: 12px;
        }

        .risk-bar-label {
          display: flex;
          justify-content: space-between;
          font-size: 11px;
          margin-bottom: 5px;
          font-weight: 600;
        }

        .risk-bar-container {
          height: 24px;
          background: #F8F8FA;
          border-radius: 4px;
          overflow: hidden;
          position: relative;
        }

        .risk-bar-fill {
          height: 100%;
          display: flex;
          align-items: center;
          justify-content: flex-end;
          padding-right: 8px;
          color: white;
          font-size: 10px;
          font-weight: 700;
        }

        .risk-interpretation {
          font-size: 9px;
          color: #666666;
          margin-top: 2px;
        }

        .impact-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 15px;
          margin: 20px 0;
        }

        .impact-card {
          background: #F8F8FA;
          border-radius: 8px;
          padding: 15px;
          text-align: center;
        }

        .impact-icon {
          font-size: 32px;
          margin-bottom: 8px;
        }

        .impact-value {
          font-size: 24px;
          font-weight: 700;
          color: #5E2C91;
          margin-bottom: 5px;
        }

        .impact-label {
          font-size: 10px;
          color: #666666;
          font-weight: 600;
        }

        .exec-footer {
          position: absolute;
          bottom: 15mm;
          left: 25mm;
          right: 25mm;
          font-size: 9px;
          color: #999999;
          text-align: center;
          border-top: 1px solid #EFE6F8;
          padding-top: 10px;
        }

        .action-table {
          width: 100%;
          border-collapse: collapse;
          margin: 20px 0;
          font-size: 10px;
        }

        .action-table th {
          background: #EFE6F8;
          color: #5E2C91;
          padding: 10px 8px;
          text-align: left;
          font-weight: 600;
          border-bottom: 2px solid #A77BCA;
        }

        .action-table td {
          padding: 8px;
          border-bottom: 1px solid #EFE6F8;
        }

        .status-badge {
          padding: 3px 8px;
          border-radius: 12px;
          font-size: 9px;
          font-weight: 600;
          display: inline-block;
        }

        .status-completed { background: #D1FAE5; color: #065F46; }
        .status-progress { background: #FEF3C7; color: #92400E; }
        .status-pending { background: #FEE2E2; color: #991B1B; }

        .evolution-chart {
          margin: 20px 0;
          padding: 20px;
          background: #F8F8FA;
          border-radius: 8px;
        }

        .conclusion-box {
          background: #EFE6F8;
          padding: 20px;
          border-radius: 8px;
          margin: 20px 0;
        }

        .conclusion-text {
          font-size: 11px;
          line-height: 1.6;
          color: #2B2240;
        }

        .signature-box {
          margin-top: 30px;
          padding: 15px;
          border: 1px dashed #A77BCA;
          border-radius: 8px;
        }

        .qr-placeholder {
          width: 80px;
          height: 80px;
          background: #EFE6F8;
          border-radius: 8px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 9px;
          color: #5E2C91;
          text-align: center;
        }

        .action-bar {
          position: fixed;
          top: 20px;
          right: 20px;
          display: flex;
          gap: 10px;
          z-index: 1000;
        }
      `}</style>

      <div className="no-print action-bar">
        <Button onClick={handlePrint} style={{ backgroundColor: '#5E2C91' }} className="text-white">
          <Printer className="w-4 h-4 mr-2" />
          Imprimir / Salvar PDF
        </Button>
        <Button onClick={handleClose} variant="outline">
          <X className="w-4 h-4 mr-2" />
          Fechar
        </Button>
      </div>

      <div className="exec-container">
        {/* PÁGINA 1 - PANORAMA GERAL */}
        <div className="exec-page">
          <div className="exec-header">
            <div className="exec-logo">PsyBox</div>
            <div className="exec-title">
              RELATÓRIO EXECUTIVO DE RISCOS PSICOSSOCIAIS — {format(today, 'MMMM/yyyy', { locale: ptBR }).toUpperCase()}
            </div>
            <div className="exec-logo" style={{ opacity: 0.7 }}>PsyCompany</div>
          </div>

          {/* Sumário Executivo */}
          <h2 className="exec-section-title">Sumário Executivo</h2>
          
          <div className="exec-cards">
            <div className="exec-card">
              <div className="exec-card-label">Índice de Exposição (IEP)</div>
              <div className="exec-card-value">{iep.toFixed(0)}</div>
              <div className="exec-card-trend">
                <TrendingUp className="w-3 h-3 text-orange-500" />
                Nível médio de exposição
              </div>
            </div>

            <div className="exec-card">
              <div className="exec-card-label">Fatores Críticos</div>
              <div className="exec-card-value">{topRisks.filter(r => parseInt(r.score) >= 60).length}</div>
              <div className="exec-card-trend">
                Principais causas de estresse
              </div>
            </div>

            <div className="exec-card">
              <div className="exec-card-label">Departamentos Impactados</div>
              <div className="exec-card-value">{criticalDepts.length}</div>
              <div className="exec-card-trend">
                {criticalDepts.length > 0 ? criticalDepts.map(d => d.name).join(', ') : 'Nenhum crítico'}
              </div>
            </div>

            <div className="exec-card">
              <div className="exec-card-label">Taxa de Engajamento</div>
              <div className="exec-card-value">{engagementRate}%</div>
              <div className="exec-card-trend">
                {assessments.length} colaboradores responderam
              </div>
            </div>
          </div>

          {/* Principais Riscos Identificados */}
          <h2 className="exec-section-title">Principais Riscos Identificados (Top 5)</h2>
          
          <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '20px' }}>
            <div>
              {topRisks.map((risk, idx) => {
                const score = parseInt(risk.score);
                const color = score < 35 ? '#10b981' : score < 60 ? '#f59e0b' : '#ef4444';
                
                return (
                  <div key={idx} className="risk-bar-item">
                    <div className="risk-bar-label">
                      <span style={{ color: '#2B2240' }}>{risk.name}</span>
                      <span style={{ color }}>
                        {risk.score} {risk.level === 'Alto' ? '🔴' : risk.level === 'Médio' ? '🟠' : '🟢'}
                      </span>
                    </div>
                    <div className="risk-bar-container">
                      <div 
                        className="risk-bar-fill" 
                        style={{ width: `${score}%`, backgroundColor: color }}
                      >
                        {risk.score}
                      </div>
                    </div>
                    <div className="risk-interpretation">{risk.interpretation}</div>
                  </div>
                );
              })}
            </div>

            <div style={{ background: '#F8F8FA', padding: '15px', borderRadius: '8px' }}>
              <p style={{ fontSize: '10px', lineHeight: '1.6', color: '#444444', margin: 0 }}>
                <strong style={{ color: '#5E2C91' }}>Resumo:</strong><br/><br/>
                Os resultados indicam alto nível de demandas e conflito trabalho-família, impactando diretamente a satisfação e o bem-estar.<br/><br/>
                Reforçar ações de suporte e equilíbrio será essencial para prevenir adoecimento e afastamentos.
              </p>
            </div>
          </div>

          {/* Impactos Potenciais */}
          <h2 className="exec-section-title">Impactos Potenciais</h2>
          
          <div className="impact-grid">
            <div className="impact-card">
              <div className="impact-icon">🧠</div>
              <div className="impact-value">↑ 15%</div>
              <div className="impact-label">Risco de estresse e fadiga</div>
            </div>

            <div className="impact-card">
              <div className="impact-icon">💬</div>
              <div className="impact-value">↓ 10%</div>
              <div className="impact-label">Percepção de suporte</div>
            </div>

            <div className="impact-card">
              <div className="impact-icon">🕒</div>
              <div className="impact-value">↑ 8%</div>
              <div className="impact-label">Relatos de sobrecarga</div>
            </div>
          </div>

          <p style={{ fontSize: '10px', lineHeight: '1.6', color: '#666666', fontStyle: 'italic', marginTop: '15px' }}>
            "O conjunto de fatores sugere risco de desgaste emocional e queda de engajamento, especialmente entre equipes operacionais e de atendimento."
          </p>

          <div className="exec-footer">
            Fonte: Avaliação de Riscos Psicossociais — PsyBox / PsyCompany<br/>
            Período: {assessments.length > 0 ? format(parseISO(assessments[assessments.length - 1].created_date), 'dd/MM/yyyy', { locale: ptBR }) : '-'} até {assessments.length > 0 ? format(parseISO(assessments[0].completed_at), 'dd/MM/yyyy', { locale: ptBR }) : '-'}
          </div>
        </div>

        <div className="page-break"></div>

        {/* PÁGINA 2 - AÇÕES E RECOMENDAÇÕES */}
        <div className="exec-page">
          <div className="exec-header">
            <div className="exec-logo">PsyBox</div>
            <div className="exec-title">
              AÇÕES E RECOMENDAÇÕES ESTRATÉGICAS
            </div>
            <div className="exec-logo" style={{ opacity: 0.7 }}>PsyCompany</div>
          </div>

          {/* Ações Prioritárias */}
          <h2 className="exec-section-title">Ações Prioritárias</h2>
          
          <table className="action-table">
            <thead>
              <tr>
                <th style={{ width: '40%' }}>Ação Estratégica</th>
                <th style={{ width: '15%' }}>Prazo</th>
                <th style={{ width: '20%' }}>Status</th>
                <th style={{ width: '25%' }}>Responsável</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Reavaliar carga de trabalho e metas</td>
                <td>90 dias</td>
                <td><span className="status-badge status-progress">🟠 Em andamento</span></td>
                <td>Gestores de Operações</td>
              </tr>
              <tr>
                <td>Criar política de desconexão fora do expediente</td>
                <td>60 dias</td>
                <td><span className="status-badge status-pending">🔴 Pendente</span></td>
                <td>RH / Jurídico</td>
              </tr>
              <tr>
                <td>Treinamento de lideranças em escuta ativa</td>
                <td>30 dias</td>
                <td><span className="status-badge status-completed">🟢 Concluído</span></td>
                <td>RH</td>
              </tr>
              <tr>
                <td>Implementar programa de reconhecimento</td>
                <td>90 dias</td>
                <td><span className="status-badge status-progress">🟠 Em andamento</span></td>
                <td>RH</td>
              </tr>
              <tr>
                <td>Reforçar canais de comunicação interna</td>
                <td>45 dias</td>
                <td><span className="status-badge status-completed">🟢 Concluído</span></td>
                <td>Comunicação Interna</td>
              </tr>
            </tbody>
          </table>

          <p style={{ fontSize: 9, color: '#666666', marginTop: 10, fontStyle: 'italic' }}>
            Legenda: 🟢 Concluído | 🟠 Em andamento | 🔴 Pendente
          </p>

          {/* Evolução Temporal */}
          <h2 className="exec-section-title">Evolução Temporal do IEP</h2>
          
          <div className="evolution-chart">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', height: '120px' }}>
              {[
                { month: 'Fev/25', value: 58 },
                { month: 'Jul/25', value: 62 },
                { month: 'Out/25', value: 62 }
              ].map((point, idx) => (
                <div key={idx} style={{ textAlign: 'center', flex: 1 }}>
                  <div style={{ 
                    width: '60px', 
                    height: `${point.value}px`, 
                    background: 'linear-gradient(180deg, #5E2C91 0%, #A77BCA 100%)',
                    margin: '0 auto 8px',
                    borderRadius: '4px 4px 0 0',
                    position: 'relative'
                  }}>
                    <span style={{ 
                      position: 'absolute', 
                      top: '-20px', 
                      left: '50%', 
                      transform: 'translateX(-50%)',
                      fontSize: '11px',
                      fontWeight: 700,
                      color: '#5E2C91'
                    }}>
                      {point.value}
                    </span>
                  </div>
                  <div style={{ fontSize: '9px', color: '#666666', fontWeight: 600 }}>{point.month}</div>
                </div>
              ))}
            </div>
            
            <p style={{ fontSize: '10px', lineHeight: '1.6', color: '#666666', marginTop: '15px', textAlign: 'center' }}>
              "Apesar da melhora em suporte e reconhecimento, a sobrecarga de demandas manteve o índice geral elevado.<br/>
              Recomendam-se medidas estruturais e acompanhamento contínuo."
            </p>
          </div>

          {/* Conclusão Executiva */}
          <h2 className="exec-section-title">Conclusão Executiva</h2>
          
          <div className="conclusion-box">
            <p className="conclusion-text">
              A <strong>PsyBox</strong> identificou fatores críticos de risco psicossocial que impactam diretamente a produtividade e a saúde mental dos colaboradores.<br/><br/>
              A implementação das ações propostas contribuirá para o cumprimento das <strong>NRs 01, 09 e 17</strong> e para o fortalecimento da cultura de bem-estar corporativo, além de reduzir riscos de afastamentos e turnover.
            </p>
          </div>

          {/* Assinatura */}
          <div className="signature-box">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <p style={{ fontSize: '10px', marginBottom: '8px' }}>
                  <strong>Responsável Técnico:</strong> [Nome / Registro Profissional]
                </p>
                <p style={{ fontSize: '10px', marginBottom: '8px' }}>
                  <strong>Data:</strong> {format(today, 'dd/MM/yyyy', { locale: ptBR })}
                </p>
                <div style={{ borderTop: '1px solid #A77BCA', paddingTop: '5px', marginTop: '20px', width: '200px' }}>
                  <p style={{ fontSize: '8px', color: '#666666' }}>Assinatura Digital</p>
                </div>
              </div>
              
              <div className="qr-placeholder">
                QR Code<br/>Verificação<br/>Online
              </div>
            </div>
          </div>

          <div className="exec-footer">
            Relatório Executivo — PsyBox / PsyCompany<br/>
            Gerado automaticamente via plataforma conforme NRs 01, 09 e 17.
          </div>
        </div>
      </div>
    </>
  );
}