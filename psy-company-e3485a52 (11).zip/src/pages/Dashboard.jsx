import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Navigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Building2, Users, Briefcase, TrendingUp, AlertCircle } from "lucide-react";
import PageHeader from "../components/common/PageHeader";
import IMScoreKPIs from "../components/dashboard/IMScoreKPIs";
import SeverityDistribution from "../components/dashboard/SeverityDistribution";
import CriticalFactors from "../components/dashboard/CriticalFactors";
import { getEffectiveContext } from "../components/utils/impersonationContext";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function Dashboard() {
  const [companyId, setCompanyId] = React.useState(null);
  const [user, setUser] = React.useState(null);
  const [context, setContext] = React.useState(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
        
        const effectiveContext = getEffectiveContext(userData);
        setContext(effectiveContext);
        
        console.log('=== Dashboard Page ===');
        console.log('User data:', userData);
        console.log('Effective context:', effectiveContext);
        
        // Usar company_id do contexto efetivo
        if (effectiveContext?.company_id) {
          console.log('Using company_id from context:', effectiveContext.company_id);
          setCompanyId(effectiveContext.company_id);
        } else {
          console.log('No company_id in context');
        }
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  const { data: company } = useQuery({
    queryKey: ['company', companyId],
    queryFn: async () => {
      if (!companyId) return null;
      const companies = await base44.entities.Company.filter({ id: companyId });
      return companies[0] || null;
    },
    enabled: !!companyId,
  });

  const { data: departments = [] } = useQuery({
    queryKey: ['departments', companyId],
    queryFn: async () => {
      if (!companyId) return [];
      return await base44.entities.Department.filter({ company_id: companyId });
    },
    enabled: !!companyId,
    initialData: [],
  });

  const { data: ghes = [] } = useQuery({
    queryKey: ['ghes', companyId],
    queryFn: async () => {
      if (!companyId) return [];
      return await base44.entities.GHE.filter({ empresa_id: companyId });
    },
    enabled: !!companyId,
    initialData: [],
  });

  const { data: employees = [] } = useQuery({
    queryKey: ['employees', companyId],
    queryFn: async () => {
      if (!companyId) return [];
      return await base44.entities.Employee.filter({ company_id: companyId });
    },
    enabled: !!companyId,
    initialData: [],
  });

  const { data: assessments = [] } = useQuery({
    queryKey: ['assessments', companyId],
    queryFn: async () => {
      if (!companyId) return [];
      return await base44.entities.Assessment.filter({ company_id: companyId });
    },
    enabled: !!companyId,
    initialData: [],
  });

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[1,2,3,4].map(i => (
              <div key={i} className="h-32 bg-gray-200 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!user || !context) {
    return <Navigate to="/" />;
  }

  // Verificar permissões
  const canAccess = context.original_role === 'admin' || context.role === 'manager';
  
  if (!canAccess) {
    return <Navigate to="/" />;
  }

  if (!companyId || !company) {
    return (
      <div className="p-8">
        <Alert className="border-yellow-200 bg-yellow-50">
          <AlertCircle className="h-4 w-4 text-yellow-600" />
          <AlertDescription className="text-yellow-800">
            Não há uma empresa selecionada para visualização.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  const activeEmployees = employees.filter(e => e.status === 'active');
  const completedAssessments = assessments.filter(a => a.completed_at);
  const engagementRate = activeEmployees.length > 0 
    ? ((completedAssessments.length / activeEmployees.length) * 100).toFixed(1)
    : 0;

  const breadcrumbs = [
    { label: "iMental" },
    { label: company.name }
  ];

  return (
    <div className="p-4 md:p-8 min-h-screen" style={{ backgroundColor: '#F8F6FB' }}>
      <div className="max-w-[1800px] mx-auto space-y-8">
        <PageHeader
          title="Painel iMental"
          description={`Visão geral de saúde mental e bem-estar de ${company.name}`}
          breadcrumbs={breadcrumbs}
          showBack={false}
        />

        {/* Resumo Executivo - Indicadores Não-Clicáveis */}
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle className="text-lg">Resumo da Organização</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl" style={{ backgroundColor: '#F8F6FB' }}>
                  <Building2 className="w-6 h-6" style={{ color: '#4B2672' }} />
                </div>
                <div>
                  <p className="text-2xl font-bold" style={{ color: '#4B2672' }}>
                    {departments.length}
                  </p>
                  <p className="text-sm text-gray-600">Departamentos</p>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl" style={{ backgroundColor: '#F8F6FB' }}>
                  <Briefcase className="w-6 h-6" style={{ color: '#4B2672' }} />
                </div>
                <div>
                  <p className="text-2xl font-bold" style={{ color: '#4B2672' }}>
                    {ghes.length}
                  </p>
                  <p className="text-sm text-gray-600">GHE</p>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-green-50">
                  <Users className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-green-600">
                    {activeEmployees.length}
                  </p>
                  <p className="text-sm text-gray-600">Colaboradores Ativos</p>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-blue-50">
                  <TrendingUp className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-blue-600">
                    {engagementRate}%
                  </p>
                  <p className="text-sm text-gray-600">Taxa de Engajamento</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Indicadores de Saúde Mental */}
        <IMScoreKPIs 
          assessments={assessments} 
          employees={employees} 
          engagementRate={engagementRate} 
        />

        {/* Gráficos de Análise */}
        <div className="grid grid-cols-1 gap-8">
          <SeverityDistribution assessments={assessments} />
          <CriticalFactors assessments={assessments} />
        </div>
      </div>
    </div>
  );
}