import React, { useState, useEffect } from "react";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Shield, ArrowRight, AlertCircle, Brain } from "lucide-react";
import IMentalLogo from "../components/ui/IMentalLogo";

export default function ResponderPage() {
  const [cpf, setCpf] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [debugInfo, setDebugInfo] = useState(null);
  const [attemptCount, setAttemptCount] = useState(0);
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
    
    try {
      const stored = localStorage.getItem('collab_session');
      if (stored) {
        const session = JSON.parse(stored);
        if (session.exp > Date.now()) {
          window.location.href = createPageUrl("ColaboradorAvaliacoes");
          return;
        } else {
          localStorage.removeItem('collab_session');
        }
      }
    } catch (e) {
      console.error('responder-session-check-error', e);
      localStorage.removeItem('collab_session');
    }
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (attemptCount >= 5) {
      setError('Número máximo de tentativas excedido. Tente novamente em 15 minutos.');
      return;
    }

    setLoading(true);
    setError('');
    setDebugInfo(null);

    try {
      const cleanCpf = cpf.replace(/\D/g, '');
      
      console.log('=== VALIDAÇÃO INÍCIO ===');
      console.log('CPF digitado:', cpf);
      console.log('CPF limpo:', cleanCpf);
      console.log('Data digitada:', birthDate);
      
      if (cleanCpf.length !== 11) {
        setError('CPF inválido. Digite os 11 dígitos.');
        setLoading(false);
        return;
      }

      if (!birthDate) {
        setError('Data de nascimento é obrigatória.');
        setLoading(false);
        return;
      }

      // Buscar TODOS os colaboradores (sem filtro de status primeiro)
      const allEmployees = await base44.entities.Employee.list();
      
      console.log(`Total de colaboradores no banco: ${allEmployees.length}`);
      
      // Ver um exemplo dos dados no banco
      if (allEmployees.length > 0) {
        console.log('Exemplo de colaborador no banco:', {
          name: allEmployees[0].name,
          cpf: allEmployees[0].cpf,
          cpf_length: allEmployees[0].cpf?.length,
          birth_date: allEmployees[0].birth_date,
          birth_date_type: typeof allEmployees[0].birth_date
        });
      }
      
      // Buscar colaborador que corresponda
      const matchingEmployees = [];
      const debugMatches = [];
      
      for (const emp of allEmployees) {
        // Limpar CPF do banco
        const empCpfClean = (emp.cpf || '').replace(/\D/g, '');
        const cpfMatch = empCpfClean === cleanCpf;
        
        // Normalizar data - tentar múltiplos formatos
        let empDate = emp.birth_date;
        if (empDate) {
          // Se tem barras, converter DD/MM/YYYY para YYYY-MM-DD
          if (empDate.includes('/')) {
            const parts = empDate.split('/');
            empDate = `${parts[2]}-${parts[1]}-${parts[0]}`;
          }
          // Se tem traços mas está em formato brasileiro (DD-MM-YYYY)
          else if (empDate.match(/^\d{2}-\d{2}-\d{4}$/)) {
            const parts = empDate.split('-');
            empDate = `${parts[2]}-${parts[1]}-${parts[0]}`;
          }
        }
        
        const dateMatch = empDate === birthDate;
        
        debugMatches.push({
          name: emp.name,
          cpf_banco: emp.cpf,
          cpf_limpo: empCpfClean,
          cpf_match: cpfMatch,
          data_banco: emp.birth_date,
          data_normalizada: empDate,
          data_digitada: birthDate,
          date_match: dateMatch,
          status: emp.status
        });
        
        if (cpfMatch && dateMatch) {
          matchingEmployees.push(emp);
        }
      }
      
      console.log('=== RESULTADO DA BUSCA ===');
      console.log('Colaboradores encontrados:', matchingEmployees.length);
      console.log('Debug de todas as tentativas:', debugMatches);
      
      // Mostrar debug info na tela
      setDebugInfo({
        total: allEmployees.length,
        found: matchingEmployees.length,
        matches: debugMatches.filter(m => m.cpf_match || m.date_match)
      });
      
      if (matchingEmployees.length === 0) {
        setAttemptCount(prev => prev + 1);
        setError('Dados não conferem. Verifique seu CPF e data de nascimento ou fale com o RH.');
        setLoading(false);
        return;
      }

      const employee = matchingEmployees[0];
      console.log('✅ Colaborador validado:', employee.name);

      const sessionData = {
        employee_id: employee.id,
        company_id: employee.company_id,
        employee_name: employee.name,
        exp: Date.now() + (60 * 60 * 1000),
        created_at: Date.now()
      };
      
      localStorage.setItem('collab_session', JSON.stringify(sessionData));
      window.location.href = createPageUrl("ColaboradorAvaliacoes");
      
    } catch (err) {
      console.error('ERRO:', err);
      setAttemptCount(prev => prev + 1);
      setError('Não foi possível validar seus dados. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  if (!isMounted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-50 to-gray-100">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-purple-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-50 to-gray-100 p-4">
      <Card className="max-w-md w-full shadow-xl">
        <CardHeader className="text-center">
          <div className="mb-6">
            <IMentalLogo variant="dark" size="default" className="mx-auto" />
          </div>
          <CardTitle className="text-2xl font-bold" style={{ color: '#2E2E2E' }}>
            Identificação do Colaborador
          </CardTitle>
          <p className="text-gray-600 text-sm mt-2">
            Acesse suas avaliações de forma rápida e segura
          </p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <Alert className="bg-red-50 border-red-200">
                <AlertCircle className="w-4 h-4 text-red-600" />
                <AlertDescription className="text-red-800">
                  {error}
                </AlertDescription>
              </Alert>
            )}

            {debugInfo && (
              <Alert className="bg-blue-50 border-blue-200">
                <AlertDescription className="text-blue-800 text-xs">
                  <p><strong>Debug:</strong></p>
                  <p>Total colaboradores: {debugInfo.total}</p>
                  <p>Encontrados: {debugInfo.found}</p>
                  {debugInfo.matches.length > 0 && (
                    <div className="mt-2 max-h-32 overflow-y-auto">
                      {debugInfo.matches.map((m, i) => (
                        <div key={i} className="text-xs border-t pt-1 mt-1">
                          <p><strong>{m.name}</strong></p>
                          <p>CPF: {m.cpf_match ? '✅' : '❌'} {m.cpf_banco}</p>
                          <p>Data: {m.date_match ? '✅' : '❌'} {m.data_banco}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </AlertDescription>
              </Alert>
            )}

            <div>
              <Label htmlFor="cpf" className="text-base font-medium">CPF *</Label>
              <Input
                id="cpf"
                value={cpf}
                onChange={(e) => {
                  const value = e.target.value.replace(/\D/g, '');
                  const formatted = value
                    .replace(/(\d{3})(\d)/, '$1.$2')
                    .replace(/(\d{3})(\d)/, '$1.$2')
                    .replace(/(\d{3})(\d{1,2})$/, '$1-$2');
                  setCpf(formatted);
                  setError('');
                  setDebugInfo(null);
                }}
                placeholder="000.000.000-00"
                maxLength={14}
                className="text-lg h-12 mt-2"
                required
                autoComplete="off"
              />
            </div>

            <div>
              <Label htmlFor="birthDate" className="text-base font-medium">Data de Nascimento *</Label>
              <Input
                id="birthDate"
                type="date"
                value={birthDate}
                onChange={(e) => {
                  setBirthDate(e.target.value);
                  setError('');
                  setDebugInfo(null);
                }}
                className="text-lg h-12 mt-2"
                required
              />
            </div>

            <Button
              type="submit"
              disabled={!cpf || !birthDate || loading}
              className="w-full h-12 text-base font-semibold text-white"
              style={{ backgroundColor: '#5E2C91' }}
            >
              {loading ? (
                <>
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Verificando...
                </>
              ) : (
                <>
                  Acessar Avaliações
                  <ArrowRight className="w-5 h-5 ml-2" />
                </>
              )}
            </Button>

            {attemptCount > 0 && attemptCount < 5 && (
              <p className="text-sm text-gray-500 text-center">
                Tentativas restantes: {5 - attemptCount}
              </p>
            )}
          </form>

          <div className="mt-6 pt-6 border-t border-gray-200">
            <p className="text-xs text-gray-500 text-center leading-relaxed">
              🔒 Seus dados são confidenciais e usados apenas para esta avaliação. 
              Suas respostas são protegidas pela LGPD.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

ResponderPage.isPublic = true;