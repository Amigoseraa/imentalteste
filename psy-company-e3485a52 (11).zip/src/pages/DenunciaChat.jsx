import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  ArrowLeft,
  Send,
  Paperclip,
  Clock,
  User,
  Building2,
  CheckCircle,
  MessageCircle,
  Shield,
  Star,
  AlertCircle
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function DenunciaChat() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const messagesEndRef = useRef(null);
  
  const [user, setUser] = useState(null);
  const [employee, setEmployee] = useState(null);
  const [loading, setLoading] = useState(true);
  const [novaMensagem, setNovaMensagem] = useState("");
  const [uploadingFile, setUploadingFile] = useState(false);
  const [showAvaliacaoDialog, setShowAvaliacaoDialog] = useState(false);
  
  const [avaliacao, setAvaliacao] = useState({
    tempo_resposta: 0,
    clareza_comunicacao: 0,
    sensacao_seguranca: 0,
    comentario: ""
  });

  // Get denuncia ID from URL
  const urlParams = new URLSearchParams(window.location.search);
  const denunciaId = urlParams.get('id');

  useEffect(() => {
    const loadUserData = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);

        if (userData.employee_id) {
          const empData = await base44.entities.Employee.filter({ 
            id: userData.employee_id 
          });
          if (empData.length > 0) {
            setEmployee(empData[0]);
          }
        }
      } catch (error) {
        console.error("Error loading user data:", error);
      } finally {
        setLoading(false);
      }
    };
    loadUserData();
  }, []);

  // Buscar denúncia
  const { data: denuncia } = useQuery({
    queryKey: ['denuncia', denunciaId],
    queryFn: async () => {
      const denuncias = await base44.entities.Denuncia.filter({ id: denunciaId });
      if (denuncias.length === 0) throw new Error("Denúncia não encontrada");
      return denuncias[0];
    },
    enabled: !!denunciaId && !loading,
  });

  // Buscar mensagens
  const { data: mensagens = [] } = useQuery({
    queryKey: ['mensagens-denuncia', denunciaId],
    queryFn: () => base44.entities.MensagemDenuncia.filter({ denuncia_id: denunciaId }),
    enabled: !!denunciaId && !loading,
    initialData: [],
    refetchInterval: 5000, // Atualizar a cada 5 segundos
  });

  // Marcar mensagens como lidas
  useEffect(() => {
    if (mensagens.length > 0 && denuncia) {
      const mensagensNaoLidas = mensagens.filter(m => 
        m.autor_tipo === 'empresa' && !m.lida
      );
      
      if (mensagensNaoLidas.length > 0) {
        mensagensNaoLidas.forEach(async (msg) => {
          try {
            await base44.entities.MensagemDenuncia.update(msg.id, {
              lida: true,
              lida_em: new Date().toISOString()
            });
          } catch (error) {
            console.error("Error marking message as read:", error);
          }
        });

        // Atualizar contador na denúncia
        base44.entities.Denuncia.update(denunciaId, {
          mensagens_nao_lidas_colaborador: 0
        }).catch(console.error);
        
        queryClient.invalidateQueries({ queryKey: ['minhas-denuncias'] });
      }
    }
  }, [mensagens, denuncia, denunciaId, queryClient]);

  // Scroll para última mensagem
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [mensagens]);

  // Enviar mensagem
  const enviarMensagemMutation = useMutation({
    mutationFn: async () => {
      if (!novaMensagem.trim()) throw new Error("Digite uma mensagem");
      
      await base44.entities.MensagemDenuncia.create({
        denuncia_id: denunciaId,
        autor_tipo: 'colaborador',
        autor_id: denuncia?.anonimo ? 'anonimo' : employee?.id,
        autor_nome: denuncia?.anonimo ? 'Anônimo' : employee?.name,
        mensagem: novaMensagem,
        anexos: []
      });

      await base44.entities.Denuncia.update(denunciaId, {
        status: 'em_resposta',
        ultima_mensagem_em: new Date().toISOString(),
        mensagens_nao_lidas_empresa: (denuncia?.mensagens_nao_lidas_empresa || 0) + 1
      });
    },
    onSuccess: () => {
      setNovaMensagem("");
      queryClient.invalidateQueries({ queryKey: ['mensagens-denuncia', denunciaId] });
      queryClient.invalidateQueries({ queryKey: ['denuncia', denunciaId] });
      toast.success("Mensagem enviada");
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao enviar mensagem");
    }
  });

  // Avaliar denúncia finalizada
  const avaliarMutation = useMutation({
    mutationFn: async () => {
      if (avaliacao.tempo_resposta === 0 || avaliacao.clareza_comunicacao === 0 || avaliacao.sensacao_seguranca === 0) {
        throw new Error("Avalie todos os critérios");
      }

      await base44.entities.Denuncia.update(denunciaId, {
        avaliacao_colaborador: avaliacao
      });
    },
    onSuccess: () => {
      toast.success("Avaliação enviada! Obrigado pelo feedback.");
      setShowAvaliacaoDialog(false);
      queryClient.invalidateQueries({ queryKey: ['denuncia', denunciaId] });
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao enviar avaliação");
    }
  });

  const getCategoriaLabel = (cat) => {
    const labels = {
      assedio_moral: "Assédio Moral",
      assedio_sexual: "Assédio Sexual",
      discriminacao: "Discriminação",
      conduta_indevida: "Conduta Indevida",
      outros: "Outros"
    };
    return labels[cat] || cat;
  };

  const getStatusBadge = (status) => {
    const badges = {
      aberto: <Badge className="bg-yellow-100 text-yellow-800"><Clock className="w-3 h-3 mr-1" />Aberto</Badge>,
      em_resposta: <Badge className="bg-blue-100 text-blue-800"><MessageCircle className="w-3 h-3 mr-1" />Em Resposta</Badge>,
      finalizado: <Badge className="bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" />Finalizado</Badge>
    };
    return badges[status] || status;
  };

  const StarRating = ({ value, onChange }) => {
    return (
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => onChange(star)}
            className="focus:outline-none transition-all duration-200"
          >
            <Star
              className={`w-6 h-6 ${star <= value ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`}
            />
          </button>
        ))}
      </div>
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#F8F6FB' }}>
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 mx-auto mb-4" style={{ borderColor: '#4B2672' }}></div>
          <p className="text-sm text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  if (!denuncia) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6" style={{ backgroundColor: '#F8F6FB' }}>
        <Card>
          <CardContent className="pt-6 text-center">
            <AlertCircle className="w-16 h-16 mx-auto mb-4 text-gray-400" />
            <h2 className="text-xl font-semibold mb-2">Denúncia não encontrada</h2>
            <Button onClick={() => navigate(createPageUrl('CanalDenunciasColaborador'))} variant="outline">
              Voltar
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: '#F8F6FB' }}>
      {/* Header */}
      <div className="border-b bg-white shadow-sm">
        <div className="max-w-6xl mx-auto p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigate(createPageUrl('CanalDenunciasColaborador'))}
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div>
                <div className="flex items-center gap-3 mb-1">
                  <span className="text-sm font-mono font-semibold" style={{ color: '#4B2672' }}>
                    {denuncia.protocolo}
                  </span>
                  {getStatusBadge(denuncia.status)}
                  <Badge variant="outline">
                    {getCategoriaLabel(denuncia.categoria)}
                  </Badge>
                </div>
                <p className="text-sm text-gray-600">
                  Aberta em {format(new Date(denuncia.created_date), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                </p>
              </div>
            </div>
            
            {denuncia.status === 'finalizado' && !denuncia.avaliacao_colaborador && (
              <Button
                onClick={() => setShowAvaliacaoDialog(true)}
                variant="outline"
                style={{ borderColor: '#4CAF50', color: '#4CAF50' }}
              >
                <Star className="w-4 h-4 mr-2" />
                Avaliar Atendimento
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-4xl mx-auto space-y-4">
          {mensagens.map((msg) => {
            const isColaborador = msg.autor_tipo === 'colaborador';
            
            return (
              <div
                key={msg.id}
                className={`flex ${isColaborador ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-[70%] ${isColaborador ? 'order-2' : 'order-1'}`}>
                  <div className="flex items-center gap-2 mb-1">
                    {!isColaborador && <Building2 className="w-4 h-4 text-gray-500" />}
                    {isColaborador && denuncia.anonimo && <Shield className="w-4 h-4 text-gray-500" />}
                    <span className="text-xs font-medium text-gray-600">
                      {isColaborador 
                        ? (denuncia.anonimo ? 'Você (Anônimo)' : msg.autor_nome)
                        : (msg.autor_nome || 'Empresa')
                      }
                    </span>
                    <span className="text-xs text-gray-400">
                      {format(new Date(msg.created_date), "HH:mm", { locale: ptBR })}
                    </span>
                  </div>
                  <div
                    className={`rounded-2xl px-4 py-3 ${
                      isColaborador
                        ? 'text-white'
                        : 'bg-white border border-gray-200'
                    }`}
                    style={isColaborador ? { backgroundColor: '#4B2672' } : {}}
                  >
                    <p className="text-sm whitespace-pre-wrap">{msg.mensagem}</p>
                    {msg.anexos?.length > 0 && (
                      <div className="mt-2 space-y-1">
                        {msg.anexos.map((anexo, idx) => (
                          <a
                            key={idx}
                            href={anexo.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-2 text-xs underline"
                          >
                            <Paperclip className="w-3 h-3" />
                            {anexo.nome}
                          </a>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input */}
      {denuncia.status !== 'finalizado' && (
        <div className="border-t bg-white p-4">
          <div className="max-w-4xl mx-auto">
            <div className="flex gap-3">
              <Textarea
                value={novaMensagem}
                onChange={(e) => setNovaMensagem(e.target.value)}
                placeholder="Digite sua mensagem..."
                className="resize-none"
                rows={2}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    enviarMensagemMutation.mutate();
                  }
                }}
              />
              <Button
                onClick={() => enviarMensagemMutation.mutate()}
                disabled={!novaMensagem.trim() || enviarMensagemMutation.isPending}
                style={{ backgroundColor: '#4CAF50' }}
                className="self-end"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-xs text-gray-500 mt-2">
              Pressione Enter para enviar, Shift+Enter para nova linha
            </p>
          </div>
        </div>
      )}

      {denuncia.status === 'finalizado' && (
        <div className="border-t bg-gray-50 p-4">
          <div className="max-w-4xl mx-auto text-center">
            <Alert className="border-green-200 bg-green-50">
              <CheckCircle className="w-4 h-4 text-green-600" />
              <AlertDescription className="text-green-800">
                Esta denúncia foi finalizada.
                {!denuncia.avaliacao_colaborador && " Você pode avaliar o atendimento recebido."}
              </AlertDescription>
            </Alert>
          </div>
        </div>
      )}

      {/* Dialog Avaliação */}
      <Dialog open={showAvaliacaoDialog} onOpenChange={setShowAvaliacaoDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Avaliar Atendimento</DialogTitle>
            <DialogDescription>
              Sua avaliação nos ajuda a melhorar nosso canal de denúncias
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4">
            <div>
              <Label className="mb-2 block">Tempo de Resposta</Label>
              <StarRating
                value={avaliacao.tempo_resposta}
                onChange={(v) => setAvaliacao({ ...avaliacao, tempo_resposta: v })}
              />
            </div>

            <div>
              <Label className="mb-2 block">Clareza da Comunicação</Label>
              <StarRating
                value={avaliacao.clareza_comunicacao}
                onChange={(v) => setAvaliacao({ ...avaliacao, clareza_comunicacao: v })}
              />
            </div>

            <div>
              <Label className="mb-2 block">Sensação de Segurança</Label>
              <StarRating
                value={avaliacao.sensacao_seguranca}
                onChange={(v) => setAvaliacao({ ...avaliacao, sensacao_seguranca: v })}
              />
            </div>

            <div>
              <Label>Comentário (opcional)</Label>
              <Textarea
                value={avaliacao.comentario}
                onChange={(e) => setAvaliacao({ ...avaliacao, comentario: e.target.value })}
                placeholder="Conte-nos sobre sua experiência..."
                rows={4}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAvaliacaoDialog(false)}>
              Cancelar
            </Button>
            <Button
              onClick={() => avaliarMutation.mutate()}
              disabled={avaliarMutation.isPending}
              style={{ backgroundColor: '#4CAF50' }}
            >
              Enviar Avaliação
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}