
import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { AlertCircle, CheckCircle, Shield, Clock, ArrowRight, ArrowLeft, Volume2 } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import ConsentTerm from "../components/respond/ConsentTerm";
import QuestionScreen from "../components/respond/QuestionScreen";
import CompletionScreen from "../components/respond/CompletionScreen";

const QUESTIONS = {
  'PHQ-9': [
    { id: 'q1', text: 'Pouco interesse ou prazer em fazer as coisas', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]},
    { id: 'q2', text: 'Sentir-se para baixo, deprimido ou sem esperança', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]},
    { id: 'q3', text: 'Problemas para adormecer, manter o sono ou dormir demais', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]},
    { id: 'q4', text: 'Sentir-se cansado ou com pouca energia', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]},
    { id: 'q5', text: 'Falta de apetite ou comer em excesso', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]},
    { id: 'q6', text: 'Sentir-se mal consigo mesmo, sentir-se fracassado ou ter decepcionado sua família', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]},
    { id: 'q7', text: 'Dificuldade de concentração em tarefas cotidianas, como ler ou assistir TV', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]},
    { id: 'q8', text: 'Mover-se ou falar tão devagar que outras pessoas percebem, ou estar tão agitado que não consegue ficar parado', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]},
    { id: 'q9', text: 'Pensamentos de que seria melhor estar morto ou de se machucar', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]}
  ],
  'GAD-7': [
    { id: 'q1', text: 'Sentir-se nervoso, ansioso ou tenso', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]},
    { id: 'q2', text: 'Não conseguir parar de se preocupar', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]},
    { id: 'q3', text: 'Preocupar-se demais com diferentes coisas', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]},
    { id: 'q4', text: 'Dificuldade para relaxar', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]},
    { id: 'q5', text: 'Ficar tão inquieto que é difícil permanecer parado', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]},
    { id: 'q6', text: 'Irritar-se ou perder a paciência facilmente', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]},
    { id: 'q7', text: 'Sentir medo como se algo terrível pudesse acontecer', scale: [
      { value: 0, label: 'Nenhuma vez' },
      { value: 1, label: 'Vários dias' },
      { value: 2, label: 'Mais da metade dos dias' },
      { value: 3, label: 'Quase todos os dias' }
    ]}
  ],
  'PRIMA-EF': [
    { id: 'q1', text: 'As tarefas que realizo são variadas e evitam a monotonia', category: 'A. Teor do Trabalho', scale: [
      { value: 1, label: 'Discordo totalmente' },
      { value: 2, label: 'Discordo' },
      { value: 3, label: 'Neutro' },
      { value: 4, label: 'Concordo' },
      { value: 5, label: 'Concordo totalmente' }
    ]},
    { id: 'q2', text: 'Meu trabalho é significativo e utiliza minhas habilidades', category: 'A. Teor do Trabalho', scale: [
      { value: 1, label: 'Discordo totalmente' },
      { value: 2, label: 'Discordo' },
      { value: 3, label: 'Neutro' },
      { value: 4, label: 'Concordo' },
      { value: 5, label: 'Concordo totalmente' }
    ]},
    { id: 'q3', text: 'O ambiente de trabalho me protege de exposição contínua a situações estressantes', category: 'A. Teor do Trabalho', scale: [
      { value: 1, label: 'Discordo totalmente' },
      { value: 2, label: 'Discordo' },
      { value: 3, label: 'Neutro' },
      { value: 4, label: 'Concordo' },
      { value: 5, label: 'Concordo totalmente' }
    ]},
    { id: 'q4', text: 'Tenho autonomia para decidir como realizar minhas tarefas', category: 'B. Autonomia e Controle', scale: [
      { value: 1, label: 'Discordo totalmente' },
      { value: 2, label: 'Discordo' },
      { value: 3, label: 'Neutro' },
      { value: 4, label: 'Concordo' },
      { value: 5, label: 'Concordo totalmente' }
    ]},
    { id: 'q5', text: 'Posso influenciar as decisões que afetam meu trabalho', category: 'B. Autonomia e Controle', scale: [
      { value: 1, label: 'Discordo totalmente' },
      { value: 2, label: 'Discordo' },
      { value: 3, label: 'Neutro' },
      { value: 4, label: 'Concordo' },
      { value: 5, label: 'Concordo totalmente' }
    ]},
    { id: 'q6', text: 'Recebo feedback claro e construtivo sobre meu desempenho', category: 'C. Recompensas e Reconhecimento', scale: [
      { value: 1, label: 'Discordo totalmente' },
      { value: 2, label: 'Discordo' },
      { value: 3, label: 'Neutro' },
      { value: 4, label: 'Concordo' },
      { value: 5, label: 'Concordo totalmente' }
    ]},
    { id: 'q7', text: 'Sinto que meu esforço é reconhecido e valorizado', category: 'C. Recompensas e Reconhecimento', scale: [
      { value: 1, label: 'Discordo totalmente' },
      { value: 2, label: 'Discordo' },
      { value: 3, label: 'Neutro' },
      { value: 4, label: 'Concordo' },
      { value: 5, label: 'Concordo totalmente' }
    ]},
    { id: 'q8', text: 'Tenho oportunidades de crescimento e desenvolvimento profissional', category: 'D. Oportunidades de Desenvolvimento', scale: [
      { value: 1, label: 'Discordo totalmente' },
      { value: 2, label: 'Discordo' },
      { value: 3, label: 'Neutro' },
      { value: 4, label: 'Concordo' },
      { value: 5, label: 'Concordo totalmente' }
    ]},
    { id: 'q9', text: 'A empresa investe no meu aprendizado e capacitação', category: 'D. Oportunidades de Desenvolvimento', scale: [
      { value: 1, label: 'Discordo totalmente' },
      { value: 2, label: 'Discordo' },
      { value: 3, label: 'Neutro' },
      { value: 4, label: 'Concordo' },
      { value: 5, label: 'Concordo totalmente' }
    ]},
    { id: 'q10', text: 'Recebo apoio suficiente dos meus colegas de trabalho', category: 'E. Apoio Social', scale: [
      { value: 1, label: 'Discordo totalmente' },
      { value: 2, label: 'Discordo' },
      { value: 3, label: 'Neutro' },
      { value: 4, label: 'Concordo' },
      { value: 5, label: 'Concordo totalmente' }
    ]},
    { id: 'q11', text: 'Meu supervisor direto me oferece suporte quando preciso', category: 'E. Apoio Social', scale: [
      { value: 1, label: 'Discordo totalmente' },
      { value: 2, label: 'Discordo' },
      { value: 3, label: 'Neutro' },
      { value: 4, label: 'Concordo' },
      { value: 5, label: 'Concordo totalmente' }
    ]},
    { id: 'q12', text: 'As exigências do meu trabalho são razoáveis e gerenciáveis', category: 'F. Exigências do Trabalho', scale: [
      { value: 1, label: 'Discordo totalmente' },
      { value: 2, label: 'Discordo' },
      { value: 3, label: 'Neutro' },
      { value: 4, label: 'Concordo' },
      { value: 5, label: 'Concordo totalmente' }
    ]},
    { id: 'q13', text: 'Tenho tempo suficiente para concluir minhas tarefas sem estresse excessivo', category: 'F. Exigências do Trabalho', scale: [
      { value: 1, label: 'Discordo totalmente' },
      { value: 2, label: 'Discordo' },
      { value: 3, label: 'Neutro' },
      { value: 4, label: 'Concordo' },
      { value: 5, label: 'Concordo totalmente' }
    ]},
    { id: 'q14', text: 'Sinto que meu trabalho está sobrecarregado', category: 'F. Exigências do Trabalho', scale: [
      { value: 1, label: 'Discordo totalmente' },
      { value: 2, label: 'Discordo' },
      { value: 3, label: 'Neutro' },
      { value: 4, label: 'Concordo' },
      { value: 5, label: 'Concordo totalmente' }
    ]},
    { id: 'q15', text: 'As políticas da empresa promovem um equilíbrio saudável entre vida profissional e pessoal', category: 'G. Equilíbrio Vida-Trabalho', scale: [
      { value: 1, label: 'Discordo totalmente' },
      { value: 2, label: 'Discordo' },
      { value: 3, label: 'Neutro' },
      { value: 4, label: 'Concordo' },
      { value: 5, label: 'Concordo totalmente' }
    ]},
    { id: 'q16', text: 'Tenho flexibilidade para gerenciar meu tempo de trabalho', category: 'G. Equilíbrio Vida-Trabalho', scale: [
      { value: 1, label: 'Discordo totalmente' },
      { value: 2, label: 'Discordo' },
      { value: 3, label: 'Neutro' },
      { value: 4, label: 'Concordo' },
      { value: 5, label: 'Concordo totalmente' }
    ]},
    { id: 'q17', text: 'Os valores da empresa estão alinhados com os meus valores pessoais', category: 'H. Valores Organizacionais', scale: [
      { value: 1, label: 'Discordo totalmente' },
      { value: 2, label: 'Discordo' },
      { value: 3, label: 'Neutro' },
      { value: 4, label: 'Concordo' },
      { value: 5, label: 'Concordo totalmente' }
    ]},
    { id: 'q18', text: 'A comunicação interna na empresa é clara e eficiente', category: 'I. Comunicação', scale: [
      { value: 1, label: 'Discordo totalmente' },
      { value: 2, label: 'Discordo' },
      { value: 3, label: 'Neutro' },
      { value: 4, label: 'Concordo' },
      { value: 5, label: 'Concordo totalmente' }
    ]},
    { id: 'q19', text: 'Sinto que sou tratado com respeito e dignidade por todos na empresa', category: 'P. Respeito e Dignidade', scale: [
      { value: 1, label: 'Discordo totalmente' },
      { value: 2, label: 'Discordo' },
      { value: 3, label: 'Neutro' },
      { value: 4, label: 'Concordo' },
      { value: 5, label: 'Concordo totalmente' }
    ]},
    { id: 'q20', text: 'A empresa promove a diversidade e inclusão', category: 'Q. Diversidade e Inclusão', scale: [
      { value: 1, label: 'Discordo totalmente' },
      { value: 2, label: 'Discordo' },
      { value: 3, label: 'Neutro' },
      { value: 4, label: 'Concordo' },
      { value: 5, label: 'Concordo totalmente' }
    ]},
    { id: 'q21', text: 'Há um esforço visível da gestão para melhorar o bem-estar dos funcionários', category: 'R. Compromisso da Gestão', scale: [
      { value: 1, label: 'Discordo totalmente' },
      { value: 2, label: 'Discordo' },
      { value: 3, label: 'Neutro' },
      { value: 4, label: 'Concordo' },
      { value: 5, label: 'Concordo totalmente' }
    ]},
    { id: 'q22', text: 'Minhas tarefas são bem definidas e claras', category: 'S. Clareza de Papel', scale: [
      { value: 1, label: 'Discordo totalmente' },
      { value: 2, label: 'Discordo' },
      { value: 3, label: 'Neutro' },
      { value: 4, label: 'Concordo' },
      { value: 5, label: 'Concordo totalmente' }
    ]},
    { id: 'q23', text: 'Não há conflito de papéis ou expectativas no meu trabalho', category: 'S. Clareza de Papel', scale: [
      { value: 1, label: 'Discordo totalmente' },
      { value: 2, label: 'Discordo' },
      { value: 3, label: 'Neutro' },
      { value: 4, label: 'Concordo' },
      { value: 5, label: 'Concordo totalmente' }
    ]},
    { id: 'q24', text: 'Sinto que posso expressar minhas preocupações sem medo de retaliação', category: 'T. Voz do Funcionário', scale: [
      { value: 1, label: 'Discordo totalmente' },
      { value: 2, label: 'Discordo' },
      { value: 3, label: 'Neutro' },
      { value: 4, label: 'Concordo' },
      { value: 5, label: 'Concordo totalmente' }
    ]}
  ]
};

export default function RespondPage() {
  const { token } = useParams();
  const [step, setStep] = useState('loading'); // loading, auth, consent, questions, complete, error, already_completed
  const [assessment, setAssessment] = useState(null);
  const [employee, setEmployee] = useState(null);
  const [company, setCompany] = useState(null);
  const [cpf, setCpf] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [responses, setResponses] = useState({});
  const [questionnaires, setQuestionnaires] = useState([]);
  const [currentQuestionnaire, setCurrentQuestionnaire] = useState(0);
  const [attemptCount, setAttemptCount] = useState(0);

  useEffect(() => {
    if (token) {
      loadAssessment();
    } else {
      setError('Link inválido. Token não encontrado.');
      setStep('error');
    }
  }, [token]);

  const loadAssessment = async () => {
    setStep('loading');
    setLoading(true);
    setError('');
    
    try {
      const assessments = await base44.entities.Assessment.filter({ 
        assessment_token: token 
      });
      
      if (assessments.length === 0) {
        setError('Link inválido ou expirado. Solicite um novo convite ao RH.');
        setStep('error');
        return;
      }

      const ass = assessments[0];
      setAssessment(ass);

      if (ass.completed_at) {
        setStep('already_completed');
        return;
      }
      
      const types = ass.assessment_type.split(',');
      setQuestionnaires(types);

      const empData = await base44.entities.Employee.filter({ id: ass.employee_id });
      if (empData.length > 0) {
        setEmployee(empData[0]);
      }

      const compData = await base44.entities.Company.filter({ id: ass.company_id });
      if (compData.length > 0) {
        setCompany(compData[0]);
      }

      // If term was already accepted and we have employee data, skip to questions
      if (ass.term_accepted && empData.length > 0) {
        setStep('questions');
      } else {
        // Otherwise, go to authentication
        setStep('auth');
      }

    } catch (err) {
      console.error(err);
      setError('Erro ao carregar avaliação. Tente novamente mais tarde.');
      setStep('error');
    } finally {
      setLoading(false);
    }
  };

  const handleAuth = async () => {
    if (attemptCount >= 5) {
      setError('Número máximo de tentativas excedido. Tente novamente em 15 minutos.');
      return;
    }

    setLoading(true);
    setError('');
    
    try {
      const cleanCpf = cpf.replace(/\D/g, '');
      
      if (employee && employee.cpf && employee.birth_date) {
        const employeeCpf = employee.cpf.replace(/\D/g, '');
        
        if (cleanCpf === employeeCpf && birthDate === employee.birth_date) {
          // Successfully authenticated, now proceed to consent
          setStep('consent');
        } else {
          setAttemptCount(prev => prev + 1);
          setError('Dados incorretos. Verifique seu CPF e data de nascimento.');
        }
      } else {
        setError('Não foi possível validar suas credenciais. Entre em contato com o RH.');
      }
    } catch (err) {
      console.error(err);
      setError('Erro ao autenticar');
    } finally {
      setLoading(false);
    }
  };

  const handleConsentAccept = async () => {
    try {
      setLoading(true);
      // Mark term as accepted in the database
      const updatedAssessment = await base44.entities.Assessment.update(assessment.id, {
        term_accepted: true,
        term_accepted_at: new Date().toISOString()
      });
      setAssessment(prev => ({ ...prev, ...updatedAssessment })); // Update local state with the returned updated object
      setStep('questions');
    } catch (err) {
      console.error('Erro ao registrar aceite do termo:', err);
      setError('Erro ao registrar aceite. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const handleAnswerQuestion = (answer) => {
    const questionnaireType = questionnaires[currentQuestionnaire];
    const questionId = QUESTIONS[questionnaireType][currentQuestionIndex].id;
    
    setResponses({
      ...responses,
      [`${questionnaireType}_${questionId}`]: answer
    });

    const totalQuestionsInCurrent = QUESTIONS[questionnaireType].length;
    
    if (currentQuestionIndex < totalQuestionsInCurrent - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      if (currentQuestionnaire < questionnaires.length - 1) {
        setCurrentQuestionnaire(prev => prev + 1);
        setCurrentQuestionIndex(0);
      } else {
        handleSubmit();
      }
    }
  };

  const handlePreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    } else if (currentQuestionnaire > 0) {
      setCurrentQuestionnaire(prev => prev - 1);
      const prevQuestionnaireType = questionnaires[currentQuestionnaire - 1];
      setCurrentQuestionIndex(QUESTIONS[prevQuestionnaireType].length - 1);
    }
  };

  const handleSubmit = async () => {
    setLoading(true);
    try {
      const updateData = {
        completed_at: new Date().toISOString(),
      };

      questionnaires.forEach(type => {
        const questionnaireResponses = {};
        Object.keys(responses).forEach(key => {
          if (key.startsWith(`${type}_`)) {
            const qId = key.replace(`${type}_`, '');
            questionnaireResponses[qId] = responses[key];
          }
        });

        if (type === 'PHQ-9') {
          updateData.phq9_responses = questionnaireResponses;
          const score = Object.values(questionnaireResponses).reduce((a, b) => a + b, 0);
          updateData.phq9_score = score;
          updateData.phq9_classification = 
            score <= 4 ? 'Mínimo' :
            score <= 9 ? 'Leve' :
            score <= 14 ? 'Moderado' :
            score <= 19 ? 'Moderado-Grave' : 'Grave';
        } else if (type === 'GAD-7') {
          updateData.gad7_responses = questionnaireResponses;
          const score = Object.values(questionnaireResponses).reduce((a, b) => a + b, 0);
          updateData.gad7_score = score;
          updateData.gad7_classification = 
            score <= 4 ? 'Mínimo' :
            score <= 9 ? 'Leve' :
            score <= 14 ? 'Moderado' : 'Grave';
        } else if (type === 'PRIMA-EF') {
          updateData.prima_responses = questionnaireResponses;
          const values = Object.values(questionnaireResponses);
          const avg = values.reduce((a, b) => a + b, 0) / values.length;
          updateData.prima_score = avg;
          // Invert classification for PRIMA-EF as higher score means lower risk/better well-being
          updateData.prima_classification = 
            avg >= 3.5 ? 'Alto' : // Higher average score indicates higher well-being
            avg >= 2.5 ? 'Moderado' : 'Baixo'; // Lower average score indicates lower well-being
        }
      });

      await base44.entities.Assessment.update(assessment.id, updateData);

      // --- Email sending logic ---
      // Assuming base44 has an actions module with a sendEmail function for notifications
      if (employee && employee.email && company && company.name) {
        try {
          // This call assumes `base44.actions.sendEmail` exists and is configured on the backend
          await base44.actions.sendEmail({
            to: employee.email,
            template: 'assessment_completion_notification', // A predefined template name in the backend
            data: {
              employeeName: employee.name,
              companyName: company.name,
              assessmentType: assessment.assessment_type.split(',').join(' e '), // Format types for email subject/body
              completionDate: new Date().toLocaleDateString('pt-BR'),
              completionTime: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
            }
          });
        } catch (emailError) {
          console.warn('Falha ao enviar e-mail de conclusão:', emailError);
          // Log the error but don't prevent the user from seeing the completion screen
        }
      }
      // --- End Email sending logic ---

      setStep('complete');
    } catch (err) {
      console.error(err);
      setError('Erro ao enviar respostas');
    } finally {
      setLoading(false);
    }
  };

  const getTotalQuestions = () => {
    return questionnaires.reduce((total, type) => {
      return total + (QUESTIONS[type]?.length || 0);
    }, 0);
  };

  const getCurrentQuestionNumber = () => {
    let count = 0;
    for (let i = 0; i < currentQuestionnaire; i++) {
      count += QUESTIONS[questionnaires[i]].length;
    }
    return count + currentQuestionIndex + 1;
  };

  const getProgress = () => {
    return (getCurrentQuestionNumber() / getTotalQuestions()) * 100;
  };

  if (step === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-gray-100">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Carregando avaliação...</p>
        </div>
      </div>
    );
  }

  // Dedicated error step for initial loading failures or invalid tokens
  if (step === 'error') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-gray-100 p-4">
        <Card className="max-w-md w-full">
          <CardContent className="p-8 text-center">
            <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Erro na Avaliação</h2>
            <p className="text-gray-600 mb-6">{error}</p>
            <Button onClick={() => window.close()} variant="outline">
              Fechar
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (step === 'already_completed') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-gray-100 p-4">
        <Card className="max-w-md w-full">
          <CardContent className="p-8 text-center">
            <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Avaliação Já Respondida</h2>
            <p className="text-gray-600 mb-4">
              Você já respondeu esta avaliação em {new Date(assessment.completed_at).toLocaleDateString('pt-BR')} às {new Date(assessment.completed_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}.
            </p>
            <p className="text-sm text-gray-500">
              Caso tenha dúvidas, entre em contato com o RH.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (step === 'auth') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-gray-100 p-4">
        <Card className="max-w-md w-full">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <CardTitle className="text-2xl font-bold">Identificação do Colaborador</CardTitle>
            <p className="text-gray-600 text-sm mt-2">
              Usamos seu CPF e data de nascimento apenas para confirmar seu convite.
              Suas respostas são confidenciais e não serão compartilhadas individualmente.
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            {error && (
              <Alert className="bg-red-50 border-red-200">
                <AlertDescription className="text-red-800">
                  {error}
                </AlertDescription>
              </Alert>
            )}

            <div>
              <Label htmlFor="cpf">CPF *</Label>
              <Input
                id="cpf"
                value={cpf}
                onChange={(e) => {
                  const value = e.target.value.replace(/\D/g, '');
                  const formatted = value
                    .replace(/(\d{3})(\d)/, '$1.$2')
                    .replace(/(\d{3})(\d)/, '$1.$2')
                    .replace(/(\d{3})(\d{1,2})$/, '$1-$2');
                  setCpf(formatted);
                }}
                placeholder="000.000.000-00"
                maxLength={14}
                className="text-lg"
              />
            </div>

            <div>
              <Label htmlFor="birthDate">Data de Nascimento *</Label>
              <Input
                id="birthDate"
                type="date"
                value={birthDate}
                onChange={(e) => setBirthDate(e.target.value)}
                className="text-lg"
              />
            </div>

            <Button
              onClick={handleAuth}
              disabled={!cpf || !birthDate || loading}
              className="w-full bg-blue-600 hover:bg-blue-700 text-lg py-6"
            >
              {loading ? (
                <>
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Verificando...
                </>
              ) : (
                <>
                  Continuar
                  <ArrowRight className="w-5 h-5 ml-2" />
                </>
              )}
            </Button>

            {attemptCount > 0 && attemptCount < 5 && (
              <p className="text-sm text-gray-500 text-center">
                Tentativas restantes: {5 - attemptCount}
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  if (step === 'consent') {
    return (
      <ConsentTerm
        company={company}
        onAccept={handleConsentAccept}
        onDecline={() => window.close()}
        loading={loading}
      />
    );
  }

  if (step === 'questions') {
    const currentQuestionnaireType = questionnaires[currentQuestionnaire];
    const question = QUESTIONS[currentQuestionnaireType][currentQuestionIndex];
    
    // Safety check: if question is not found (e.g., due to misconfiguration)
    if (!question) {
        console.error(`Question not found: questionnaireType=${currentQuestionnaireType}, index=${currentQuestionIndex}`);
        return (
            <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-gray-100 p-4">
                <Card className="max-w-md w-full">
                    <CardContent className="p-8 text-center">
                        <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
                        <h2 className="text-2xl font-bold text-gray-900 mb-2">Erro na Avaliação</h2>
                        <p className="text-gray-600">
                            Não foi possível carregar a pergunta atual. Por favor, recarregue a página ou entre em contato com o suporte.
                        </p>
                    </CardContent>
                </Card>
            </div>
        );
    }

    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-gray-100">
        <div className="max-w-4xl mx-auto p-4 py-8">
          <div className="mb-6 bg-white rounded-xl p-4 shadow-sm">
            <div className="flex items-center gap-2 mb-2">
              <Clock className="w-5 h-5 text-gray-500" />
              <span className="text-sm text-gray-600">
                Pergunta {getCurrentQuestionNumber()} de {getTotalQuestions()}
              </span>
            </div>
            <Progress value={getProgress()} className="h-2" />
          </div>

          <QuestionScreen
            question={question}
            questionnaire={currentQuestionnaireType}
            onAnswer={handleAnswerQuestion}
            onPrevious={handlePreviousQuestion}
            canGoPrevious={currentQuestionIndex > 0 || currentQuestionnaire > 0}
            // Pass current response value to QuestionScreen for pre-filling if user goes back
            currentResponse={responses[`${currentQuestionnaireType}_${question.id}`]}
          />
        </div>
      </div>
    );
  }

  if (step === 'complete') {
    return (
      <CompletionScreen
        company={company}
        completedAt={new Date()}
      />
    );
  }

  return null;
}
