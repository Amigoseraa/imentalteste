
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  Search,
  User,
  Key,
  Database,
  Shield,
  RefreshCw // Added RefreshCw icon for activation button
} from "lucide-react";
import { toast } from "sonner";

export default function TestMasterUser() {
  const [testEmail, setTestEmail] = useState("arthur@mednet-saocaetano.com.br");
  const [testResults, setTestResults] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isActivating, setIsActivating] = useState(false); // New state for activation loading

  // Buscar todas as consultorias
  const { data: consultorias = [] } = useQuery({
    queryKey: ['consultorias-test'],
    queryFn: () => base44.entities.Consultoria.list(),
  });

  const runDiagnostics = async () => {
    setIsLoading(true);
    setTestResults(null);

    try {
      const results = {
        timestamp: new Date().toISOString(),
        tests: []
      };

      // Teste 1: Verificar se a consultoria existe
      results.tests.push({
        name: "1. Verificar Consultoria",
        status: "running"
      });

      const consultoriaComEmail = consultorias.find(c => 
        c.email_master && c.email_master.toLowerCase() === testEmail.toLowerCase()
      );

      if (!consultoriaComEmail) {
        results.tests[0] = {
          name: "1. Verificar Consultoria",
          status: "error",
          message: `Nenhuma consultoria encontrada com email_master: ${testEmail}`,
          data: null
        };
        setTestResults(results);
        setIsLoading(false);
        return;
      }

      results.tests[0] = {
        name: "1. Verificar Consultoria",
        status: "success",
        message: `Consultoria encontrada: ${consultoriaComEmail.nome_fantasia}`,
        data: {
          id: consultoriaComEmail.id,
          nome: consultoriaComEmail.nome_fantasia,
          email_master: consultoriaComEmail.email_master,
          status: consultoriaComEmail.status
        }
      };

      // Teste 2: Verificar master_user_data
      results.tests.push({
        name: "2. Verificar master_user_data",
        status: "running"
      });

      const masterData = consultoriaComEmail.master_user_data;

      if (!masterData) {
        results.tests[1] = {
          name: "2. Verificar master_user_data",
          status: "error",
          message: "master_user_data não existe na consultoria",
          data: null
        };
        setTestResults(results);
        setIsLoading(false);
        return;
      }

      results.tests[1] = {
        name: "2. Verificar master_user_data",
        status: "success",
        message: "master_user_data encontrado",
        data: {
          nome: masterData.nome,
          email: masterData.email,
          cpf: masterData.cpf ? "***" : "vazio",
          senha_temp: masterData.senha_temp ? "***" : "vazio",
          has_credentials: masterData.has_credentials,
          login_ativado: masterData.login_ativado,
          user_id: masterData.user_id || "não definido",
          created_at: masterData.created_at,
          updated_at: masterData.updated_at
        }
      };

      // Teste 3: Verificar se usuário existe na entidade User
      results.tests.push({
        name: "3. Verificar User no Sistema",
        status: "running"
      });

      try {
        const users = await base44.entities.User.filter({ 
          email: testEmail 
        });

        if (!users || users.length === 0) {
          results.tests[2] = {
            name: "3. Verificar User no Sistema",
            status: "warning",
            message: "Usuário NÃO encontrado na entidade User do sistema",
            data: {
              note: "O usuário pode não ter sido criado no sistema de autenticação"
            }
          };
        } else {
          const userRecord = users[0];
          results.tests[2] = {
            name: "3. Verificar User no Sistema",
            status: "success",
            message: "Usuário encontrado na entidade User",
            data: {
              id: userRecord.id,
              email: userRecord.email,
              full_name: userRecord.full_name,
              user_role: userRecord.user_role,
              consultoria_id: userRecord.consultoria_id,
              is_master: userRecord.is_master,
              status: userRecord.status,
              password_temp: userRecord.password_temp ? "***" : "vazio"
            }
          };
        }
      } catch (userError) {
        results.tests[2] = {
          name: "3. Verificar User no Sistema",
          status: "error",
          message: `Erro ao buscar User: ${userError.message}`,
          data: {
            error: userError.message,
            note: "Pode ser que a entidade User não esteja acessível"
          }
        };
      }

      // Teste 4: Verificar InviteToken
      results.tests.push({
        name: "4. Verificar InviteToken",
        status: "running"
      });

      try {
        const invites = await base44.entities.InviteToken.filter({
          user_email: testEmail,
          consultoria_id: consultoriaComEmail.id
        });

        if (!invites || invites.length === 0) {
          results.tests[3] = {
            name: "4. Verificar InviteToken",
            status: "warning",
            message: "Nenhum InviteToken encontrado",
            data: null
          };
        } else {
          const invite = invites[0];
          results.tests[3] = {
            name: "4. Verificar InviteToken",
            status: "success",
            message: "InviteToken encontrado",
            data: {
              token: invite.token ? "***" : "vazio",
              status: invite.status,
              role: invite.role,
              expires_at: invite.expires_at,
              accepted_at: invite.accepted_at || "não aceito",
              created_by: invite.created_by
            }
          };
        }
      } catch (inviteError) {
        results.tests[3] = {
          name: "4. Verificar InviteToken",
          status: "error",
          message: `Erro ao buscar InviteToken: ${inviteError.message}`,
          data: null
        };
      }

      // Teste 5: Resumo e recomendações
      results.tests.push({
        name: "5. Resumo e Diagnóstico",
        status: "info"
      });

      const hasPassword = masterData.senha_temp;
      const hasUser = results.tests[2].status === "success";
      const loginAtivado = masterData.login_ativado;

      let diagnostico = "";
      let recomendacao = "";

      if (!hasPassword) {
        diagnostico = "❌ PROBLEMA: Senha não está salva no master_user_data";
        recomendacao = "Edite a consultoria e preencha a senha do usuário master novamente";
      } else if (!hasUser) {
        diagnostico = "⚠️ ATENÇÃO: Senha salva na consultoria, mas usuário não existe na entidade User";
        recomendacao = "O sistema tentou criar o User mas falhou. Verifique os logs de erro.";
      } else if (!loginAtivado) {
        diagnostico = "⚠️ ATENÇÃO: Usuário existe mas login_ativado está false";
        recomendacao = "Edite a consultoria para tentar reativar o usuário";
      } else {
        diagnostico = "✅ TUDO OK: Credenciais configuradas e usuário criado no sistema";
        recomendacao = "O usuário deve conseguir fazer login com as credenciais";
      }

      results.tests[4] = {
        name: "5. Resumo e Diagnóstico",
        status: "info",
        message: diagnostico,
        data: {
          diagnostico,
          recomendacao,
          senha_salva: hasPassword,
          user_criado: hasUser,
          login_ativado: loginAtivado
        }
      };

      setTestResults(results);
      toast.success("Diagnóstico completo!");

    } catch (error) {
      console.error("Erro ao executar diagnósticos:", error);
      toast.error("Erro ao executar diagnósticos: " + error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const activateUserLogin = async () => {
    setIsActivating(true);
    
    try {
      // Buscar consultoria
      const consultoriaComEmail = consultorias.find(c => 
        c.email_master && c.email_master.toLowerCase() === testEmail.toLowerCase()
      );

      if (!consultoriaComEmail) {
        toast.error('Consultoria não encontrada');
        setIsActivating(false);
        return;
      }

      const masterData = consultoriaComEmail.master_user_data;
      
      if (!masterData || !masterData.senha_temp) {
        toast.error('Senha não encontrada no master_user_data. Por favor, edite a consultoria e preencha a senha.');
        setIsActivating(false);
        return;
      }

      console.log('=== Ativando login do usuário master ===');
      console.log('Email:', testEmail);
      // console.log('Senha:', masterData.senha_temp); // Avoid logging sensitive info

      // Tentar usar o endpoint de auth do base44
      const inviteResponse = await fetch('/api/auth/invite-user', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: testEmail,
          password: masterData.senha_temp,
          full_name: masterData.nome,
          role: 'consultoria', // Assuming 'consultoria' is the correct role
          consultoria_id: consultoriaComEmail.id,
          is_master: true,
          cpf: masterData.cpf,
          data_nascimento: masterData.data_nascimento, // Include if available
          telefone: masterData.telefone // Include if available
        })
      });

      if (inviteResponse.ok) {
        toast.success('✅ Login ativado com sucesso! Agora o usuário pode fazer login.');
        
        // Atualizar consultoria marcando como ativado
        // Ensure master_user_data is properly merged to avoid overwriting
        await base44.entities.Consultoria.update(consultoriaComEmail.id, {
          master_user_data: {
            ...masterData,
            login_ativado: true,
            updated_at: new Date().toISOString()
          }
        });
        
        // Recarregar diagnóstico para atualizar o status
        await runDiagnostics();
      } else {
        const errorData = await inviteResponse.json();
        toast.error('❌ Erro ao ativar login: ' + (errorData.message || 'Erro desconhecido'));
      }
      
    } catch (error) {
      console.error('Erro ao ativar login:', error);
      toast.error('❌ Erro ao ativar login: ' + error.message);
    } finally {
      setIsActivating(false);
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case "success":
        return <CheckCircle className="w-5 h-5 text-green-600" />;
      case "error":
        return <XCircle className="w-5 h-5 text-red-600" />;
      case "warning":
        return <AlertTriangle className="w-5 h-5 text-yellow-600" />;
      case "info":
        return <Shield className="w-5 h-5 text-blue-600" />;
      default:
        return <Search className="w-5 h-5 text-gray-400 animate-spin" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "success":
        return "bg-green-50 border-green-200";
      case "error":
        return "bg-red-50 border-red-200";
      case "warning":
        return "bg-yellow-50 border-yellow-200";
      case "info":
        return "bg-blue-50 border-blue-200";
      default:
        return "bg-gray-50 border-gray-200";
    }
  };

  // Helper to safely get the login_ativado status from the last test result
  const getLoginAtivadoStatus = () => {
    if (testResults && testResults.tests && testResults.tests.length > 0) {
      const lastTest = testResults.tests[testResults.tests.length - 1];
      if (lastTest && lastTest.data && typeof lastTest.data.login_ativado === 'boolean') {
        return lastTest.data.login_ativado;
      }
    }
    return false; // Default to false if status is not found
  };

  const showActivateButton = testResults && testResults.tests && testResults.tests.length > 0;
  const loginAlreadyActive = getLoginAtivadoStatus();

  return (
    <div className="p-8 min-h-screen" style={{ backgroundColor: '#F8F6FB' }}>
      <div className="max-w-4xl mx-auto">
        <Card className="shadow-lg mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="w-6 h-6" style={{ color: '#4B2672' }} />
              Diagnóstico de Usuário Master
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert className="bg-blue-50 border-blue-200">
              <AlertDescription className="text-sm text-blue-900">
                <p className="font-semibold mb-2">ℹ️ Sobre esta ferramenta</p>
                <p>
                  Esta página verifica se o usuário master de uma consultoria foi criado corretamente
                  e se pode fazer login no sistema. Digite o email do usuário master para iniciar o diagnóstico.
                </p>
              </AlertDescription>
            </Alert>

            <div className="space-y-2">
              <Label htmlFor="test-email">Email do Usuário Master</Label>
              <div className="flex gap-2">
                <Input
                  id="test-email"
                  type="email"
                  value={testEmail}
                  onChange={(e) => setTestEmail(e.target.value)}
                  placeholder="email@consultoria.com"
                  className="flex-1"
                />
                <Button
                  onClick={runDiagnostics}
                  disabled={isLoading || !testEmail}
                  className="text-white"
                  style={{ backgroundColor: '#4B2672' }}
                >
                  {isLoading ? (
                    <>
                      <Search className="w-4 h-4 mr-2 animate-spin" />
                      Diagnosticando...
                    </>
                  ) : (
                    <>
                      <Search className="w-4 h-4 mr-2" />
                      Executar Diagnóstico
                    </>
                  )}
                </Button>
              </div>
            </div>

            {showActivateButton && (
              <div className="pt-4 border-t">
                <Button
                  onClick={activateUserLogin}
                  disabled={isActivating || loginAlreadyActive}
                  className="w-full text-white"
                  style={{ backgroundColor: '#10B981' }}
                  size="lg"
                >
                  {isActivating ? (
                    <>
                      <RefreshCw className="w-5 h-5 mr-2 animate-spin" />
                      Ativando Login...
                    </>
                  ) : loginAlreadyActive ? (
                    <>
                      <CheckCircle className="w-5 h-5 mr-2" />
                      Login Já Está Ativo
                    </>
                  ) : (
                    <>
                      <Key className="w-5 h-5 mr-2" />
                      🚀 Ativar Login Agora
                    </>
                  )}
                </Button>
                <p className="text-xs text-center mt-2 text-gray-500">
                  {loginAlreadyActive 
                    ? 'O usuário já pode fazer login no sistema'
                    : 'Clique para criar a conta de autenticação e permitir login'}
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {testResults && (
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-lg">
                Resultados do Diagnóstico
              </CardTitle>
              <p className="text-xs text-gray-500">
                Executado em: {new Date(testResults.timestamp).toLocaleString('pt-BR')}
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              {testResults.tests.map((test, idx) => (
                <Alert key={idx} className={getStatusColor(test.status)}>
                  <div className="flex items-start gap-3">
                    {getStatusIcon(test.status)}
                    <div className="flex-1">
                      <p className="font-semibold text-sm mb-1">
                        {test.name}
                      </p>
                      <p className="text-sm mb-2">
                        {test.message}
                      </p>
                      {test.data && (
                        <details className="mt-2">
                          <summary className="cursor-pointer text-xs font-medium mb-1">
                            Ver detalhes
                          </summary>
                          <pre className="text-xs bg-white p-2 rounded mt-1 overflow-auto max-h-40">
                            {JSON.stringify(test.data, null, 2)}
                          </pre>
                        </details>
                      )}
                    </div>
                  </div>
                </Alert>
              ))}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
