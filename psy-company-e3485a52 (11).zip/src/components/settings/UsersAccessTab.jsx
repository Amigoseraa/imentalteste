import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  UserPlus,
  Search,
  MoreVertical,
  Edit,
  Ban,
  Trash2,
  Mail,
  Eye,
  CheckCircle,
  XCircle,
  Clock
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import InviteUserModal from "./InviteUserModal";
import EditUserDrawer from "./EditUserDrawer";
import AuditLogDrawer from "./AuditLogDrawer";
import { format } from "date-fns";

export default function UsersAccessTab({ user }) {
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [showEditDrawer, setShowEditDrawer] = useState(false);
  const [showAuditDrawer, setShowAuditDrawer] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [roleFilter, setRoleFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const queryClient = useQueryClient();

  const { data: allUsers = [] } = useQuery({
    queryKey: ['all-users'],
    queryFn: async () => {
      const users = await base44.entities.User.list('-last_access');
      
      if (user.user_role !== 'admin') {
        if (user.user_role === 'consultoria') {
          return users.filter(u => u.consultoria_id === user.consultoria_id);
        } else if (user.company_id) {
          return users.filter(u => u.company_id === user.company_id);
        }
      }
      
      return users;
    },
  });

  const { data: consultorias = [] } = useQuery({
    queryKey: ['consultorias'],
    queryFn: () => base44.entities.Consultoria.list(),
    enabled: user?.user_role === 'admin',
  });

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: () => base44.entities.Company.list(),
  });

  const blockUserMutation = useMutation({
    mutationFn: async ({ userId, block }) => {
      const targetUser = allUsers.find(u => u.id === userId);
      const newStatus = block ? 'blocked' : 'active';
      
      await base44.entities.User.update(userId, { status: newStatus });
      
      await base44.entities.AuditLog.create({
        actor_user_email: user.email,
        target_user_email: targetUser.email,
        action: block ? 'user_blocked' : 'user_unblocked',
        meta: { reason: 'Manual action by admin' }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-users'] });
      toast.success('Status do usuário atualizado');
    },
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (userId) => {
      const targetUser = allUsers.find(u => u.id === userId);
      
      await base44.entities.User.update(userId, { status: 'disabled' });
      
      await base44.entities.AuditLog.create({
        actor_user_email: user.email,
        target_user_email: targetUser.email,
        action: 'user_disabled',
        meta: {}
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-users'] });
      toast.success('Usuário desativado');
    },
  });

  const resendInviteMutation = useMutation({
    mutationFn: async (userId) => {
      const targetUser = allUsers.find(u => u.id === userId);
      
      const invites = await base44.entities.InviteToken.filter({ user_email: targetUser.email, status: 'pending' });
      if (invites.length === 0) {
        throw new Error('Convite não encontrado');
      }
      
      await base44.integrations.Core.SendEmail({
        to: targetUser.email,
        subject: 'Lembrete: Seu convite para o iMental',
        body: `Olá! Você foi convidado para acessar o iMental como ${targetUser.user_role}. Clique no link para ativar sua conta.`
      });
      
      await base44.entities.AuditLog.create({
        actor_user_email: user.email,
        target_user_email: targetUser.email,
        action: 'invite_resent',
        meta: {}
      });
    },
    onSuccess: () => {
      toast.success('Convite reenviado com sucesso');
    },
  });

  let filteredUsers = allUsers.filter(u => {
    if (roleFilter !== 'all' && u.user_role !== roleFilter) return false;
    if (statusFilter !== 'all' && u.status !== statusFilter) return false;
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      return u.full_name?.toLowerCase().includes(term) || u.email?.toLowerCase().includes(term);
    }
    return true;
  });

  const getRoleBadge = (role) => {
    const badges = {
      admin: <Badge className="bg-purple-100 text-purple-800">Admin iMental</Badge>,
      consultoria: <Badge className="bg-blue-100 text-blue-800">Admin Consultoria</Badge>,
      manager: <Badge className="bg-green-100 text-green-800">Admin Empresa</Badge>,
      employee: <Badge className="bg-gray-100 text-gray-800">Colaborador</Badge>
    };
    return badges[role] || <Badge>{role}</Badge>;
  };

  const getStatusBadge = (status) => {
    const badges = {
      active: (
        <Badge className="bg-green-100 text-green-800 flex items-center gap-1">
          <CheckCircle className="w-3 h-3" /> Ativo
        </Badge>
      ),
      invited: (
        <Badge className="bg-yellow-100 text-yellow-800 flex items-center gap-1">
          <Clock className="w-3 h-3" /> Convite Pendente
        </Badge>
      ),
      blocked: (
        <Badge className="bg-red-100 text-red-800 flex items-center gap-1">
          <Ban className="w-3 h-3" /> Bloqueado
        </Badge>
      ),
      disabled: (
        <Badge className="bg-gray-100 text-gray-800 flex items-center gap-1">
          <XCircle className="w-3 h-3" /> Desativado
        </Badge>
      )
    };
    return badges[status] || <Badge>{status}</Badge>;
  };

  const getScope = (u) => {
    if (u.user_role === 'admin') return 'Global';
    if (u.consultoria_id) {
      const consultoria = consultorias.find(c => c.id === u.consultoria_id);
      return consultoria?.nome_fantasia || u.consultoria_id;
    }
    if (u.company_id) {
      const company = companies.find(c => c.id === u.company_id);
      return company?.name || u.company_id;
    }
    return '-';
  };

  const canManageUser = (targetUser) => {
    if (user.user_role === 'admin') return true;
    if (user.user_role === 'consultoria' && targetUser.consultoria_id === user.consultoria_id) return true;
    if (user.user_role === 'manager' && targetUser.company_id === user.company_id) return true;
    return false;
  };

  return (
    <div className="space-y-6">
      <Card className="shadow-md">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Usuários & Acessos</CardTitle>
              <p className="text-sm text-gray-500 mt-1">
                Gerencie usuários, papéis e permissões do sistema
              </p>
            </div>
            <Button
              onClick={() => setShowInviteModal(true)}
              style={{ backgroundColor: '#4B2672' }}
              className="text-white"
            >
              <UserPlus className="w-4 h-4 mr-2" />
              Convidar Usuário
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 mb-6 flex-wrap">
            <div className="flex-1 min-w-[200px]">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Buscar por nome ou e-mail..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={roleFilter} onValueChange={setRoleFilter}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filtrar por papel" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os papéis</SelectItem>
                <SelectItem value="admin">Admin iMental</SelectItem>
                <SelectItem value="consultoria">Admin Consultoria</SelectItem>
                <SelectItem value="manager">Admin Empresa</SelectItem>
                <SelectItem value="employee">Colaborador</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filtrar por status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os status</SelectItem>
                <SelectItem value="active">Ativo</SelectItem>
                <SelectItem value="invited">Convite Pendente</SelectItem>
                <SelectItem value="blocked">Bloqueado</SelectItem>
                <SelectItem value="disabled">Desativado</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {filteredUsers.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50">
                    <TableHead>Nome</TableHead>
                    <TableHead>E-mail</TableHead>
                    <TableHead>Papel Principal</TableHead>
                    <TableHead>Escopo</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Último Acesso</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.map((u) => (
                    <TableRow key={u.id}>
                      <TableCell className="font-medium">{u.full_name || '-'}</TableCell>
                      <TableCell>{u.email}</TableCell>
                      <TableCell>{getRoleBadge(u.user_role)}</TableCell>
                      <TableCell className="text-sm text-gray-600">{getScope(u)}</TableCell>
                      <TableCell>{getStatusBadge(u.status)}</TableCell>
                      <TableCell className="text-sm text-gray-500">
                        {u.last_access ? format(new Date(u.last_access), 'dd/MM/yyyy HH:mm') : 'Nunca'}
                      </TableCell>
                      <TableCell className="text-right">
                        {canManageUser(u) && (
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreVertical className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem
                                onClick={() => {
                                  setSelectedUser(u);
                                  setShowEditDrawer(true);
                                }}
                              >
                                <Edit className="w-4 h-4 mr-2" />
                                Editar Acesso
                              </DropdownMenuItem>
                              {u.status === 'invited' && (
                                <DropdownMenuItem
                                  onClick={() => resendInviteMutation.mutate(u.id)}
                                >
                                  <Mail className="w-4 h-4 mr-2" />
                                  Reenviar Convite
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuItem
                                onClick={() => {
                                  setSelectedUser(u);
                                  setShowAuditDrawer(true);
                                }}
                              >
                                <Eye className="w-4 h-4 mr-2" />
                                Ver Auditoria
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              {u.status === 'active' ? (
                                <DropdownMenuItem
                                  onClick={() => blockUserMutation.mutate({ userId: u.id, block: true })}
                                  className="text-red-600"
                                >
                                  <Ban className="w-4 h-4 mr-2" />
                                  Bloquear
                                </DropdownMenuItem>
                              ) : u.status === 'blocked' ? (
                                <DropdownMenuItem
                                  onClick={() => blockUserMutation.mutate({ userId: u.id, block: false })}
                                  className="text-green-600"
                                >
                                  <CheckCircle className="w-4 h-4 mr-2" />
                                  Desbloquear
                                </DropdownMenuItem>
                              ) : null}
                              <DropdownMenuItem
                                onClick={() => {
                                  if (window.confirm(`Tem certeza que deseja desativar ${u.full_name || u.email}?`)) {
                                    deleteUserMutation.mutate(u.id);
                                  }
                                }}
                                className="text-red-600"
                              >
                                <Trash2 className="w-4 h-4 mr-2" />
                                Desativar
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-12">
              <UserPlus className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 mb-4">Nenhum usuário encontrado</p>
              <Button
                onClick={() => setShowInviteModal(true)}
                style={{ backgroundColor: '#4B2672' }}
                className="text-white"
              >
                <UserPlus className="w-4 h-4 mr-2" />
                Convidar Primeiro Usuário
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {showInviteModal && (
        <InviteUserModal
          currentUser={user}
          onClose={() => setShowInviteModal(false)}
        />
      )}
      
      {showEditDrawer && selectedUser && (
        <EditUserDrawer
          user={selectedUser}
          currentUser={user}
          onClose={() => {
            setShowEditDrawer(false);
            setSelectedUser(null);
          }}
        />
      )}
      
      {showAuditDrawer && selectedUser && (
        <AuditLogDrawer
          targetUser={selectedUser}
          onClose={() => {
            setShowAuditDrawer(false);
            setSelectedUser(null);
          }}
        />
      )}
    </div>
  );
}