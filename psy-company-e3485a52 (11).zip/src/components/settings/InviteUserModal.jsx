import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Info, UserPlus } from "lucide-react";
import { toast } from "sonner";
import { addDays } from "date-fns";

export default function InviteUserModal({ currentUser, onClose }) {
  const [formData, setFormData] = useState({
    email: "",
    role: "manager",
    consultoria_id: currentUser.user_role === 'consultoria' ? currentUser.consultoria_id : "",
    company_id: "",
    additional_roles: []
  });

  const queryClient = useQueryClient();

  const { data: consultorias = [] } = useQuery({
    queryKey: ['consultorias'],
    queryFn: () => base44.entities.Consultoria.list(),
    enabled: currentUser?.user_role === 'admin',
  });

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: async () => {
      if (formData.consultoria_id) {
        return await base44.entities.Company.filter({ consultoria_id: formData.consultoria_id });
      }
      return [];
    },
    enabled: !!formData.consultoria_id,
  });

  const inviteMutation = useMutation({
    mutationFn: async (data) => {
      // Gerar token único
      const token = Math.random().toString(36).substring(2) + Date.now().toString(36);
      
      // Criar convite
      await base44.entities.InviteToken.create({
        user_email: data.email,
        token,
        role: data.role,
        consultoria_id: data.consultoria_id || null,
        empresa_id: data.company_id || null,
        additional_roles: data.additional_roles,
        expires_at: addDays(new Date(), 7).toISOString(),
        created_by: currentUser.email,
        status: 'pending'
      });
      
      // Criar usuário com status invited
      await base44.entities.User.create({
        email: data.email,
        full_name: "",
        user_role: data.role,
        consultoria_id: data.consultoria_id || null,
        company_id: data.company_id || null,
        additional_roles: data.additional_roles,
        status: 'invited'
      });
      
      // Enviar e-mail de convite
      await base44.integrations.Core.SendEmail({
        to: data.email,
        subject: 'Você foi convidado para o iMental',
        body: `Olá!

Você foi convidado para acessar o iMental como ${getRoleLabel(data.role)}.

Clique no link abaixo para ativar sua conta e definir sua senha:
[Link de ativação - válido por 7 dias]

Este convite expira em 7 dias.

Atenciosamente,
Equipe iMental`
      });
      
      // Registrar auditoria
      await base44.entities.AuditLog.create({
        actor_user_email: currentUser.email,
        target_user_email: data.email,
        action: 'user_invited',
        meta: {
          role: data.role,
          consultoria_id: data.consultoria_id,
          company_id: data.company_id
        }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-users'] });
      toast.success('Convite enviado com sucesso!');
      onClose();
    },
    onError: (error) => {
      toast.error(error.message || 'Erro ao enviar convite');
    }
  });

  const getRoleLabel = (role) => {
    const labels = {
      admin: 'Admin iMental (Nível 1)',
      consultoria: 'Admin de Consultoria (Nível 2)',
      manager: 'Admin de Empresa (Nível 3)',
      employee: 'Colaborador'
    };
    return labels[role] || role;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Validações
    if (!formData.email) {
      toast.error('E-mail é obrigatório');
      return;
    }
    
    if (formData.role === 'consultoria' && !formData.consultoria_id && currentUser.user_role !== 'consultoria') {
      toast.error('Selecione uma consultoria');
      return;
    }
    
    if (formData.role === 'manager' && !formData.company_id) {
      toast.error('Selecione uma empresa');
      return;
    }
    
    inviteMutation.mutate(formData);
  };

  const needsConsultoria = (formData.role === 'consultoria' || formData.role === 'manager') && currentUser.user_role === 'admin';
  const needsCompany = formData.role === 'manager' || formData.role === 'employee';

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <UserPlus className="w-5 h-5" style={{ color: '#4B2672' }} />
            Convidar Novo Usuário
          </DialogTitle>
          <DialogDescription>
            O usuário receberá um e-mail com link para ativar a conta (válido por 7 dias)
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="email">E-mail *</Label>
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({...formData, email: e.target.value})}
              placeholder="usuario@empresa.com"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="role">Papel Principal *</Label>
            <Select 
              value={formData.role} 
              onValueChange={(value) => setFormData({...formData, role: value, company_id: ""})}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {currentUser.user_role === 'admin' && (
                  <>
                    <SelectItem value="admin">
                      <div className="flex flex-col items-start py-1">
                        <span className="font-semibold">Admin iMental (Nível 1)</span>
                        <span className="text-xs text-gray-500">Acesso total ao ecossistema</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="consultoria">
                      <div className="flex flex-col items-start py-1">
                        <span className="font-semibold">Admin de Consultoria (Nível 2)</span>
                        <span className="text-xs text-gray-500">Gerencia empresas clientes</span>
                      </div>
                    </SelectItem>
                  </>
                )}
                <SelectItem value="manager">
                  <div className="flex flex-col items-start py-1">
                    <span className="font-semibold">Admin de Empresa (Nível 3)</span>
                    <span className="text-xs text-gray-500">Gerencia departamentos e colaboradores</span>
                  </div>
                </SelectItem>
                <SelectItem value="employee">
                  <div className="flex flex-col items-start py-1">
                    <span className="font-semibold">Colaborador</span>
                    <span className="text-xs text-gray-500">Acesso restrito (avaliações próprias)</span>
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          {needsConsultoria && (
            <div className="space-y-2">
              <Label htmlFor="consultoria">Consultoria *</Label>
              <Select 
                value={formData.consultoria_id} 
                onValueChange={(value) => setFormData({...formData, consultoria_id: value, company_id: ""})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione uma consultoria" />
                </SelectTrigger>
                <SelectContent>
                  {consultorias.map(c => (
                    <SelectItem key={c.id} value={c.id}>{c.nome_fantasia}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {needsCompany && formData.consultoria_id && (
            <div className="space-y-2">
              <Label htmlFor="company">Empresa *</Label>
              <Select 
                value={formData.company_id} 
                onValueChange={(value) => setFormData({...formData, company_id: value})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione uma empresa" />
                </SelectTrigger>
                <SelectContent>
                  {companies.map(c => (
                    <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="space-y-3">
            <Label>Permissões Adicionais (opcionais)</Label>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Checkbox
                  id="finance"
                  checked={formData.additional_roles.includes('finance')}
                  onCheckedChange={(checked) => {
                    const roles = checked 
                      ? [...formData.additional_roles, 'finance']
                      : formData.additional_roles.filter(r => r !== 'finance');
                    setFormData({...formData, additional_roles: roles});
                  }}
                />
                <Label htmlFor="finance" className="cursor-pointer">
                  <span className="font-semibold">Financeiro</span>
                  <span className="text-xs text-gray-500 block">Acesso ao módulo Financeiro e Faturamento</span>
                </Label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="reports"
                  checked={formData.additional_roles.includes('reports')}
                  onCheckedChange={(checked) => {
                    const roles = checked 
                      ? [...formData.additional_roles, 'reports']
                      : formData.additional_roles.filter(r => r !== 'reports');
                    setFormData({...formData, additional_roles: roles});
                  }}
                />
                <Label htmlFor="reports" className="cursor-pointer">
                  <span className="font-semibold">Relatórios</span>
                  <span className="text-xs text-gray-500 block">Acesso a dashboards e relatórios (somente leitura)</span>
                </Label>
              </div>
            </div>
          </div>

          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription className="text-sm">
              O usuário receberá um e-mail com link de ativação válido por 7 dias.
              Após ativar, ele poderá acessar o sistema conforme as permissões definidas.
            </AlertDescription>
          </Alert>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button 
              type="submit" 
              disabled={inviteMutation.isPending}
              style={{ backgroundColor: '#4B2672' }}
              className="text-white"
            >
              {inviteMutation.isPending ? 'Enviando...' : 'Enviar Convite'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}