import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Save } from "lucide-react";
import { toast } from "sonner";

export default function EditUserDrawer({ user, currentUser, onClose }) {
  const [formData, setFormData] = useState({
    full_name: user.full_name || "",
    user_role: user.user_role,
    consultoria_id: user.consultoria_id || "",
    company_id: user.company_id || "",
    additional_roles: user.additional_roles || [],
    mfa_required: user.mfa_required || false,
    status: user.status
  });

  const queryClient = useQueryClient();

  const { data: consultorias = [] } = useQuery({
    queryKey: ['consultorias'],
    queryFn: () => base44.entities.Consultoria.list(),
    enabled: currentUser?.user_role === 'admin',
  });

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: async () => {
      if (formData.consultoria_id) {
        return await base44.entities.Company.filter({ consultoria_id: formData.consultoria_id });
      }
      return [];
    },
    enabled: !!formData.consultoria_id,
  });

  const updateMutation = useMutation({
    mutationFn: async (data) => {
      await base44.entities.User.update(user.id, data);
      
      await base44.entities.AuditLog.create({
        actor_user_email: currentUser.email,
        target_user_email: user.email,
        action: 'user_edited',
        meta: {
          changes: data
        }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-users'] });
      toast.success('Usuário atualizado com sucesso!');
      onClose();
    },
    onError: (error) => {
      toast.error(error.message || 'Erro ao atualizar usuário');
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    updateMutation.mutate(formData);
  };

  return (
    <Sheet open onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-md">
        <SheetHeader>
          <SheetTitle>Editar Acesso</SheetTitle>
        </SheetHeader>

        <form onSubmit={handleSubmit} className="space-y-6 mt-6">
          <div className="space-y-2">
            <Label htmlFor="full_name">Nome Completo</Label>
            <Input
              id="full_name"
              value={formData.full_name}
              onChange={(e) => setFormData({...formData, full_name: e.target.value})}
              placeholder="Nome do usuário"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">E-mail</Label>
            <Input
              id="email"
              value={user.email}
              disabled
              className="bg-gray-50"
            />
            <p className="text-xs text-gray-500">O e-mail não pode ser alterado</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="role">Papel Principal</Label>
            <Select 
              value={formData.user_role} 
              onValueChange={(value) => setFormData({...formData, user_role: value})}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {currentUser.user_role === 'admin' && (
                  <>
                    <SelectItem value="admin">Admin iMental</SelectItem>
                    <SelectItem value="consultoria">Admin Consultoria</SelectItem>
                  </>
                )}
                <SelectItem value="manager">Admin Empresa</SelectItem>
                <SelectItem value="employee">Colaborador</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {(formData.user_role === 'consultoria' || formData.user_role === 'manager') && currentUser.user_role === 'admin' && (
            <div className="space-y-2">
              <Label htmlFor="consultoria">Consultoria</Label>
              <Select 
                value={formData.consultoria_id} 
                onValueChange={(value) => setFormData({...formData, consultoria_id: value, company_id: ""})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent>
                  {consultorias.map(c => (
                    <SelectItem key={c.id} value={c.id}>{c.nome_fantasia}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {(formData.user_role === 'manager' || formData.user_role === 'employee') && formData.consultoria_id && (
            <div className="space-y-2">
              <Label htmlFor="company">Empresa</Label>
              <Select 
                value={formData.company_id} 
                onValueChange={(value) => setFormData({...formData, company_id: value})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent>
                  {companies.map(c => (
                    <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="space-y-3">
            <Label>Permissões Adicionais</Label>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Checkbox
                  id="finance-edit"
                  checked={formData.additional_roles.includes('finance')}
                  onCheckedChange={(checked) => {
                    const roles = checked 
                      ? [...formData.additional_roles, 'finance']
                      : formData.additional_roles.filter(r => r !== 'finance');
                    setFormData({...formData, additional_roles: roles});
                  }}
                />
                <Label htmlFor="finance-edit">Financeiro</Label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="reports-edit"
                  checked={formData.additional_roles.includes('reports')}
                  onCheckedChange={(checked) => {
                    const roles = checked 
                      ? [...formData.additional_roles, 'reports']
                      : formData.additional_roles.filter(r => r !== 'reports');
                    setFormData({...formData, additional_roles: roles});
                  }}
                />
                <Label htmlFor="reports-edit">Relatórios</Label>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <Label>Segurança</Label>
            <div className="flex items-center justify-between">
              <div>
                <Label>Forçar MFA no próximo login</Label>
                <p className="text-xs text-gray-500">Usuário deverá configurar autenticação de dois fatores</p>
              </div>
              <Switch
                checked={formData.mfa_required}
                onCheckedChange={(checked) => setFormData({...formData, mfa_required: checked})}
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button 
              type="submit" 
              disabled={updateMutation.isPending}
              style={{ backgroundColor: '#4B2672' }}
              className="text-white"
            >
              <Save className="w-4 h-4 mr-2" />
              {updateMutation.isPending ? 'Salvando...' : 'Salvar Alterações'}
            </Button>
          </div>
        </form>
      </SheetContent>
    </Sheet>
  );
}