import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Clock, User, Activity } from "lucide-react";
import { format } from "date-fns";

export default function AuditLogDrawer({ targetUser, onClose }) {
  const { data: logs = [], isLoading } = useQuery({
    queryKey: ['audit-logs', targetUser.email],
    queryFn: async () => {
      const allLogs = await base44.entities.AuditLog.list('-created_date');
      return allLogs.filter(log => 
        log.target_user_email === targetUser.email || 
        log.actor_user_email === targetUser.email
      );
    },
  });

  const getActionLabel = (action) => {
    const labels = {
      user_invited: 'Convite Enviado',
      user_activated: 'Conta Ativada',
      user_edited: 'Informações Editadas',
      user_blocked: 'Usuário Bloqueado',
      user_unblocked: 'Usuário Desbloqueado',
      user_disabled: 'Usuário Desativado',
      user_enabled: 'Usuário Habilitado',
      user_deleted: 'Usuário Removido',
      role_changed: 'Papel Alterado',
      scope_changed: 'Escopo Alterado',
      password_reset: 'Senha Resetada',
      invite_resent: 'Convite Reenviado',
      invite_cancelled: 'Convite Cancelado',
      mfa_enabled: 'MFA Ativado',
      mfa_disabled: 'MFA Desativado'
    };
    return labels[action] || action;
  };

  const getActionColor = (action) => {
    if (action.includes('blocked') || action.includes('disabled') || action.includes('deleted')) {
      return 'bg-red-100 text-red-800';
    }
    if (action.includes('activated') || action.includes('enabled') || action.includes('unblocked')) {
      return 'bg-green-100 text-green-800';
    }
    return 'bg-blue-100 text-blue-800';
  };

  return (
    <Sheet open onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-lg">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <Activity className="w-5 h-5" />
            Histórico de Auditoria
          </SheetTitle>
          <p className="text-sm text-gray-500">
            {targetUser.full_name || targetUser.email}
          </p>
        </SheetHeader>

        <ScrollArea className="h-[calc(100vh-120px)] mt-6">
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin w-8 h-8 border-4 border-purple-600 border-t-transparent rounded-full"></div>
            </div>
          ) : logs.length > 0 ? (
            <div className="space-y-4">
              {logs.map((log, index) => (
                <div key={index} className="border-l-2 border-gray-200 pl-4 pb-4">
                  <div className="flex items-start gap-3">
                    <div className="mt-1">
                      <Badge className={getActionColor(log.action)}>
                        {getActionLabel(log.action)}
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="mt-2 space-y-1 text-sm text-gray-600">
                    <div className="flex items-center gap-2">
                      <User className="w-3 h-3" />
                      <span>Por: {log.actor_user_email}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="w-3 h-3" />
                      <span>{format(new Date(log.created_date), 'dd/MM/yyyy HH:mm:ss')}</span>
                    </div>
                    {log.meta && Object.keys(log.meta).length > 0 && (
                      <div className="mt-2 p-2 bg-gray-50 rounded text-xs">
                        <pre className="whitespace-pre-wrap">
                          {JSON.stringify(log.meta, null, 2)}
                        </pre>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Activity className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">Nenhum registro de auditoria encontrado</p>
            </div>
          )}
        </ScrollArea>
      </SheetContent>
    </Sheet>
  );
}