import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Shield, Lock, Clock, AlertTriangle, Save } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { toast } from "sonner";

export default function SecurityPoliciesTab({ user }) {
  const [policies, setPolicies] = useState({
    password_min_length: 8,
    password_require_uppercase: true,
    password_require_lowercase: true,
    password_require_number: true,
    password_require_special: false,
    mfa_optional: true,
    mfa_required_for_admins: false,
    max_login_attempts: 5,
    lockout_duration_minutes: 30,
    session_timeout_hours: 12
  });

  const handleSave = () => {
    // Aqui você salvaria as políticas no backend
    toast.success('Políticas de segurança atualizadas');
  };

  return (
    <div className="space-y-6">
      <Alert>
        <Shield className="h-4 w-4" />
        <AlertDescription>
          As políticas de segurança se aplicam a todos os usuários do sistema. 
          Alterações entram em vigor imediatamente.
        </AlertDescription>
      </Alert>

      <Card className="shadow-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lock className="w-5 h-5" />
            Política de Senha
          </CardTitle>
          <CardDescription>
            Defina os requisitos mínimos para senhas de usuário
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="min_length">Comprimento Mínimo</Label>
            <Input
              id="min_length"
              type="number"
              value={policies.password_min_length}
              onChange={(e) => setPolicies({...policies, password_min_length: parseInt(e.target.value)})}
              min="6"
              max="32"
            />
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label>Exigir letra maiúscula</Label>
              <Switch
                checked={policies.password_require_uppercase}
                onCheckedChange={(checked) => setPolicies({...policies, password_require_uppercase: checked})}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label>Exigir letra minúscula</Label>
              <Switch
                checked={policies.password_require_lowercase}
                onCheckedChange={(checked) => setPolicies({...policies, password_require_lowercase: checked})}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label>Exigir número</Label>
              <Switch
                checked={policies.password_require_number}
                onCheckedChange={(checked) => setPolicies({...policies, password_require_number: checked})}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label>Exigir caractere especial</Label>
              <Switch
                checked={policies.password_require_special}
                onCheckedChange={(checked) => setPolicies({...policies, password_require_special: checked})}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="shadow-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5" />
            Autenticação Multifator (MFA)
          </CardTitle>
          <CardDescription>
            Configure as regras de autenticação de dois fatores
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label>MFA Opcional</Label>
              <p className="text-xs text-gray-500">
                Usuários podem habilitar MFA por conta própria
              </p>
            </div>
            <Switch
              checked={policies.mfa_optional}
              onCheckedChange={(checked) => setPolicies({...policies, mfa_optional: checked})}
            />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <Label>MFA Obrigatório para Admins</Label>
              <p className="text-xs text-gray-500">
                Administradores devem usar MFA
              </p>
            </div>
            <Switch
              checked={policies.mfa_required_for_admins}
              onCheckedChange={(checked) => setPolicies({...policies, mfa_required_for_admins: checked})}
            />
          </div>
        </CardContent>
      </Card>

      <Card className="shadow-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5" />
            Bloqueio e Tentativas
          </CardTitle>
          <CardDescription>
            Proteção contra tentativas de acesso indevido
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="max_attempts">Máximo de tentativas de login</Label>
            <Input
              id="max_attempts"
              type="number"
              value={policies.max_login_attempts}
              onChange={(e) => setPolicies({...policies, max_login_attempts: parseInt(e.target.value)})}
              min="3"
              max="10"
            />
          </div>
          <div>
            <Label htmlFor="lockout_duration">Duração do bloqueio (minutos)</Label>
            <Input
              id="lockout_duration"
              type="number"
              value={policies.lockout_duration_minutes}
              onChange={(e) => setPolicies({...policies, lockout_duration_minutes: parseInt(e.target.value)})}
              min="15"
              max="1440"
            />
          </div>
        </CardContent>
      </Card>

      <Card className="shadow-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Sessão
          </CardTitle>
          <CardDescription>
            Controle o tempo de inatividade permitido
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div>
            <Label htmlFor="session_timeout">Timeout de sessão (horas)</Label>
            <Input
              id="session_timeout"
              type="number"
              value={policies.session_timeout_hours}
              onChange={(e) => setPolicies({...policies, session_timeout_hours: parseInt(e.target.value)})}
              min="1"
              max="72"
            />
            <p className="text-xs text-gray-500 mt-1">
              Após este período sem atividade, o usuário será desconectado automaticamente
            </p>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button
          onClick={handleSave}
          style={{ backgroundColor: '#4B2672' }}
          className="text-white"
        >
          <Save className="w-4 h-4 mr-2" />
          Salvar Políticas
        </Button>
      </div>
    </div>
  );
}