import { base44 } from "@/api/base44Client";
import { cleanCPF } from "../utils/validators";

/**
 * Cria ou atualiza usuário master de uma consultoria
 * Cria InviteToken para que o usuário possa ativar via link
 */
export async function createOrUpdateMasterUser(consultoria, masterUserData, createdBy, isEdit = false) {
  try {
    console.log('=== createOrUpdateMasterUser START ===');
    console.log('consultoria.id:', consultoria.id);
    console.log('masterUserData.email:', masterUserData.email);
    console.log('masterUserData.senha provided:', masterUserData.senha ? 'SIM (****)' : 'NÃO');
    console.log('isEdit:', isEdit);
    
    const cleanedCPF = masterUserData.cpf ? cleanCPF(masterUserData.cpf) : null;
    const finalPassword = masterUserData.senha;
    
    if (!finalPassword) {
      console.error('❌ ERRO: Senha não fornecida!');
      throw new Error('Senha é obrigatória');
    }
    
    console.log('✅ Senha válida, prosseguindo...');
    
    // 1. SALVAR DADOS DO MASTER USER NA CONSULTORIA
    const masterUserDataToSave = {
      nome: masterUserData.nome,
      cpf: cleanedCPF,
      data_nascimento: masterUserData.data_nascimento,
      email: masterUserData.email,
      telefone: masterUserData.telefone || null,
      senha_temp: finalPassword,
      status: 'pending_activation',
      has_credentials: true,
      login_ativado: false, // Será ativado via link
      created_at: isEdit ? (consultoria.master_user_data?.created_at || new Date().toISOString()) : new Date().toISOString(),
      updated_at: new Date().toISOString(),
      created_by: createdBy
    };
    
    console.log('📝 Salvando master_user_data na consultoria');
    
    // 2. ATUALIZAR CONSULTORIA COM DADOS DO MASTER USER
    console.log('🔄 Atualizando consultoria...');
    await base44.entities.Consultoria.update(consultoria.id, {
      email_master: masterUserData.email,
      master_user_data: masterUserDataToSave
    });
    
    console.log('✅ Consultoria atualizada');
    
    // 3. CRIAR OU ATUALIZAR INVITETOKEN
    let inviteToken = null;
    let activationUrl = null;
    
    try {
      console.log('🔄 Gerenciando InviteToken...');
      
      const existingInvites = await base44.entities.InviteToken.filter({
        user_email: masterUserData.email,
        consultoria_id: consultoria.id
      });
      
      const token = `master-${consultoria.id}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 365); // 1 ano de validade
      
      if (existingInvites && existingInvites.length > 0) {
        const invite = existingInvites[0];
        if (invite.status === 'pending') {
          // Atualizar token existente
          await base44.entities.InviteToken.update(invite.id, {
            token,
            expires_at: expiresAt.toISOString(),
            created_by: createdBy
          });
          inviteToken = token;
          console.log('✅ InviteToken atualizado');
        } else {
          // Criar novo se o anterior foi aceito
          const newInvite = await base44.entities.InviteToken.create({
            user_email: masterUserData.email,
            token,
            role: 'consultoria',
            consultoria_id: consultoria.id,
            expires_at: expiresAt.toISOString(),
            created_by: createdBy,
            status: 'pending',
            additional_roles: ['master']
          });
          inviteToken = token;
          console.log('✅ Novo InviteToken criado');
        }
      } else {
        // Criar novo
        await base44.entities.InviteToken.create({
          user_email: masterUserData.email,
          token,
          role: 'consultoria',
          consultoria_id: consultoria.id,
          expires_at: expiresAt.toISOString(),
          created_by: createdBy,
          status: 'pending',
          additional_roles: ['master']
        });
        inviteToken = token;
        console.log('✅ InviteToken criado');
      }
      
      // Gerar URL de ativação
      activationUrl = `${window.location.origin}/activate-master-user?token=${inviteToken}`;
      console.log('✅ URL de ativação gerada:', activationUrl);
      
    } catch (inviteError) {
      console.error('⚠️ Erro ao gerenciar convite:', inviteError);
    }
    
    console.log('=== createOrUpdateMasterUser END ===');
    
    return {
      success: true,
      temp_password: finalPassword,
      master_user_data: masterUserDataToSave,
      invite_token: inviteToken,
      activation_url: activationUrl,
      message: isEdit 
        ? 'Dados do usuário master atualizados! Envie o link de ativação para o usuário.' 
        : 'Usuário master criado! Envie o link de ativação para o usuário fazer login.',
      email_sent: false
    };
    
  } catch (error) {
    console.error('❌ Error in createOrUpdateMasterUser:', error);
    throw new Error(error.message || 'Erro ao configurar usuário master');
  }
}