import { base44 } from "@/api/base44Client";
import { generateTemporaryPassword } from "../utils/passwordGenerator";

/**
 * Ativa o usuário master de uma consultoria
 * Cria o usuário no sistema e envia email de boas-vindas
 */
export async function activateMasterUser(consultoriaId, sendWelcomeEmail = true, activatedBy) {
  try {
    console.log('=== activateMasterUser ===');
    console.log('consultoriaId:', consultoriaId);
    console.log('sendWelcomeEmail:', sendWelcomeEmail);
    
    // Buscar consultoria
    const consultorias = await base44.entities.Consultoria.filter({ id: consultoriaId });
    if (!consultorias || consultorias.length === 0) {
      throw new Error('Consultoria não encontrada');
    }
    
    const consultoria = consultorias[0];
    const masterData = consultoria.master_user_data || {};
    
    if (!masterData.email) {
      throw new Error('Email do usuário master não está configurado');
    }
    
    if (!masterData.has_credentials) {
      throw new Error('Credenciais do usuário master não foram definidas. Edite a consultoria e configure a senha.');
    }
    
    // Verificar se já existe usuário com este email
    const existingUsers = await base44.entities.User.filter({ email: masterData.email });
    
    let userId;
    let tempPassword = masterData.senha_temp;
    
    if (existingUsers && existingUsers.length > 0) {
      // Usuário já existe, apenas atualizar
      userId = existingUsers[0].id;
      await base44.entities.User.update(userId, {
        consultoria_id: consultoriaId,
        user_role: 'consultoria',
        is_master: true,
        status: 'active'
      });
    } else {
      // Criar novo usuário
      // IMPORTANTE: Não podemos criar usuários diretamente no base44
      // Vamos apenas marcar como ativo e o usuário usará a senha temporária no primeiro login
      throw new Error('Sistema não permite criação direta de usuários. Use o link de ativação para que o usuário se registre.');
    }
    
    // Atualizar consultoria com status ativo
    await base44.entities.Consultoria.update(consultoriaId, {
      master_user_data: {
        ...masterData,
        status: 'active',
        user_id: userId,
        activated_at: new Date().toISOString(),
        activated_by: activatedBy
      }
    });
    
    // Enviar email de boas-vindas APENAS se o usuário já existe no sistema
    if (sendWelcomeEmail && userId) {
      try {
        await base44.integrations.Core.SendEmail({
          from_name: 'iMental',
          to: masterData.email,
          subject: `Conta Ativada - ${consultoria.nome_fantasia}`,
          body: `
            <h2>Sua conta foi ativada!</h2>
            <p>Olá ${masterData.nome},</p>
            <p>Sua conta de administrador da consultoria <strong>${consultoria.nome_fantasia}</strong> foi ativada com sucesso.</p>
            
            <h3>📋 Seus dados de acesso:</h3>
            <ul>
              <li><strong>Email:</strong> ${masterData.email}</li>
              <li><strong>Senha Temporária:</strong> ${tempPassword}</li>
            </ul>
            
            <h3>🔐 Como Acessar:</h3>
            <p><a href="${window.location.origin}/login" style="background: #4B2672; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block; margin: 16px 0;">Fazer Login</a></p>
            
            <p style="color: #666; font-size: 12px; margin-top: 24px;">
              ⚠️ Por segurança, você precisará trocar a senha no primeiro login.
            </p>
            
            <p>Em caso de dúvidas, entre em contato com o suporte.</p>
            <p>Atenciosamente,<br/>Equipe iMental</p>
          `
        });
      } catch (emailError) {
        console.error('Erro ao enviar email:', emailError);
        // Não falhar a ativação se o email não for enviado
      }
    }
    
    return {
      success: true,
      user_id: userId,
      temp_password: tempPassword,
      message: 'Usuário ativado com sucesso!',
      email_sent: sendWelcomeEmail && userId
    };
    
  } catch (error) {
    console.error('Error in activateMasterUser:', error);
    throw error;
  }
}

/**
 * Inativa o usuário master de uma consultoria
 */
export async function deactivateMasterUser(consultoriaId, deactivatedBy) {
  try {
    console.log('=== deactivateMasterUser ===');
    console.log('consultoriaId:', consultoriaId);
    
    // Buscar consultoria
    const consultorias = await base44.entities.Consultoria.filter({ id: consultoriaId });
    if (!consultorias || consultorias.length === 0) {
      throw new Error('Consultoria não encontrada');
    }
    
    const consultoria = consultorias[0];
    const masterData = consultoria.master_user_data || {};
    
    // Atualizar status no user (se existir)
    if (masterData.user_id) {
      try {
        await base44.entities.User.update(masterData.user_id, {
          status: 'disabled'
        });
      } catch (error) {
        console.error('Erro ao desativar usuário:', error);
        // Continuar mesmo se falhar
      }
    }
    
    // Atualizar consultoria
    await base44.entities.Consultoria.update(consultoriaId, {
      master_user_data: {
        ...masterData,
        status: 'inactive',
        deactivated_at: new Date().toISOString(),
        deactivated_by: deactivatedBy
      }
    });
    
    return {
      success: true,
      message: 'Usuário master inativado com sucesso. O acesso foi bloqueado.'
    };
    
  } catch (error) {
    console.error('Error in deactivateMasterUser:', error);
    throw error;
  }
}