import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  User, 
  Mail, 
  Calendar, 
  Shield, 
  AlertCircle, 
  CheckCircle,
  Key,
  IdCard,
  Phone,
  Copy
} from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";
import { formatCPF } from "../utils/validators";

export default function MasterUserInfo({ consultoriaId, masterUserData: initialMasterUserData, onClose }) {
  console.log('=== MasterUserInfo Component Mounted ===');
  console.log('consultoriaId:', consultoriaId);
  console.log('initialMasterUserData:', initialMasterUserData);

  // Buscar consultoria atualizada
  const { data: consultoria, isLoading, error } = useQuery({
    queryKey: ['consultoria-master-detail', consultoriaId],
    queryFn: async () => {
      console.log('=== Fetching consultoria ===');
      console.log('consultoriaId:', consultoriaId);
      
      try {
        const consultorias = await base44.entities.Consultoria.filter({ id: consultoriaId });
        console.log('Fetched consultorias:', consultorias);
        
        if (!consultorias || consultorias.length === 0) {
          throw new Error('Consultoria não encontrada');
        }
        
        const found = consultorias[0];
        console.log('Found consultoria:', found);
        console.log('master_user_data:', found.master_user_data);
        
        return found;
      } catch (err) {
        console.error('Error fetching consultoria:', err);
        throw err;
      }
    },
    enabled: !!consultoriaId,
    refetchOnWindowFocus: false
  });

  const masterData = consultoria?.master_user_data || initialMasterUserData;

  console.log('=== Render MasterUserInfo ===');
  console.log('masterData:', masterData);
  console.log('masterData.status:', masterData?.status);
  console.log('masterData.login_ativado:', masterData?.login_ativado);

  const copyToClipboard = (text, label) => {
    navigator.clipboard.writeText(text);
    toast.success(`${label} copiado!`);
  };

  const copyCredentials = () => {
    const credentials = `E-mail: ${masterData.email}\nSenha: ${masterData.senha_temp}`;
    navigator.clipboard.writeText(credentials);
    toast.success('Credenciais copiadas!');
  };

  const copyActivationLink = async () => {
    try {
      // Buscar InviteToken
      const invites = await base44.entities.InviteToken.filter({
        user_email: masterData.email,
        consultoria_id: consultoriaId,
        status: 'pending'
      });

      if (invites && invites.length > 0) {
        const token = invites[0].token;
        const activationUrl = `${window.location.origin}/activate-master-user?token=${token}`;
        navigator.clipboard.writeText(activationUrl);
        toast.success('Link de ativação copiado!');
      } else {
        toast.error('Token de ativação não encontrado');
      }
    } catch (error) {
      console.error('Error copying activation link:', error);
      toast.error('Erro ao copiar link');
    }
  };

  if (isLoading) {
    return (
      <Dialog open onOpenChange={onClose}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Carregando...</DialogTitle>
          </DialogHeader>
          <div className="py-8 text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 mx-auto" style={{ borderColor: '#4B2672' }}></div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  if (error || !masterData) {
    return (
      <Dialog open onOpenChange={onClose}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Erro</DialogTitle>
          </DialogHeader>
          <Alert className="bg-red-50 border-red-200">
            <AlertDescription className="text-red-800">
              {error?.message || 'Dados do usuário master não encontrados'}
            </AlertDescription>
          </Alert>
        </DialogContent>
      </Dialog>
    );
  }

  const isActive = masterData.login_ativado === true;
  const isPending = masterData.status === 'pending_activation' || !masterData.login_ativado;

  console.log('isActive:', isActive);
  console.log('isPending:', isPending);

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5" style={{ color: '#4B2672' }} />
            Credenciais do Usuário Master
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Status Badge */}
          <div className="flex items-center justify-between p-4 rounded-lg" style={{ 
            backgroundColor: isActive ? '#F0FDF4' : '#FFF7ED'
          }}>
            <div className="flex items-center gap-3">
              {isActive ? (
                <CheckCircle className="w-6 h-6 text-green-600" />
              ) : (
                <Key className="w-6 h-6 text-orange-600" />
              )}
              <div>
                <p className="font-semibold" style={{ 
                  color: isActive ? '#15803D' : '#C2410C'
                }}>
                  {isActive ? 'Login Ativo' : 'Login Inativo'}
                </p>
                <p className="text-sm text-gray-600">
                  {isActive 
                    ? 'O usuário pode fazer login no sistema'
                    : 'O login não foi ativado'}
                </p>
              </div>
            </div>
            <Badge className={
              isActive ? 'bg-green-100 text-green-800' : 'bg-orange-100 text-orange-800'
            }>
              {isActive ? '✓ Ativo' : '○ Inativo'}
            </Badge>
          </div>

          {/* Alerta de Ativação Pendente - SEMPRE MOSTRAR SE NÃO ESTIVER ATIVO */}
          {!isActive && (
            <Alert className="bg-orange-50 border-orange-200">
              <AlertCircle className="h-4 w-4 text-orange-600" />
              <AlertDescription className="text-orange-800">
                <p className="font-semibold mb-2">🔐 Ativação Necessária</p>
                <p className="text-sm mb-3">
                  Para fazer login, o usuário master precisa ativar a conta através do link de ativação.
                </p>
                <Button
                  onClick={copyActivationLink}
                  size="sm"
                  className="bg-orange-600 hover:bg-orange-700 text-white"
                >
                  <Copy className="w-3 h-3 mr-2" />
                  Copiar Link de Ativação
                </Button>
                <p className="text-xs text-orange-600 mt-2">
                  💡 Envie este link para o usuário master ativar a conta.
                </p>
              </AlertDescription>
            </Alert>
          )}

          {/* Informações do Usuário */}
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <User className="w-5 h-5 mt-1 text-gray-400" />
              <div className="flex-1">
                <p className="text-sm text-gray-500">Nome Completo</p>
                <p className="font-semibold text-gray-900">{masterData.nome}</p>
                <p className="text-sm text-gray-500 mt-1">Administrador Master - {consultoria?.nome_fantasia}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-start gap-3 p-4 rounded-lg bg-gray-50">
                <Mail className="w-5 h-5 mt-1 text-gray-400" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-gray-500">E-mail/Login:</p>
                  <p className="font-semibold text-gray-900 truncate">{masterData.email}</p>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => copyToClipboard(masterData.email, 'E-mail')}
                    className="mt-2 h-7 text-xs"
                  >
                    <Copy className="w-3 h-3 mr-1" />
                    Copiar
                  </Button>
                </div>
              </div>

              <div className="flex items-start gap-3 p-4 rounded-lg bg-gray-50">
                <Key className="w-5 h-5 mt-1 text-gray-400" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-gray-500">Senha:</p>
                  <p className="font-semibold text-gray-900 font-mono">{masterData.senha_temp}</p>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => copyToClipboard(masterData.senha_temp, 'Senha')}
                    className="mt-2 h-7 text-xs"
                  >
                    <Copy className="w-3 h-3 mr-1" />
                    Copiar
                  </Button>
                </div>
              </div>

              {masterData.cpf && (
                <div className="flex items-start gap-3">
                  <IdCard className="w-5 h-5 mt-1 text-gray-400" />
                  <div>
                    <p className="text-sm text-gray-500">CPF:</p>
                    <p className="font-semibold text-gray-900">{formatCPF(masterData.cpf)}</p>
                  </div>
                </div>
              )}

              {masterData.data_nascimento && (
                <div className="flex items-start gap-3">
                  <Calendar className="w-5 h-5 mt-1 text-gray-400" />
                  <div>
                    <p className="text-sm text-gray-500">Data de Nascimento:</p>
                    <p className="font-semibold text-gray-900">
                      {format(new Date(masterData.data_nascimento), 'dd/MM/yyyy')}
                    </p>
                  </div>
                </div>
              )}

              {masterData.telefone && (
                <div className="flex items-start gap-3">
                  <Phone className="w-5 h-5 mt-1 text-gray-400" />
                  <div>
                    <p className="text-sm text-gray-500">Telefone:</p>
                    <p className="font-semibold text-gray-900">{masterData.telefone}</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Informações de Auditoria */}
          {masterData.created_at && (
            <div className="pt-4 border-t text-xs text-gray-500">
              <p>Dados de usuário master criados em: {format(new Date(masterData.created_at), 'dd/MM/yyyy HH:mm')}</p>
              {masterData.updated_at && masterData.updated_at !== masterData.created_at && (
                <p className="mt-1">Última atualização: {format(new Date(masterData.updated_at), 'dd/MM/yyyy HH:mm')}</p>
              )}
            </div>
          )}

          {/* Ações */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            {!isActive && (
              <Button variant="outline" onClick={copyActivationLink}>
                <Copy className="w-4 h-4 mr-2" />
                Copiar Link de Ativação
              </Button>
            )}
            <Button variant="outline" onClick={copyCredentials}>
              <Copy className="w-4 h-4 mr-2" />
              Copiar Credenciais
            </Button>
            <Button onClick={onClose} className="text-white" style={{ backgroundColor: '#4B2672' }}>
              Fechar
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}