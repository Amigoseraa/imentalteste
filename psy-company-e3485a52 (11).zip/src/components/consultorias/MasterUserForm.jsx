import React, { useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Eye, EyeOff, AlertCircle, CheckCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  validateCPF, 
  formatCPF, 
  cleanCPF, 
  validateEmail, 
  validatePassword, 
  isAdult, 
  dateFromISO 
} from "../utils/validators";

export default function MasterUserForm({ formData, onChange, errors, setErrors, isEdit = false }) {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const handleCPFChange = (value) => {
    const formatted = formatCPF(value);
    onChange({ ...formData, cpf: formatted });
    
    // Validar CPF apenas se foi preenchido
    if (formatted) {
      const cleaned = cleanCPF(formatted);
      if (cleaned.length === 11) {
        if (!validateCPF(cleaned)) {
          setErrors({ ...errors, cpf: 'CPF inválido' });
        } else {
          const newErrors = { ...errors };
          delete newErrors.cpf;
          setErrors(newErrors);
        }
      }
    } else {
      const newErrors = { ...errors };
      delete newErrors.cpf;
      setErrors(newErrors);
    }
  };

  const handleEmailChange = (value) => {
    onChange({ ...formData, email: value });
    
    if (value && !validateEmail(value)) {
      setErrors({ ...errors, email: 'E-mail inválido' });
    } else {
      const newErrors = { ...errors };
      delete newErrors.email;
      setErrors(newErrors);
    }
  };

  const handlePasswordChange = (value) => {
    onChange({ ...formData, senha: value });
    
    if (value) {
      const validation = validatePassword(value);
      if (!validation.valid) {
        setErrors({ ...errors, senha: validation.message });
      } else {
        const newErrors = { ...errors };
        delete newErrors.senha;
        setErrors(newErrors);
      }
      
      // Validar confirmação se já preenchida
      if (formData.confirmacao_senha && value !== formData.confirmacao_senha) {
        setErrors({ ...errors, confirmacao_senha: 'As senhas não coincidem' });
      } else if (formData.confirmacao_senha) {
        const newErrors = { ...errors };
        delete newErrors.confirmacao_senha;
        setErrors(newErrors);
      }
    } else {
      const newErrors = { ...errors };
      delete newErrors.senha;
      setErrors(newErrors);
    }
  };

  const handleConfirmPasswordChange = (value) => {
    onChange({ ...formData, confirmacao_senha: value });
    
    if (value && value !== formData.senha) {
      setErrors({ ...errors, confirmacao_senha: 'As senhas não coincidem' });
    } else {
      const newErrors = { ...errors };
      delete newErrors.confirmacao_senha;
      setErrors(newErrors);
    }
  };

  const handleBirthDateChange = (value) => {
    onChange({ ...formData, data_nascimento: value });
    
    if (value && !isAdult(value)) {
      setErrors({ ...errors, data_nascimento: 'Usuário deve ser maior de 18 anos' });
    } else {
      const newErrors = { ...errors };
      delete newErrors.data_nascimento;
      setErrors(newErrors);
    }
  };

  return (
    <div className="space-y-6">
      <div className="border-t pt-6">
        <h3 className="text-lg font-semibold mb-4" style={{ color: '#2E2E2E' }}>
          👤 Usuário Master da Consultoria
        </h3>
        
        <Alert className="mb-4 bg-purple-50 border-purple-200">
          <AlertCircle className="h-4 w-4" style={{ color: '#4B2672' }} />
          <AlertDescription className="text-sm" style={{ color: '#2E2E2E' }}>
            {isEdit ? (
              <>Preencha apenas os campos que deseja alterar. Campos vazios não serão modificados.</>
            ) : (
              <>O usuário master terá acesso completo para gerenciar a consultoria e suas empresas.</>
            )}
          </AlertDescription>
        </Alert>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Nome Completo */}
          <div className="md:col-span-2">
            <Label htmlFor="master_nome">Nome Completo {!isEdit && '*'}</Label>
            <Input
              id="master_nome"
              value={formData.nome || ''}
              onChange={(e) => onChange({ ...formData, nome: e.target.value })}
              placeholder={isEdit ? "Deixe vazio para não alterar" : "Nome completo do responsável"}
              className={errors.nome ? 'border-red-500' : ''}
            />
            {errors.nome && (
              <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                {errors.nome}
              </p>
            )}
          </div>

          {/* CPF */}
          <div>
            <Label htmlFor="master_cpf">CPF {!isEdit && '*'}</Label>
            <Input
              id="master_cpf"
              value={formData.cpf || ''}
              onChange={(e) => handleCPFChange(e.target.value)}
              placeholder={isEdit ? "Deixe vazio para não alterar" : "000.000.000-00"}
              maxLength={14}
              className={errors.cpf ? 'border-red-500' : ''}
            />
            {errors.cpf && (
              <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                {errors.cpf}
              </p>
            )}
          </div>

          {/* Data de Nascimento */}
          <div>
            <Label htmlFor="master_data_nascimento">Data de Nascimento {!isEdit && '*'}</Label>
            <Input
              id="master_data_nascimento"
              type="date"
              value={formData.data_nascimento || ''}
              onChange={(e) => handleBirthDateChange(e.target.value)}
              className={errors.data_nascimento ? 'border-red-500' : ''}
            />
            {errors.data_nascimento && (
              <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                {errors.data_nascimento}
              </p>
            )}
          </div>

          {/* E-mail */}
          <div className="md:col-span-2">
            <Label htmlFor="master_email">E-mail {!isEdit && '*'}</Label>
            <Input
              id="master_email"
              type="email"
              value={formData.email || ''}
              onChange={(e) => handleEmailChange(e.target.value)}
              placeholder="email@consultoria.com"
              className={errors.email ? 'border-red-500' : ''}
            />
            {errors.email && (
              <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                {errors.email}
              </p>
            )}
          </div>

          {/* Senha */}
          <div>
            <Label htmlFor="master_senha">
              Senha {!isEdit ? '*' : '(deixe em branco para não alterar)'}
            </Label>
            <div className="relative">
              <Input
                id="master_senha"
                type={showPassword ? 'text' : 'password'}
                value={formData.senha || ''}
                onChange={(e) => handlePasswordChange(e.target.value)}
                placeholder={isEdit ? "Deixe vazio para não alterar" : "Mínimo 8 caracteres"}
                className={errors.senha ? 'border-red-500 pr-10' : 'pr-10'}
              />
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="absolute right-0 top-0 h-full"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? (
                  <EyeOff className="w-4 h-4 text-gray-500" />
                ) : (
                  <Eye className="w-4 h-4 text-gray-500" />
                )}
              </Button>
            </div>
            {errors.senha && (
              <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                {errors.senha}
              </p>
            )}
            {!errors.senha && formData.senha && validatePassword(formData.senha).valid && (
              <p className="text-xs text-green-600 mt-1 flex items-center gap-1">
                <CheckCircle className="w-3 h-3" />
                Senha forte
              </p>
            )}
          </div>

          {/* Confirmar Senha */}
          <div>
            <Label htmlFor="master_confirmacao_senha">
              Confirmar Senha {!isEdit && formData.senha ? '*' : ''}
            </Label>
            <div className="relative">
              <Input
                id="master_confirmacao_senha"
                type={showConfirmPassword ? 'text' : 'password'}
                value={formData.confirmacao_senha || ''}
                onChange={(e) => handleConfirmPasswordChange(e.target.value)}
                placeholder="Repita a senha"
                className={errors.confirmacao_senha ? 'border-red-500 pr-10' : 'pr-10'}
              />
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="absolute right-0 top-0 h-full"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
              >
                {showConfirmPassword ? (
                  <EyeOff className="w-4 h-4 text-gray-500" />
                ) : (
                  <Eye className="w-4 h-4 text-gray-500" />
                )}
              </Button>
            </div>
            {errors.confirmacao_senha && (
              <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                {errors.confirmacao_senha}
              </p>
            )}
            {!errors.confirmacao_senha && formData.confirmacao_senha && formData.senha === formData.confirmacao_senha && (
              <p className="text-xs text-green-600 mt-1 flex items-center gap-1">
                <CheckCircle className="w-3 h-3" />
                Senhas coincidem
              </p>
            )}
          </div>
        </div>

        {/* Checkbox de enviar e-mail */}
        {!isEdit && (
          <div className="flex items-center gap-2 mt-4">
            <Checkbox
              id="enviar_boas_vindas"
              checked={formData.enviar_boas_vindas !== false}
              onCheckedChange={(checked) => 
                onChange({ ...formData, enviar_boas_vindas: checked })
              }
            />
            <Label 
              htmlFor="enviar_boas_vindas" 
              className="text-sm font-normal cursor-pointer"
            >
              Enviar e-mail de boas-vindas com link de acesso
            </Label>
          </div>
        )}

        <div className="mt-4 p-3 bg-gray-50 rounded-lg">
          <p className="text-xs text-gray-600 leading-relaxed">
            💡 <strong>Requisitos de senha:</strong> Mínimo 8 caracteres, com pelo menos uma letra e um número.
          </p>
          {isEdit && (
            <p className="text-xs text-gray-600 leading-relaxed mt-1">
              ℹ️ <strong>Modo edição:</strong> Campos vazios não serão alterados. Preencha apenas o que deseja modificar.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}