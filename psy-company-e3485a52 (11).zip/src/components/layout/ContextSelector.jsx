import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Building2, Briefcase, Eye, X, RefreshCw, AlertCircle, User } from "lucide-react";
import { toast } from "sonner";

export default function ContextSelector({ user, onContextChange }) {
  const [showDialog, setShowDialog] = useState(false);
  const [selectedType, setSelectedType] = useState('consultoria');
  const [selectedConsultoriaId, setSelectedConsultoriaId] = useState('');
  const [selectedCompanyId, setSelectedCompanyId] = useState('');
  const [selectedEmployeeId, setSelectedEmployeeId] = useState('');
  const [currentContext, setCurrentContext] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const { data: consultorias = [], isError: consultoriasError } = useQuery({
    queryKey: ['consultorias-selector'],
    queryFn: async () => {
      try {
        return await base44.entities.Consultoria.filter({ status: 'ativo' });
      } catch (error) {
        console.error('Error loading consultorias:', error);
        return [];
      }
    },
    enabled: user?.role === 'admin',
    initialData: [],
    retry: 1,
  });

  const { data: companies = [] } = useQuery({
    queryKey: ['companies-selector', selectedConsultoriaId],
    queryFn: async () => {
      if (!selectedConsultoriaId) return [];
      try {
        return await base44.entities.Company.filter({ consultoria_id: selectedConsultoriaId });
      } catch (error) {
        console.error('Error loading companies:', error);
        return [];
      }
    },
    enabled: user?.role === 'admin' && (selectedType === 'empresa' || selectedType === 'colaborador') && !!selectedConsultoriaId,
    initialData: [],
    retry: 1,
  });

  const { data: employees = [] } = useQuery({
    queryKey: ['employees-selector', selectedCompanyId],
    queryFn: async () => {
      if (!selectedCompanyId) return [];
      try {
        return await base44.entities.Employee.filter({ company_id: selectedCompanyId, status: 'active' });
      } catch (error) {
        console.error('Error loading employees:', error);
        return [];
      }
    },
    enabled: user?.role === 'admin' && selectedType === 'colaborador' && !!selectedCompanyId,
    initialData: [],
    retry: 1,
  });

  useEffect(() => {
    const impersonationData = localStorage.getItem('admin_impersonation');
    if (impersonationData) {
      try {
        const parsed = JSON.parse(impersonationData);
        setCurrentContext(parsed);
      } catch (error) {
        console.error('Error parsing impersonation data:', error);
        localStorage.removeItem('admin_impersonation');
      }
    }
  }, []);

  const handleApplyContext = async () => {
    if (!selectedType) {
      toast.error('Selecione o tipo de visualização');
      return;
    }

    setIsLoading(true);

    try {
      if (selectedType === 'consultoria') {
        if (!selectedConsultoriaId) {
          toast.error('Selecione uma consultoria');
          setIsLoading(false);
          return;
        }

        const consultoria = consultorias.find(c => c.id === selectedConsultoriaId);
        if (!consultoria) {
          toast.error('Consultoria não encontrada');
          setIsLoading(false);
          return;
        }

        const context = {
          type: 'consultoria',
          consultoria_id: selectedConsultoriaId,
          consultoria_nome: consultoria.nome_fantasia,
          company_id: null,
          company_nome: null,
          employee_id: null,
          employee_nome: null
        };

        localStorage.setItem('admin_impersonation', JSON.stringify(context));
        setCurrentContext(context);
        setShowDialog(false);
        
        toast.success(`Visualizando como: ${consultoria.nome_fantasia}`);
        
        if (onContextChange) {
          await onContextChange(context);
        }
        
        window.location.href = '/ConsultoriaDashboard';
      } else if (selectedType === 'empresa') {
        if (!selectedConsultoriaId) {
          toast.error('Selecione uma consultoria primeiro');
          setIsLoading(false);
          return;
        }

        if (!selectedCompanyId) {
          toast.error('Selecione uma empresa');
          setIsLoading(false);
          return;
        }

        const consultoria = consultorias.find(c => c.id === selectedConsultoriaId);
        const company = companies.find(c => c.id === selectedCompanyId);

        if (!company) {
          toast.error('Empresa não encontrada');
          setIsLoading(false);
          return;
        }

        const context = {
          type: 'empresa',
          consultoria_id: selectedConsultoriaId,
          consultoria_nome: consultoria?.nome_fantasia || '',
          company_id: selectedCompanyId,
          company_nome: company.name,
          employee_id: null,
          employee_nome: null
        };

        localStorage.setItem('admin_impersonation', JSON.stringify(context));
        setCurrentContext(context);
        setShowDialog(false);
        
        toast.success(`Visualizando como: ${company.name}`);
        
        if (onContextChange) {
          await onContextChange(context);
        }
        
        window.location.href = '/Dashboard';
      } else if (selectedType === 'colaborador') {
        if (!selectedConsultoriaId) {
          toast.error('Selecione uma consultoria primeiro');
          setIsLoading(false);
          return;
        }

        if (!selectedCompanyId) {
          toast.error('Selecione uma empresa');
          setIsLoading(false);
          return;
        }

        if (!selectedEmployeeId) {
          toast.error('Selecione um colaborador');
          setIsLoading(false);
          return;
        }

        const consultoria = consultorias.find(c => c.id === selectedConsultoriaId);
        const company = companies.find(c => c.id === selectedCompanyId);
        const employee = employees.find(e => e.id === selectedEmployeeId);

        if (!employee) {
          toast.error('Colaborador não encontrado');
          setIsLoading(false);
          return;
        }

        const context = {
          type: 'colaborador',
          consultoria_id: selectedConsultoriaId,
          consultoria_nome: consultoria?.nome_fantasia || '',
          company_id: selectedCompanyId,
          company_nome: company?.name || '',
          employee_id: selectedEmployeeId,
          employee_nome: employee.name
        };

        localStorage.setItem('admin_impersonation', JSON.stringify(context));
        setCurrentContext(context);
        setShowDialog(false);
        
        toast.success(`Visualizando como: ${employee.name}`);
        
        if (onContextChange) {
          await onContextChange(context);
        }
        
        window.location.href = '/ColaboradorAvaliacoes';
      }
    } catch (error) {
      console.error('Error applying context:', error);
      toast.error('Erro ao aplicar contexto. Tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleClearContext = async () => {
    setIsLoading(true);
    
    try {
      localStorage.removeItem('admin_impersonation');
      setCurrentContext(null);
      setSelectedType('consultoria');
      setSelectedConsultoriaId('');
      setSelectedCompanyId('');
      setSelectedEmployeeId('');
      
      toast.info('Voltando para visão de administrador');
      
      if (onContextChange) {
        await onContextChange(null);
      }
      
      window.location.href = '/AdminDashboard';
    } catch (error) {
      console.error('Error clearing context:', error);
      toast.error('Erro ao limpar contexto. Recarregando...');
      window.location.href = '/AdminDashboard';
    } finally {
      setIsLoading(false);
    }
  };

  if (user?.role !== 'admin') {
    return null;
  }

  return (
    <div className="border-b px-4 py-2" style={{ backgroundColor: '#F8F6FB', borderColor: '#E5E1EB' }}>
      <div className="max-w-[1800px] mx-auto flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Eye className="w-4 h-4" style={{ color: '#6B5B7F' }} />
          <span className="text-sm font-medium" style={{ color: '#6B5B7F' }}>
            Contexto de visualização:
          </span>
          
          {currentContext ? (
            <div className="flex items-center gap-2 flex-wrap">
              {currentContext.type === 'consultoria' ? (
                <Badge variant="outline" className="flex items-center gap-1">
                  <Briefcase className="w-3 h-3" />
                  Consultoria: {currentContext.consultoria_nome}
                </Badge>
              ) : currentContext.type === 'empresa' ? (
                <>
                  <Badge variant="outline" className="flex items-center gap-1">
                    <Briefcase className="w-3 h-3" />
                    {currentContext.consultoria_nome}
                  </Badge>
                  <Badge variant="outline" className="flex items-center gap-1">
                    <Building2 className="w-3 h-3" />
                    {currentContext.company_nome}
                  </Badge>
                </>
              ) : currentContext.type === 'colaborador' ? (
                <>
                  <Badge variant="outline" className="flex items-center gap-1 text-xs">
                    <Briefcase className="w-3 h-3" />
                    {currentContext.consultoria_nome}
                  </Badge>
                  <Badge variant="outline" className="flex items-center gap-1 text-xs">
                    <Building2 className="w-3 h-3" />
                    {currentContext.company_nome}
                  </Badge>
                  <Badge variant="outline" className="flex items-center gap-1 text-xs">
                    <User className="w-3 h-3" />
                    {currentContext.employee_nome}
                  </Badge>
                </>
              ) : null}
              <Button
                variant="ghost"
                size="sm"
                onClick={handleClearContext}
                disabled={isLoading}
                className="h-7"
              >
                <X className="w-3 h-3 mr-1" />
                Limpar
              </Button>
            </div>
          ) : (
            <Badge variant="outline">
              Administrador iMental (visão global)
            </Badge>
          )}
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={() => setShowDialog(true)}
          disabled={isLoading}
          style={{ borderColor: '#4B2672', color: '#4B2672' }}
        >
          <Eye className="w-4 h-4 mr-2" />
          Visualizar Como...
        </Button>
      </div>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Eye className="w-5 h-5" style={{ color: '#4B2672' }} />
              Visualizar Contexto
            </DialogTitle>
            <DialogDescription>
              Selecione uma consultoria, empresa ou colaborador para visualizar o sistema sob sua perspectiva.
            </DialogDescription>
          </DialogHeader>

          {consultoriasError && (
            <Alert className="border-yellow-200 bg-yellow-50">
              <AlertCircle className="h-4 w-4 text-yellow-600" />
              <AlertDescription className="text-yellow-800 text-sm">
                Erro ao carregar consultorias. Verifique sua conexão.
              </AlertDescription>
            </Alert>
          )}

          <div className="space-y-4 py-4">
            <div>
              <label className="text-sm font-medium mb-2 block">
                Tipo de Visualização
              </label>
              <Select value={selectedType} onValueChange={(value) => {
                setSelectedType(value);
                setSelectedConsultoriaId('');
                setSelectedCompanyId('');
                setSelectedEmployeeId('');
              }}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="consultoria">
                    <div className="flex items-center gap-2">
                      <Briefcase className="w-4 h-4" />
                      Ver como Consultoria
                    </div>
                  </SelectItem>
                  <SelectItem value="empresa">
                    <div className="flex items-center gap-2">
                      <Building2 className="w-4 h-4" />
                      Ver como Empresa
                    </div>
                  </SelectItem>
                  <SelectItem value="colaborador">
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4" />
                      Ver como Colaborador
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            {selectedType && (
              <div>
                <label className="text-sm font-medium mb-2 block">
                  Selecione uma Consultoria
                </label>
                <Select 
                  value={selectedConsultoriaId} 
                  onValueChange={(value) => {
                    setSelectedConsultoriaId(value);
                    setSelectedCompanyId('');
                    setSelectedEmployeeId('');
                  }}
                  disabled={consultorias.length === 0}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Escolha uma consultoria" />
                  </SelectTrigger>
                  <SelectContent>
                    {consultorias.map((cons) => (
                      <SelectItem key={cons.id} value={cons.id}>
                        {cons.nome_fantasia}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {(selectedType === 'empresa' || selectedType === 'colaborador') && selectedConsultoriaId && (
              <div>
                <label className="text-sm font-medium mb-2 block">
                  Selecione uma Empresa
                </label>
                <Select 
                  value={selectedCompanyId} 
                  onValueChange={(value) => {
                    setSelectedCompanyId(value);
                    setSelectedEmployeeId('');
                  }}
                  disabled={companies.length === 0}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Escolha uma empresa" />
                  </SelectTrigger>
                  <SelectContent>
                    {companies.map((comp) => (
                      <SelectItem key={comp.id} value={comp.id}>
                        {comp.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {selectedType === 'colaborador' && selectedCompanyId && (
              <div>
                <label className="text-sm font-medium mb-2 block">
                  Selecione um Colaborador
                </label>
                <Select 
                  value={selectedEmployeeId} 
                  onValueChange={setSelectedEmployeeId}
                  disabled={employees.length === 0}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Escolha um colaborador" />
                  </SelectTrigger>
                  <SelectContent>
                    {employees.map((emp) => (
                      <SelectItem key={emp.id} value={emp.id}>
                        {emp.name} - {emp.position || 'Sem cargo'}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>

          <div className="flex justify-end gap-3">
            <Button 
              variant="outline" 
              onClick={() => setShowDialog(false)}
              disabled={isLoading}
            >
              Cancelar
            </Button>
            <Button 
              onClick={handleApplyContext}
              disabled={
                isLoading || 
                !selectedConsultoriaId || 
                (selectedType === 'empresa' && !selectedCompanyId) ||
                (selectedType === 'colaborador' && (!selectedCompanyId || !selectedEmployeeId))
              }
              className="text-white"
              style={{ backgroundColor: '#4B2672' }}
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Aplicando...
                </>
              ) : (
                'Aplicar Contexto'
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}