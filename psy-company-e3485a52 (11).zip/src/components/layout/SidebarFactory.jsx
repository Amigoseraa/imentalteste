
import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Home,
  Building2,
  ClipboardList,
  Users,
  Settings,
  FileText,
  LayoutDashboard,
  DollarSign,
  Briefcase,
  Package,
  Activity,
  Building,
  BookOpen, // Added BookOpen icon
  ShieldAlert // Added ShieldAlert icon for Denúncias
} from "lucide-react";
import { ChevronDown } from "lucide-react";
import { Button } from '@/components/ui/button'; // Added import for Button

function SidebarItem({ item }) {
  const location = useLocation();
  const [isOpen, setIsOpen] = useState(false);
  
  // Verificar se algum submenu está ativo
  React.useEffect(() => {
    if (item.submenu) {
      const isAnyActive = item.submenu.some(sub => {
        const subPath = createPageUrl(sub.path.replace('/', ''));
        return location.pathname === subPath;
      });
      setIsOpen(isAnyActive);
    }
  }, [location.pathname, item.submenu]);
  
  // Item com submenu
  if (item.submenu) {
    return (
      <div className="mb-1">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors hover:bg-gray-100"
          style={{ 
            backgroundColor: isOpen ? '#F3F0F7' : 'transparent',
            color: isOpen ? '#4B2672' : '#6B5B7F' 
          }}
        >
          {item.icon && <item.icon className="w-5 h-5 flex-shrink-0" />}
          <span className="flex-1 text-left">{item.label}</span>
          <ChevronDown 
            className={`w-4 h-4 transition-transform ${isOpen ? 'rotate-180' : ''}`} 
          />
        </button>
        {isOpen && (
          <div className="ml-4 mt-1 space-y-1">
            {item.submenu.map((subItem, index) => {
              const subPath = createPageUrl(subItem.path.replace('/', ''));
              const isSubActive = location.pathname === subPath;
              
              return (
                <Link
                  key={index}
                  to={subPath}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm transition-colors hover:bg-gray-100"
                  style={{
                    color: isSubActive ? '#4B2672' : '#6B5B7F',
                    fontWeight: isSubActive ? '600' : '400'
                  }}
                >
                  {subItem.label}
                </Link>
              );
            })}
          </div>
        )}
      </div>
    );
  }
  
  // Item normal
  const itemPath = createPageUrl(item.path.replace('/', ''));
  const isActive = location.pathname === itemPath;
  
  return (
    <Link
      to={itemPath}
      className="flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all mb-1"
      style={{
        backgroundColor: isActive ? '#4B2672' : 'transparent',
        color: isActive ? '#FFFFFF' : '#6B5B7F',
      }}
      aria-current={isActive ? 'page' : undefined}
    >
      {item.icon && <item.icon className="w-5 h-5 flex-shrink-0" />}
      <span className="flex-1">{item.label}</span>
    </Link>
  );
}

export default function SidebarFactory({ role, context }) {
  console.log('=== SidebarFactory Debug ===');
  console.log('role:', role);
  console.log('context:', context);
  
  if (!role || !context) {
    return (
      <nav className="flex-1 p-4">
        <div className="animate-pulse space-y-2">
          {[1, 2, 3, 4, 5].map(i => (
            <div key={i} className="h-12 bg-gray-200 rounded-lg" />
          ))}
        </div>
      </nav>
    );
  }
  
  // Determinar qual menu exibir baseado no role e impersonation
  let menuItems = [];
  
  const effectiveRole = context.role || role;
  const isImpersonating = context.is_impersonating === true; // Changed from context.impersonating
  const impersonationType = context.impersonation_type;
  
  console.log('effectiveRole:', effectiveRole);
  console.log('isImpersonating:', isImpersonating);
  console.log('impersonationType:', impersonationType);
  
  // Admin sem impersonation OU com impersonation inválida
  if (effectiveRole === 'admin' && (!isImpersonating || !impersonationType)) { // Corrected condition
    console.log('Loading ADMIN menu');
    menuItems = [
      { key: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, path: '/AdminDashboard' },
      { key: 'consultorias', label: 'Consultorias', icon: Briefcase, path: '/Consultorias' },
      { 
        key: 'financeiro', 
        label: 'Financeiro', 
        icon: DollarSign,
        submenu: [
          { label: 'Visão Geral', path: '/FinanceOverview' },
          { label: 'Receitas', path: '/FinanceReceitas' },
          { label: 'Recebíveis', path: '/FinanceRecebiveis' },
          { label: 'Cobrança', path: '/FinanceCobranca' },
          { label: 'Previsão', path: '/FinanceForecast' },
          { label: 'Clientes', path: '/FinanceClientes' },
          { label: 'Relatórios', path: '/FinanceRelatorios' },
          { label: 'Configurações', path: '/FinanceConfig' }
        ]
      },
      { key: 'biblioteca', label: 'Biblioteca de Conteúdos', icon: BookOpen, path: '/MediaLibraryAdmin' },
      { key: 'planos', label: 'Planos', icon: Package, path: '/Planos' },
      { key: 'configuracoes', label: 'Configurações', icon: Settings, path: '/Settings' },
      { key: 'diagnostico', label: 'Diagnóstico', icon: Activity, path: '/SystemDiagnostics' },
    ];
  }
  // Consultoria (ou admin impersonando consultoria)
  else if (effectiveRole === 'consultoria' || impersonationType === 'consultoria') {
    console.log('Loading CONSULTORIA menu');
    menuItems = [
      { key: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, path: '/ConsultoriaDashboard' },
      { key: 'empresas', label: 'Empresas', icon: Building, path: '/Companies' },
      { key: 'biblioteca', label: 'Conteúdos', icon: BookOpen, path: '/MediaLibraryColaborador' },
      { key: 'planos', label: 'Planos', icon: Package, path: '/Planos' }, // Added 'Planos' for Consultoria
      { key: 'financeiro', label: 'Faturamento', icon: DollarSign, path: '/FaturamentoConsultoria' },
      { key: 'configuracoes', label: 'Configurações', icon: Settings, path: '/Personalizacao' },
    ];
  }
  // Empresa (ou admin impersonando empresa)
  else if (effectiveRole === 'manager' || impersonationType === 'empresa') {
    console.log('Loading EMPRESA menu');
    menuItems = [
      { key: 'dashboard', label: 'Painel iMental', icon: Home, path: '/Dashboard' },
      { key: 'departamentos', label: 'Departamentos', icon: Building2, path: '/Departments' },
      { key: 'ghe', label: 'GHE', icon: Briefcase, path: '/GHE' },
      { key: 'colaboradores', label: 'Colaboradores', icon: Users, path: '/Employees' },
      { key: 'avaliacoes', label: 'Avaliações', icon: ClipboardList, path: '/Assessments' },
      { key: 'biblioteca', label: 'Biblioteca', icon: BookOpen, path: '/MediaLibraryColaborador' },
      { key: 'denuncias', label: 'Gestão de Denúncias', icon: ShieldAlert, path: '/CanalDenunciasEmpresa' },
      { key: 'relatorios', label: 'Relatórios', icon: FileText, path: '/Reports' },
      { key: 'configuracoes', label: 'Configurações', icon: Settings, path: '/Settings' },
    ];
  }
  // Colaborador (ou admin impersonando colaborador)
  else if (effectiveRole === 'employee' || impersonationType === 'colaborador') {
    console.log('Loading EMPLOYEE menu');
    menuItems = [
      { key: 'avaliacoes', label: 'Minhas Avaliações', icon: ClipboardList, path: '/ColaboradorAvaliacoes' },
      { key: 'biblioteca', label: 'Biblioteca', icon: BookOpen, path: '/MediaLibraryColaborador' },
      { key: 'denuncias', label: 'Denúncia', icon: ShieldAlert, path: '/CanalDenunciasColaborador' },
      { key: 'perfil', label: 'Meu Perfil', icon: Settings, path: '/Settings' },
    ];
  }
  
  console.log('Menu items count:', menuItems.length);
  console.log('=========================');
  
  if (menuItems.length === 0) {
    return (
      <nav className="flex-1 p-4">
        <div className="text-center py-8">
          <p className="text-sm text-gray-500">Nenhum menu disponível</p>
          <p className="text-xs text-gray-400 mt-1">Role: {effectiveRole}</p>
          <p className="text-xs text-gray-400">Impersonating: {isImpersonating ? 'Sim' : 'Não'}</p>
          <p className="text-xs text-gray-400">Type: {impersonationType || 'null'}</p> {/* Added impersonationType display */}
          <Button 
            onClick={() => {
              localStorage.removeItem('admin_impersonation');
              window.location.reload();
            }}
            size="sm"
            className="mt-4"
          >
            Limpar Cache e Recarregar
          </Button> {/* Added button to clear cache */}
        </div>
      </nav>
    );
  }
  
  return (
    <nav className="flex-1 p-4 space-y-1 overflow-y-auto" data-testid="sidebar-menu">
      {menuItems.map((item) => (
        <SidebarItem key={item.key} item={item} />
      ))}
    </nav>
  );
}
