import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { ChevronDown } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function SidebarMenu({ menuItems, context }) {
  const location = useLocation();

  if (!context || !menuItems || menuItems.length === 0) {
    return null;
  }

  const renderMenuItem = (item) => {
    // Item com submenu
    if (item.submenu) {
      return (
        <DropdownMenu key={item.key}>
          <DropdownMenuTrigger asChild>
            <button
              className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors hover:bg-gray-50"
              style={{ color: '#6B5B7F' }}
              data-testid={`nav-item-${item.key}`}
            >
              {item.icon && <item.icon className="w-5 h-5" />}
              <span className="flex-1 text-left">{item.label}</span>
              <ChevronDown className="w-4 h-4" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            {item.submenu.map((subItem, index) => (
              <DropdownMenuItem key={index} asChild>
                <Link 
                  to={createPageUrl(subItem.path.slice(1))} 
                  className="cursor-pointer flex items-center gap-2"
                >
                  {subItem.icon && <subItem.icon className="w-4 h-4" />}
                  {subItem.label}
                </Link>
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      );
    }

    // Item normal
    const isActive = location.pathname === item.path || 
                     location.pathname === createPageUrl(item.path.slice(1));

    return (
      <Link
        key={item.key}
        to={createPageUrl(item.path.slice(1))}
        className="flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors"
        style={{
          backgroundColor: isActive ? '#4B2672' : 'transparent',
          color: isActive ? '#FFFFFF' : '#6B5B7F',
        }}
        data-testid={`nav-item-${item.key}`}
      >
        {item.icon && <item.icon className="w-5 h-5" />}
        <span>{item.label}</span>
      </Link>
    );
  };

  return (
    <nav className="flex-1 p-4 space-y-1" data-testid="sidebar-menu">
      {menuItems.map(renderMenuItem)}
    </nav>
  );
}