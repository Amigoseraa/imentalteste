import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from "recharts";
import { AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { format } from "date-fns";

export default function RevenueDistributionChart({ consultorias, faturas }) {
  // Garantir que sempre temos arrays válidos
  const safeConsultorias = Array.isArray(consultorias) ? consultorias : [];
  const safeFaturas = Array.isArray(faturas) ? faturas : [];
  
  const currentMonth = format(new Date(), 'yyyy-MM');

  // Calcular faturamento por consultoria
  const consultoriaData = safeConsultorias
    .filter(c => c && c.id)
    .map(consultoria => {
      const consultoriaFaturas = safeFaturas.filter(f => 
        f && f.destino_id === consultoria.id && 
        f.competencia === currentMonth &&
        f.status === 'paga'
      );
      
      const faturamento = consultoriaFaturas.reduce((acc, f) => acc + (f.valor_total || 0), 0);

      return {
        id: consultoria.id,
        nome_fantasia: consultoria.nome_fantasia || 'Sem nome',
        faturamento
      };
    });

  const totalRevenue = consultoriaData.reduce((acc, c) => acc + c.faturamento, 0);

  // Preparar dados para o gráfico de pizza
  const distributionData = consultoriaData
    .filter(c => c.faturamento > 0)
    .map(c => ({
      name: c.nome_fantasia,
      value: c.faturamento,
      percentage: totalRevenue > 0 ? ((c.faturamento / totalRevenue) * 100).toFixed(1) : 0
    }))
    .sort((a, b) => b.value - a.value);

  // Agrupar "Outros" se houver mais de 10
  let chartData = distributionData;
  if (distributionData.length > 10) {
    const top9 = distributionData.slice(0, 9);
    const others = distributionData.slice(9);
    const othersTotal = others.reduce((acc, item) => acc + item.value, 0);
    
    chartData = [
      ...top9,
      {
        name: 'Outros',
        value: othersTotal,
        percentage: totalRevenue > 0 ? ((othersTotal / totalRevenue) * 100).toFixed(1) : 0
      }
    ];
  }

  // Calcular concentração (top 2)
  const top2Revenue = distributionData.slice(0, 2).reduce((acc, item) => acc + item.value, 0);
  const concentrationPercentage = totalRevenue > 0 ? ((top2Revenue / totalRevenue) * 100).toFixed(1) : 0;

  const COLORS = [
    '#4B2672', '#6B36B4', '#A57CE0', '#FFD84D', '#00B37E',
    '#4D7CFF', '#F59E0B', '#EC4899', '#8B5CF6', '#10B981', '#94A3B8'
  ];

  const formatCurrency = (value) => {
    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 0 });
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold" style={{ color: '#2E2E2E' }}>
        Distribuição de Clientes e Receita
      </h2>

      {/* Grid: Gráfico + Insights */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Gráfico de Pizza - Distribuição de Receita */}
        <Card className="shadow-md lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg font-semibold">
              📊 Distribuição de Receita por Consultoria
            </CardTitle>
            <p className="text-sm text-gray-600 mt-1">
              Visualização da concentração de faturamento
            </p>
          </CardHeader>
          <CardContent>
            {chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height={400}>
                <PieChart>
                  <Pie
                    data={chartData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={(entry) => `${entry.percentage}%`}
                    outerRadius={120}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0].payload;
                        return (
                          <div className="bg-white p-3 rounded-lg shadow-lg border border-gray-200">
                            <p className="font-semibold text-gray-900 mb-1">{data.name}</p>
                            <p className="text-sm text-green-600">
                              {formatCurrency(data.value)}
                            </p>
                            <p className="text-xs text-gray-500">
                              {data.percentage}% do total
                            </p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Legend 
                    verticalAlign="bottom" 
                    height={36}
                    formatter={(value) => (
                      <span className="text-xs">{value}</span>
                    )}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[400px] flex items-center justify-center text-gray-400">
                Aguardando dados de faturamento
              </div>
            )}
          </CardContent>
        </Card>

        {/* Insights de Concentração */}
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle className="text-lg font-semibold">
              💡 Insights de Concentração
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Análise de Risco */}
            {parseFloat(concentrationPercentage) >= 60 && safeConsultorias.length > 2 && (
              <Alert className="border-red-200 bg-red-50">
                <AlertCircle className="h-4 w-4 text-red-600" />
                <AlertDescription className="text-red-800 text-sm">
                  <p className="font-semibold mb-1">⚠️ Alto Risco de Concentração</p>
                  <p>
                    As 2 maiores consultorias representam <strong>{concentrationPercentage}%</strong> da receita total. 
                    Considere estratégias de diversificação da base.
                  </p>
                </AlertDescription>
              </Alert>
            )}

            {parseFloat(concentrationPercentage) >= 40 && parseFloat(concentrationPercentage) < 60 && safeConsultorias.length > 2 && (
              <Alert className="border-yellow-200 bg-yellow-50">
                <AlertCircle className="h-4 w-4 text-yellow-600" />
                <AlertDescription className="text-yellow-800 text-sm">
                  <p className="font-semibold mb-1">⚡ Concentração Moderada</p>
                  <p>
                    As 2 maiores consultorias representam <strong>{concentrationPercentage}%</strong> da receita. 
                    Monitore o crescimento de consultorias menores.
                  </p>
                </AlertDescription>
              </Alert>
            )}

            {parseFloat(concentrationPercentage) < 40 && safeConsultorias.length > 2 && (
              <Alert className="border-green-200 bg-green-50">
                <AlertCircle className="h-4 w-4 text-green-600" />
                <AlertDescription className="text-green-800 text-sm">
                  <p className="font-semibold mb-1">✅ Boa Diversificação</p>
                  <p>
                    As 2 maiores consultorias representam apenas <strong>{concentrationPercentage}%</strong> da receita. 
                    Base bem distribuída.
                  </p>
                </AlertDescription>
              </Alert>
            )}

            {/* Estatísticas Adicionais */}
            <div className="space-y-3 pt-4 border-t">
              <div>
                <p className="text-xs text-gray-500 mb-1">Receita Média por Consultoria</p>
                <p className="text-2xl font-bold" style={{ color: '#4B2672' }}>
                  {formatCurrency(safeConsultorias.length > 0 ? totalRevenue / safeConsultorias.length : 0)}
                </p>
              </div>

              <div>
                <p className="text-xs text-gray-500 mb-1">Maior Contribuição Individual</p>
                <p className="text-lg font-semibold text-green-600">
                  {distributionData.length > 0 ? `${distributionData[0].percentage}%` : '—'}
                </p>
                {distributionData.length > 0 && (
                  <p className="text-xs text-gray-600">{distributionData[0].name}</p>
                )}
              </div>

              <div>
                <p className="text-xs text-gray-500 mb-1">Consultorias com Faturamento</p>
                <p className="text-lg font-semibold" style={{ color: '#A57CE0' }}>
                  {distributionData.length} de {safeConsultorias.length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}