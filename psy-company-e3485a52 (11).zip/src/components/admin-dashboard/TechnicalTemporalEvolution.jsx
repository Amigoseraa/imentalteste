import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { format, parseISO, startOfMonth } from "date-fns";
import { TrendingUp } from "lucide-react";

export default function TechnicalTemporalEvolution({ assessments }) {
  const getTemporalData = () => {
    const monthlyData = {};

    assessments.forEach(assessment => {
      if (assessment.completed_at) {
        const month = format(startOfMonth(parseISO(assessment.completed_at)), 'MM/yyyy');
        
        if (!monthlyData[month]) {
          monthlyData[month] = {
            month,
            phq9: [],
            gad7: [],
            prima: []
          };
        }

        if (assessment.phq9_score !== undefined && assessment.phq9_score !== null) {
          monthlyData[month].phq9.push(assessment.phq9_score);
        }
        if (assessment.gad7_score !== undefined && assessment.gad7_score !== null) {
          monthlyData[month].gad7.push(assessment.gad7_score);
        }
        if (assessment.prima_score !== undefined && assessment.prima_score !== null) {
          monthlyData[month].prima.push(assessment.prima_score);
        }
      }
    });

    return Object.values(monthlyData).map(data => ({
      month: data.month,
      'PHQ-9': data.phq9.length > 0 ? parseFloat((data.phq9.reduce((a, b) => a + b, 0) / data.phq9.length).toFixed(1)) : null,
      'GAD-7': data.gad7.length > 0 ? parseFloat((data.gad7.reduce((a, b) => a + b, 0) / data.gad7.length).toFixed(1)) : null,
      'PRIMA-EF': data.prima.length > 0 ? parseFloat((data.prima.reduce((a, b) => a + b, 0) / data.prima.length).toFixed(2)) : null
    })).sort((a, b) => {
      const [monthA, yearA] = a.month.split('/');
      const [monthB, yearB] = b.month.split('/');
      return new Date(yearA, monthA - 1) - new Date(yearB, monthB - 1);
    });
  };

  const data = getTemporalData();

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-blue-600" />
          Evolução Temporal dos Indicadores Técnicos
        </CardTitle>
      </CardHeader>
      <CardContent>
        {data.length > 0 ? (
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} />
              <YAxis yAxisId="left" domain={[0, 27]} tick={{ fontSize: 12 }} label={{ value: 'PHQ-9 / GAD-7', angle: -90, position: 'insideLeft' }} />
              <YAxis yAxisId="right" orientation="right" domain={[1, 5]} tick={{ fontSize: 12 }} label={{ value: 'PRIMA-EF', angle: 90, position: 'insideRight' }} />
              <Tooltip />
              <Legend />
              <Line yAxisId="left" type="monotone" dataKey="PHQ-9" stroke="#a855f7" strokeWidth={3} dot={{ r: 4 }} />
              <Line yAxisId="left" type="monotone" dataKey="GAD-7" stroke="#3b82f6" strokeWidth={3} dot={{ r: 4 }} />
              <Line yAxisId="right" type="monotone" dataKey="PRIMA-EF" stroke="#10b981" strokeWidth={3} dot={{ r: 4 }} />
            </LineChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-[400px] flex items-center justify-center text-gray-400">
            Aguardando dados históricos
          </div>
        )}
      </CardContent>
    </Card>
  );
}