import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, AlertTriangle, MessageCircle, Lightbulb } from "lucide-react";
import { subMonths, isAfter } from "date-fns";

export default function PerformanceInsights({ consultorias, companies, assessments, employees }) {
  const thirtyDaysAgo = subMonths(new Date(), 1);
  
  const getInsights = () => {
    const insights = [];

    // Insight 1: Expansão
    const consultoriasEmExpansao = consultorias.filter(c => {
      const newCompanies = companies.filter(comp => 
        comp.consultoria_id === c.id && 
        comp.created_date && 
        isAfter(new Date(comp.created_date), thirtyDaysAgo)
      ).length;
      const totalCompanies = companies.filter(comp => comp.consultoria_id === c.id).length;
      return newCompanies > 0 && totalCompanies > 0 && (newCompanies / totalCompanies) > 0.2;
    });

    if (consultoriasEmExpansao.length > 0) {
      insights.push({
        type: 'success',
        icon: TrendingUp,
        title: 'Expansão Acelerada',
        message: `${consultoriasEmExpansao.length} ${consultoriasEmExpansao.length === 1 ? 'consultoria cresceu' : 'consultorias cresceram'} acima de 20% em empresas ativas no último mês.`,
        color: 'text-green-600',
        bgColor: 'bg-green-50',
        borderColor: 'border-green-200'
      });
    }

    // Insight 2: Risco de Inatividade
    const consultoriasInativas = consultorias.filter(c => {
      const hasRecentActivity = companies.some(comp => 
        comp.consultoria_id === c.id && 
        comp.updated_date && 
        isAfter(new Date(comp.updated_date), subMonths(new Date(), 2))
      );
      return !hasRecentActivity && c.status === 'ativo';
    });

    if (consultoriasInativas.length > 0) {
      insights.push({
        type: 'warning',
        icon: AlertTriangle,
        title: 'Risco de Inatividade',
        message: `${consultoriasInativas.length} ${consultoriasInativas.length === 1 ? 'consultoria não registra' : 'consultorias não registram'} atividade significativa há mais de 60 dias.`,
        color: 'text-orange-600',
        bgColor: 'bg-orange-50',
        borderColor: 'border-orange-200'
      });
    }

    // Insight 3: Correlação Engajamento x Receita
    const highEngagementConsultorias = consultorias.filter(c => {
      const consultoriaCompanies = companies.filter(comp => comp.consultoria_id === c.id);
      const consultoriaEmployees = employees.filter(e => 
        consultoriaCompanies.some(comp => comp.id === e.company_id)
      );
      const consultoriaAssessments = assessments.filter(a => 
        consultoriaCompanies.some(comp => comp.id === a.company_id)
      );
      
      const engagementRate = consultoriaEmployees.length > 0
        ? (consultoriaAssessments.length / consultoriaEmployees.length) * 100
        : 0;
      
      return engagementRate > 70;
    });

    if (highEngagementConsultorias.length > 0) {
      insights.push({
        type: 'info',
        icon: MessageCircle,
        title: 'Alta Performance em Engajamento',
        message: `Consultorias com engajamento acima de 70% demonstram melhor retenção e crescimento sustentável.`,
        color: 'text-purple-600',
        bgColor: 'bg-purple-50',
        borderColor: 'border-purple-200'
      });
    }

    return insights;
  };

  const insights = getInsights();

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Lightbulb className="w-5 h-5" style={{ color: '#FFD84D' }} />
          Insights de Performance
        </CardTitle>
      </CardHeader>
      <CardContent>
        {insights.length > 0 ? (
          <div className="grid md:grid-cols-3 gap-4">
            {insights.map((insight, idx) => (
              <div
                key={idx}
                className={`p-4 rounded-lg border-2 ${insight.bgColor} ${insight.borderColor} transition-all hover:shadow-md`}
              >
                <div className="flex items-start gap-3">
                  <insight.icon className={`w-6 h-6 ${insight.color} flex-shrink-0 mt-0.5`} />
                  <div>
                    <h4 className={`font-semibold ${insight.color} mb-1`}>
                      {insight.title}
                    </h4>
                    <p className="text-sm text-gray-700 leading-relaxed">
                      {insight.message}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <Lightbulb className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-sm text-gray-500">Aguardando dados suficientes para gerar insights</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}