import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Grid3x3 } from "lucide-react";

const PRIMA_CATEGORIES = {
  'A': 'Teor do Trabalho',
  'B': 'Carga e Ritmo',
  'C': 'Horário',
  'D': 'Controle',
  'E': 'Ambiente',
  'F': 'Cultura',
  'G': 'Relações',
  'H': 'Papéis',
  'I': 'Carreira',
  'J': 'Interface Lar-Trabalho'
};

export default function CategoryHeatmap({ companies, assessments }) {
  const getHeatmapData = () => {
    const categoryItems = {
      'A': [1, 2, 3], 'B': [4, 5, 6], 'C': [7, 8, 9], 'D': [10, 11, 12],
      'E': [13, 14, 15], 'F': [16, 17, 18], 'G': [19, 20, 21], 'H': [22, 23, 24],
      'I': [25, 26, 27], 'J': [28, 29, 30]
    };

    return companies.slice(0, 8).map(company => {
      const companyAssessments = assessments.filter(a => a.company_id === company.id);
      
      const categoryScores = {};
      Object.entries(PRIMA_CATEGORIES).forEach(([key, name]) => {
        let sum = 0;
        let count = 0;

        companyAssessments.forEach(assessment => {
          if (assessment.prima_responses) {
            categoryItems[key].forEach(item => {
              const value = assessment.prima_responses[`q${item}`];
              if (value) {
                sum += value;
                count++;
              }
            });
          }
        });

        categoryScores[name] = count > 0 ? (sum / count) : null;
      });

      return {
        company: company.name,
        ...categoryScores
      };
    });
  };

  const data = getHeatmapData();

  const getColor = (value) => {
    if (!value) return '#f3f4f6';
    if (value <= 2.4) return '#ef4444';
    if (value <= 3.4) return '#f59e0b';
    return '#10b981';
  };

  const getTextColor = (value) => {
    if (!value) return '#6b7280';
    if (value <= 2.4) return '#ffffff';
    if (value <= 3.4) return '#ffffff';
    return '#ffffff';
  };

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg font-semibold">
          <Grid3x3 className="w-5 h-5 text-blue-600" />
          Mapa de Calor - Categorias PRIMA-EF por Empresa
        </CardTitle>
      </CardHeader>
      <CardContent>
        {data.length > 0 ? (
          <div className="overflow-x-auto">
            <div className="min-w-[1000px]">
              <div className="grid grid-cols-11 gap-1 mb-1">
                <div className="text-xs font-semibold text-gray-600 p-2"></div>
                {Object.values(PRIMA_CATEGORIES).map((cat, idx) => (
                  <div key={idx} className="text-xs font-semibold text-gray-600 p-2 text-center">
                    {cat.split(' ')[0]}
                  </div>
                ))}
              </div>
              {data.map((row, rowIdx) => (
                <div key={rowIdx} className="grid grid-cols-11 gap-1 mb-1">
                  <div className="text-xs font-semibold text-gray-700 p-2 flex items-center truncate">
                    {row.company}
                  </div>
                  {Object.values(PRIMA_CATEGORIES).map((cat, colIdx) => {
                    const value = row[cat];
                    return (
                      <div
                        key={colIdx}
                        className="p-3 rounded text-center font-semibold text-sm flex items-center justify-center transition-all hover:scale-105"
                        style={{
                          backgroundColor: getColor(value),
                          color: getTextColor(value)
                        }}
                        title={`${row.company} - ${cat}: ${value ? value.toFixed(2) : 'N/A'}`}
                      >
                        {value ? value.toFixed(1) : '-'}
                      </div>
                    );
                  })}
                </div>
              ))}
              <div className="mt-4 flex items-center justify-center gap-6 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: '#10b981' }}></div>
                  <span className="text-gray-600">Baixo (≥3.5)</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: '#f59e0b' }}></div>
                  <span className="text-gray-600">Moderado (2.5-3.4)</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: '#ef4444' }}></div>
                  <span className="text-gray-600">Alto (≤2.4)</span>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="h-[300px] flex items-center justify-center text-gray-400">
            Aguardando dados de categorias
          </div>
        )}
      </CardContent>
    </Card>
  );
}