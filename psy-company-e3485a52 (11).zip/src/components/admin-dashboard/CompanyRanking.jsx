import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { Trophy, TrendingUp, TrendingDown } from "lucide-react";

export default function CompanyRanking({ companies, assessments, employees }) {
  const getCompanyData = () => {
    return companies.map(company => {
      const companyAssessments = assessments.filter(a => a.company_id === company.id);
      const companyEmployees = employees.filter(e => e.company_id === company.id);
      
      const ibcScores = companyAssessments.map(a => a.ibc_score).filter(s => s);
      const avgIBC = ibcScores.length > 0 
        ? (ibcScores.reduce((a, b) => a + b, 0) / ibcScores.length)
        : 0;

      const highRisk = companyAssessments.filter(a => a.prima_classification === 'Alto').length;
      const highRiskPct = companyAssessments.length > 0 
        ? ((highRisk / companyAssessments.length) * 100)
        : 0;

      const mentalHealthCritical = companyAssessments.filter(a => 
        a.phq9_classification === 'Moderado-Grave' || 
        a.phq9_classification === 'Grave'
      ).length;
      const mentalHealthPct = companyAssessments.length > 0
        ? ((mentalHealthCritical / companyAssessments.length) * 100)
        : 0;

      return {
        name: company.name,
        IBC: parseFloat(avgIBC.toFixed(1)),
        highRiskPct: parseFloat(highRiskPct.toFixed(1)),
        mentalHealthPct: parseFloat(mentalHealthPct.toFixed(1)),
        totalAssessments: companyAssessments.length,
        totalEmployees: companyEmployees.length
      };
    })
    .filter(c => c.IBC > 0)
    .sort((a, b) => b.IBC - a.IBC)
    .slice(0, 10);
  };

  const data = getCompanyData();

  const getColor = (value) => {
    if (value >= 80) return '#10b981';
    if (value >= 60) return '#f59e0b';
    return '#ef4444';
  };

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg font-semibold">
          <Trophy className="w-5 h-5 text-yellow-500" />
          Ranking de Empresas por IBC
        </CardTitle>
      </CardHeader>
      <CardContent>
        {data.length > 0 ? (
          <ResponsiveContainer width="100%" height={400}>
            <BarChart data={data} layout="vertical" margin={{ left: 20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 12 }} />
              <YAxis 
                type="category" 
                dataKey="name" 
                width={150} 
                tick={{ fontSize: 12 }} 
              />
              <Tooltip 
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload;
                    return (
                      <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
                        <p className="font-semibold text-gray-900 mb-2">{data.name}</p>
                        <div className="space-y-1 text-sm">
                          <p className="flex items-center justify-between gap-4">
                            <span className="text-gray-600">IBC:</span>
                            <span className="font-semibold" style={{ color: getColor(data.IBC) }}>
                              {data.IBC}
                            </span>
                          </p>
                          <p className="flex items-center justify-between gap-4">
                            <span className="text-gray-600">Risco Alto:</span>
                            <span className="font-semibold text-red-600">{data.highRiskPct}%</span>
                          </p>
                          <p className="flex items-center justify-between gap-4">
                            <span className="text-gray-600">PHQ-9 Grave:</span>
                            <span className="font-semibold text-orange-600">{data.mentalHealthPct}%</span>
                          </p>
                          <p className="flex items-center justify-between gap-4 pt-2 border-t">
                            <span className="text-gray-600">Avaliações:</span>
                            <span className="font-semibold">{data.totalAssessments}</span>
                          </p>
                        </div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Bar dataKey="IBC" radius={[0, 8, 8, 0]}>
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={getColor(entry.IBC)} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-[400px] flex items-center justify-center text-gray-400">
            Aguardando dados de empresas
          </div>
        )}
      </CardContent>
    </Card>
  );
}