import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { Trophy } from "lucide-react";

export default function ConsultoriaRanking({ consultorias, companies, assessments, employees }) {
  const getConsultoriaData = () => {
    return consultorias
      .filter(c => c.status === 'ativo')
      .map(consultoria => {
        const consultoriaCompanies = companies.filter(c => c.consultoria_id === consultoria.id);
        const consultoriaEmployees = employees.filter(e => 
          consultoriaCompanies.some(c => c.id === e.company_id)
        );
        const consultoriaAssessments = assessments.filter(a => 
          consultoriaCompanies.some(c => c.id === a.company_id)
        );
        
        // Calcular IM-Score da consultoria
        const validScores = consultoriaAssessments.filter(a => 
          (a.phq9_score !== undefined || a.gad7_score !== undefined || a.prima_score !== undefined)
        );
        
        let imScore = 0;
        if (validScores.length > 0) {
          let mentalHealthSum = 0;
          let psychosocialSum = 0;
          let mentalHealthCount = 0;
          let psychosocialCount = 0;
          
          validScores.forEach(a => {
            if (a.phq9_score !== undefined || a.gad7_score !== undefined) {
              let mh = 0;
              let count = 0;
              
              if (a.phq9_score !== undefined) {
                mh += ((27 - a.phq9_score) / 27) * 100;
                count++;
              }
              if (a.gad7_score !== undefined) {
                mh += ((21 - a.gad7_score) / 21) * 100;
                count++;
              }
              
              if (count > 0) {
                mentalHealthSum += mh / count;
                mentalHealthCount++;
              }
            }
            
            if (a.prima_score !== undefined) {
              psychosocialSum += ((a.prima_score - 1) / 4) * 100;
              psychosocialCount++;
            }
          });
          
          const avgMentalHealth = mentalHealthCount > 0 ? mentalHealthSum / mentalHealthCount : 0;
          const avgPsychosocial = psychosocialCount > 0 ? psychosocialSum / psychosocialCount : 0;
          
          let totalWeight = 0;
          let weightedSum = 0;
          
          if (mentalHealthCount > 0) {
            weightedSum += avgMentalHealth * 0.5;
            totalWeight += 0.5;
          }
          
          if (psychosocialCount > 0) {
            weightedSum += avgPsychosocial * 0.5;
            totalWeight += 0.5;
          }
          
          imScore = totalWeight > 0 ? weightedSum / totalWeight : 0;
        }

        return {
          name: consultoria.nome_fantasia,
          score: parseFloat(imScore.toFixed(1)),
          companies: consultoriaCompanies.length,
          employees: consultoriaEmployees.length,
          assessments: consultoriaAssessments.length
        };
      })
      .filter(c => c.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 10);
  };

  const data = getConsultoriaData();

  const getColor = (value) => {
    if (value >= 70) return '#2ECC71';
    if (value >= 50) return '#FFD84D';
    return '#E74C3C';
  };

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg font-semibold">
          <Trophy className="w-5 h-5" style={{ color: '#FFD84D' }} />
          Ranking de Consultorias por IM-Score
        </CardTitle>
      </CardHeader>
      <CardContent>
        {data.length > 0 ? (
          <ResponsiveContainer width="100%" height={400}>
            <BarChart data={data} layout="vertical" margin={{ left: 20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 12 }} />
              <YAxis 
                type="category" 
                dataKey="name" 
                width={150} 
                tick={{ fontSize: 12 }} 
              />
              <Tooltip 
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload;
                    return (
                      <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
                        <p className="font-semibold text-gray-900 mb-2">{data.name}</p>
                        <div className="space-y-1 text-sm">
                          <p className="flex items-center justify-between gap-4">
                            <span className="text-gray-600">IM-Score:</span>
                            <span className="font-semibold" style={{ color: getColor(data.score) }}>
                              {data.score}
                            </span>
                          </p>
                          <p className="flex items-center justify-between gap-4">
                            <span className="text-gray-600">Empresas:</span>
                            <span className="font-semibold">{data.companies}</span>
                          </p>
                          <p className="flex items-center justify-between gap-4">
                            <span className="text-gray-600">Colaboradores:</span>
                            <span className="font-semibold">{data.employees}</span>
                          </p>
                          <p className="flex items-center justify-between gap-4">
                            <span className="text-gray-600">Avaliações:</span>
                            <span className="font-semibold">{data.assessments}</span>
                          </p>
                        </div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Bar dataKey="score" radius={[0, 8, 8, 0]}>
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={getColor(entry.score)} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-[400px] flex items-center justify-center text-gray-400">
            Aguardando dados de consultorias
          </div>
        )}
      </CardContent>
    </Card>
  );
}