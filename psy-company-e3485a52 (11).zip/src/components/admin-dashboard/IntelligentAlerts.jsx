import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle, TrendingDown, DollarSign, Lightbulb } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function IntelligentAlerts({ consultorias, companies, assessments }) {
  const generateAlerts = () => {
    const alerts = [];

    consultorias.forEach(consultoria => {
      if (consultoria.status !== 'ativo') return;

      const consultoriaCompanies = companies.filter(c => c.consultoria_id === consultoria.id);
      const consultoriaAssessments = assessments.filter(a => 
        consultoriaCompanies.some(c => c.id === a.company_id)
      );

      // Alerta: Saúde Mental Crítica
      const criticalMH = consultoriaAssessments.filter(a => 
        (a.phq9_score !== undefined && a.phq9_score >= 15) ||
        (a.gad7_score !== undefined && a.gad7_score >= 15)
      ).length;
      
      const criticalMHPct = consultoriaAssessments.length > 0 
        ? (criticalMH / consultoriaAssessments.length) * 100 
        : 0;

      if (criticalMHPct >= 30) {
        alerts.push({
          type: 'critical',
          icon: AlertTriangle,
          message: `${consultoria.nome_fantasia} apresenta ${criticalMHPct.toFixed(0)}% de casos graves de ansiedade ou depressão`,
          color: 'text-red-600',
          bgColor: 'bg-red-50',
          borderColor: 'border-red-200'
        });
      }

      // Alerta: Risco Psicossocial Alto
      const highRisk = consultoriaAssessments.filter(a => 
        a.prima_score !== undefined && a.prima_score <= 2.4
      ).length;
      
      const highRiskPct = consultoriaAssessments.length > 0 
        ? (highRisk / consultoriaAssessments.length) * 100 
        : 0;

      if (highRiskPct >= 40) {
        alerts.push({
          type: 'warning',
          icon: AlertTriangle,
          message: `${consultoria.nome_fantasia} com ${highRiskPct.toFixed(0)}% de colaboradores em alto risco psicossocial (PRIMA-EF)`,
          color: 'text-orange-600',
          bgColor: 'bg-orange-50',
          borderColor: 'border-orange-200'
        });
      }

      // Alerta: Baixo Engajamento
      const totalEmployees = consultoriaCompanies.reduce((acc, c) => {
        // Aqui precisaríamos dos employees, mas simplificando
        return acc + consultoriaAssessments.filter(a => a.company_id === c.id).length;
      }, 0);

      if (consultoriaAssessments.length > 0 && consultoriaAssessments.length < totalEmployees * 0.4) {
        alerts.push({
          type: 'info',
          icon: TrendingDown,
          message: `${consultoria.nome_fantasia}: baixa taxa de engajamento (< 40%) nas avaliações`,
          color: 'text-blue-600',
          bgColor: 'bg-blue-50',
          borderColor: 'border-blue-200'
        });
      }
    });

    return alerts.slice(0, 8);
  };

  const alerts = generateAlerts();

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="text-lg font-semibold flex items-center gap-2">
          <Lightbulb className="w-5 h-5" style={{ color: '#FFD84D' }} />
          Alertas Inteligentes
        </CardTitle>
      </CardHeader>
      <CardContent>
        {alerts.length > 0 ? (
          <div className="space-y-3">
            {alerts.map((alert, idx) => (
              <div
                key={idx}
                className={`p-4 rounded-lg border ${alert.bgColor} ${alert.borderColor} transition-all hover:shadow-md`}
              >
                <div className="flex items-start gap-3">
                  <alert.icon className={`w-5 h-5 ${alert.color} flex-shrink-0 mt-0.5`} />
                  <p className={`text-sm ${alert.color} leading-relaxed`}>
                    {alert.message}
                  </p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <AlertTriangle className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-sm text-gray-500">Nenhum alerta no momento</p>
            <p className="text-xs text-gray-400 mt-1">O sistema monitora automaticamente as consultorias</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}