import React from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardHeader } from "@/components/ui/card";
import { Building2, Briefcase, Users, Activity, DollarSign, AlertCircle } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useQuery } from "@tanstack/react-query";

export default function AdminKPIs({ user }) {
  // Buscar dados reais
  const { data: consultorias = [] } = useQuery({
    queryKey: ['admin-kpis-consultorias'],
    queryFn: () => base44.entities.Consultoria.list(),
    initialData: [],
  });

  const { data: companies = [] } = useQuery({
    queryKey: ['admin-kpis-companies'],
    queryFn: () => base44.entities.Company.list(),
    initialData: [],
  });

  const { data: employees = [] } = useQuery({
    queryKey: ['admin-kpis-employees'],
    queryFn: () => base44.entities.Employee.list(),
    initialData: [],
  });

  const { data: assessments = [] } = useQuery({
    queryKey: ['admin-kpis-assessments'],
    queryFn: () => base44.entities.Assessment.list(),
    initialData: [],
  });

  const { data: faturas = [] } = useQuery({
    queryKey: ['admin-kpis-faturas'],
    queryFn: () => base44.entities.Fatura.list(),
    initialData: [],
  });

  // Calcular KPIs reais
  const consultoriasAtivas = consultorias.filter(c => c.status === 'ativo').length;
  const totalConsultorias = consultorias.length;
  const percentualAtivas = totalConsultorias > 0 
    ? ((consultoriasAtivas / totalConsultorias) * 100).toFixed(0)
    : 0;

  const totalEmpresas = companies.length;
  
  const colaboradoresAtivos = employees.filter(e => e.status === 'active').length;
  
  const avaliacoesCompletas = assessments.filter(a => a.completed_at).length;
  const totalColaboradores = employees.length;
  const engajamentoRate = totalColaboradores > 0
    ? ((avaliacoesCompletas / totalColaboradores) * 100).toFixed(1)
    : 0;

  // Calcular empresas com avaliações nos últimos 30 dias
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
  
  const empresasComAvaliacoes = new Set(
    assessments
      .filter(a => a.completed_at && new Date(a.completed_at) >= thirtyDaysAgo)
      .map(a => a.company_id)
  );
  
  const empresasEngajadas = empresasComAvaliacoes.size;
  const taxaEngajamentoEmpresas = totalEmpresas > 0
    ? ((empresasEngajadas / totalEmpresas) * 100).toFixed(1)
    : 0;

  // Calcular MRR real baseado em faturas pagas
  const currentMonth = new Date().toISOString().slice(0, 7); // YYYY-MM
  const faturasDoMes = faturas.filter(f => 
    f.competencia === currentMonth && f.status === 'paga'
  );
  const mrrReal = faturasDoMes.reduce((sum, f) => sum + (f.valor_liquido || 0), 0);

  return (
    <TooltipProvider>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        {/* Consultorias Ativas */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-shadow cursor-help">
              <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 rounded-full opacity-10" style={{ backgroundColor: '#4B2672' }} />
              <CardHeader className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-600 mb-1">Consultorias Ativas</p>
                    <div className="flex items-baseline gap-2">
                      <p className="text-4xl font-bold" style={{ color: '#4B2672' }}>
                        {consultoriasAtivas}
                      </p>
                      {totalConsultorias > 0 && (
                        <p className="text-lg text-gray-500">/ {totalConsultorias}</p>
                      )}
                    </div>
                    {totalConsultorias > 0 ? (
                      <p className="text-xs text-gray-500 mt-2">
                        {percentualAtivas}% do total
                      </p>
                    ) : (
                      <p className="text-xs text-gray-400 mt-2 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        Nenhuma consultoria cadastrada
                      </p>
                    )}
                  </div>
                  <div className="p-3 rounded-xl" style={{ backgroundColor: '#F8F6FB' }}>
                    <Building2 className="w-6 h-6" style={{ color: '#4B2672' }} />
                  </div>
                </div>
              </CardHeader>
            </Card>
          </TooltipTrigger>
          <TooltipContent>
            <p className="text-xs max-w-xs">
              Consultorias em operação ativa com empresas vinculadas
            </p>
          </TooltipContent>
        </Tooltip>

        {/* Empresas Vinculadas */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-shadow cursor-help">
              <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 rounded-full opacity-10" style={{ backgroundColor: '#A57CE0' }} />
              <CardHeader className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-600 mb-1">Empresas Vinculadas</p>
                    <p className="text-4xl font-bold" style={{ color: '#A57CE0' }}>
                      {totalEmpresas}
                    </p>
                    {totalEmpresas > 0 ? (
                      <p className="text-xs text-gray-500 mt-2">
                        Cadastradas no sistema
                      </p>
                    ) : (
                      <p className="text-xs text-gray-400 mt-2 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        Nenhuma empresa cadastrada
                      </p>
                    )}
                  </div>
                  <div className="p-3 rounded-xl" style={{ backgroundColor: '#F8F6FB' }}>
                    <Briefcase className="w-6 h-6" style={{ color: '#A57CE0' }} />
                  </div>
                </div>
              </CardHeader>
            </Card>
          </TooltipTrigger>
          <TooltipContent>
            <p className="text-xs max-w-xs">
              Total de empresas cadastradas nas consultorias ativas
            </p>
          </TooltipContent>
        </Tooltip>

        {/* Colaboradores Monitorados */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-shadow cursor-help">
              <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 rounded-full opacity-10" style={{ backgroundColor: '#4D7CFF' }} />
              <CardHeader className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-600 mb-1">Colaboradores Monitorados</p>
                    <p className="text-4xl font-bold" style={{ color: '#4D7CFF' }}>
                      {colaboradoresAtivos.toLocaleString('pt-BR')}
                    </p>
                    {colaboradoresAtivos > 0 ? (
                      <p className="text-xs text-gray-500 mt-2">
                        Colaboradores ativos
                      </p>
                    ) : (
                      <p className="text-xs text-gray-400 mt-2 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        Nenhum colaborador cadastrado
                      </p>
                    )}
                  </div>
                  <div className="p-3 rounded-xl" style={{ backgroundColor: '#EBF3FF' }}>
                    <Users className="w-6 h-6" style={{ color: '#4D7CFF' }} />
                  </div>
                </div>
              </CardHeader>
            </Card>
          </TooltipTrigger>
          <TooltipContent>
            <p className="text-xs max-w-xs">
              Total de colaboradores ativos nas empresas vinculadas
            </p>
          </TooltipContent>
        </Tooltip>

        {/* Taxa de Engajamento */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-shadow cursor-help">
              <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 bg-green-500 rounded-full opacity-10" />
              <CardHeader className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-600 mb-1">Taxa de Engajamento</p>
                    <p className="text-4xl font-bold text-green-600">
                      {totalEmpresas > 0 ? `${taxaEngajamentoEmpresas}%` : '—'}
                    </p>
                    {totalEmpresas > 0 ? (
                      <p className="text-xs text-gray-500 mt-2">
                        {empresasEngajadas} de {totalEmpresas} empresas
                      </p>
                    ) : (
                      <p className="text-xs text-gray-400 mt-2 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        Aguardando empresas e avaliações
                      </p>
                    )}
                  </div>
                  <div className="p-3 rounded-xl bg-green-50">
                    <Activity className="w-6 h-6 text-green-600" />
                  </div>
                </div>
              </CardHeader>
            </Card>
          </TooltipTrigger>
          <TooltipContent>
            <p className="text-xs max-w-xs">
              Percentual de empresas com avaliações nos últimos 30 dias
            </p>
          </TooltipContent>
        </Tooltip>

        {/* MRR Global - Dados Reais */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-shadow cursor-help">
              <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 rounded-full opacity-10" style={{ backgroundColor: '#FFD84D' }} />
              <CardHeader className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-600 mb-1">MRR Global</p>
                    <p className="text-4xl font-bold" style={{ color: '#F5B800' }}>
                      {faturasDoMes.length > 0 ? (
                        mrrReal.toLocaleString('pt-BR', { 
                          style: 'currency', 
                          currency: 'BRL', 
                          minimumFractionDigits: 0 
                        })
                      ) : (
                        '—'
                      )}
                    </p>
                    {faturasDoMes.length > 0 ? (
                      <p className="text-xs text-gray-500 mt-2">
                        {faturasDoMes.length} fatura{faturasDoMes.length > 1 ? 's' : ''} paga{faturasDoMes.length > 1 ? 's' : ''}
                      </p>
                    ) : (
                      <p className="text-xs text-gray-400 mt-2 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        Aguardando faturas pagas
                      </p>
                    )}
                  </div>
                  <div className="p-3 rounded-xl" style={{ backgroundColor: '#FFFBEA' }}>
                    <DollarSign className="w-6 h-6" style={{ color: '#F5B800' }} />
                  </div>
                </div>
              </CardHeader>
            </Card>
          </TooltipTrigger>
          <TooltipContent>
            <p className="text-xs max-w-xs">
              Receita mensal recorrente real baseada em faturas pagas do mês atual
            </p>
          </TooltipContent>
        </Tooltip>
      </div>
    </TooltipProvider>
  );
}