import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DollarSign, TrendingUp, AlertCircle, Award } from "lucide-react";
import { format, startOfMonth } from "date-fns";

export default function FinancialMetrics({ consultorias, faturas }) {
  const currentMonth = format(new Date(), 'yyyy-MM');
  
  const faturasAtuais = faturas.filter(f => f.competencia === currentMonth);
  const faturasPagas = faturasAtuais.filter(f => f.status === 'paga');
  const faturasPendentes = faturasAtuais.filter(f => f.status === 'pendente' || f.status === 'gerada');
  
  const mrr = faturasPagas.reduce((acc, f) => acc + (f.valor_total || 0), 0);
  const receitaPrevista = faturasAtuais.reduce((acc, f) => acc + (f.valor_total || 0), 0);
  const valorPendente = faturasPendentes.reduce((acc, f) => acc + (f.valor_total || 0), 0);
  
  // Calcular crescimento comparando com mês anterior
  const lastMonth = format(new Date(new Date().setMonth(new Date().getMonth() - 1)), 'yyyy-MM');
  const faturasLastMonth = faturas.filter(f => f.competencia === lastMonth && f.status === 'paga');
  const mrrLastMonth = faturasLastMonth.reduce((acc, f) => acc + (f.valor_total || 0), 0);
  const crescimento = mrrLastMonth > 0 ? (((mrr - mrrLastMonth) / mrrLastMonth) * 100).toFixed(1) : 0;
  
  // Consultoria com maior faturamento
  const faturamentoPorConsultoria = {};
  faturasAtuais.forEach(f => {
    if (!faturamentoPorConsultoria[f.destino_id]) {
      faturamentoPorConsultoria[f.destino_id] = {
        nome: f.destino_nome,
        valor: 0
      };
    }
    faturamentoPorConsultoria[f.destino_id].valor += f.valor_total || 0;
  });
  
  const topConsultoria = Object.values(faturamentoPorConsultoria)
    .sort((a, b) => b.valor - a.valor)[0];

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold" style={{ color: '#2E2E2E' }}>
        Indicadores Financeiros
      </h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="shadow-md hover:shadow-lg transition-all">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <DollarSign className="w-4 h-4" />
              MRR (Receita Recorrente)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold" style={{ color: '#2ECC71' }}>
              R$ {mrr.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </p>
            <p className="text-xs text-gray-500 mt-2">
              {currentMonth}
            </p>
          </CardContent>
        </Card>

        <Card className="shadow-md hover:shadow-lg transition-all">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <TrendingUp className="w-4 h-4" />
              Receita Prevista
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold" style={{ color: '#4B2672' }}>
              R$ {receitaPrevista.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </p>
            <p className="text-xs text-gray-500 mt-2">
              Total do período
            </p>
          </CardContent>
        </Card>

        <Card className="shadow-md hover:shadow-lg transition-all">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <AlertCircle className="w-4 h-4" />
              Faturas Pendentes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-yellow-600">
              R$ {valorPendente.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </p>
            <p className="text-xs text-gray-500 mt-2">
              {faturasPendentes.length} faturas
            </p>
          </CardContent>
        </Card>

        <Card className="shadow-md hover:shadow-lg transition-all">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <Award className="w-4 h-4" />
              Top Consultoria
            </CardTitle>
          </CardHeader>
          <CardContent>
            {topConsultoria ? (
              <>
                <p className="text-lg font-bold" style={{ color: '#FFD84D' }}>
                  {topConsultoria.nome}
                </p>
                <p className="text-xs text-gray-500 mt-2">
                  R$ {topConsultoria.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </p>
              </>
            ) : (
              <p className="text-sm text-gray-400">Sem dados</p>
            )}
          </CardContent>
        </Card>
      </div>

      {crescimento !== 0 && (
        <Card className="shadow-md" style={{ borderLeft: `4px solid ${parseFloat(crescimento) >= 0 ? '#2ECC71' : '#E74C3C'}` }}>
          <CardContent className="py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <TrendingUp className={`w-6 h-6 ${parseFloat(crescimento) >= 0 ? 'text-green-600' : 'text-red-600 rotate-180'}`} />
                <div>
                  <p className="text-sm text-gray-600">Crescimento Mensal de Receita</p>
                  <p className={`text-2xl font-bold ${parseFloat(crescimento) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {crescimento > 0 ? '+' : ''}{crescimento}%
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-xs text-gray-500">vs. mês anterior</p>
                <p className="text-sm font-semibold text-gray-700">
                  R$ {mrrLastMonth.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}