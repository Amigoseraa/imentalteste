import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertCircle, AlertTriangle, Bell, TrendingUp } from "lucide-react";
import { toast } from "sonner";

export default function ConsultoriaAlertsPanel({ consultoriaData, faturas, currentMonth }) {
  const generateAlerts = () => {
    const alerts = [];

    consultoriaData.forEach(consultoria => {
      // Alerta: Consultoria sem atividade
      const sixtyDaysAgo = new Date();
      sixtyDaysAgo.setDate(sixtyDaysAgo.getDate() - 60);
      const lastActivity = new Date(consultoria.ultimaAtividade);
      
      if (lastActivity < sixtyDaysAgo && consultoria.status === 'ativo') {
        alerts.push({
          type: 'critical',
          icon: AlertCircle,
          color: 'text-red-600',
          bgColor: 'bg-red-50',
          borderColor: 'border-red-200',
          title: 'Sem atividade',
          message: `${consultoria.nome_fantasia} não envia avaliações há mais de 60 dias`,
          action: () => toast.info(`Entrando como ${consultoria.nome_fantasia}...`)
        });
      }

      // Alerta: Fatura pendente
      const consultoriaFaturas = faturas.filter(f => 
        f.destino_id === consultoria.id && 
        f.competencia === currentMonth &&
        (f.status === 'pendente' || f.status === 'vencida')
      );

      if (consultoriaFaturas.length > 0) {
        const totalPendente = consultoriaFaturas.reduce((acc, f) => acc + (f.valor_total || 0), 0);
        alerts.push({
          type: 'warning',
          icon: AlertTriangle,
          color: 'text-yellow-600',
          bgColor: 'bg-yellow-50',
          borderColor: 'border-yellow-200',
          title: 'Fatura pendente',
          message: `${consultoria.nome_fantasia} possui ${consultoriaFaturas.length} fatura(s) pendente(s) (${totalPendente.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })})`,
          action: () => toast.info('Enviando lembrete...')
        });
      }

      // Alerta: Baixo engajamento
      if (consultoria.engajamento < 40 && consultoria.colaboradores > 0) {
        alerts.push({
          type: 'info',
          icon: Bell,
          color: 'text-blue-600',
          bgColor: 'bg-blue-50',
          borderColor: 'border-blue-200',
          title: 'Baixo engajamento',
          message: `${consultoria.nome_fantasia} tem apenas ${consultoria.engajamento}% de respostas`,
          action: () => toast.info('Notificando consultoria...')
        });
      }

      // Alerta: Alta performance (positivo)
      if (consultoria.engajamento >= 90 && consultoria.imScore >= 80) {
        alerts.push({
          type: 'success',
          icon: TrendingUp,
          color: 'text-green-600',
          bgColor: 'bg-green-50',
          borderColor: 'border-green-200',
          title: 'Alta performance',
          message: `${consultoria.nome_fantasia} atingiu ${consultoria.engajamento}% de engajamento e IM-Score ${consultoria.imScore}`,
          action: null
        });
      }
    });

    // Limitar a 8 alertas mais relevantes
    return alerts
      .sort((a, b) => {
        const priority = { critical: 0, warning: 1, info: 2, success: 3 };
        return priority[a.type] - priority[b.type];
      })
      .slice(0, 8);
  };

  const alerts = generateAlerts();

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg font-semibold">
          <Bell className="w-5 h-5" style={{ color: '#FFD84D' }} />
          Alertas Inteligentes
        </CardTitle>
      </CardHeader>
      <CardContent>
        {alerts.length > 0 ? (
          <div className="space-y-3">
            {alerts.map((alert, idx) => (
              <div
                key={idx}
                className={`p-4 rounded-lg border ${alert.bgColor} ${alert.borderColor} transition-all hover:shadow-md`}
              >
                <div className="flex items-start gap-3">
                  <alert.icon className={`w-5 h-5 ${alert.color} flex-shrink-0 mt-0.5`} />
                  <div className="flex-1">
                    <p className={`text-sm font-semibold ${alert.color} mb-1`}>
                      {alert.title}
                    </p>
                    <p className="text-xs text-gray-600 leading-relaxed">
                      {alert.message}
                    </p>
                    {alert.action && (
                      <Button
                        size="sm"
                        variant="outline"
                        className="mt-3"
                        onClick={alert.action}
                      >
                        Ação
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <Bell className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-sm text-gray-500">Nenhum alerta no momento</p>
            <p className="text-xs text-gray-400 mt-1">
              O sistema monitora automaticamente as consultorias
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}