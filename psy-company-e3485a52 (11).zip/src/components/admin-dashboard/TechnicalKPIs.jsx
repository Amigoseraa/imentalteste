import React from "react";
import { Card, CardHeader, CardContent } from "@/components/ui/card";
import { Brain, FileText, Activity, AlertCircle } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

export default function TechnicalKPIs({ assessments }) {
  // Total de Avaliações Respondidas
  const totalAvaliacoes = assessments.length;

  // Instrumentos Ativos (simplificado - contando tipos únicos presentes)
  const instrumentos = new Set();
  assessments.forEach(a => {
    if (a.phq9_score !== undefined && a.phq9_score !== null) instrumentos.add('PHQ-9');
    if (a.gad7_score !== undefined && a.gad7_score !== null) instrumentos.add('GAD-7');
    if (a.prima_score !== undefined && a.prima_score !== null) instrumentos.add('PRIMA-EF');
  });
  const instrumentosAtivos = instrumentos.size;

  // Prevalência de Transtornos Moderado+
  const transtornosModerGrave = assessments.filter(a => 
    (a.phq9_score !== undefined && a.phq9_score >= 10) ||
    (a.gad7_score !== undefined && a.gad7_score >= 10)
  ).length;
  const prevalencia = totalAvaliacoes > 0
    ? ((transtornosModerGrave / totalAvaliacoes) * 100).toFixed(1)
    : 0;

  // Média PRIMA-EF Global
  const primaScores = assessments
    .filter(a => a.prima_score !== undefined && a.prima_score !== null)
    .map(a => a.prima_score);
  const mediaPrima = primaScores.length > 0
    ? (primaScores.reduce((acc, score) => acc + score, 0) / primaScores.length).toFixed(2)
    : 0;

  return (
    <TooltipProvider>
      <div>
        <h2 className="text-2xl font-bold mb-6" style={{ color: '#2E2E2E' }}>
          🧠 Indicadores Técnicos Consolidados
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Tooltip>
            <TooltipTrigger asChild>
              <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-shadow cursor-help">
                <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 opacity-10" style={{ backgroundColor: '#4B2672' }} />
                <CardHeader className="p-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-sm font-medium text-gray-600 mb-1">Avaliações Respondidas</p>
                      <p className="text-4xl font-bold" style={{ color: '#4B2672' }}>
                        {totalAvaliacoes.toLocaleString('pt-BR')}
                      </p>
                      <p className="text-xs text-gray-500 mt-2">
                        Total consolidado
                      </p>
                    </div>
                    <div className="p-3 rounded-xl" style={{ backgroundColor: '#F8F6FB' }}>
                      <FileText className="w-6 h-6" style={{ color: '#4B2672' }} />
                    </div>
                  </div>
                </CardHeader>
              </Card>
            </TooltipTrigger>
            <TooltipContent>
              <p className="text-xs max-w-xs">Total de avaliações completas em todo o ecossistema</p>
            </TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-shadow cursor-help">
                <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 bg-gray-500 rounded-full opacity-10" />
                <CardHeader className="p-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-sm font-medium text-gray-600 mb-1">Instrumentos Ativos</p>
                      <p className="text-4xl font-bold text-gray-700">
                        {instrumentosAtivos}
                      </p>
                      <p className="text-xs text-gray-500 mt-2">
                        PHQ-9, GAD-7, PRIMA-EF
                      </p>
                    </div>
                    <div className="p-3 rounded-xl bg-gray-50">
                      <Activity className="w-6 h-6 text-gray-600" />
                    </div>
                  </div>
                </CardHeader>
              </Card>
            </TooltipTrigger>
            <TooltipContent>
              <p className="text-xs max-w-xs">Instrumentos de avaliação utilizados no sistema</p>
            </TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-shadow cursor-help">
                <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 bg-orange-500 rounded-full opacity-10" />
                <CardHeader className="p-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-sm font-medium text-gray-600 mb-1">Prevalência Moderado+</p>
                      <p className="text-4xl font-bold text-orange-600">
                        {prevalencia}%
                      </p>
                      <p className="text-xs text-gray-500 mt-2">
                        PHQ-9/GAD-7 ≥ 10
                      </p>
                    </div>
                    <div className="p-3 rounded-xl bg-orange-50">
                      <AlertCircle className="w-6 h-6 text-orange-600" />
                    </div>
                  </div>
                </CardHeader>
              </Card>
            </TooltipTrigger>
            <TooltipContent>
              <p className="text-xs max-w-xs">Percentual de colaboradores com sintomas moderados ou graves</p>
            </TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-shadow cursor-help">
                <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 bg-green-500 rounded-full opacity-10" />
                <CardHeader className="p-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-sm font-medium text-gray-600 mb-1">Média PRIMA-EF Global</p>
                      <p className="text-4xl font-bold text-green-600">
                        {mediaPrima}
                      </p>
                      <p className="text-xs text-gray-500 mt-2">
                        Escala 1-5
                      </p>
                    </div>
                    <div className="p-3 rounded-xl bg-green-50">
                      <Brain className="w-6 h-6 text-green-600" />
                    </div>
                  </div>
                </CardHeader>
              </Card>
            </TooltipTrigger>
            <TooltipContent>
              <p className="text-xs max-w-xs">Pontuação média de riscos psicossociais (quanto maior, melhor)</p>
            </TooltipContent>
          </Tooltip>
        </div>
      </div>
    </TooltipProvider>
  );
}