import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { format, startOfMonth, subMonths } from "date-fns";
import { TrendingUp } from "lucide-react";

export default function TemporalEvolutionChart({ consultorias, companies, employees, assessments }) {
  const getTemporalData = () => {
    const monthlyData = {};
    const months = 12;

    // Inicializar últimos 12 meses
    for (let i = months - 1; i >= 0; i--) {
      const date = subMonths(new Date(), i);
      const month = format(startOfMonth(date), 'MM/yyyy');
      monthlyData[month] = {
        month,
        consultorias: 0,
        empresas: 0,
        colaboradores: 0,
        avaliacoes: 0
      };
    }

    // Contar consultorias ativas por mês
    consultorias.forEach(cons => {
      if (cons.created_date) {
        const createdDate = new Date(cons.created_date);
        for (let i = 0; i < months; i++) {
          const checkDate = subMonths(new Date(), i);
          if (createdDate <= checkDate && cons.status === 'ativo') {
            const month = format(startOfMonth(checkDate), 'MM/yyyy');
            if (monthlyData[month]) {
              monthlyData[month].consultorias++;
            }
          }
        }
      }
    });

    // Contar empresas por mês
    companies.forEach(comp => {
      if (comp.created_date) {
        const createdDate = new Date(comp.created_date);
        for (let i = 0; i < months; i++) {
          const checkDate = subMonths(new Date(), i);
          if (createdDate <= checkDate && comp.status === 'active') {
            const month = format(startOfMonth(checkDate), 'MM/yyyy');
            if (monthlyData[month]) {
              monthlyData[month].empresas++;
            }
          }
        }
      }
    });

    // Contar colaboradores por mês
    employees.forEach(emp => {
      if (emp.created_date) {
        const createdDate = new Date(emp.created_date);
        for (let i = 0; i < months; i++) {
          const checkDate = subMonths(new Date(), i);
          if (createdDate <= checkDate && emp.status === 'active') {
            const month = format(startOfMonth(checkDate), 'MM/yyyy');
            if (monthlyData[month]) {
              monthlyData[month].colaboradores++;
            }
          }
        }
      }
    });

    // Contar avaliações por mês
    assessments.forEach(ass => {
      if (ass.completed_at) {
        const month = format(startOfMonth(new Date(ass.completed_at)), 'MM/yyyy');
        if (monthlyData[month]) {
          monthlyData[month].avaliacoes++;
        }
      }
    });

    return Object.values(monthlyData).sort((a, b) => {
      const [monthA, yearA] = a.month.split('/');
      const [monthB, yearB] = b.month.split('/');
      return new Date(yearA, monthA - 1) - new Date(yearB, monthB - 1);
    });
  };

  const data = getTemporalData();

  // Calcular crescimento do último mês
  const lastMonth = data[data.length - 1];
  const previousMonth = data[data.length - 2];
  
  let insight = "Aguardando mais dados para gerar insights.";
  if (lastMonth && previousMonth) {
    const empresasCrescimento = previousMonth.empresas > 0 
      ? (((lastMonth.empresas - previousMonth.empresas) / previousMonth.empresas) * 100).toFixed(1)
      : 0;
    
    if (parseFloat(empresasCrescimento) > 0) {
      insight = `📈 As consultorias aumentaram o número de empresas em +${empresasCrescimento}% no último mês.`;
    } else if (parseFloat(empresasCrescimento) < 0) {
      insight = `📉 Houve uma redução de ${Math.abs(empresasCrescimento)}% no número de empresas no último mês.`;
    } else {
      insight = "📊 O número de empresas permaneceu estável no último mês.";
    }
  }

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg font-semibold">
          <TrendingUp className="w-5 h-5 text-blue-600" />
          Evolução do Ecossistema
        </CardTitle>
        <p className="text-sm text-gray-600 mt-1">
          Crescimento mensal de consultorias, empresas, colaboradores e avaliações
        </p>
      </CardHeader>
      <CardContent>
        {data.length > 0 ? (
          <>
            <ResponsiveContainer width="100%" height={350}>
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'white', 
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px',
                    padding: '12px'
                  }}
                />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="consultorias" 
                  stroke="#4B2672" 
                  strokeWidth={3} 
                  dot={{ r: 4 }} 
                  name="Consultorias"
                />
                <Line 
                  type="monotone" 
                  dataKey="empresas" 
                  stroke="#A57CE0" 
                  strokeWidth={3} 
                  dot={{ r: 4 }} 
                  name="Empresas"
                />
                <Line 
                  type="monotone" 
                  dataKey="colaboradores" 
                  stroke="#4D7CFF" 
                  strokeWidth={2} 
                  dot={{ r: 3 }} 
                  name="Colaboradores"
                />
                <Line 
                  type="monotone" 
                  dataKey="avaliacoes" 
                  stroke="#00B37E" 
                  strokeWidth={2} 
                  dot={{ r: 3 }} 
                  name="Avaliações"
                />
              </LineChart>
            </ResponsiveContainer>
            <div className="mt-4 p-4 rounded-lg" style={{ backgroundColor: '#F8F6FB' }}>
              <p className="text-sm font-semibold" style={{ color: '#4B2672' }}>
                {insight}
              </p>
            </div>
          </>
        ) : (
          <div className="h-[350px] flex items-center justify-center text-gray-400">
            Aguardando dados históricos
          </div>
        )}
      </CardContent>
    </Card>
  );
}