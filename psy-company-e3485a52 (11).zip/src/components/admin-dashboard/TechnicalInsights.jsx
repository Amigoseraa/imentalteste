import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Brain, TrendingUp, AlertTriangle, MessageCircle } from "lucide-react";
import { subMonths } from "date-fns";

export default function TechnicalInsights({ assessments }) {
  const getInsights = () => {
    const insights = [];
    
    const threeMonthsAgo = subMonths(new Date(), 3);
    
    // Avaliações recentes vs antigas
    const recentAssessments = assessments.filter(a => 
      a.completed_at && new Date(a.completed_at) > threeMonthsAgo
    );
    const oldAssessments = assessments.filter(a => 
      a.completed_at && new Date(a.completed_at) <= threeMonthsAgo
    );

    // Calcular mudança no PRIMA
    if (recentAssessments.length > 10 && oldAssessments.length > 10) {
      const recentPrima = recentAssessments
        .filter(a => a.prima_score)
        .reduce((acc, a) => acc + a.prima_score, 0) / recentAssessments.filter(a => a.prima_score).length;
      
      const oldPrima = oldAssessments
        .filter(a => a.prima_score)
        .reduce((acc, a) => acc + a.prima_score, 0) / oldAssessments.filter(a => a.prima_score).length;

      const change = ((recentPrima - oldPrima) / oldPrima) * 100;
      
      if (Math.abs(change) > 5) {
        insights.push({
          icon: change > 0 ? TrendingUp : AlertTriangle,
          color: change > 0 ? 'text-green-600' : 'text-orange-600',
          bgColor: change > 0 ? 'bg-green-50' : 'bg-orange-50',
          borderColor: change > 0 ? 'border-green-200' : 'border-orange-200',
          message: `A média de risco psicossocial ${change > 0 ? 'melhorou' : 'piorou'} ${Math.abs(change).toFixed(1)}% nos últimos 3 meses (PRIMA-EF).`
        });
      }
    }

    // Prevalência de casos graves
    const casesGraves = assessments.filter(a => 
      (a.phq9_score && a.phq9_score >= 15) || (a.gad7_score && a.gad7_score >= 15)
    ).length;
    
    const prevalenciaGrave = assessments.length > 0
      ? (casesGraves / assessments.length) * 100
      : 0;

    if (prevalenciaGrave > 10) {
      insights.push({
        icon: AlertTriangle,
        color: 'text-red-600',
        bgColor: 'bg-red-50',
        borderColor: 'border-red-200',
        message: `${prevalenciaGrave.toFixed(1)}% dos colaboradores apresentam sintomas graves de ansiedade ou depressão (PHQ-9/GAD-7 ≥15). Ação prioritária recomendada.`
      });
    }

    // Insight genérico se houver dados
    if (assessments.length > 100 && insights.length < 2) {
      insights.push({
        icon: Brain,
        color: 'text-purple-600',
        bgColor: 'bg-purple-50',
        borderColor: 'border-purple-200',
        message: `Base de dados consolidada com ${assessments.length.toLocaleString('pt-BR')} avaliações permite análises preditivas e intervenções baseadas em evidências.`
      });
    }

    return insights;
  };

  const insights = getInsights();

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Brain className="w-5 h-5" style={{ color: '#4B2672' }} />
          Insights Técnicos Automáticos
        </CardTitle>
      </CardHeader>
      <CardContent>
        {insights.length > 0 ? (
          <div className="grid md:grid-cols-3 gap-4">
            {insights.map((insight, idx) => (
              <div
                key={idx}
                className={`p-4 rounded-lg border-2 ${insight.bgColor} ${insight.borderColor}`}
              >
                <div className="flex items-start gap-3">
                  <insight.icon className={`w-6 h-6 ${insight.color} flex-shrink-0 mt-0.5`} />
                  <p className="text-sm text-gray-700 leading-relaxed">
                    {insight.message}
                  </p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <Brain className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-sm text-gray-500">Aguardando volume suficiente de dados para gerar insights</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}