import React from "react";
import { Card, CardHeader } from "@/components/ui/card";
import { DollarSign, TrendingUp, Users, CreditCard, AlertTriangle } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { format } from "date-fns";

export default function FinancialKPIs({ consultorias, faturas }) {
  const currentMonth = format(new Date(), 'yyyy-MM');
  const lastMonth = format(new Date(new Date().setMonth(new Date().getMonth() - 1)), 'yyyy-MM');

  // MRR Real - Faturas pagas do mês atual
  const faturasDoMes = (faturas || []).filter(f => 
    f.competencia === currentMonth && f.status === 'paga'
  );
  const mrrAtual = faturasDoMes.reduce((sum, f) => sum + (f.valor_liquido || 0), 0);

  // MRR do mês anterior
  const faturasDoMesAnterior = (faturas || []).filter(f => 
    f.competencia === lastMonth && f.status === 'paga'
  );
  const mrrAnterior = faturasDoMesAnterior.reduce((sum, f) => sum + (f.valor_liquido || 0), 0);

  // Crescimento de MRR
  const mrrGrowth = mrrAnterior > 0
    ? (((mrrAtual - mrrAnterior) / mrrAnterior) * 100).toFixed(1)
    : 0;

  // ARR (MRR * 12)
  const arr = mrrAtual * 12;

  // Receita total realizada
  const receitaRealizada = (faturas || []).filter(f => f.status === 'paga')
    .reduce((sum, f) => sum + (f.valor_liquido || 0), 0);

  // Inadimplência
  const faturasVencidas = (faturas || []).filter(f => {
    if (f.status === 'paga') return false;
    if (!f.vencimento_em) return false;
    return new Date(f.vencimento_em) < new Date();
  });
  const valorInadimplente = faturasVencidas.reduce((sum, f) => sum + (f.valor_liquido || 0), 0);

  // Taxa de conversão (faturas pagas / faturas emitidas)
  const faturasEmitidas = (faturas || []).filter(f => 
    f.competencia === currentMonth && ['autorizada', 'enviada', 'paga', 'vencida'].includes(f.status)
  );
  const taxaConversao = faturasEmitidas.length > 0
    ? ((faturasDoMes.length / faturasEmitidas.length) * 100).toFixed(1)
    : 0;

  const formatCurrency = (value) => {
    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 0 });
  };

  return (
    <TooltipProvider>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        {/* MRR Real */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-shadow cursor-help">
              <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 rounded-full opacity-10" style={{ backgroundColor: '#4B2672' }} />
              <CardHeader className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-600 mb-1">MRR (Real)</p>
                    <p className="text-4xl font-bold" style={{ color: '#4B2672' }}>
                      {formatCurrency(mrrAtual)}
                    </p>
                    {mrrAnterior > 0 && (
                      <p className={`text-xs font-semibold mt-2 ${
                        parseFloat(mrrGrowth) >= 0 ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {parseFloat(mrrGrowth) >= 0 ? '+' : ''}{mrrGrowth}% vs mês anterior
                      </p>
                    )}
                  </div>
                  <div className="p-3 rounded-xl" style={{ backgroundColor: '#F8F6FB' }}>
                    <DollarSign className="w-6 h-6" style={{ color: '#4B2672' }} />
                  </div>
                </div>
              </CardHeader>
            </Card>
          </TooltipTrigger>
          <TooltipContent>
            <p className="text-xs max-w-xs">
              Receita mensal recorrente real baseada em faturas pagas no mês atual ({currentMonth})
            </p>
          </TooltipContent>
        </Tooltip>

        {/* ARR */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-shadow cursor-help">
              <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 rounded-full opacity-10" style={{ backgroundColor: '#00B37E' }} />
              <CardHeader className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-600 mb-1">ARR (Projeção)</p>
                    <p className="text-4xl font-bold text-green-600">
                      {formatCurrency(arr)}
                    </p>
                    <p className="text-xs text-gray-500 mt-2">
                      MRR × 12
                    </p>
                  </div>
                  <div className="p-3 rounded-xl bg-green-50">
                    <TrendingUp className="w-6 h-6 text-green-600" />
                  </div>
                </div>
              </CardHeader>
            </Card>
          </TooltipTrigger>
          <TooltipContent>
            <p className="text-xs max-w-xs">
              Receita recorrente anual projetada baseada no MRR atual
            </p>
          </TooltipContent>
        </Tooltip>

        {/* Receita Realizada Total */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-shadow cursor-help">
              <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 rounded-full opacity-10" style={{ backgroundColor: '#4D7CFF' }} />
              <CardHeader className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-600 mb-1">Receita Total</p>
                    <p className="text-4xl font-bold" style={{ color: '#4D7CFF' }}>
                      {formatCurrency(receitaRealizada)}
                    </p>
                    <p className="text-xs text-gray-500 mt-2">
                      Acumulado histórico
                    </p>
                  </div>
                  <div className="p-3 rounded-xl bg-blue-50">
                    <DollarSign className="w-6 h-6 text-blue-600" />
                  </div>
                </div>
              </CardHeader>
            </Card>
          </TooltipTrigger>
          <TooltipContent>
            <p className="text-xs max-w-xs">
              Total de receita realizada desde o início (todas faturas pagas)
            </p>
          </TooltipContent>
        </Tooltip>

        {/* Taxa de Conversão */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-shadow cursor-help">
              <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 rounded-full opacity-10" style={{ backgroundColor: '#FFD84D' }} />
              <CardHeader className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-600 mb-1">Taxa de Conversão</p>
                    <p className="text-4xl font-bold text-yellow-600">
                      {taxaConversao}%
                    </p>
                    <p className="text-xs text-gray-500 mt-2">
                      {faturasDoMes.length} de {faturasEmitidas.length} pagas
                    </p>
                  </div>
                  <div className="p-3 rounded-xl bg-yellow-50">
                    <CreditCard className="w-6 h-6 text-yellow-600" />
                  </div>
                </div>
              </CardHeader>
            </Card>
          </TooltipTrigger>
          <TooltipContent>
            <p className="text-xs max-w-xs">
              Percentual de faturas emitidas no mês atual que foram pagas
            </p>
          </TooltipContent>
        </Tooltip>

        {/* Inadimplência */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-shadow cursor-help">
              <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 rounded-full opacity-10 bg-red-500" />
              <CardHeader className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-600 mb-1">Inadimplência</p>
                    <p className="text-4xl font-bold text-red-600">
                      {formatCurrency(valorInadimplente)}
                    </p>
                    <p className="text-xs text-gray-500 mt-2">
                      {faturasVencidas.length} fatura{faturasVencidas.length !== 1 ? 's' : ''} vencida{faturasVencidas.length !== 1 ? 's' : ''}
                    </p>
                  </div>
                  <div className="p-3 rounded-xl bg-red-50">
                    <AlertTriangle className="w-6 h-6 text-red-600" />
                  </div>
                </div>
              </CardHeader>
            </Card>
          </TooltipTrigger>
          <TooltipContent>
            <p className="text-xs max-w-xs">
              Total de faturas vencidas e não pagas
            </p>
          </TooltipContent>
        </Tooltip>
      </div>
    </TooltipProvider>
  );
}