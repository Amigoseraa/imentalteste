import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Building2, Eye } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { createPageUrl } from "@/utils";

export default function ConsultoriaTable({ consultorias, companies, assessments, employees }) {
  const [search, setSearch] = useState('');

  const getConsultoriaData = () => {
    return consultorias.map(consultoria => {
      const consultoriaCompanies = companies.filter(c => c.consultoria_id === consultoria.id);
      const consultoriaEmployees = employees.filter(e => 
        consultoriaCompanies.some(c => c.id === e.company_id)
      );
      const consultoriaAssessments = assessments.filter(a => 
        consultoriaCompanies.some(c => c.id === a.company_id)
      );
      
      const engagementRate = consultoriaEmployees.length > 0
        ? ((consultoriaAssessments.length / consultoriaEmployees.length) * 100).toFixed(1)
        : 0;

      return {
        id: consultoria.id,
        nome: consultoria.nome_fantasia,
        status: consultoria.status,
        empresas: consultoriaCompanies.length,
        colaboradores: consultoriaEmployees.length,
        avaliacoes: consultoriaAssessments.length,
        engajamento: parseFloat(engagementRate)
      };
    });
  };

  const data = getConsultoriaData().filter(c => 
    c.nome.toLowerCase().includes(search.toLowerCase())
  );

  const getStatusBadge = (status) => {
    switch (status) {
      case 'ativo':
        return <Badge className="bg-green-100 text-green-800">🟢 Ativo</Badge>;
      case 'inativo':
        return <Badge className="bg-gray-100 text-gray-800">⚪ Inativo</Badge>;
      case 'suspenso':
        return <Badge className="bg-red-100 text-red-800">🔴 Suspenso</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">⚪ Indefinido</Badge>;
    }
  };

  const handleViewConsultoria = (consultoriaId) => {
    // Implementar visualização detalhada da consultoria
    window.location.href = createPageUrl(`ConsultoriaDashboard?id=${consultoriaId}`);
  };

  return (
    <Card className="shadow-md">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-lg font-semibold">
            <Building2 className="w-5 h-5" style={{ color: '#4B2672' }} />
            Tabela de Consultorias
          </CardTitle>
          <Input
            placeholder="Buscar consultoria..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="max-w-xs"
          />
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50">
                <TableHead>Consultoria</TableHead>
                <TableHead className="text-center">Empresas</TableHead>
                <TableHead className="text-center">Colaboradores</TableHead>
                <TableHead className="text-center">Avaliações</TableHead>
                <TableHead className="text-center">Engajamento</TableHead>
                <TableHead className="text-center">Status</TableHead>
                <TableHead className="text-center">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((consultoria) => (
                <TableRow key={consultoria.id} className="hover:bg-gray-50">
                  <TableCell className="font-medium">{consultoria.nome}</TableCell>
                  <TableCell className="text-center">{consultoria.empresas}</TableCell>
                  <TableCell className="text-center">{consultoria.colaboradores}</TableCell>
                  <TableCell className="text-center">{consultoria.avaliacoes}</TableCell>
                  <TableCell className="text-center">
                    <span className={`font-semibold ${
                      consultoria.engajamento >= 75 ? 'text-green-600' :
                      consultoria.engajamento >= 50 ? 'text-yellow-600' :
                      'text-red-600'
                    }`}>
                      {consultoria.engajamento}%
                    </span>
                  </TableCell>
                  <TableCell className="text-center">
                    {getStatusBadge(consultoria.status)}
                  </TableCell>
                  <TableCell className="text-center">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleViewConsultoria(consultoria.id)}
                      title="Ver detalhes"
                    >
                      <Eye className="w-4 h-4" style={{ color: '#4B2672' }} />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}