import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Activity, Clock, Users, TrendingUp } from "lucide-react";
import { format, parseISO, differenceInDays } from "date-fns";

export default function AdvancedMetrics({ assessments, employees, companies }) {
  const getEngagementRate = () => {
    const completed = assessments.filter(a => a.completed_at).length;
    return employees.length > 0 
      ? ((completed / employees.length) * 100).toFixed(1)
      : 0;
  };

  const getAssessmentsLast6Months = () => {
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
    
    return assessments.filter(a => {
      if (!a.completed_at) return false;
      return new Date(a.completed_at) >= sixMonthsAgo;
    }).length;
  };

  const getAverageDaysSinceLastAssessment = () => {
    const companyLastAssessments = companies.map(company => {
      const companyAssessments = assessments
        .filter(a => a.company_id === company.id && a.completed_at)
        .sort((a, b) => new Date(b.completed_at) - new Date(a.completed_at));
      
      if (companyAssessments.length === 0) return null;
      
      return differenceInDays(new Date(), parseISO(companyAssessments[0].completed_at));
    }).filter(d => d !== null);

    if (companyLastAssessments.length === 0) return 0;
    
    return Math.round(
      companyLastAssessments.reduce((a, b) => a + b, 0) / companyLastAssessments.length
    );
  };

  const getTopRiskSectors = () => {
    const sectorData = {};
    
    companies.forEach(company => {
      if (!company.sector) return;
      
      const companyAssessments = assessments.filter(a => a.company_id === company.id);
      const highRisk = companyAssessments.filter(a => a.prima_classification === 'Alto').length;
      const total = companyAssessments.length;
      
      if (total === 0) return;
      
      if (!sectorData[company.sector]) {
        sectorData[company.sector] = { highRisk: 0, total: 0 };
      }
      
      sectorData[company.sector].highRisk += highRisk;
      sectorData[company.sector].total += total;
    });

    return Object.entries(sectorData)
      .map(([sector, data]) => ({
        sector,
        percentage: ((data.highRisk / data.total) * 100).toFixed(1)
      }))
      .sort((a, b) => b.percentage - a.percentage)
      .slice(0, 5);
  };

  const topSectors = getTopRiskSectors();

  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
      <Card className="shadow-md">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
            <Activity className="w-4 h-4" />
            Taxa de Engajamento
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-3xl font-bold text-blue-600">{getEngagementRate()}%</p>
          <p className="text-xs text-gray-500 mt-2">
            {assessments.filter(a => a.completed_at).length} de {employees.length} colaboradores
          </p>
        </CardContent>
      </Card>

      <Card className="shadow-md">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
            <TrendingUp className="w-4 h-4" />
            Avaliações (6 meses)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-3xl font-bold text-green-600">{getAssessmentsLast6Months()}</p>
          <p className="text-xs text-gray-500 mt-2">
            Total coletadas
          </p>
        </CardContent>
      </Card>

      <Card className="shadow-md">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
            <Clock className="w-4 h-4" />
            Tempo Médio
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-3xl font-bold text-purple-600">{getAverageDaysSinceLastAssessment()}</p>
          <p className="text-xs text-gray-500 mt-2">
            dias desde última avaliação
          </p>
        </CardContent>
      </Card>

      <Card className="shadow-md">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
            <Users className="w-4 h-4" />
            Setores de Risco
          </CardTitle>
        </CardHeader>
        <CardContent>
          {topSectors.length > 0 ? (
            <div className="space-y-2">
              {topSectors.slice(0, 2).map((sector, idx) => (
                <div key={idx} className="flex justify-between text-xs">
                  <span className="text-gray-600 truncate">{sector.sector}</span>
                  <span className="font-semibold text-red-600">{sector.percentage}%</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-gray-400">Sem dados</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}