import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts";
import { PieChart as PieIcon } from "lucide-react";

export default function RiskDistributionPie({ assessments }) {
  const getRiskData = () => {
    const dist = { Baixo: 0, Moderado: 0, Alto: 0 };
    assessments.forEach(a => {
      if (a.prima_classification) {
        dist[a.prima_classification]++;
      }
    });
    
    return [
      { name: 'Baixo Risco', value: dist.Baixo, color: '#10b981', percentage: assessments.length > 0 ? ((dist.Baixo / assessments.length) * 100).toFixed(1) : 0 },
      { name: 'Moderado', value: dist.Moderado, color: '#f59e0b', percentage: assessments.length > 0 ? ((dist.Moderado / assessments.length) * 100).toFixed(1) : 0 },
      { name: 'Alto Risco', value: dist.Alto, color: '#ef4444', percentage: assessments.length > 0 ? ((dist.Alto / assessments.length) * 100).toFixed(1) : 0 }
    ];
  };

  const data = getRiskData();
  const total = assessments.length;

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg font-semibold">
          <PieIcon className="w-5 h-5 text-blue-600" />
          Distribuição de Riscos Psicossociais
        </CardTitle>
      </CardHeader>
      <CardContent>
        {assessments.length > 0 ? (
          <div className="space-y-4">
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <Pie
                  data={data}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ percentage }) => `${percentage}%`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  formatter={(value, name, props) => [
                    `${value} colaboradores (${props.payload.percentage}%)`,
                    props.payload.name
                  ]}
                />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
            <div className="text-center text-sm text-gray-600">
              Total de <span className="font-semibold">{total}</span> colaboradores avaliados
            </div>
          </div>
        ) : (
          <div className="h-[300px] flex items-center justify-center text-gray-400">
            Aguardando dados de avaliações
          </div>
        )}
      </CardContent>
    </Card>
  );
}