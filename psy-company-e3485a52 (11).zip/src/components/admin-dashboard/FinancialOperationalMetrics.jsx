import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { format } from "date-fns";
import { TrendingUp, DollarSign, FileText, CheckCircle, AlertTriangle } from "lucide-react";

export default function FinancialOperationalMetrics({ consultorias, companies, employees, faturas }) {
  const currentMonth = format(new Date(), 'yyyy-MM');

  // Ticket Médio por Consultoria
  const consultoriasAtivas = consultorias.filter(c => c.status === 'ativo');
  const faturasAtuais = faturas.filter(f => f.competencia === currentMonth && f.status === 'paga');
  const receitaTotal = faturasAtuais.reduce((acc, f) => acc + (f.valor_total || 0), 0);
  const ticketMedioPorConsultoria = consultoriasAtivas.length > 0
    ? receitaTotal / consultoriasAtivas.length
    : 0;

  // Ticket Médio por Empresa
  const empresasAtivas = companies.filter(c => c.status === 'active');
  const ticketMedioPorEmpresa = empresasAtivas.length > 0
    ? receitaTotal / empresasAtivas.length
    : 0;

  // Novas Faturas Emitidas
  const novasFaturas = faturas.filter(f => f.competencia === currentMonth).length;

  // Faturas Pagas (%)
  const faturasCompetencia = faturas.filter(f => f.competencia === currentMonth);
  const faturasPagas = faturasCompetencia.filter(f => f.status === 'paga').length;
  const percentualPagas = faturasCompetencia.length > 0
    ? ((faturasPagas / faturasCompetencia.length) * 100).toFixed(1)
    : 0;

  // Consultorias com Receita 0
  const consultoriasReceitaZero = consultorias.filter(c => {
    const consultoriaFaturas = faturas.filter(f => f.destino_id === c.id && f.competencia === currentMonth);
    return consultoriaFaturas.length === 0 || consultoriaFaturas.every(f => (f.valor_total || 0) === 0);
  }).length;

  const metrics = [
    {
      title: "Ticket Médio por Consultoria",
      value: ticketMedioPorConsultoria.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }),
      icon: TrendingUp,
      color: "text-purple-600",
      bgColor: "bg-purple-50"
    },
    {
      title: "Ticket Médio por Empresa",
      value: ticketMedioPorEmpresa.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }),
      icon: DollarSign,
      color: "text-blue-600",
      bgColor: "bg-blue-50"
    },
    {
      title: "Novas Faturas Emitidas",
      value: novasFaturas,
      icon: FileText,
      color: "text-green-600",
      bgColor: "bg-green-50"
    },
    {
      title: "Faturas Pagas (%)",
      value: `${percentualPagas}%`,
      detail: `${faturasPagas} de ${faturasCompetencia.length}`,
      icon: CheckCircle,
      color: "text-green-600",
      bgColor: "bg-green-50"
    },
    {
      title: "Consultorias com Receita 0",
      value: consultoriasReceitaZero,
      detail: "Inativas no mês",
      icon: AlertTriangle,
      color: "text-red-600",
      bgColor: "bg-red-50"
    }
  ];

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle>Indicadores Operacionais Financeiros</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {metrics.map((metric, idx) => (
            <div key={idx} className={`p-4 rounded-lg border-2 ${metric.bgColor} border-gray-200`}>
              <div className="flex items-start justify-between mb-2">
                <p className="text-sm font-medium text-gray-600">{metric.title}</p>
                <metric.icon className={`w-5 h-5 ${metric.color}`} />
              </div>
              <p className={`text-2xl font-bold ${metric.color}`}>
                {metric.value}
              </p>
              {metric.detail && (
                <p className="text-xs text-gray-500 mt-1">{metric.detail}</p>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}