import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { Trophy, TrendingUp, Users, DollarSign } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function ConsultoriaStrategicRankings({ consultoriaData, faturas, currentMonth }) {
  // Ranking por Receita (Top 10)
  const revenueRanking = [...consultoriaData]
    .filter(c => c.faturamento > 0)
    .sort((a, b) => b.faturamento - a.faturamento)
    .slice(0, 10)
    .map(c => ({
      name: c.nome_fantasia,
      value: c.faturamento,
      empresas: c.empresas
    }));

  // Ranking por Crescimento (últimos 30 dias)
  const growthRanking = [...consultoriaData]
    .filter(c => {
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      return c.created_date && new Date(c.created_date) > thirtyDaysAgo;
    })
    .sort((a, b) => b.empresas - a.empresas)
    .slice(0, 10)
    .map(c => ({
      name: c.nome_fantasia,
      empresas: c.empresas,
      crescimento: c.empresas // Placeholder, ideally calculate real growth
    }));

  // Ranking por Base de Clientes
  const clientBaseRanking = [...consultoriaData]
    .sort((a, b) => b.empresas - a.empresas)
    .slice(0, 10);

  // Ranking por Ticket Médio
  const ticketRanking = [...consultoriaData]
    .filter(c => c.empresas > 0 && c.faturamento > 0)
    .map(c => ({
      ...c,
      ticketMedio: c.faturamento / c.empresas
    }))
    .sort((a, b) => b.ticketMedio - a.ticketMedio)
    .slice(0, 10);

  const formatCurrency = (value) => {
    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 0 });
  };

  const getRevenueColor = (value, max) => {
    const percentage = (value / max) * 100;
    if (percentage >= 80) return '#2ECC71';
    if (percentage >= 50) return '#FFD84D';
    return '#A57CE0';
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold" style={{ color: '#2E2E2E' }}>
        Rankings Estratégicos
      </h2>

      {/* Rankings Grid */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Ranking por Receita */}
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg font-semibold">
              <Trophy className="w-5 h-5" style={{ color: '#FFD84D' }} />
              Top 10 por Faturamento
            </CardTitle>
            <p className="text-sm text-gray-600 mt-1">
              Consultorias com maior receita no mês corrente
            </p>
          </CardHeader>
          <CardContent>
            {revenueRanking.length > 0 ? (
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={revenueRanking} layout="vertical" margin={{ left: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis type="number" tick={{ fontSize: 12 }} />
                  <YAxis 
                    type="category" 
                    dataKey="name" 
                    width={150} 
                    tick={{ fontSize: 12 }} 
                  />
                  <Tooltip 
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0].payload;
                        return (
                          <div className="bg-white p-3 rounded-lg shadow-lg border border-gray-200">
                            <p className="font-semibold text-gray-900 mb-1">{data.name}</p>
                            <p className="text-sm text-green-600">
                              Receita: {formatCurrency(data.value)}
                            </p>
                            <p className="text-xs text-gray-500">
                              {data.empresas} empresas
                            </p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Bar dataKey="value" radius={[0, 8, 8, 0]}>
                    {revenueRanking.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={getRevenueColor(entry.value, revenueRanking[0].value)} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[400px] flex items-center justify-center text-gray-400">
                Aguardando dados de faturamento
              </div>
            )}
          </CardContent>
        </Card>

        {/* Ranking por Base de Clientes */}
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg font-semibold">
              <Users className="w-5 h-5" style={{ color: '#4B2672' }} />
              Top 10 por Base de Clientes
            </CardTitle>
            <p className="text-sm text-gray-600 mt-1">
              Consultorias com mais empresas vinculadas
            </p>
          </CardHeader>
          <CardContent>
            {clientBaseRanking.length > 0 ? (
              <div className="space-y-2">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead>#</TableHead>
                      <TableHead>Consultoria</TableHead>
                      <TableHead className="text-center">Empresas</TableHead>
                      <TableHead className="text-center">Colaboradores</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {clientBaseRanking.map((c, idx) => (
                      <TableRow key={c.id}>
                        <TableCell className="font-semibold">
                          {idx + 1}
                        </TableCell>
                        <TableCell>
                          <p className="font-medium">{c.nome_fantasia}</p>
                        </TableCell>
                        <TableCell className="text-center font-semibold text-blue-600">
                          {c.empresas}
                        </TableCell>
                        <TableCell className="text-center font-semibold text-gray-600">
                          {c.colaboradores.toLocaleString('pt-BR')}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="h-[400px] flex items-center justify-center text-gray-400">
                Nenhum dado disponível
              </div>
            )}
          </CardContent>
        </Card>

        {/* Ranking por Ticket Médio */}
        <Card className="shadow-md lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg font-semibold">
              <DollarSign className="w-5 h-5 text-green-600" />
              Top 10 por Ticket Médio
            </CardTitle>
            <p className="text-sm text-gray-600 mt-1">
              Consultorias com maior receita média por empresa
            </p>
          </CardHeader>
          <CardContent>
            {ticketRanking.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50">
                    <TableHead>#</TableHead>
                    <TableHead>Consultoria</TableHead>
                    <TableHead className="text-center">Empresas</TableHead>
                    <TableHead className="text-center">Faturamento Total</TableHead>
                    <TableHead className="text-center">Ticket Médio</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {ticketRanking.map((c, idx) => (
                    <TableRow key={c.id}>
                      <TableCell className="font-semibold">
                        {idx + 1}
                      </TableCell>
                      <TableCell>
                        <p className="font-medium">{c.nome_fantasia}</p>
                      </TableCell>
                      <TableCell className="text-center">
                        {c.empresas}
                      </TableCell>
                      <TableCell className="text-center text-green-600 font-semibold">
                        {formatCurrency(c.faturamento)}
                      </TableCell>
                      <TableCell className="text-center font-bold" style={{ color: '#4B2672' }}>
                        {formatCurrency(c.ticketMedio)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="h-[200px] flex items-center justify-center text-gray-400">
                Aguardando dados de faturamento
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}