import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { Trophy, TrendingUp } from "lucide-react";

export default function ConsultoriaRankings({ consultoriaData }) {
  // Ranking por IM-Score
  const imScoreData = consultoriaData
    .filter(c => c.imScore > 0)
    .sort((a, b) => b.imScore - a.imScore)
    .slice(0, 10)
    .map(c => ({
      name: c.nome_fantasia,
      score: parseFloat(c.imScore)
    }));

  // Ranking por Engajamento
  const engagementData = consultoriaData
    .filter(c => c.colaboradores > 0)
    .sort((a, b) => b.engajamento - a.engajamento)
    .slice(0, 10)
    .map(c => ({
      name: c.nome_fantasia,
      engagement: parseFloat(c.engajamento)
    }));

  const getIMScoreColor = (value) => {
    if (value >= 70) return '#2ECC71';
    if (value >= 50) return '#FFD84D';
    return '#E74C3C';
  };

  const getEngagementColor = (value) => {
    if (value >= 75) return '#2ECC71';
    if (value >= 50) return '#FFD84D';
    return '#E74C3C';
  };

  return (
    <div className="grid lg:grid-cols-2 gap-6">
      {/* Ranking por IM-Score */}
      <Card className="shadow-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg font-semibold">
            <Trophy className="w-5 h-5" style={{ color: '#FFD84D' }} />
            Ranking por IM-Score
          </CardTitle>
          <p className="text-sm text-gray-600 mt-1">
            Top 10 consultorias com melhor índice de saúde mental
          </p>
        </CardHeader>
        <CardContent>
          {imScoreData.length > 0 ? (
            <ResponsiveContainer width="100%" height={400}>
              <BarChart data={imScoreData} layout="vertical" margin={{ left: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 12 }} />
                <YAxis 
                  type="category" 
                  dataKey="name" 
                  width={150} 
                  tick={{ fontSize: 12 }} 
                />
                <Tooltip 
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="bg-white p-3 rounded-lg shadow-lg border border-gray-200">
                          <p className="font-semibold text-gray-900 mb-1">{data.name}</p>
                          <p className="text-sm" style={{ color: getIMScoreColor(data.score) }}>
                            IM-Score: {data.score}
                          </p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar dataKey="score" radius={[0, 8, 8, 0]}>
                  {imScoreData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={getIMScoreColor(entry.score)} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[400px] flex items-center justify-center text-gray-400">
              Aguardando dados de avaliações
            </div>
          )}
        </CardContent>
      </Card>

      {/* Ranking por Engajamento */}
      <Card className="shadow-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg font-semibold">
            <TrendingUp className="w-5 h-5" style={{ color: '#4B2672' }} />
            Ranking por Engajamento
          </CardTitle>
          <p className="text-sm text-gray-600 mt-1">
            Top 10 consultorias com maior taxa de resposta
          </p>
        </CardHeader>
        <CardContent>
          {engagementData.length > 0 ? (
            <ResponsiveContainer width="100%" height={400}>
              <BarChart data={engagementData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} tick={{ fontSize: 10 }} />
                <YAxis domain={[0, 100]} tick={{ fontSize: 12 }} />
                <Tooltip 
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="bg-white p-3 rounded-lg shadow-lg border border-gray-200">
                          <p className="font-semibold text-gray-900 mb-1">{data.name}</p>
                          <p className="text-sm" style={{ color: getEngagementColor(data.engagement) }}>
                            Engajamento: {data.engagement}%
                          </p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar dataKey="engagement" radius={[8, 8, 0, 0]}>
                  {engagementData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={getEngagementColor(entry.engagement)} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[400px] flex items-center justify-center text-gray-400">
              Aguardando dados de engajamento
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}