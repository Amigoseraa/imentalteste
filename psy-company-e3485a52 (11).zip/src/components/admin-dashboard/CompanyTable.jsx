import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Building, ExternalLink } from "lucide-react";
import { format, parseISO } from "date-fns";
import { Input } from "@/components/ui/input";

export default function CompanyTable({ companies, assessments, employees }) {
  const [search, setSearch] = useState('');

  const getCompanyData = () => {
    return companies.map(company => {
      const companyAssessments = assessments.filter(a => a.company_id === company.id);
      const companyEmployees = employees.filter(e => e.company_id === company.id);
      
      const ibcScores = companyAssessments.map(a => a.ibc_score).filter(s => s);
      const avgIBC = ibcScores.length > 0 
        ? (ibcScores.reduce((a, b) => a + b, 0) / ibcScores.length).toFixed(1)
        : 0;

      const highRisk = companyAssessments.filter(a => a.prima_classification === 'Alto').length;
      const highRiskPct = companyAssessments.length > 0 
        ? ((highRisk / companyAssessments.length) * 100).toFixed(1)
        : 0;

      const mentalHealthCritical = companyAssessments.filter(a => 
        a.phq9_classification === 'Moderado-Grave' || 
        a.phq9_classification === 'Grave' ||
        a.gad7_classification === 'Moderado' ||
        a.gad7_classification === 'Grave'
      ).length;
      const mentalHealthPct = companyAssessments.length > 0
        ? ((mentalHealthCritical / companyAssessments.length) * 100).toFixed(1)
        : 0;

      const lastAssessment = companyAssessments
        .filter(a => a.completed_at)
        .sort((a, b) => new Date(b.completed_at) - new Date(a.completed_at))[0];

      const status = avgIBC >= 80 ? 'healthy' : avgIBC >= 60 ? 'warning' : avgIBC > 0 ? 'critical' : 'inactive';

      return {
        id: company.id,
        name: company.name,
        cnpj: company.cnpj,
        ibc: avgIBC,
        highRiskPct,
        mentalHealthPct,
        assessedEmployees: companyAssessments.length,
        totalEmployees: companyEmployees.length,
        lastAssessment: lastAssessment?.completed_at || null,
        status
      };
    });
  };

  const data = getCompanyData().filter(c => 
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.cnpj.includes(search)
  );

  const getStatusBadge = (status) => {
    switch (status) {
      case 'healthy':
        return <Badge className="bg-green-100 text-green-800">🟢 Saudável</Badge>;
      case 'warning':
        return <Badge className="bg-yellow-100 text-yellow-800">🟡 Atenção</Badge>;
      case 'critical':
        return <Badge className="bg-red-100 text-red-800">🔴 Crítico</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">⚪ Inativa</Badge>;
    }
  };

  return (
    <Card className="shadow-md">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-lg font-semibold">
            <Building className="w-5 h-5 text-blue-600" />
            Tabela Consolidada de Empresas
          </CardTitle>
          <Input
            placeholder="Buscar empresa..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="max-w-xs"
          />
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50">
                <TableHead>Empresa</TableHead>
                <TableHead>CNPJ</TableHead>
                <TableHead className="text-center">IBC</TableHead>
                <TableHead className="text-center">PRIMA Alto</TableHead>
                <TableHead className="text-center">PHQ/GAD Grave</TableHead>
                <TableHead className="text-center">Avaliados</TableHead>
                <TableHead>Última Avaliação</TableHead>
                <TableHead className="text-center">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((company) => (
                <TableRow key={company.id} className="hover:bg-gray-50">
                  <TableCell className="font-medium">{company.name}</TableCell>
                  <TableCell className="text-sm text-gray-600">{company.cnpj}</TableCell>
                  <TableCell className="text-center">
                    <span className={`font-semibold ${
                      company.ibc >= 80 ? 'text-green-600' :
                      company.ibc >= 60 ? 'text-yellow-600' :
                      company.ibc > 0 ? 'text-red-600' : 'text-gray-400'
                    }`}>
                      {company.ibc || '-'}
                    </span>
                  </TableCell>
                  <TableCell className="text-center">
                    <span className="font-semibold text-red-600">{company.highRiskPct}%</span>
                  </TableCell>
                  <TableCell className="text-center">
                    <span className="font-semibold text-orange-600">{company.mentalHealthPct}%</span>
                  </TableCell>
                  <TableCell className="text-center">
                    <span className="text-sm">
                      {company.assessedEmployees}/{company.totalEmployees}
                    </span>
                  </TableCell>
                  <TableCell className="text-sm">
                    {company.lastAssessment 
                      ? format(parseISO(company.lastAssessment), 'dd/MM/yyyy')
                      : '-'
                    }
                  </TableCell>
                  <TableCell className="text-center">
                    {getStatusBadge(company.status)}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}