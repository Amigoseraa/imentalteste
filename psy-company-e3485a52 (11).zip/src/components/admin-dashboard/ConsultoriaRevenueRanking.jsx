import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { Trophy } from "lucide-react";
import { format } from "date-fns";

export default function ConsultoriaRevenueRanking({ consultorias, faturas }) {
  const currentMonth = format(new Date(), 'yyyy-MM');

  const getRevenueRanking = () => {
    return consultorias
      .map(consultoria => {
        const consultoriaFaturas = faturas.filter(f => 
          f.destino_id === consultoria.id && 
          f.competencia === currentMonth &&
          f.status === 'paga'
        );
        
        const revenue = consultoriaFaturas.reduce((acc, f) => acc + (f.valor_total || 0), 0);

        return {
          name: consultoria.nome_fantasia,
          revenue,
          faturas: consultoriaFaturas.length
        };
      })
      .filter(c => c.revenue > 0)
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 10);
  };

  const data = getRevenueRanking();

  const getColor = (index) => {
    const colors = ['#00B37E', '#4B2672', '#A57CE0', '#FFD84D', '#4D7CFF', '#F5B800', '#6B36B4', '#E8C4FF', '#2ECC71', '#95E1D3'];
    return colors[index % colors.length];
  };

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Trophy className="w-5 h-5" style={{ color: '#FFD84D' }} />
          Top 10 Consultorias por Faturamento
        </CardTitle>
      </CardHeader>
      <CardContent>
        {data.length > 0 ? (
          <ResponsiveContainer width="100%" height={400}>
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis 
                dataKey="name" 
                angle={-45} 
                textAnchor="end" 
                height={120} 
                tick={{ fontSize: 11 }} 
              />
              <YAxis 
                tickFormatter={(value) => `R$ ${(value / 1000).toFixed(0)}k`}
                tick={{ fontSize: 12 }}
              />
              <Tooltip 
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload;
                    return (
                      <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
                        <p className="font-semibold text-gray-900 mb-2">{data.name}</p>
                        <div className="space-y-1 text-sm">
                          <p className="flex items-center justify-between gap-4">
                            <span className="text-gray-600">Receita:</span>
                            <span className="font-semibold text-green-600">
                              {data.revenue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                            </span>
                          </p>
                          <p className="flex items-center justify-between gap-4">
                            <span className="text-gray-600">Faturas:</span>
                            <span className="font-semibold">{data.faturas}</span>
                          </p>
                        </div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Bar dataKey="revenue" radius={[8, 8, 0, 0]}>
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={getColor(index)} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-[400px] flex items-center justify-center text-gray-400">
            Aguardando dados de faturamento
          </div>
        )}
      </CardContent>
    </Card>
  );
}