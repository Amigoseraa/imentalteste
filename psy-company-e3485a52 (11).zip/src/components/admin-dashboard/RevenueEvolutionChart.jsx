import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { format } from "date-fns";
import { TrendingUp } from "lucide-react";

export default function RevenueEvolutionChart({ faturas }) {
  const getRevenueData = () => {
    const monthlyRevenue = {};

    faturas.forEach(fatura => {
      if (fatura.competencia) {
        const month = fatura.competencia;
        
        if (!monthlyRevenue[month]) {
          monthlyRevenue[month] = {
            month,
            total: 0,
            pago: 0,
            pendente: 0,
            vencido: 0
          };
        }

        monthlyRevenue[month].total += fatura.valor_total || 0;
        
        if (fatura.status === 'paga') {
          monthlyRevenue[month].pago += fatura.valor_total || 0;
        } else if (fatura.status === 'pendente') {
          monthlyRevenue[month].pendente += fatura.valor_total || 0;
        } else if (fatura.status === 'vencida') {
          monthlyRevenue[month].vencido += fatura.valor_total || 0;
        }
      }
    });

    return Object.values(monthlyRevenue)
      .sort((a, b) => a.month.localeCompare(b.month))
      .slice(-12); // Últimos 12 meses
  };

  const data = getRevenueData();

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
      minimumFractionDigits: 0
    }).format(value);
  };

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-green-600" />
          Evolução de Receita Mensal
        </CardTitle>
      </CardHeader>
      <CardContent>
        {data.length > 0 ? (
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis 
                dataKey="month" 
                tick={{ fontSize: 12 }}
                tickFormatter={(value) => {
                  const [year, month] = value.split('-');
                  return `${month}/${year.slice(2)}`;
                }}
              />
              <YAxis 
                tickFormatter={(value) => `R$ ${(value / 1000).toFixed(0)}k`}
                tick={{ fontSize: 12 }}
              />
              <Tooltip 
                formatter={(value) => formatCurrency(value)}
                contentStyle={{ 
                  backgroundColor: 'white', 
                  border: '1px solid #e5e7eb',
                  borderRadius: '8px',
                  padding: '12px'
                }}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="total" 
                stroke="#4B2672" 
                strokeWidth={3} 
                dot={{ r: 4 }} 
                name="Receita Total"
              />
              <Line 
                type="monotone" 
                dataKey="pago" 
                stroke="#00B37E" 
                strokeWidth={2} 
                dot={{ r: 3 }} 
                name="Pago"
              />
              <Line 
                type="monotone" 
                dataKey="pendente" 
                stroke="#FFD84D" 
                strokeWidth={2} 
                dot={{ r: 3 }} 
                name="Pendente"
              />
              <Line 
                type="monotone" 
                dataKey="vencido" 
                stroke="#E63946" 
                strokeWidth={2} 
                dot={{ r: 3 }} 
                name="Vencido"
              />
            </LineChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-[400px] flex items-center justify-center text-gray-400">
            Aguardando dados de faturamento
          </div>
        )}
      </CardContent>
    </Card>
  );
}