import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, Legend, ResponsiveContainer } from "recharts";
import { BarChart3 } from "lucide-react";

export default function SeverityDistribution({ assessments }) {
  const getSeverityData = () => {
    const phq9Dist = { minimal: 0, leve: 0, moderado: 0, grave: 0 };
    const gad7Dist = { minimal: 0, leve: 0, moderado: 0, grave: 0 };

    assessments.forEach(a => {
      // PHQ-9: 0-4 minimal, 5-9 leve, 10-14 moderado, 15+ grave
      if (a.phq9_score !== undefined && a.phq9_score !== null) {
        if (a.phq9_score <= 4) phq9Dist.minimal++;
        else if (a.phq9_score <= 9) phq9Dist.leve++;
        else if (a.phq9_score <= 14) phq9Dist.moderado++;
        else phq9Dist.grave++;
      }

      // GAD-7: 0-4 minimal, 5-9 leve, 10-14 moderado, 15+ grave
      if (a.gad7_score !== undefined && a.gad7_score !== null) {
        if (a.gad7_score <= 4) gad7Dist.minimal++;
        else if (a.gad7_score <= 9) gad7Dist.leve++;
        else if (a.gad7_score <= 14) gad7Dist.moderado++;
        else gad7Dist.grave++;
      }
    });

    return [
      {
        name: 'PHQ-9 (Depressão)',
        'Sem Sintomas': phq9Dist.minimal,
        'Leve': phq9Dist.leve,
        'Moderado': phq9Dist.moderado,
        'Grave': phq9Dist.grave
      },
      {
        name: 'GAD-7 (Ansiedade)',
        'Sem Sintomas': gad7Dist.minimal,
        'Leve': gad7Dist.leve,
        'Moderado': gad7Dist.moderado,
        'Grave': gad7Dist.grave
      }
    ];
  };

  const data = getSeverityData();

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BarChart3 className="w-5 h-5" style={{ color: '#4B2672' }} />
          Distribuição de Severidade (PHQ-9 / GAD-7)
        </CardTitle>
      </CardHeader>
      <CardContent>
        {assessments.length > 0 ? (
          <ResponsiveContainer width="100%" height={350}>
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="name" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <RechartsTooltip />
              <Legend />
              <Bar dataKey="Sem Sintomas" stackId="a" fill="#10b981" />
              <Bar dataKey="Leve" stackId="a" fill="#f59e0b" />
              <Bar dataKey="Moderado" stackId="a" fill="#f97316" />
              <Bar dataKey="Grave" stackId="a" fill="#ef4444" />
            </BarChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-[350px] flex items-center justify-center text-gray-400">
            Aguardando dados de avaliações
          </div>
        )}
      </CardContent>
    </Card>
  );
}