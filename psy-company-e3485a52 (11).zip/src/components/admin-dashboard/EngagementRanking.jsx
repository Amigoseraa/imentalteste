import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { TrendingUp } from "lucide-react";

export default function EngagementRanking({ consultorias, companies, assessments, employees }) {
  const getEngagementData = () => {
    return consultorias
      .filter(c => c.status === 'ativo')
      .map(consultoria => {
        const consultoriaCompanies = companies.filter(c => c.consultoria_id === consultoria.id);
        const consultoriaEmployees = employees.filter(e => 
          consultoriaCompanies.some(c => c.id === e.company_id)
        );
        const consultoriaAssessments = assessments.filter(a => 
          consultoriaCompanies.some(c => c.id === a.company_id)
        );
        
        const engagementRate = consultoriaEmployees.length > 0
          ? ((consultoriaAssessments.length / consultoriaEmployees.length) * 100)
          : 0;

        return {
          name: consultoria.nome_fantasia,
          engagement: parseFloat(engagementRate.toFixed(1)),
          employees: consultoriaEmployees.length,
          assessments: consultoriaAssessments.length
        };
      })
      .filter(c => c.employees > 0)
      .sort((a, b) => b.engagement - a.engagement)
      .slice(0, 10);
  };

  const data = getEngagementData();

  const getColor = (value) => {
    if (value >= 75) return '#2ECC71';
    if (value >= 50) return '#FFD84D';
    return '#E74C3C';
  };

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg font-semibold">
          <TrendingUp className="w-5 h-5" style={{ color: '#4B2672' }} />
          Ranking de Engajamento por Consultoria
        </CardTitle>
      </CardHeader>
      <CardContent>
        {data.length > 0 ? (
          <ResponsiveContainer width="100%" height={400}>
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} tick={{ fontSize: 10 }} />
              <YAxis domain={[0, 100]} tick={{ fontSize: 12 }} />
              <Tooltip 
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload;
                    return (
                      <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
                        <p className="font-semibold text-gray-900 mb-2">{data.name}</p>
                        <div className="space-y-1 text-sm">
                          <p className="flex items-center justify-between gap-4">
                            <span className="text-gray-600">Engajamento:</span>
                            <span className="font-semibold" style={{ color: getColor(data.engagement) }}>
                              {data.engagement}%
                            </span>
                          </p>
                          <p className="flex items-center justify-between gap-4">
                            <span className="text-gray-600">Respondentes:</span>
                            <span className="font-semibold">{data.assessments} / {data.employees}</span>
                          </p>
                        </div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Bar dataKey="engagement" radius={[8, 8, 0, 0]}>
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={getColor(entry.engagement)} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-[400px] flex items-center justify-center text-gray-400">
            Aguardando dados de engajamento
          </div>
        )}
      </CardContent>
    </Card>
  );
}