/**
 * Sistema de Controle de Acesso (ACL) centralizado
 * Define permissões por nível: Admin, Consultoria, Empresa, Colaborador
 */

// Definição de níveis (roles)
export const ROLES = {
  ADMIN: 'admin',
  CONSULTORIA: 'consultoria',
  EMPRESA: 'manager',
  COLABORADOR: 'employee'
};

// Definição de recursos
export const RESOURCES = {
  CONSULTORIAS: 'consultorias',
  EMPRESAS: 'empresas',
  DEPARTAMENTOS: 'departamentos',
  GHE: 'ghe',
  COLABORADORES: 'colaboradores',
  AVALIACOES: 'avaliacoes',
  RELATORIOS: 'relatorios',
  FINANCEIRO_ADMIN: 'financeiro_admin',
  FINANCEIRO_CONSULTORIA: 'financeiro_consultoria',
  FINANCEIRO_EMPRESA: 'financeiro_empresa',
  FATURAMENTO_ADMIN: 'faturamento_admin',
  FATURAMENTO_CONSULTORIA: 'faturamento_consultoria',
  CONFIGURACOES_ADMIN: 'configuracoes_admin',
  CONFIGURACOES_CONSULTORIA: 'configuracoes_consultoria',
  CONFIGURACOES_EMPRESA: 'configuracoes_empresa',
  USUARIOS_ADMIN: 'usuarios_admin',
  USUARIOS_CONSULTORIA: 'usuarios_consultoria',
  USUARIOS_EMPRESA: 'usuarios_empresa',
  IMPERSONATE: 'impersonate',
  DIAGNOSTICO: 'diagnostico',
  PLANOS: 'planos',
  MEUS_DADOS: 'meus_dados',
  MINHAS_AVALIACOES: 'minhas_avaliacoes'
};

// Definição de ações
export const ACTIONS = {
  CREATE: 'create',
  READ: 'read',
  UPDATE: 'update',
  DELETE: 'delete',
  LIST: 'list',
  EXPORT: 'export',
  IMPORT: 'import',
  IMPERSONATE: 'impersonate'
};

// Matriz de permissões
const PERMISSIONS = {
  [ROLES.ADMIN]: {
    [RESOURCES.CONSULTORIAS]: [ACTIONS.CREATE, ACTIONS.READ, ACTIONS.UPDATE, ACTIONS.DELETE, ACTIONS.LIST, ACTIONS.EXPORT],
    [RESOURCES.EMPRESAS]: [ACTIONS.CREATE, ACTIONS.READ, ACTIONS.UPDATE, ACTIONS.DELETE, ACTIONS.LIST, ACTIONS.EXPORT],
    [RESOURCES.DEPARTAMENTOS]: [ACTIONS.READ, ACTIONS.LIST],
    [RESOURCES.GHE]: [ACTIONS.READ, ACTIONS.LIST],
    [RESOURCES.COLABORADORES]: [ACTIONS.READ, ACTIONS.LIST, ACTIONS.EXPORT],
    [RESOURCES.AVALIACOES]: [ACTIONS.READ, ACTIONS.LIST, ACTIONS.EXPORT],
    [RESOURCES.RELATORIOS]: [ACTIONS.READ, ACTIONS.EXPORT],
    [RESOURCES.FINANCEIRO_ADMIN]: [ACTIONS.CREATE, ACTIONS.READ, ACTIONS.UPDATE, ACTIONS.DELETE, ACTIONS.LIST, ACTIONS.EXPORT],
    [RESOURCES.FATURAMENTO_ADMIN]: [ACTIONS.CREATE, ACTIONS.READ, ACTIONS.UPDATE, ACTIONS.DELETE, ACTIONS.LIST, ACTIONS.EXPORT],
    [RESOURCES.CONFIGURACOES_ADMIN]: [ACTIONS.READ, ACTIONS.UPDATE],
    [RESOURCES.USUARIOS_ADMIN]: [ACTIONS.CREATE, ACTIONS.READ, ACTIONS.UPDATE, ACTIONS.DELETE, ACTIONS.LIST],
    [RESOURCES.IMPERSONATE]: [ACTIONS.IMPERSONATE],
    [RESOURCES.DIAGNOSTICO]: [ACTIONS.READ, ACTIONS.UPDATE],
    [RESOURCES.PLANOS]: [ACTIONS.CREATE, ACTIONS.READ, ACTIONS.UPDATE, ACTIONS.DELETE, ACTIONS.LIST]
  },
  
  [ROLES.CONSULTORIA]: {
    [RESOURCES.EMPRESAS]: [ACTIONS.CREATE, ACTIONS.READ, ACTIONS.UPDATE, ACTIONS.DELETE, ACTIONS.LIST, ACTIONS.EXPORT, ACTIONS.IMPORT],
    [RESOURCES.DEPARTAMENTOS]: [ACTIONS.READ, ACTIONS.LIST],
    [RESOURCES.GHE]: [ACTIONS.READ, ACTIONS.LIST],
    [RESOURCES.COLABORADORES]: [ACTIONS.READ, ACTIONS.LIST, ACTIONS.EXPORT],
    [RESOURCES.AVALIACOES]: [ACTIONS.READ, ACTIONS.LIST, ACTIONS.EXPORT],
    [RESOURCES.RELATORIOS]: [ACTIONS.READ, ACTIONS.EXPORT],
    [RESOURCES.FINANCEIRO_CONSULTORIA]: [ACTIONS.READ, ACTIONS.LIST, ACTIONS.EXPORT],
    [RESOURCES.FATURAMENTO_CONSULTORIA]: [ACTIONS.CREATE, ACTIONS.READ, ACTIONS.UPDATE, ACTIONS.LIST],
    [RESOURCES.CONFIGURACOES_CONSULTORIA]: [ACTIONS.READ, ACTIONS.UPDATE],
    [RESOURCES.USUARIOS_CONSULTORIA]: [ACTIONS.CREATE, ACTIONS.READ, ACTIONS.UPDATE, ACTIONS.DELETE, ACTIONS.LIST],
    [RESOURCES.IMPERSONATE]: [ACTIONS.IMPERSONATE]
  },
  
  [ROLES.EMPRESA]: {
    [RESOURCES.DEPARTAMENTOS]: [ACTIONS.CREATE, ACTIONS.READ, ACTIONS.UPDATE, ACTIONS.DELETE, ACTIONS.LIST, ACTIONS.EXPORT, ACTIONS.IMPORT],
    [RESOURCES.GHE]: [ACTIONS.CREATE, ACTIONS.READ, ACTIONS.UPDATE, ACTIONS.DELETE, ACTIONS.LIST, ACTIONS.EXPORT, ACTIONS.IMPORT],
    [RESOURCES.COLABORADORES]: [ACTIONS.CREATE, ACTIONS.READ, ACTIONS.UPDATE, ACTIONS.DELETE, ACTIONS.LIST, ACTIONS.EXPORT, ACTIONS.IMPORT],
    [RESOURCES.AVALIACOES]: [ACTIONS.CREATE, ACTIONS.READ, ACTIONS.UPDATE, ACTIONS.DELETE, ACTIONS.LIST, ACTIONS.EXPORT],
    [RESOURCES.RELATORIOS]: [ACTIONS.READ, ACTIONS.EXPORT],
    [RESOURCES.FINANCEIRO_EMPRESA]: [ACTIONS.READ, ACTIONS.LIST],
    [RESOURCES.CONFIGURACOES_EMPRESA]: [ACTIONS.READ, ACTIONS.UPDATE],
    [RESOURCES.USUARIOS_EMPRESA]: [ACTIONS.CREATE, ACTIONS.READ, ACTIONS.UPDATE, ACTIONS.DELETE, ACTIONS.LIST]
  },
  
  [ROLES.COLABORADOR]: {
    [RESOURCES.MEUS_DADOS]: [ACTIONS.READ, ACTIONS.UPDATE],
    [RESOURCES.MINHAS_AVALIACOES]: [ACTIONS.READ, ACTIONS.CREATE]
  }
};

export function can(action, resource, context = {}) {
  if (!context || !context.role) {
    return false;
  }

  const role = context.role;
  
  if (!PERMISSIONS[role]) {
    return false;
  }

  if (!PERMISSIONS[role][resource]) {
    return false;
  }

  const hasPermission = PERMISSIONS[role][resource].includes(action);
  
  if (!hasPermission) {
    return false;
  }

  return validateTenancy(role, resource, context);
}

function validateTenancy(role, resource, context) {
  if (role === ROLES.ADMIN && !context.impersonating) {
    return true;
  }

  if (context.impersonating) {
    if (context.impersonation_type === 'consultoria') {
      role = ROLES.CONSULTORIA;
    } else if (context.impersonation_type === 'empresa') {
      role = ROLES.EMPRESA;
    }
  }

  if (role === ROLES.CONSULTORIA) {
    const resourcesRequiringConsultoria = [
      RESOURCES.EMPRESAS,
      RESOURCES.FINANCEIRO_CONSULTORIA,
      RESOURCES.FATURAMENTO_CONSULTORIA,
      RESOURCES.CONFIGURACOES_CONSULTORIA,
      RESOURCES.USUARIOS_CONSULTORIA
    ];
    
    if (resourcesRequiringConsultoria.includes(resource)) {
      return !!context.consultoria_id;
    }
  }

  if (role === ROLES.EMPRESA) {
    const resourcesRequiringCompany = [
      RESOURCES.DEPARTAMENTOS,
      RESOURCES.GHE,
      RESOURCES.COLABORADORES,
      RESOURCES.AVALIACOES,
      RESOURCES.RELATORIOS,
      RESOURCES.FINANCEIRO_EMPRESA,
      RESOURCES.CONFIGURACOES_EMPRESA,
      RESOURCES.USUARIOS_EMPRESA
    ];
    
    if (resourcesRequiringCompany.includes(resource)) {
      return !!context.company_id;
    }
  }

  if (role === ROLES.COLABORADOR) {
    return !!context.employee_id;
  }

  return true;
}

export function getMenuItems(context) {
  const role = context?.role;
  
  if (!role) {
    return [];
  }

  const allMenus = {
    [ROLES.ADMIN]: [
      {
        name: 'Dashboard',
        path: '/AdminDashboard',
        icon: 'BarChart3',
        permission: { action: ACTIONS.READ, resource: RESOURCES.FINANCEIRO_ADMIN }
      },
      {
        name: 'Consultorias',
        path: '/Consultorias',
        icon: 'Briefcase',
        permission: { action: ACTIONS.LIST, resource: RESOURCES.CONSULTORIAS }
      },
      {
        name: 'Financeiro',
        path: '/FinanceOverview',
        icon: 'DollarSign',
        permission: { action: ACTIONS.READ, resource: RESOURCES.FINANCEIRO_ADMIN },
        submenu: [
          { name: 'Visão Geral', path: '/FinanceOverview' },
          { name: 'Receitas', path: '/FinanceReceitas' },
          { name: 'Recebíveis', path: '/FinanceRecebiveis' },
          { name: 'Cobrança', path: '/FinanceCobranca' },
          { name: 'Previsões', path: '/FinanceForecast' },
          { name: 'Clientes', path: '/FinanceClientes' },
          { name: 'Relatórios', path: '/FinanceRelatorios' }
        ]
      },
      {
        name: 'Planos',
        path: '/Planos',
        icon: 'Package',
        permission: { action: ACTIONS.LIST, resource: RESOURCES.PLANOS }
      },
      {
        name: 'Configurações',
        path: '/Settings',
        icon: 'Settings',
        permission: { action: ACTIONS.READ, resource: RESOURCES.CONFIGURACOES_ADMIN }
      }
    ],

    [ROLES.CONSULTORIA]: [
      {
        name: 'Dashboard',
        path: '/ConsultoriaDashboard',
        icon: 'BarChart3',
        permission: { action: ACTIONS.READ, resource: RESOURCES.EMPRESAS }
      },
      {
        name: 'Empresas',
        path: '/Companies',
        icon: 'Building2',
        permission: { action: ACTIONS.LIST, resource: RESOURCES.EMPRESAS }
      },
      {
        name: 'Financeiro',
        path: '/FaturamentoConsultoria',
        icon: 'DollarSign',
        permission: { action: ACTIONS.READ, resource: RESOURCES.FINANCEIRO_CONSULTORIA }
      },
      {
        name: 'Configurações',
        path: '/Settings',
        icon: 'Settings',
        permission: { action: ACTIONS.READ, resource: RESOURCES.CONFIGURACOES_CONSULTORIA }
      }
    ],

    [ROLES.EMPRESA]: [
      {
        name: 'Dashboard',
        path: '/Dashboard',
        icon: 'Home',
        permission: { action: ACTIONS.READ, resource: RESOURCES.AVALIACOES }
      },
      {
        name: 'Departamentos',
        path: '/Departments',
        icon: 'Building2',
        permission: { action: ACTIONS.LIST, resource: RESOURCES.DEPARTAMENTOS }
      },
      {
        name: 'GHE',
        path: '/GHE',
        icon: 'Briefcase',
        permission: { action: ACTIONS.LIST, resource: RESOURCES.GHE }
      },
      {
        name: 'Colaboradores',
        path: '/Employees',
        icon: 'Users',
        permission: { action: ACTIONS.LIST, resource: RESOURCES.COLABORADORES }
      },
      {
        name: 'Avaliações',
        path: '/Assessments',
        icon: 'FileText',
        permission: { action: ACTIONS.LIST, resource: RESOURCES.AVALIACOES }
      },
      {
        name: 'Relatórios',
        path: '/Reports',
        icon: 'BarChart3',
        permission: { action: ACTIONS.READ, resource: RESOURCES.RELATORIOS }
      },
      {
        name: 'Configurações',
        path: '/Settings',
        icon: 'Settings',
        permission: { action: ACTIONS.READ, resource: RESOURCES.CONFIGURACOES_EMPRESA }
      }
    ],

    [ROLES.COLABORADOR]: [
      {
        name: 'Minhas Avaliações',
        path: '/ColaboradorAvaliacoes',
        icon: 'FileText',
        permission: { action: ACTIONS.READ, resource: RESOURCES.MINHAS_AVALIACOES }
      },
      {
        name: 'Meu Perfil',
        path: '/Settings',
        icon: 'User',
        permission: { action: ACTIONS.READ, resource: RESOURCES.MEUS_DADOS }
      }
    ]
  };

  const menus = allMenus[role] || [];
  
  return menus.filter(menu => {
    if (!menu.permission) return true;
    return can(menu.permission.action, menu.permission.resource, context);
  });
}

export function getUserContext(user, impersonation = null) {
  if (!user) {
    return null;
  }

  const context = {
    role: user.role || user.user_role,
    user_id: user.id,
    email: user.email,
    company_id: user.company_id,
    consultoria_id: user.consultoria_id,
    employee_id: user.employee_id,
    impersonating: false,
    impersonation_type: null
  };

  if (impersonation) {
    context.impersonating = true;
    context.impersonation_type = impersonation.type;
    
    if (impersonation.type === 'consultoria') {
      context.consultoria_id = impersonation.consultoria_id;
      context.company_id = null;
    } else if (impersonation.type === 'empresa') {
      context.company_id = impersonation.company_id;
      context.consultoria_id = impersonation.consultoria_id;
    }
  }

  return context;
}