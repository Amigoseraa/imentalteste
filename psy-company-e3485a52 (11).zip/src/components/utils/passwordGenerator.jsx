/**
 * Gerador de senhas temporárias e helpers de senha
 */

export const generateTemporaryPassword = () => {
  const prefix = 'IM';
  const digits = Math.floor(100000 + Math.random() * 900000);
  return `${prefix}-${digits}`;
};

export const generateResetToken = () => {
  return Math.random().toString(36).substring(2, 15) + 
         Math.random().toString(36).substring(2, 15) +
         Date.now().toString(36);
};

export const isPasswordExpired = (createdAt, expiryHours = 72) => {
  const now = new Date();
  const created = new Date(createdAt);
  const diffHours = (now - created) / (1000 * 60 * 60);
  return diffHours > expiryHours;
};