/**
 * Guards de Tenancy para garantir isolamento multi-tenant
 * Usar em todas as queries para prevenir vazamento de dados
 */

import { base44 } from "@/api/base44Client";

export const getTenantContext = async (user) => {
  if (!user) {
    throw new Error('Usuário não autenticado');
  }

  // Admin iMental tem acesso global (sem restrições)
  if (user.user_role === 'admin') {
    return {
      isGlobal: true,
      consultoriaId: null,
      empresaId: null,
      role: 'admin'
    };
  }

  // Consultoria tem acesso apenas aos seus dados
  if (user.user_role === 'consultoria') {
    if (!user.consultoria_id) {
      throw new Error('Consultoria sem consultoria_id definido');
    }
    return {
      isGlobal: false,
      consultoriaId: user.consultoria_id,
      empresaId: null,
      role: 'consultoria'
    };
  }

  // Manager/Employee tem acesso apenas à sua empresa
  if (user.company_id) {
    // Buscar consultoria_id da empresa
    const companies = await base44.entities.Company.filter({ id: user.company_id });
    if (companies.length === 0) {
      throw new Error('Empresa não encontrada');
    }
    
    return {
      isGlobal: false,
      consultoriaId: companies[0].consultoria_id,
      empresaId: user.company_id,
      role: user.user_role
    };
  }

  throw new Error('Usuário sem escopo definido');
};

export const filterByTenant = (records, tenantContext, entityType) => {
  if (tenantContext.isGlobal) {
    return records;
  }

  let filtered = records.filter(r => {
    if (entityType === 'Consultoria') {
      return r.id === tenantContext.consultoriaId;
    }
    return r.consultoria_id === tenantContext.consultoriaId;
  });

  if (tenantContext.empresaId) {
    filtered = filtered.filter(r => {
      if (entityType === 'Company') {
        return r.id === tenantContext.empresaId;
      }
      return !r.company_id || r.company_id === tenantContext.empresaId;
    });
  }

  return filtered;
};

export const canAccessRecord = (record, tenantContext, entityType) => {
  if (tenantContext.isGlobal) {
    return true;
  }

  if (entityType === 'Consultoria') {
    return record.id === tenantContext.consultoriaId;
  }

  if (record.consultoria_id && record.consultoria_id !== tenantContext.consultoriaId) {
    return false;
  }

  if (tenantContext.empresaId) {
    if (entityType === 'Company') {
      return record.id === tenantContext.empresaId;
    }
    if (record.company_id && record.company_id !== tenantContext.empresaId) {
      return false;
    }
  }

  return true;
};

export const addTenantData = (data, tenantContext, entityType) => {
  if (tenantContext.isGlobal) {
    return data;
  }

  const enriched = { ...data };

  if (entityType !== 'Consultoria' && tenantContext.consultoriaId) {
    enriched.consultoria_id = tenantContext.consultoriaId;
  }

  if (tenantContext.empresaId && !enriched.company_id) {
    enriched.company_id = tenantContext.empresaId;
  }

  return enriched;
};

export const auditLog = async (user, action, targetEntity, targetId, metadata = {}) => {
  try {
    const tenantContext = await getTenantContext(user);
    
    await base44.entities.AuditLog.create({
      actor_user_email: user.email,
      action,
      meta: {
        target_entity: targetEntity,
        target_id: targetId,
        tenant_context: {
          consultoria_id: tenantContext.consultoriaId,
          empresa_id: tenantContext.empresaId,
          role: tenantContext.role
        },
        ...metadata,
        timestamp: new Date().toISOString()
      }
    });
  } catch (error) {
    console.error('Erro ao criar log de auditoria:', error);
  }
};

export const assertCanAccess = (record, tenantContext, entityType) => {
  if (!canAccessRecord(record, tenantContext, entityType)) {
    throw new Error(`Acesso negado: você não tem permissão para acessar este ${entityType}`);
  }
};