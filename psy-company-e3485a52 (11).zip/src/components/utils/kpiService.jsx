/**
 * Serviço centralizado de KPIs - fonte única de verdade
 * Todos os indicadores devem usar este serviço
 */

import { base44 } from "@/api/base44Client";
import { getTenantContext, filterByTenant } from "./tenancyGuards";
import { format, subMonths, isAfter, parseISO } from "date-fns";

/**
 * Calcula KPIs de performance (Admin, Consultoria, Empresa)
 */
export const calculatePerformanceKPIs = async (user, period = 'all') => {
  const tenantContext = await getTenantContext(user);
  
  // Buscar dados base respeitando tenant
  let consultorias = await base44.entities.Consultoria.list();
  let companies = await base44.entities.Company.list();
  let employees = await base44.entities.Employee.list();
  let assessments = await base44.entities.Assessment.list();
  
  // Aplicar filtros de tenant
  if (!tenantContext.isGlobal) {
    consultorias = filterByTenant(consultorias, tenantContext, 'Consultoria');
    companies = filterByTenant(companies, tenantContext, 'Company');
    employees = filterByTenant(employees, tenantContext, 'Employee');
    assessments = filterByTenant(assessments, tenantContext, 'Assessment');
  }
  
  // Aplicar filtro de período
  if (period !== 'all') {
    const periodDays = parseInt(period);
    const cutoffDate = subMonths(new Date(), periodDays / 30);
    
    companies = companies.filter(c => 
      c.created_date && isAfter(parseISO(c.created_date), cutoffDate)
    );
    employees = employees.filter(e => 
      e.created_date && isAfter(parseISO(e.created_date), cutoffDate)
    );
    assessments = assessments.filter(a => 
      a.created_date && isAfter(parseISO(a.created_date), cutoffDate)
    );
  }
  
  // Calcular métricas
  const currentMonth = format(new Date(), 'yyyy-MM');
  const lastMonth = format(subMonths(new Date(), 1), 'yyyy-MM');
  
  const consultoriasAtivas = consultorias.filter(c => c.status === 'ativo');
  const empresasAtivas = companies.filter(c => c.status === 'active');
  const colaboradoresAtivos = employees.filter(e => e.status === 'active');
  const avaliacoesCompletas = assessments.filter(a => a.completed_at);
  
  // Taxa de engajamento
  const empresasComAvaliacoes = new Set(
    avaliacoesCompletas.map(a => a.company_id)
  ).size;
  const taxaEngajamento = empresasAtivas.length > 0
    ? (empresasComAvaliacoes / empresasAtivas.length) * 100
    : 0;
  
  // Crescimento mês anterior
  const empresasAnterior = companies.filter(c => {
    const created = new Date(c.created_date);
    return created < subMonths(new Date(), 1) && c.status === 'active';
  }).length;
  
  const colaboradoresAnterior = employees.filter(e => {
    const created = new Date(e.created_date);
    return created < subMonths(new Date(), 1) && e.status === 'active';
  }).length;
  
  const crescimentoEmpresas = empresasAnterior > 0
    ? ((empresasAtivas.length - empresasAnterior) / empresasAnterior) * 100
    : null;
  
  const crescimentoColaboradores = colaboradoresAnterior > 0
    ? ((colaboradoresAtivos.length - colaboradoresAnterior) / colaboradoresAnterior) * 100
    : null;
  
  return {
    consultorias: {
      total: consultorias.length,
      ativas: consultoriasAtivas.length,
      percentualAtivas: consultorias.length > 0 
        ? (consultoriasAtivas.length / consultorias.length) * 100 
        : 0
    },
    empresas: {
      total: empresasAtivas.length,
      crescimento: crescimentoEmpresas,
      hasComparison: empresasAnterior > 0
    },
    colaboradores: {
      total: colaboradoresAtivos.length,
      crescimento: crescimentoColaboradores,
      hasComparison: colaboradoresAnterior > 0
    },
    engajamento: {
      taxa: taxaEngajamento,
      empresasEngajadas: empresasComAvaliacoes,
      empresasTotal: empresasAtivas.length
    },
    avaliacoes: {
      total: assessments.length,
      completas: avaliacoesCompletas.length,
      pendentes: assessments.length - avaliacoesCompletas.length
    }
  };
};

/**
 * Calcula KPIs financeiros
 */
export const calculateFinancialKPIs = async (user, competencia = null) => {
  const tenantContext = await getTenantContext(user);
  const currentMonth = competencia || format(new Date(), 'yyyy-MM');
  const lastMonth = format(subMonths(new Date(), 1), 'yyyy-MM');
  
  // Buscar faturas
  let faturas = await base44.entities.Fatura.list();
  let pagamentos = await base44.entities.Pagamento.list();
  
  // Filtrar por tenant
  if (!tenantContext.isGlobal) {
    if (tenantContext.consultoriaId) {
      faturas = faturas.filter(f => 
        f.alvo_id === tenantContext.consultoriaId || 
        f.emitente_id === tenantContext.consultoriaId
      );
    }
  }
  
  // Faturas do mês atual
  const faturasCompetencia = faturas.filter(f => f.competencia === currentMonth);
  const faturasCompetenciaAnterior = faturas.filter(f => f.competencia === lastMonth);
  
  // Cálculos
  const receitaMes = faturasCompetencia
    .filter(f => f.status === 'PAGA')
    .reduce((acc, f) => acc + (f.valor_liquido || 0), 0);
  
  const receitaMesAnterior = faturasCompetenciaAnterior
    .filter(f => f.status === 'PAGA')
    .reduce((acc, f) => acc + (f.valor_liquido || 0), 0);
  
  const receitaAnual = faturas
    .filter(f => {
      const ano = f.competencia?.split('-')[0];
      return ano === new Date().getFullYear().toString() && f.status === 'PAGA';
    })
    .reduce((acc, f) => acc + (f.valor_liquido || 0), 0);
  
  const mrr = faturasCompetencia
    .filter(f => ['PAGA', 'AUTORIZADA', 'ENVIADA'].includes(f.status))
    .reduce((acc, f) => acc + (f.valor_liquido || 0), 0);
  
  const faturasPendentes = faturas
    .filter(f => ['AUTORIZADA', 'ENVIADA', 'VENCIDA'].includes(f.status))
    .reduce((acc, f) => acc + (f.valor_liquido || 0), 0);
  
  const faturasVencidas = faturas
    .filter(f => f.status === 'VENCIDA')
    .reduce((acc, f) => acc + (f.valor_liquido || 0), 0);
  
  const totalEmitidas = faturasCompetencia.length;
  const totalVencidas = faturasCompetencia.filter(f => f.status === 'VENCIDA').length;
  const taxaInadimplencia = totalEmitidas > 0 ? (totalVencidas / totalEmitidas) * 100 : 0;
  
  const crescimentoReceita = receitaMesAnterior > 0
    ? ((receitaMes - receitaMesAnterior) / receitaMesAnterior) * 100
    : null;
  
  return {
    receitaMes,
    receitaAnual,
    mrr,
    arr: mrr * 12,
    faturasPendentes,
    faturasVencidas,
    taxaInadimplencia,
    crescimentoReceita,
    hasComparison: receitaMesAnterior > 0,
    totalFaturas: faturasCompetencia.length,
    faturasPagas: faturasCompetencia.filter(f => f.status === 'PAGA').length
  };
};

/**
 * Calcula KPIs técnicos (saúde mental)
 */
export const calculateTechnicalKPIs = async (user, period = 'all') => {
  const tenantContext = await getTenantContext(user);
  
  let assessments = await base44.entities.Assessment.list();
  
  // Filtrar por tenant
  if (!tenantContext.isGlobal) {
    assessments = filterByTenant(assessments, tenantContext, 'Assessment');
  }
  
  // Apenas avaliações completas
  const completedAssessments = assessments.filter(a => a.completed_at);
  
  if (completedAssessments.length === 0) {
    return {
      total: 0,
      instrumentos: 0,
      prevalenciaModGrave: 0,
      mediaPrima: 0,
      phq9: { minimo: 0, leve: 0, moderado: 0, grave: 0 },
      gad7: { minimo: 0, leve: 0, moderado: 0, grave: 0 },
      prima: { baixo: 0, moderado: 0, alto: 0 }
    };
  }
  
  // Instrumentos ativos
  const instrumentos = new Set();
  completedAssessments.forEach(a => {
    if (a.phq9_score !== undefined && a.phq9_score !== null) instrumentos.add('PHQ-9');
    if (a.gad7_score !== undefined && a.gad7_score !== null) instrumentos.add('GAD-7');
    if (a.prima_score !== undefined && a.prima_score !== null) instrumentos.add('PRIMA-EF');
  });
  
  // Prevalência moderado/grave
  const modGrave = completedAssessments.filter(a =>
    (a.phq9_score !== undefined && a.phq9_score >= 10) ||
    (a.gad7_score !== undefined && a.gad7_score >= 10)
  ).length;
  
  const prevalencia = (modGrave / completedAssessments.length) * 100;
  
  // Média PRIMA
  const primaScores = completedAssessments
    .filter(a => a.prima_score !== undefined && a.prima_score !== null)
    .map(a => a.prima_score);
  
  const mediaPrima = primaScores.length > 0
    ? primaScores.reduce((a, b) => a + b, 0) / primaScores.length
    : 0;
  
  // Distribuições
  const phq9Dist = { minimo: 0, leve: 0, moderado: 0, grave: 0 };
  const gad7Dist = { minimo: 0, leve: 0, moderado: 0, grave: 0 };
  const primaDist = { baixo: 0, moderado: 0, alto: 0 };
  
  completedAssessments.forEach(a => {
    if (a.phq9_score !== undefined && a.phq9_score !== null) {
      if (a.phq9_score <= 4) phq9Dist.minimo++;
      else if (a.phq9_score <= 9) phq9Dist.leve++;
      else if (a.phq9_score <= 14) phq9Dist.moderado++;
      else phq9Dist.grave++;
    }
    
    if (a.gad7_score !== undefined && a.gad7_score !== null) {
      if (a.gad7_score <= 4) gad7Dist.minimo++;
      else if (a.gad7_score <= 9) gad7Dist.leve++;
      else if (a.gad7_score <= 14) gad7Dist.moderado++;
      else gad7Dist.grave++;
    }
    
    if (a.prima_classification) {
      if (a.prima_classification === 'Baixo') primaDist.baixo++;
      else if (a.prima_classification === 'Moderado') primaDist.moderado++;
      else if (a.prima_classification === 'Alto') primaDist.alto++;
    }
  });
  
  return {
    total: completedAssessments.length,
    instrumentos: instrumentos.size,
    prevalenciaModGrave: prevalencia,
    mediaPrima,
    phq9: phq9Dist,
    gad7: gad7Dist,
    prima: primaDist
  };
};

/**
 * Verifica se há dados mockados no sistema
 */
export const detectMockData = async () => {
  // Procurar por padrões suspeitos de mock
  const consultorias = await base44.entities.Consultoria.list();
  const companies = await base44.entities.Company.list();
  
  const mockPatterns = [
    'demo', 'test', 'mock', 'sample', 'exemplo',
    'fake', 'dummy', 'seed', 'fixture'
  ];
  
  const suspectedMocks = [];
  
  consultorias.forEach(c => {
    const name = (c.nome_fantasia || '').toLowerCase();
    if (mockPatterns.some(pattern => name.includes(pattern))) {
      suspectedMocks.push({ type: 'Consultoria', id: c.id, name: c.nome_fantasia });
    }
  });
  
  companies.forEach(c => {
    const name = (c.name || '').toLowerCase();
    if (mockPatterns.some(pattern => name.includes(pattern))) {
      suspectedMocks.push({ type: 'Company', id: c.id, name: c.name });
    }
  });
  
  return suspectedMocks;
};

/**
 * Limpa cache local
 */
export const clearLocalCaches = () => {
  if (typeof window === 'undefined') return;
  
  const keysToRemove = [];
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key && (
      key.includes('_kpis') ||
      key.includes('_cache') ||
      key.includes('dashboard') ||
      key.includes('_snapshot')
    )) {
      keysToRemove.push(key);
    }
  }
  
  keysToRemove.forEach(key => localStorage.removeItem(key));
  sessionStorage.clear();
};