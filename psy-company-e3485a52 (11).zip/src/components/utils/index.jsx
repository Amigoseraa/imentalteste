
/**
 * Barrel file para reexportar todos os helpers e utilities
 * Centraliza imports para evitar paths quebrados
 */

// ACL e Segurança
export { can, getUserContext, requirePermission, usePermission, ROLES, RESOURCES } from '../security/acl';

// Menu Schema
export { getMenuForContext, MENU_SCHEMA } from '../ui/menu.schema';
