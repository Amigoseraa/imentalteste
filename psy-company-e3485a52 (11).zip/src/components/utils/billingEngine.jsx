/**
 * Motor unificado de faturamento
 */

import { base44 } from "@/api/base44Client";

export const generateIdempotencyKey = (competencia, alvoTipo, alvoId) => {
  return `${competencia}|${alvoTipo}|${alvoId}`;
};

export const calculateInvoiceValue = async (contrato, competencia) => {
  const itens = [];
  let valorBruto = 0;

  switch (contrato.modelo_cobranca) {
    case 'FIXO_MENSAL':
      valorBruto = contrato.valor_fixo || 0;
      itens.push({
        descricao: 'Mensalidade Fixa',
        quantidade: 1,
        valor_unitario: valorBruto,
        valor_total: valorBruto
      });
      break;

    case 'POR_EMPRESA_ATIVA':
      const empresas = await base44.entities.Company.filter({
        consultoria_id: contrato.consultoria_id,
        status: 'active'
      });
      
      valorBruto = empresas.length * (contrato.valor_unitario || 0);
      itens.push({
        descricao: `Empresas Ativas (${empresas.length})`,
        quantidade: empresas.length,
        valor_unitario: contrato.valor_unitario,
        valor_total: valorBruto
      });
      break;

    case 'POR_COLABORADOR_ATIVO':
      let colaboradores;
      if (contrato.empresa_id) {
        colaboradores = await base44.entities.Employee.filter({
          company_id: contrato.empresa_id,
          status: 'active'
        });
      } else {
        const empresas = await base44.entities.Company.filter({
          consultoria_id: contrato.consultoria_id
        });
        const empresaIds = empresas.map(e => e.id);
        
        const allColabs = await base44.entities.Employee.list();
        colaboradores = allColabs.filter(c => 
          empresaIds.includes(c.company_id) && c.status === 'active'
        );
      }
      
      valorBruto = colaboradores.length * (contrato.valor_unitario || 0);
      itens.push({
        descricao: `Colaboradores Ativos (${colaboradores.length})`,
        quantidade: colaboradores.length,
        valor_unitario: contrato.valor_unitario,
        valor_total: valorBruto
      });
      break;

    case 'HIBRIDO':
      const valorFixo = contrato.valor_fixo || 0;
      
      let colabsHibrido;
      if (contrato.empresa_id) {
        colabsHibrido = await base44.entities.Employee.filter({
          company_id: contrato.empresa_id,
          status: 'active'
        });
      } else {
        const empresas = await base44.entities.Company.filter({
          consultoria_id: contrato.consultoria_id
        });
        const empresaIds = empresas.map(e => e.id);
        
        const allColabs = await base44.entities.Employee.list();
        colabsHibrido = allColabs.filter(c => 
          empresaIds.includes(c.company_id) && c.status === 'active'
        );
      }
      
      const valorVariavel = colabsHibrido.length * (contrato.valor_unitario || 0);
      valorBruto = valorFixo + valorVariavel;
      
      itens.push({
        descricao: 'Mensalidade Fixa',
        quantidade: 1,
        valor_unitario: valorFixo,
        valor_total: valorFixo
      });
      
      itens.push({
        descricao: `Colaboradores Ativos (${colabsHibrido.length})`,
        quantidade: colabsHibrido.length,
        valor_unitario: contrato.valor_unitario,
        valor_total: valorVariavel
      });
      break;
  }

  const descontoValor = valorBruto * ((contrato.desconto_percent || 0) / 100);
  const valorLiquido = Math.max(valorBruto - descontoValor, contrato.minimo_mensal || 0);

  return {
    itens,
    valor_bruto: valorBruto,
    desconto_percent: contrato.desconto_percent || 0,
    desconto_valor: descontoValor,
    valor_liquido: valorLiquido
  };
};

export const generateOrUpdateInvoice = async (contrato, competencia, user) => {
  const idempotencyKey = generateIdempotencyKey(
    competencia,
    contrato.empresa_id ? 'EMPRESA' : 'CONSULTORIA',
    contrato.empresa_id || contrato.consultoria_id
  );

  const existing = await base44.entities.Fatura.filter({ idempotency_key: idempotencyKey });
  
  if (existing.length > 0) {
    return existing[0];
  }

  const calculo = await calculateInvoiceValue(contrato, competencia);

  let alvoTipo, alvoId, alvoNome, emitenteTipo, emitenteId;
  
  if (contrato.empresa_id) {
    alvoTipo = 'EMPRESA';
    alvoId = contrato.empresa_id;
    emitenteTipo = 'CONSULTORIA';
    emitenteId = contrato.consultoria_id;
    
    const empresa = await base44.entities.Company.filter({ id: contrato.empresa_id });
    alvoNome = empresa[0]?.name || 'Empresa';
  } else {
    alvoTipo = 'CONSULTORIA';
    alvoId = contrato.consultoria_id;
    emitenteTipo = 'ADMIN';
    emitenteId = null;
    
    const consultoria = await base44.entities.Consultoria.filter({ id: contrato.consultoria_id });
    alvoNome = consultoria[0]?.nome_fantasia || 'Consultoria';
  }

  const vencimentoDia = contrato.vencimento_dia || 10;
  const [ano, mes] = competencia.split('-');
  const vencimento = `${ano}-${mes}-${String(vencimentoDia).padStart(2, '0')}`;

  const fatura = await base44.entities.Fatura.create({
    competencia,
    alvo_tipo: alvoTipo,
    alvo_id: alvoId,
    alvo_nome: alvoNome,
    emitente_tipo: emitenteTipo,
    emitente_id: emitenteId,
    contrato_id: contrato.id,
    modelo_cobranca: contrato.modelo_cobranca,
    origem_calculo: 'AUTOMATICO',
    itens: calculo.itens,
    valor_bruto: calculo.valor_bruto,
    desconto_percent: calculo.desconto_percent,
    desconto_valor: calculo.desconto_valor,
    valor_liquido: calculo.valor_liquido,
    status: 'PREVIA',
    vencimento_em: vencimento,
    idempotency_key: idempotencyKey,
    meta: {
      generated_at: new Date().toISOString(),
      generated_by: user.email
    },
    historico: [{
      acao: 'criacao',
      status_anterior: null,
      status_novo: 'PREVIA',
      usuario: user.email,
      data: new Date().toISOString(),
      observacao: 'Fatura gerada automaticamente'
    }]
  });

  return fatura;
};

export const transitionInvoiceStatus = async (faturaId, newStatus, user, observacao = '') => {
  const fatura = await base44.entities.Fatura.filter({ id: faturaId });
  if (fatura.length === 0) {
    throw new Error('Fatura não encontrada');
  }

  const current = fatura[0];
  const oldStatus = current.status;

  const allowedTransitions = {
    'PREVIA': ['EDITADA', 'AUTORIZADA', 'CANCELADA'],
    'EDITADA': ['AUTORIZADA', 'CANCELADA'],
    'AUTORIZADA': ['ENVIADA', 'CANCELADA'],
    'ENVIADA': ['PAGA', 'VENCIDA', 'CANCELADA'],
    'VENCIDA': ['PAGA', 'CANCELADA'],
    'PAGA': [],
    'CANCELADA': []
  };

  if (!allowedTransitions[oldStatus]?.includes(newStatus)) {
    throw new Error(`Transição inválida de ${oldStatus} para ${newStatus}`);
  }

  const updates = {
    status: newStatus,
    historico: [
      ...(current.historico || []),
      {
        acao: 'mudanca_status',
        status_anterior: oldStatus,
        status_novo: newStatus,
        usuario: user.email,
        data: new Date().toISOString(),
        observacao
      }
    ]
  };

  if (newStatus === 'AUTORIZADA') {
    updates.autorizada_em = new Date().toISOString();
    updates.autorizada_por = user.email;
  } else if (newStatus === 'ENVIADA') {
    updates.enviada_em = new Date().toISOString();
  } else if (newStatus === 'PAGA') {
    updates.paga_em = new Date().toISOString();
  }

  await base44.entities.Fatura.update(faturaId, updates);

  return { success: true, oldStatus, newStatus };
};