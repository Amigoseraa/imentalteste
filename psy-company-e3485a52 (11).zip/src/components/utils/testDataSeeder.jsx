import { base44 } from "@/api/base44Client";

const FIRST_NAMES = [
  "João", "Maria", "Pedro", "Ana", "Carlos", "Juliana", "Lucas", "Fernanda",
  "Rafael", "Beatriz", "Fernando", "Camila", "Gustavo", "Patricia", "Ricardo",
  "Amanda", "Marcelo", "Larissa", "Diego", "Leticia", "Bruno", "Tatiana",
  "Rodrigo", "Gabriela", "Felipe", "Mariana", "Eduardo", "Carolina", "Thiago",
  "Vanessa", "Andre", "Luciana", "Fabio", "Renata", "Paulo", "Adriana"
];

const LAST_NAMES = [
  "Silva", "Santos", "Oliveira", "Souza", "Rodrigues", "Ferreira", "Alves",
  "Pereira", "Lima", "Gomes", "Costa", "Ribeiro", "Martins", "Carvalho",
  "Rocha", "Almeida", "Nascimento", "Araujo", "Melo", "Barbosa"
];

const POSITIONS = [
  "Analista", "Coordenador", "Gerente", "Assistente", "Supervisor",
  "Especialista", "Consultor", "Desenvolvedor", "Designer", "Engenheiro"
];

function generateCPF() {
  const random = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
  const cpf = Array.from({ length: 9 }, () => random(0, 9));
  
  // Calcular primeiro dígito
  let sum = 0;
  for (let i = 0; i < 9; i++) {
    sum += cpf[i] * (10 - i);
  }
  let digit = 11 - (sum % 11);
  cpf.push(digit > 9 ? 0 : digit);
  
  // Calcular segundo dígito
  sum = 0;
  for (let i = 0; i < 10; i++) {
    sum += cpf[i] * (11 - i);
  }
  digit = 11 - (sum % 11);
  cpf.push(digit > 9 ? 0 : digit);
  
  return cpf.join('');
}

function generateBirthDate() {
  const year = 1960 + Math.floor(Math.random() * 40); // 1960-2000
  const month = String(Math.floor(Math.random() * 12) + 1).padStart(2, '0');
  const day = String(Math.floor(Math.random() * 28) + 1).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function generateEmail(name) {
  const normalized = name.toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, '.');
  return `${normalized}@teste.com`;
}

function generatePhone() {
  const ddd = 11 + Math.floor(Math.random() * 80);
  const prefix = 9;
  const number = String(Math.floor(Math.random() * 100000000)).padStart(8, '0');
  return `(${ddd}) ${prefix}${number.slice(0, 4)}-${number.slice(4)}`;
}

function randomChoice(array) {
  return array[Math.floor(Math.random() * array.length)];
}

// Gerar respostas PRIMA-EF (30 questões, escala 1-5)
function generatePRIMAResponses() {
  const responses = {};
  for (let i = 1; i <= 30; i++) {
    // Maioria das respostas entre 2-4 (distribuição mais realista)
    const weights = [0.05, 0.25, 0.40, 0.25, 0.05]; // probabilidades para 1,2,3,4,5
    const random = Math.random();
    let cumulative = 0;
    let value = 3;
    
    for (let j = 0; j < weights.length; j++) {
      cumulative += weights[j];
      if (random <= cumulative) {
        value = j + 1;
        break;
      }
    }
    
    responses[`q${i}`] = value;
  }
  return responses;
}

// Gerar respostas PHQ-9 (9 questões, escala 0-3)
function generatePHQ9Responses() {
  const responses = {};
  for (let i = 1; i <= 9; i++) {
    // Maioria com sintomas leves/moderados
    const weights = [0.40, 0.30, 0.20, 0.10]; // probabilidades para 0,1,2,3
    const random = Math.random();
    let cumulative = 0;
    let value = 0;
    
    for (let j = 0; j < weights.length; j++) {
      cumulative += weights[j];
      if (random <= cumulative) {
        value = j;
        break;
      }
    }
    
    responses[`q${i}`] = value;
  }
  return responses;
}

// Gerar respostas GAD-7 (7 questões, escala 0-3)
function generateGAD7Responses() {
  const responses = {};
  for (let i = 1; i <= 7; i++) {
    const weights = [0.40, 0.30, 0.20, 0.10];
    const random = Math.random();
    let cumulative = 0;
    let value = 0;
    
    for (let j = 0; j < weights.length; j++) {
      cumulative += weights[j];
      if (random <= cumulative) {
        value = j;
        break;
      }
    }
    
    responses[`q${i}`] = value;
  }
  return responses;
}

// Calcular score PRIMA
function calculatePRIMAScore(responses) {
  const values = Object.values(responses);
  const sum = values.reduce((a, b) => a + b, 0);
  return sum / values.length;
}

// Calcular score PHQ-9
function calculatePHQ9Score(responses) {
  return Object.values(responses).reduce((a, b) => a + b, 0);
}

// Calcular score GAD-7
function calculateGAD7Score(responses) {
  return Object.values(responses).reduce((a, b) => a + b, 0);
}

// Classificar PRIMA
function classifyPRIMA(score) {
  if (score >= 3.5) return "Baixo";
  if (score >= 2.5) return "Moderado";
  return "Alto";
}

// Classificar PHQ-9
function classifyPHQ9(score) {
  if (score <= 4) return "Mínimo";
  if (score <= 9) return "Leve";
  if (score <= 14) return "Moderado";
  if (score <= 19) return "Moderado-Grave";
  return "Grave";
}

// Classificar GAD-7
function classifyGAD7(score) {
  if (score <= 4) return "Mínimo";
  if (score <= 9) return "Leve";
  if (score <= 14) return "Moderado";
  return "Grave";
}

export async function seedTestData(options = {}) {
  const {
    employeesPerCompany = 15,
    assessmentPercentage = 80, // 80% completam as avaliações
    onProgress = () => {}
  } = options;

  try {
    onProgress({ step: 'loading', message: 'Carregando empresas...' });
    
    // Buscar todas as empresas ativas
    const companies = await base44.entities.Company.filter({ status: 'active' });
    
    if (companies.length === 0) {
      throw new Error('Nenhuma empresa encontrada para popular dados');
    }

    onProgress({ step: 'companies', message: `${companies.length} empresas encontradas` });

    let totalEmployees = 0;
    let totalAssessments = 0;

    for (let companyIndex = 0; companyIndex < companies.length; companyIndex++) {
      const company = companies[companyIndex];
      
      onProgress({ 
        step: 'company', 
        message: `Processando ${company.name} (${companyIndex + 1}/${companies.length})...`,
        progress: Math.floor((companyIndex / companies.length) * 100)
      });

      // Buscar departamentos da empresa
      const departments = await base44.entities.Department.filter({ company_id: company.id });
      
      // Buscar GHEs da empresa
      const ghes = await base44.entities.GHE.filter({ empresa_id: company.id });

      if (departments.length === 0) {
        console.warn(`Empresa ${company.name} não tem departamentos, pulando...`);
        continue;
      }

      // Criar colaboradores
      const employeesToCreate = [];
      for (let i = 0; i < employeesPerCompany; i++) {
        const firstName = randomChoice(FIRST_NAMES);
        const lastName = randomChoice(LAST_NAMES);
        const fullName = `${firstName} ${lastName}`;
        
        const employee = {
          company_id: company.id,
          department_id: randomChoice(departments).id,
          ghe_id: ghes.length > 0 ? randomChoice(ghes).id : null,
          name: fullName,
          cpf: generateCPF(),
          birth_date: generateBirthDate(),
          email: generateEmail(fullName),
          phone: generatePhone(),
          position: randomChoice(POSITIONS),
          is_leader: Math.random() < 0.15, // 15% são líderes
          gender: Math.random() < 0.5 ? "Masculino" : "Feminino",
          status: "active"
        };
        
        employeesToCreate.push(employee);
      }

      // Criar colaboradores em batch
      const createdEmployees = await base44.entities.Employee.bulkCreate(employeesToCreate);
      totalEmployees += createdEmployees.length;

      onProgress({ 
        step: 'employees', 
        message: `${createdEmployees.length} colaboradores criados em ${company.name}` 
      });

      // Criar avaliações para alguns colaboradores
      const assessmentsToCreate = [];
      const numAssessments = Math.floor(createdEmployees.length * (assessmentPercentage / 100));
      
      for (let i = 0; i < numAssessments; i++) {
        const employee = createdEmployees[i];
        
        const primaResponses = generatePRIMAResponses();
        const phq9Responses = generatePHQ9Responses();
        const gad7Responses = generateGAD7Responses();
        
        const primaScore = calculatePRIMAScore(primaResponses);
        const phq9Score = calculatePHQ9Score(phq9Responses);
        const gad7Score = calculateGAD7Score(gad7Responses);
        
        const assessment = {
          employee_id: employee.id,
          company_id: company.id,
          department_id: employee.department_id,
          assessment_type: "PHQ-9,GAD-7,PRIMA-EF",
          assessment_token: `TEST_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          assessment_name: "Avaliação de Bem-Estar - Teste",
          term_accepted: true,
          term_accepted_at: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
          prima_responses: primaResponses,
          phq9_responses: phq9Responses,
          gad7_responses: gad7Responses,
          prima_score: primaScore,
          prima_classification: classifyPRIMA(primaScore),
          phq9_score: phq9Score,
          phq9_classification: classifyPHQ9(phq9Score),
          gad7_score: gad7Score,
          gad7_classification: classifyGAD7(gad7Score),
          has_suicide_risk: phq9Responses.q9 >= 2, // Item 9 do PHQ-9
          completed_at: new Date(Date.now() - Math.random() * 20 * 24 * 60 * 60 * 1000).toISOString()
        };
        
        assessmentsToCreate.push(assessment);
      }

      if (assessmentsToCreate.length > 0) {
        await base44.entities.Assessment.bulkCreate(assessmentsToCreate);
        totalAssessments += assessmentsToCreate.length;
        
        onProgress({ 
          step: 'assessments', 
          message: `${assessmentsToCreate.length} avaliações criadas em ${company.name}` 
        });
      }
    }

    onProgress({ 
      step: 'complete', 
      message: `Concluído! ${totalEmployees} colaboradores e ${totalAssessments} avaliações criadas.`,
      progress: 100
    });

    return {
      success: true,
      totalEmployees,
      totalAssessments,
      companies: companies.length
    };

  } catch (error) {
    console.error('Error seeding test data:', error);
    throw error;
  }
}