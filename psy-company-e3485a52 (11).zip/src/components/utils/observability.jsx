/**
 * Sistema de observabilidade e logging
 */

export const structuredLog = (level, message, context = {}) => {
  const logEntry = {
    timestamp: new Date().toISOString(),
    level,
    message,
    ...context
  };
  
  console.log(JSON.stringify(logEntry));
  
  return logEntry;
};

export const measurePerformance = async (fn, label, context = {}) => {
  const startTime = performance.now();
  
  try {
    const result = await fn();
    const duration = performance.now() - startTime;
    
    structuredLog('info', `Performance: ${label}`, {
      ...context,
      duration_ms: duration.toFixed(2),
      status: 'success'
    });
    
    return result;
  } catch (error) {
    const duration = performance.now() - startTime;
    
    structuredLog('error', `Performance: ${label} (failed)`, {
      ...context,
      duration_ms: duration.toFixed(2),
      status: 'error',
      error: error.message
    });
    
    throw error;
  }
};

export const queryWithLogging = async (entityName, operation, params, tenantContext) => {
  return measurePerformance(
    async () => {
      const result = await operation(params);
      return result;
    },
    `Query: ${entityName}`,
    {
      entity: entityName,
      tenant_id: tenantContext?.consultoriaId,
      empresa_id: tenantContext?.empresaId,
      operation: 'query'
    }
  );
};

export const trackError = (error, context = {}) => {
  structuredLog('error', error.message, {
    error_type: error.name,
    stack: error.stack,
    ...context
  });
  
  if (typeof window !== 'undefined' && window.Sentry) {
    window.Sentry.captureException(error, { extra: context });
  }
};

export const trackMetric = (metricName, value, tags = {}) => {
  structuredLog('metric', metricName, {
    metric_name: metricName,
    value,
    tags
  });
};