/**
 * Helper para obter o contexto correto (impersonado ou real)
 */
export function getEffectiveContext(user) {
  if (!user) return null;

  const impersonationData = localStorage.getItem('admin_impersonation');
  
  // Se não há impersonation, retornar contexto do usuário
  if (!impersonationData || impersonationData === 'null') {
    return {
      user_id: user.id,
      email: user.email,
      full_name: user.full_name,
      role: user.user_role || user.role,
      consultoria_id: user.consultoria_id,
      company_id: user.company_id,
      employee_id: null,
      is_impersonating: false,
      original_role: user.user_role || user.role,
      original_email: user.email
    };
  }

  // Parse impersonation
  let impersonation;
  try {
    impersonation = JSON.parse(impersonationData);
  } catch (e) {
    console.error('Error parsing impersonation:', e);
    return null;
  }

  // Construir contexto baseado no tipo de impersonation
  const context = {
    user_id: user.id, // Manter ID do admin para auditoria
    is_impersonating: true,
    original_role: user.user_role || user.role,
    original_email: user.email
  };

  if (impersonation.type === 'consultoria') {
    context.role = 'consultoria';
    context.consultoria_id = impersonation.consultoria_id;
    context.company_id = null;
    context.employee_id = null;
    context.email = user.email; // Manter email do admin
    context.full_name = `Admin visualizando: ${impersonation.consultoria_nome}`;
  } else if (impersonation.type === 'empresa') {
    context.role = 'manager';
    context.consultoria_id = impersonation.consultoria_id;
    context.company_id = impersonation.company_id;
    context.employee_id = null;
    context.email = user.email;
    context.full_name = `Admin visualizando: ${impersonation.company_nome}`;
  } else if (impersonation.type === 'colaborador') {
    context.role = 'employee';
    context.consultoria_id = impersonation.consultoria_id;
    context.company_id = impersonation.company_id;
    context.employee_id = impersonation.employee_id;
    context.email = user.email;
    context.full_name = `Admin visualizando: ${impersonation.employee_nome}`;
  }

  return context;
}

/**
 * Hook para usar o contexto efetivo
 */
export function useEffectiveContext() {
  const [context, setContext] = React.useState(null);

  React.useEffect(() => {
    const loadContext = async () => {
      try {
        const userData = await base44.auth.me();
        const effectiveContext = getEffectiveContext(userData);
        setContext(effectiveContext);
      } catch (error) {
        console.error('Error loading context:', error);
      }
    };
    loadContext();
  }, []);

  return context;
}