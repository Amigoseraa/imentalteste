/**
 * Serviço de geração de dados fictícios para demonstração
 * Gera dados realistas em todas as entidades do sistema
 * COM RATE LIMITING AGRESSIVO
 */

import { base44 } from "@/api/base44Client";
import { format, subMonths, addDays } from "date-fns";

// Configurações de perfis - REDUZIDOS para evitar rate limit
const PROFILES = {
  leve: {
    consultorias: 1,
    empresasPorConsultoria: 2,
    departamentosPorEmpresa: 3,
    ghesPorDepartamento: [1, 2],
    colaboradoresTotal: 50,
  },
  medio: {
    consultorias: 2,
    empresasPorConsultoria: 3,
    departamentosPorEmpresa: 4,
    ghesPorDepartamento: [1, 2],
    colaboradoresTotal: 150,
  },
  completo: {
    consultorias: 3,
    empresasPorConsultoria: 4,
    departamentosPorEmpresa: 5,
    ghesPorDepartamento: [1, 2],
    colaboradoresTotal: 300,
  }
};

// Nomes realistas
const NOMES_CONSULTORIAS = [
  "MedNet Consultoria", "PsicoWork Empresarial", "MindCare Solutions", 
  "Saúde Corporativa Plus", "WellBeing Consultores"
];

const NOMES_EMPRESAS = [
  "TechCorp Brasil", "Indústrias Moderna", "Varejo & Cia", "Logística Express",
  "Financeira Nacional", "Construtora Alvorada", "Comércio Popular", "Serviços Integrados",
  "Agro Forte", "Telecom Connect", "Energia Limpa", "Química Industrial",
  "Transporte Rápido", "Hospital São Lucas", "Educação Digital", "Manufatura XYZ",
  "Distribuidora Central", "Alimentos & Bebidas", "Farmacêutica Vita", "Engenharia Total"
];

const NOMES_DEPARTAMENTOS = [
  "Administrativo", "Financeiro", "Comercial", "Operacional", "TI",
  "RH", "Logística", "Produção", "Qualidade", "Manutenção"
];

const NOMES = [
  "João Silva", "Maria Santos", "Pedro Oliveira", "Ana Costa", "Carlos Souza",
  "Juliana Lima", "Fernando Alves", "Patrícia Rocha", "Roberto Ferreira", "Camila Martins",
  "Lucas Ribeiro", "Amanda Carvalho", "Rafael Gomes", "Fernanda Dias", "Rodrigo Pereira",
  "Beatriz Araújo", "Gabriel Barbosa", "Larissa Campos", "Thiago Monteiro", "Mariana Freitas"
];

/**
 * Delay AUMENTADO para evitar rate limiting
 */
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

/**
 * Processa items SEQUENCIALMENTE com delay entre cada um
 */
async function processSequentially(items, processor, delayMs = 1000) {
  const results = [];
  for (let i = 0; i < items.length; i++) {
    try {
      const result = await processor(items[i]);
      results.push(result);
      
      // Delay após cada item
      if (i < items.length - 1) {
        await sleep(delayMs);
      }
    } catch (error) {
      console.error(`[SEED] Erro ao processar item ${i}:`, error);
      // Continuar mesmo com erro
      results.push(null);
      await sleep(delayMs * 2); // Delay maior após erro
    }
  }
  return results.filter(r => r !== null);
}

/**
 * Gera CPF fictício válido
 */
function gerarCPF() {
  const n = () => Math.floor(Math.random() * 10);
  const cpf = Array(9).fill(0).map(n);
  
  let sum = cpf.reduce((acc, val, i) => acc + val * (10 - i), 0);
  cpf.push(sum % 11 < 2 ? 0 : 11 - (sum % 11));
  
  sum = cpf.reduce((acc, val, i) => acc + val * (11 - i), 0);
  cpf.push(sum % 11 < 2 ? 0 : 11 - (sum % 11));
  
  return cpf.join('');
}

/**
 * Gera CNPJ fictício válido
 */
function gerarCNPJ() {
  const n = () => Math.floor(Math.random() * 10);
  const cnpj = Array(12).fill(0).map(n);
  
  const pesos1 = [5,4,3,2,9,8,7,6,5,4,3,2];
  let sum = cnpj.reduce((acc, val, i) => acc + val * pesos1[i], 0);
  cnpj.push(sum % 11 < 2 ? 0 : 11 - (sum % 11));
  
  const pesos2 = [6,5,4,3,2,9,8,7,6,5,4,3,2];
  sum = [...cnpj].reduce((acc, val, i) => acc + val * pesos2[i], 0);
  cnpj.push(sum % 11 < 2 ? 0 : 11 - (sum % 11));
  
  return cnpj.join('');
}

/**
 * Gera score PHQ-9 com distribuição realista
 */
function gerarPHQ9Score() {
  const rand = Math.random();
  if (rand < 0.55) return Math.floor(Math.random() * 5);
  if (rand < 0.75) return Math.floor(Math.random() * 5) + 5;
  if (rand < 0.93) return Math.floor(Math.random() * 5) + 10;
  return Math.floor(Math.random() * 13) + 15;
}

/**
 * Gera score GAD-7 com distribuição realista
 */
function gerarGAD7Score() {
  const rand = Math.random();
  if (rand < 0.55) return Math.floor(Math.random() * 5);
  if (rand < 0.75) return Math.floor(Math.random() * 5) + 5;
  if (rand < 0.93) return Math.floor(Math.random() * 5) + 10;
  return Math.floor(Math.random() * 7) + 15;
}

/**
 * Gera respostas PRIMA-EF realistas
 */
function gerarPRIMARespostas() {
  const responses = {};
  const mediaGeral = 2.8 + Math.random() * 0.8;
  
  for (let i = 1; i <= 30; i++) {
    const variacao = (Math.random() - 0.5) * 1.5;
    let valor = Math.round(mediaGeral + variacao);
    valor = Math.max(1, Math.min(5, valor));
    responses[`q${i}`] = valor;
  }
  
  return responses;
}

/**
 * Calcula score e classificação PRIMA-EF
 */
function calcularPRIMAScore(responses) {
  const valores = Object.values(responses);
  const soma = valores.reduce((a, b) => a + b, 0);
  const media = soma / valores.length;
  
  let classification;
  if (media >= 3.5) classification = "Baixo";
  else if (media >= 2.5) classification = "Moderado";
  else classification = "Alto";
  
  return { score: parseFloat(media.toFixed(2)), classification };
}

/**
 * Função principal de seed COM DELAYS AGRESSIVOS
 */
export async function seedDemo(config, onProgress) {
  const { profile, months, mode, withBilling } = config;
  const profileConfig = PROFILES[profile];
  const seedRunId = `demo_${Date.now()}`;
  const seedTag = 'demo';
  
  const log = (step, message, percent) => {
    console.log(`[SEED] ${step}: ${message}`);
    if (onProgress) onProgress(step, message, percent);
  };
  
  try {
    // Etapa 1: Limpar dados demo anteriores
    if (mode === 'reset') {
      log('cleanup', 'Removendo dados demo anteriores...', 0);
      await cleanupDemoData();
      await sleep(2000);
    }
    
    // Etapa 2: Gerar Consultorias (SEQUENCIAL)
    log('consultorias', 'Gerando consultorias...', 10);
    const consultorias = [];
    for (let i = 0; i < profileConfig.consultorias; i++) {
      const consultoria = await base44.entities.Consultoria.create({
        nome_fantasia: NOMES_CONSULTORIAS[i],
        razao_social: `${NOMES_CONSULTORIAS[i]} LTDA`,
        cnpj: gerarCNPJ(),
        email_master: `demo.consultoria${i+1}@example.com`,
        status: 'ativo',
        plano_id: null,
        seed_tag: seedTag,
        seed_run_id: seedRunId,
        faturamento_modelo: 'por_empresa',
        valor_unitario: 49.90 + (i * 10),
        ciclo_faturamento: 'mensal'
      });
      consultorias.push(consultoria);
      await sleep(1000); // 1 segundo entre consultorias
    }
    
    // Etapa 3: Gerar Empresas (SEQUENCIAL)
    log('empresas', 'Gerando empresas...', 20);
    const empresas = [];
    let empresaIdx = 0;
    for (const consultoria of consultorias) {
      for (let i = 0; i < profileConfig.empresasPorConsultoria; i++) {
        if (empresaIdx >= NOMES_EMPRESAS.length) break;
        
        const empresa = await base44.entities.Company.create({
          consultoria_id: consultoria.id,
          name: NOMES_EMPRESAS[empresaIdx],
          cnpj: gerarCNPJ(),
          sector: ['Tecnologia', 'Indústria', 'Comércio', 'Serviços', 'Saúde'][empresaIdx % 5],
          status: 'active',
          seed_tag: seedTag,
          seed_run_id: seedRunId,
          plano_empresa: ['Starter', 'Plus', 'Enterprise'][empresaIdx % 3],
          faturamento_modelo: 'por_colaborador',
          valor_unitario: 4.90,
          ciclo_faturamento: 'mensal'
        });
        empresas.push(empresa);
        empresaIdx++;
        await sleep(800); // 800ms entre empresas
      }
    }
    
    // Etapa 4: Gerar Departamentos e GHEs (SEQUENCIAL)
    log('estruturas', 'Gerando departamentos e GHEs...', 30);
    const departamentos = [];
    const ghes = [];
    
    for (const empresa of empresas) {
      const numDeps = profileConfig.departamentosPorEmpresa;
      for (let i = 0; i < numDeps; i++) {
        const dept = await base44.entities.Department.create({
          company_id: empresa.id,
          name: NOMES_DEPARTAMENTOS[i % NOMES_DEPARTAMENTOS.length],
          seed_tag: seedTag,
          seed_run_id: seedRunId
        });
        departamentos.push({ ...dept, company_id: empresa.id });
        await sleep(500);
        
        // GHEs por departamento
        const [minGHE, maxGHE] = profileConfig.ghesPorDepartamento;
        const numGHEs = minGHE + Math.floor(Math.random() * (maxGHE - minGHE + 1));
        for (let g = 0; g < numGHEs; g++) {
          const ghe = await base44.entities.GHE.create({
            empresa_id: empresa.id,
            nome: `GHE ${dept.name} ${g + 1}`,
            descricao: `Grupo homogêneo de exposição do ${dept.name}`,
            status: 'ativo',
            seed_tag: seedTag,
            seed_run_id: seedRunId
          });
          ghes.push({ ...ghe, department_id: dept.id, company_id: empresa.id });
          await sleep(500);
        }
      }
    }
    
    // Etapa 5: Gerar Colaboradores (SEQUENCIAL, LENTO)
    log('colaboradores', 'Gerando colaboradores (pode levar alguns minutos)...', 40);
    const colaboradores = [];
    const colaboradoresPorEmpresa = Math.floor(profileConfig.colaboradoresTotal / empresas.length);
    
    for (const empresa of empresas) {
      const empresaDepts = departamentos.filter(d => d.company_id === empresa.id);
      if (empresaDepts.length === 0) continue;
      
      for (let i = 0; i < colaboradoresPorEmpresa; i++) {
        const dept = empresaDepts[i % empresaDepts.length];
        const deptGHEs = ghes.filter(g => g.department_id === dept.id);
        const ghe = deptGHEs.length > 0 ? deptGHEs[i % deptGHEs.length] : null;
        
        const cpf = gerarCPF();
        const colaborador = await base44.entities.Employee.create({
          company_id: empresa.id,
          department_id: dept.id,
          ghe_id: ghe?.id || null,
          name: `${NOMES[i % NOMES.length]} ${i}`,
          cpf: cpf,
          email: `colaborador.${cpf}@example.com`,
          phone: `11${Math.floor(Math.random() * 100000000).toString().padStart(9, '0')}`,
          position: ['Analista', 'Assistente', 'Coordenador', 'Gerente', 'Diretor'][i % 5],
          is_leader: i % 10 === 0,
          gender: ['Masculino', 'Feminino'][i % 2],
          birth_date: format(new Date(1970 + Math.floor(Math.random() * 35), Math.floor(Math.random() * 12), 1), 'yyyy-MM-dd'),
          status: 'active',
          seed_tag: seedTag,
          seed_run_id: seedRunId
        });
        
        colaboradores.push({
          ...colaborador,
          company_id: empresa.id,
          department_id: dept.id
        });
        
        await sleep(800); // 800ms entre cada colaborador
        
        // Atualizar progresso
        const progressPercent = 40 + ((colaboradores.length / profileConfig.colaboradoresTotal) * 20);
        log('colaboradores', `${colaboradores.length}/${profileConfig.colaboradoresTotal} colaboradores criados`, progressPercent);
      }
    }
    
    // Etapa 6: Gerar Avaliações (SEQUENCIAL, MUITO LENTO)
    log('avaliacoes', 'Gerando avaliações (pode levar vários minutos)...', 60);
    const avaliacoes = [];
    
    // Limitar meses para evitar timeout
    const maxMonths = Math.min(months, 3);
    
    for (let m = 0; m < maxMonths; m++) {
      const competencia = format(subMonths(new Date(), m), 'yyyy-MM');
      log('avaliacoes', `Gerando avaliações para ${competencia}...`, 60 + (m / maxMonths) * 15);
      
      // Taxa de resposta reduzida para gerar menos dados
      const taxaResposta = 0.3;
      
      let avaliacoesCount = 0;
      for (const colaborador of colaboradores) {
        if (Math.random() > taxaResposta) continue;
        
        const primaResponses = gerarPRIMARespostas();
        const { score: primaScore, classification: primaClassification } = calcularPRIMAScore(primaResponses);
        const phq9Score = gerarPHQ9Score();
        const gad7Score = gerarGAD7Score();
        
        let phq9Classification = "Mínimo";
        if (phq9Score >= 15) phq9Classification = "Grave";
        else if (phq9Score >= 10) phq9Classification = "Moderado";
        else if (phq9Score >= 5) phq9Classification = "Leve";
        
        let gad7Classification = "Mínimo";
        if (gad7Score >= 15) gad7Classification = "Grave";
        else if (gad7Score >= 10) gad7Classification = "Moderado";
        else if (gad7Score >= 5) gad7Classification = "Leve";
        
        const dataResposta = new Date(competencia);
        dataResposta.setDate(Math.floor(Math.random() * 28) + 1);
        
        const avaliacao = await base44.entities.Assessment.create({
          employee_id: colaborador.id,
          company_id: colaborador.company_id,
          department_id: colaborador.department_id,
          assessment_type: 'PRIMA-EF,PHQ-9,GAD-7',
          assessment_token: `demo_${colaborador.id}_${competencia}`,
          assessment_name: `Avaliação ${competencia}`,
          due_date: format(addDays(dataResposta, 7), 'yyyy-MM-dd'),
          term_accepted: true,
          term_accepted_at: dataResposta.toISOString(),
          prima_responses: primaResponses,
          prima_score: primaScore,
          prima_classification: primaClassification,
          phq9_score: phq9Score,
          phq9_classification: phq9Classification,
          gad7_score: gad7Score,
          gad7_classification: gad7Classification,
          has_suicide_risk: phq9Score >= 20 && Math.random() < 0.3,
          completed_at: dataResposta.toISOString(),
          seed_tag: seedTag,
          seed_run_id: seedRunId
        });
        
        avaliacoes.push(avaliacao);
        avaliacoesCount++;
        await sleep(1000); // 1 segundo entre avaliações
        
        // Atualizar progresso a cada 5 avaliações
        if (avaliacoesCount % 5 === 0) {
          log('avaliacoes', `${avaliacoesCount} avaliações criadas para ${competencia}`, 60 + (m / maxMonths) * 15);
        }
      }
    }
    
    // Etapa 7: Faturamento (SE HABILITADO, SEQUENCIAL)
    if (withBilling) {
      log('faturamento', 'Gerando contratos e faturas...', 80);
      
      // Contratos (sequencial)
      for (const consultoria of consultorias) {
        await base44.entities.ContratoConsultoria.create({
          consultoria_id: consultoria.id,
          modelo_cobranca: 'POR_EMPRESA_ATIVA',
          valor_unitario: consultoria.valor_unitario,
          minimo_mensal: 0,
          ciclo: 'MENSAL',
          data_inicio: format(subMonths(new Date(), maxMonths), 'yyyy-MM-dd'),
          status: 'ATIVO',
          vencimento_dia: 10,
          seed_tag: seedTag,
          seed_run_id: seedRunId
        });
        await sleep(1000);
      }
      
      for (const empresa of empresas) {
        await base44.entities.ContratoEmpresa.create({
          empresa_id: empresa.id,
          consultoria_id: empresa.consultoria_id,
          modelo_cobranca: 'POR_COLABORADOR_ATIVO',
          valor_unitario: empresa.valor_unitario,
          minimo_mensal: 0,
          ciclo: 'MENSAL',
          data_inicio: format(subMonths(new Date(), maxMonths), 'yyyy-MM-dd'),
          status: 'ATIVO',
          vencimento_dia: 10,
          seed_tag: seedTag,
          seed_run_id: seedRunId
        });
        await sleep(1000);
      }
      
      // Faturas (apenas último mês para economizar tempo)
      const competencia = format(subMonths(new Date(), 0), 'yyyy-MM');
      log('faturamento', `Gerando faturas para ${competencia}...`, 85);
      
      for (const consultoria of consultorias) {
        const empresasAtivas = empresas.filter(e => e.consultoria_id === consultoria.id);
        const valor = empresasAtivas.length * consultoria.valor_unitario;
        
        const vencimento = new Date(competencia);
        vencimento.setDate(10);
        
        await base44.entities.Fatura.create({
          competencia,
          alvo_tipo: 'CONSULTORIA',
          alvo_id: consultoria.id,
          alvo_nome: consultoria.nome_fantasia,
          emitente_tipo: 'ADMIN',
          emitente_id: null,
          modelo_cobranca: 'POR_EMPRESA_ATIVA',
          valor_bruto: valor,
          valor_liquido: valor,
          status: 'PAGA',
          vencimento_em: format(vencimento, 'yyyy-MM-dd'),
          emitida_em: format(subMonths(vencimento, 1), 'yyyy-MM-dd\'T\'HH:mm:ss'),
          autorizada_em: format(subMonths(vencimento, 1), 'yyyy-MM-dd\'T\'HH:mm:ss'),
          paga_em: format(addDays(vencimento, 5), 'yyyy-MM-dd\'T\'HH:mm:ss'),
          idempotency_key: `${competencia}|CONSULTORIA|${consultoria.id}`,
          seed_tag: seedTag,
          seed_run_id: seedRunId
        });
        
        await sleep(1000);
      }
    }
    
    // Etapa Final
    log('complete', 'Dados fictícios gerados com sucesso!', 100);
    
    return {
      success: true,
      summary: {
        consultorias: consultorias.length,
        empresas: empresas.length,
        departamentos: departamentos.length,
        ghes: ghes.length,
        colaboradores: colaboradores.length,
        avaliacoes: avaliacoes.length,
        months: maxMonths,
        seedRunId
      }
    };
    
  } catch (error) {
    console.error('[SEED] Erro:', error);
    throw error;
  }
}

/**
 * Remove todos os dados marcados com seed_tag='demo'
 */
export async function cleanupDemoData() {
  const entities = [
    'Pagamento',
    'Fatura',
    'ContratoEmpresa',
    'ContratoConsultoria',
    'Assessment',
    'Employee',
    'GHE',
    'Department',
    'Company',
    'Consultoria'
  ];
  
  for (const entityName of entities) {
    try {
      const records = await base44.entities[entityName].filter({ seed_tag: 'demo' });
      
      // Deletar sequencialmente
      for (const record of records) {
        await base44.entities[entityName].delete(record.id);
        await sleep(500); // 500ms entre cada delete
      }
      
      console.log(`[CLEANUP] Removidos ${records.length} registros de ${entityName}`);
    } catch (error) {
      console.error(`[CLEANUP] Erro ao limpar ${entityName}:`, error);
    }
  }
}