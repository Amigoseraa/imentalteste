import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertTriangle, ChevronDown, ChevronUp } from "lucide-react";

const PRIMA_ITEMS = {
  1: { category: 'A', name: 'Variedade de tarefas', action: 'Diversificar tarefas diárias e rotacionar funções' },
  2: { category: 'A', name: 'Significado do trabalho', action: 'Readequar tarefas às habilidades e dar feedback de impacto' },
  3: { category: 'A', name: 'Exposição contínua ao estresse', action: 'Criar pausas regulares e técnicas de recuperação' },
  4: { category: 'B', name: 'Carga equilibrada', action: 'Revisar distribuição de tarefas entre equipe' },
  5: { category: 'B', name: 'Ritmo de trabalho', action: 'Ajustar ritmo e treinar gestão do tempo' },
  6: { category: 'B', name: 'Pressão por prazos', action: 'Estabelecer prazos realistas e priorizações claras' },
  7: { category: 'C', name: 'Flexibilidade de horário', action: 'Implantar políticas de flexibilidade (híbrido/remoto)' },
  8: { category: 'C', name: 'Longas jornadas', action: 'Rever duração de jornadas e banco de horas' },
  9: { category: 'C', name: 'Previsibilidade de escalas', action: 'Tornar escalas previsíveis com antecedência' },
  10: { category: 'D', name: 'Participação em decisões', action: 'Incluir colaboradores em fóruns decisórios' },
  11: { category: 'D', name: 'Organização do ritmo', action: 'Aumentar autonomia sobre métodos de trabalho' },
  12: { category: 'D', name: 'Voz nas mudanças', action: 'Abrir canais de escuta e consulta' },
  13: { category: 'E', name: 'Equipamentos adequados', action: 'Investir em manutenção preventiva' },
  14: { category: 'E', name: 'Condições ambientais', action: 'Garantir iluminação/ventilação adequadas' },
  15: { category: 'E', name: 'Silêncio no ambiente', action: 'Reduzir ruído e criar zonas de concentração' },
  16: { category: 'F', name: 'Comunicação clara', action: 'Treinamentos de comunicação não-violenta' },
  17: { category: 'F', name: 'Apoio e incentivo', action: 'Programas de mentoria e reconhecimento' },
  18: { category: 'F', name: 'Clareza nos objetivos', action: 'Comunicar OKRs/metas de forma transparente' },
  19: { category: 'G', name: 'Relações com colegas', action: 'Dinâmicas de integração e team building' },
  20: { category: 'G', name: 'Suporte dos superiores', action: 'Treinar liderança em escuta ativa' },
  21: { category: 'G', name: 'Assédio moral/sexual/bullying', action: 'Política zero tolerância e canal de denúncias' },
  22: { category: 'H', name: 'Definição de papéis', action: 'Matriz RACI clara para todas as funções' },
  23: { category: 'H', name: 'Conflito de papéis', action: 'Resolver sobreposições de responsabilidades' },
  24: { category: 'H', name: 'Expectativas de desempenho', action: 'Definir critérios e metas mensuráveis' },
  25: { category: 'I', name: 'Oportunidades de crescimento', action: 'Trilhas de carreira e PDI estruturados' },
  26: { category: 'I', name: 'Investimento em treinamentos', action: 'Programas de capacitação contínua' },
  27: { category: 'I', name: 'Estabilidade no trabalho', action: 'Transparência organizacional e comunicação' },
  28: { category: 'J', name: 'Equilíbrio trabalho-família', action: 'Políticas de conciliação (licenças, flexibilidade)' },
  29: { category: 'J', name: 'Apoio para equilíbrio', action: 'Programas de bem-estar e apoio familiar' },
  30: { category: 'J', name: 'Tempo em casa preservado', action: 'Evitar contato fora do expediente' }
};

export default function TopRisks({ assessments }) {
  const [expanded, setExpanded] = useState({});

  const getTopRisks = () => {
    const riskCounts = {};

    for (let i = 1; i <= 30; i++) {
      riskCounts[i] = 0;
    }

    assessments.forEach(assessment => {
      if (assessment.prima_responses) {
        for (let i = 1; i <= 30; i++) {
          const value = assessment.prima_responses[`q${i}`];
          if (value && value <= 2) {
            riskCounts[i]++;
          }
        }
      }
    });

    const total = assessments.length || 1;
    
    return Object.entries(riskCounts)
      .map(([item, count]) => ({
        item: parseInt(item),
        count,
        percentage: ((count / total) * 100).toFixed(1),
        ...PRIMA_ITEMS[parseInt(item)]
      }))
      .filter(risk => risk.count > 0)
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
  };

  const topRisks = getTopRisks();

  const toggleExpanded = (item) => {
    setExpanded(prev => ({
      ...prev,
      [item]: !prev[item]
    }));
  };

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="text-lg font-semibold flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-orange-500" />
          Top 5 Riscos Prioritários
        </CardTitle>
        <p className="text-sm text-gray-500 mt-1">
          Fatores com maior incidência de respostas críticas (≤2 na escala 1-5)
        </p>
      </CardHeader>
      <CardContent>
        {topRisks.length > 0 ? (
          <div className="space-y-3">
            {topRisks.map((risk, index) => (
              <div
                key={risk.item}
                className="rounded-lg border-2 transition-all hover:shadow-md"
                style={{ 
                  borderColor: index === 0 ? '#E35B5B' : index <= 2 ? '#F8A13F' : '#A77BCA',
                  backgroundColor: index === 0 ? '#FEF2F2' : index <= 2 ? '#FFF7ED' : '#F8F8FA'
                }}
              >
                <div 
                  className="p-4 cursor-pointer"
                  onClick={() => toggleExpanded(risk.item)}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-center gap-3 flex-1">
                      <Badge 
                        variant="outline" 
                        className="text-sm font-bold"
                        style={{
                          borderColor: index === 0 ? '#E35B5B' : index <= 2 ? '#F8A13F' : '#A77BCA',
                          color: index === 0 ? '#E35B5B' : index <= 2 ? '#F8A13F' : '#A77BCA'
                        }}
                      >
                        #{index + 1}
                      </Badge>
                      <h4 className="font-semibold text-gray-900">{risk.name}</h4>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-orange-100 text-orange-800 font-semibold">
                        {risk.percentage}%
                      </Badge>
                      {expanded[risk.item] ? (
                        <ChevronUp className="w-5 h-5 text-gray-400" />
                      ) : (
                        <ChevronDown className="w-5 h-5 text-gray-400" />
                      )}
                    </div>
                  </div>
                  
                  <p className="text-sm text-gray-600 mt-2 ml-[52px]">
                    <span className="font-medium">{risk.count}</span> colaboradores com resposta crítica
                  </p>
                </div>

                {expanded[risk.item] && (
                  <div className="px-4 pb-4">
                    <div className="mt-3 p-4 rounded-lg" style={{ backgroundColor: '#EFE6F8' }}>
                      <p className="text-sm font-semibold mb-2" style={{ color: '#5E2C91' }}>
                        💡 Ação Recomendada:
                      </p>
                      <p className="text-sm" style={{ color: '#2B2240' }}>
                        {risk.action}
                      </p>
                    </div>
                    <div className="mt-3 flex gap-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        style={{ borderColor: '#5E2C91', color: '#5E2C91' }}
                      >
                        📋 Criar Plano de Ação
                      </Button>
                      <Button variant="ghost" size="sm" className="text-gray-600">
                        Ver Detalhes
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="h-[300px] flex flex-col items-center justify-center text-gray-400">
            <AlertTriangle className="w-16 h-16 mb-3 opacity-30" />
            <p className="font-medium">Nenhum risco crítico identificado</p>
            <p className="text-xs mt-2 text-center max-w-md">
              Isso pode indicar baixa exposição a fatores de risco, ou ausência de dados.
              Aguarde mais respostas para análise precisa.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}