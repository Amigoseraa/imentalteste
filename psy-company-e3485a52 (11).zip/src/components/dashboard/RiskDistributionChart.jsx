import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts";

export default function RiskDistributionChart({ assessments }) {
  const getRiskData = () => {
    const dist = { Baixo: 0, Moderado: 0, Alto: 0 };
    assessments.forEach(a => {
      if (a.prima_classification) {
        dist[a.prima_classification]++;
      }
    });
    
    return [
      { name: 'Baixo', value: dist.Baixo, color: '#10b981' },
      { name: 'Moderado', value: dist.Moderado, color: '#f59e0b' },
      { name: 'Alto', value: dist.Alto, color: '#ef4444' }
    ];
  };

  const data = getRiskData();

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="text-lg font-semibold">
          Distribuição de Risco PRIMA-EF
        </CardTitle>
      </CardHeader>
      <CardContent>
        {assessments.length > 0 ? (
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-[300px] flex items-center justify-center text-gray-400">
            Aguardando dados de avaliações
          </div>
        )}
      </CardContent>
    </Card>
  );
}