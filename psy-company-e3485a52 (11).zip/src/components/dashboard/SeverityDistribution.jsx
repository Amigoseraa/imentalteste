import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { Info, Activity } from "lucide-react";

export default function SeverityDistribution({ assessments }) {
  const getSeverityData = () => {
    const phq9Dist = { none: 0, mild: 0, moderate: 0, severe: 0 };
    const gad7Dist = { none: 0, mild: 0, moderate: 0, severe: 0 };

    assessments.forEach(a => {
      // PHQ-9
      if (a.phq9_score !== undefined) {
        if (a.phq9_score <= 4) phq9Dist.none++;
        else if (a.phq9_score <= 9) phq9Dist.mild++;
        else if (a.phq9_score <= 14) phq9Dist.moderate++;
        else phq9Dist.severe++;
      }

      // GAD-7
      if (a.gad7_score !== undefined) {
        if (a.gad7_score <= 4) gad7Dist.none++;
        else if (a.gad7_score <= 9) gad7Dist.mild++;
        else if (a.gad7_score <= 14) gad7Dist.moderate++;
        else gad7Dist.severe++;
      }
    });

    const total = assessments.length || 1;

    return [
      {
        name: 'Sem sintomas',
        PHQ9: ((phq9Dist.none / total) * 100).toFixed(1),
        GAD7: ((gad7Dist.none / total) * 100).toFixed(1),
        color: '#2ECC71'
      },
      {
        name: 'Leve',
        PHQ9: ((phq9Dist.mild / total) * 100).toFixed(1),
        GAD7: ((gad7Dist.mild / total) * 100).toFixed(1),
        color: '#FFD84D'
      },
      {
        name: 'Moderado',
        PHQ9: ((phq9Dist.moderate / total) * 100).toFixed(1),
        GAD7: ((gad7Dist.moderate / total) * 100).toFixed(1),
        color: '#F39C12'
      },
      {
        name: 'Grave',
        PHQ9: ((phq9Dist.severe / total) * 100).toFixed(1),
        GAD7: ((gad7Dist.severe / total) * 100).toFixed(1),
        color: '#E74C3C'
      }
    ];
  };

  const data = getSeverityData();

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 rounded-lg shadow-lg border" style={{ borderColor: '#E8E3F5' }}>
          <p className="font-semibold mb-2" style={{ color: '#2E2E2E' }}>{payload[0].payload.name}</p>
          {payload.map((entry, index) => (
            <p key={index} className="text-sm" style={{ color: entry.color }}>
              {entry.name}: {entry.value}%
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg font-semibold">
          <Activity className="w-5 h-5" style={{ color: '#A57CE0' }} />
          Distribuição de Severidade (Saúde Mental)
        </CardTitle>
        <p className="text-sm text-gray-600 mt-1">
          Percentual de colaboradores por nível de sintomas emocionais
        </p>
      </CardHeader>
      <CardContent>
        {assessments.length > 0 ? (
          <>
            <ResponsiveContainer width="100%" height={320}>
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E8E3F5" />
                <XAxis dataKey="name" tick={{ fontSize: 12, fill: '#6B6B6B' }} />
                <YAxis tick={{ fontSize: 12, fill: '#6B6B6B' }} label={{ value: '%', angle: -90, position: 'insideLeft' }} />
                <Tooltip content={<CustomTooltip />} />
                <Legend wrapperStyle={{ paddingTop: '16px' }} />
                <Bar dataKey="PHQ9" name="PHQ-9 (Depressão)" fill="#A57CE0" radius={[8, 8, 0, 0]} />
                <Bar dataKey="GAD7" name="GAD-7 (Ansiedade)" fill="#4B2672" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
            
            <div className="mt-6 p-4 rounded-lg" style={{ backgroundColor: '#F8F6FB' }}>
              <p className="text-sm leading-relaxed" style={{ color: '#6B6B6B' }}>
                <strong style={{ color: '#4B2672' }}>Interpretação:</strong> Este gráfico mostra a distribuição de sintomas de ansiedade e depressão. 
                Colaboradores em níveis "Moderado" e "Grave" podem se beneficiar de acompanhamento psicológico.
              </p>
            </div>
          </>
        ) : (
          <div className="h-[320px] flex flex-col items-center justify-center text-gray-400">
            <Info className="w-12 h-12 mb-3 opacity-30" />
            <p className="font-medium">Aguardando dados de avaliações</p>
            <p className="text-xs mt-2 text-center max-w-md">
              Os dados de saúde mental serão exibidos após os colaboradores responderem aos questionários PHQ-9 e GAD-7
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}