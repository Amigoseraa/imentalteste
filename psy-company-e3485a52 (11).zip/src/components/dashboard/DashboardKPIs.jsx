import React from "react";
import { Card, CardHeader } from "@/components/ui/card";
import { Activity, Users, Target, TrendingUp, Brain, AlertTriangle } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

export default function DashboardKPIs({ assessments, employees, engagementRate }) {
  
  const calculateAverageIBC = () => {
    if (assessments.length === 0) return 0;
    
    // IBC = média ponderada de PHQ-9, GAD-7 e PRIMA-EF normalizados
    const validScores = assessments.filter(a => 
      a.phq9_score !== undefined && 
      a.gad7_score !== undefined && 
      a.prima_score !== undefined
    );
    
    if (validScores.length === 0) return 0;
    
    const ibcScores = validScores.map(a => {
      // PHQ-9: 0-27, quanto menor melhor (normalizar invertido)
      const phq9Normalized = ((27 - a.phq9_score) / 27) * 100;
      
      // GAD-7: 0-21, quanto menor melhor (normalizar invertido)
      const gad7Normalized = ((21 - a.gad7_score) / 21) * 100;
      
      // PRIMA-EF: 1-5, quanto maior melhor (normalizar direto)
      const primaNormalized = ((a.prima_score - 1) / 4) * 100;
      
      // IBC = média ponderada (40% PRIMA, 30% PHQ, 30% GAD)
      return (primaNormalized * 0.4) + (phq9Normalized * 0.3) + (gad7Normalized * 0.3);
    });
    
    const avgIBC = ibcScores.reduce((a, b) => a + b, 0) / ibcScores.length;
    return avgIBC.toFixed(1);
  };

  const getRiskDistribution = () => {
    const dist = { Baixo: 0, Moderado: 0, Alto: 0 };
    assessments.forEach(a => {
      if (a.prima_classification) {
        dist[a.prima_classification]++;
      }
    });
    return dist;
  };

  const getPHQDistribution = () => {
    const phqScores = assessments.filter(a => a.phq9_score !== undefined);
    if (phqScores.length === 0) return 0;
    
    const critical = phqScores.filter(a => a.phq9_score >= 10).length;
    return ((critical / phqScores.length) * 100).toFixed(1);
  };

  const getGADDistribution = () => {
    const gadScores = assessments.filter(a => a.gad7_score !== undefined);
    if (gadScores.length === 0) return 0;
    
    const critical = gadScores.filter(a => a.gad7_score >= 10).length;
    return ((critical / gadScores.length) * 100).toFixed(1);
  };

  const getMentalHealthPrevalence = () => {
    const totalWithScores = assessments.filter(a => 
      a.phq9_score !== undefined || a.gad7_score !== undefined
    );
    
    if (totalWithScores.length === 0) return 0;
    
    const critical = totalWithScores.filter(a => 
      (a.phq9_score !== undefined && a.phq9_score >= 10) ||
      (a.gad7_score !== undefined && a.gad7_score >= 10)
    ).length;
    
    return ((critical / totalWithScores.length) * 100).toFixed(1);
  };

  const avgIBC = parseFloat(calculateAverageIBC());
  const riskDist = getRiskDistribution();
  const mentalHealthPct = parseFloat(getMentalHealthPrevalence());
  const primaHighPct = assessments.length > 0 
    ? ((riskDist.Alto / assessments.length) * 100).toFixed(0)
    : 0;

  const ibcColor = avgIBC >= 70 ? 'text-green-600' : avgIBC >= 50 ? 'text-yellow-600' : 'text-red-600';
  const ibcBg = avgIBC >= 70 ? 'bg-green-50' : avgIBC >= 50 ? 'bg-yellow-50' : 'bg-red-50';
  const ibcIconBg = avgIBC >= 70 ? 'bg-green-500' : avgIBC >= 50 ? 'bg-yellow-500' : 'bg-red-500';
  const ibcStatus = avgIBC >= 70 ? 'Saudável' : avgIBC >= 50 ? 'Atenção' : 'Crítico';

  const mentalHealthColor = mentalHealthPct < 20 ? 'text-green-600' : mentalHealthPct < 35 ? 'text-yellow-600' : 'text-red-600';
  const mentalHealthBg = mentalHealthPct < 20 ? 'bg-green-50' : mentalHealthPct < 35 ? 'bg-yellow-50' : 'bg-red-50';
  const mentalHealthIconBg = mentalHealthPct < 20 ? 'bg-green-500' : mentalHealthPct < 35 ? 'bg-yellow-500' : 'bg-red-500';

  return (
    <TooltipProvider>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* IBC Card */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-all cursor-help">
              <div className={`absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 ${ibcIconBg} rounded-full opacity-10`} />
              <CardHeader className="p-6">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-600 mb-1">IBC Médio</p>
                    <div className={`text-4xl font-bold ${ibcColor} mb-2`}>
                      {assessments.length > 0 ? avgIBC : '—'}
                    </div>
                    <p className="text-xs text-gray-500">
                      {assessments.length > 0 ? ibcStatus : 'Aguardando dados'}
                    </p>
                  </div>
                  <div className={`p-3 rounded-xl ${ibcBg} flex-shrink-0`}>
                    <Brain className={`w-6 h-6 ${ibcColor}`} />
                  </div>
                </div>
              </CardHeader>
            </Card>
          </TooltipTrigger>
          <TooltipContent side="bottom" className="max-w-xs">
            <p className="font-semibold mb-1">Índice de Bem-Estar Corporativo (IBC)</p>
            <p className="text-xs">
              Média ponderada de saúde mental (PHQ-9, GAD-7) e riscos psicossociais (PRIMA-EF).
              <br/>• 70-100: Saudável
              <br/>• 50-69: Atenção
              <br/>• 0-49: Crítico
            </p>
          </TooltipContent>
        </Tooltip>

        {/* Engajamento Card */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-all cursor-help">
              <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 bg-blue-500 rounded-full opacity-10" />
              <CardHeader className="p-6">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-600 mb-1">Engajamento</p>
                    <div className="text-4xl font-bold text-blue-600 mb-2">
                      {engagementRate}%
                    </div>
                    <p className="text-xs text-gray-500">
                      {assessments.length}/{employees.length} respondidos
                    </p>
                  </div>
                  <div className="p-3 rounded-xl bg-blue-50 flex-shrink-0">
                    <Users className="w-6 h-6 text-blue-600" />
                  </div>
                </div>
              </CardHeader>
            </Card>
          </TooltipTrigger>
          <TooltipContent side="bottom" className="max-w-xs">
            <p className="font-semibold mb-1">Taxa de Engajamento</p>
            <p className="text-xs">
              Percentual de colaboradores que completaram as avaliações enviadas.
              Meta recomendada: ≥ 70%
            </p>
          </TooltipContent>
        </Tooltip>

        {/* PRIMA Alto Card */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-all cursor-help">
              <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 bg-orange-500 rounded-full opacity-10" />
              <CardHeader className="p-6">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-600 mb-1">PRIMA-EF Alto</p>
                    <div className="text-4xl font-bold text-orange-600 mb-2">
                      {assessments.length > 0 ? primaHighPct : '—'}%
                    </div>
                    <p className="text-xs text-gray-500">
                      {riskDist.Alto} colaboradores
                    </p>
                  </div>
                  <div className="p-3 rounded-xl bg-orange-50 flex-shrink-0">
                    <AlertTriangle className="w-6 h-6 text-orange-600" />
                  </div>
                </div>
              </CardHeader>
            </Card>
          </TooltipTrigger>
          <TooltipContent side="bottom" className="max-w-xs">
            <p className="font-semibold mb-1">Risco Psicossocial Alto (PRIMA-EF)</p>
            <p className="text-xs">
              Percentual de colaboradores com exposição elevada a fatores de risco organizacional.
              Classificação: score PRIMA ≤ 2.4 (escala 1-5)
            </p>
          </TooltipContent>
        </Tooltip>

        {/* Saúde Mental Card */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-all cursor-help">
              <div className={`absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 ${mentalHealthIconBg} rounded-full opacity-10`} />
              <CardHeader className="p-6">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-600 mb-1">Saúde Mental</p>
                    <div className={`text-4xl font-bold ${mentalHealthColor} mb-2`}>
                      {assessments.length > 0 ? mentalHealthPct : '—'}%
                    </div>
                    <p className="text-xs text-gray-500">
                      Sintomas moderados+
                    </p>
                  </div>
                  <div className={`p-3 rounded-xl ${mentalHealthBg} flex-shrink-0`}>
                    <Activity className={`w-6 h-6 ${mentalHealthColor}`} />
                  </div>
                </div>
              </CardHeader>
            </Card>
          </TooltipTrigger>
          <TooltipContent side="bottom" className="max-w-xs">
            <p className="font-semibold mb-1">Prevalência de Transtornos</p>
            <p className="text-xs">
              Colaboradores com sintomas moderados ou graves de ansiedade (GAD-7 ≥10) ou depressão (PHQ-9 ≥10).
              <br/>• &lt;20%: Baixo
              <br/>• 20-35%: Médio
              <br/>• &gt;35%: Alto
            </p>
          </TooltipContent>
        </Tooltip>
      </div>
    </TooltipProvider>
  );
}