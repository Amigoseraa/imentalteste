import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, ResponsiveContainer, Tooltip, Legend } from "recharts";
import { Info } from "lucide-react";
import {
  Tooltip as UITooltip,
  TooltipContent as UITooltipContent,
  TooltipProvider,
  TooltipTrigger as UITooltipTrigger,
} from "@/components/ui/tooltip";

const PRIMA_CATEGORIES = {
  'A': 'Teor do Trabalho',
  'B': 'Carga e Ritmo',
  'C': 'Horário',
  'D': 'Controle',
  'E': 'Ambiente',
  'F': 'Cultura',
  'G': 'Relações',
  'H': 'Papéis',
  'I': 'Carreira',
  'J': 'Interface Lar-Trabalho'
};

export default function CategoryRadarChart({ assessments }) {
  const getCategoryAverages = () => {
    if (assessments.length === 0) return [];

    const categoryItems = {
      'A': [1, 2, 3],
      'B': [4, 5, 6],
      'C': [7, 8, 9],
      'D': [10, 11, 12],
      'E': [13, 14, 15],
      'F': [16, 17, 18],
      'G': [19, 20, 21],
      'H': [22, 23, 24],
      'I': [25, 26, 27],
      'J': [28, 29, 30]
    };

    return Object.entries(PRIMA_CATEGORIES).map(([key, name]) => {
      let sum = 0;
      let count = 0;

      assessments.forEach(assessment => {
        if (assessment.prima_responses) {
          categoryItems[key].forEach(item => {
            const value = assessment.prima_responses[`q${item}`];
            if (value) {
              sum += value;
              count++;
            }
          });
        }
      });

      // Converter para escala 0-100 (invertido: quanto maior, pior)
      const avgScore = count > 0 ? sum / count : 0;
      const riskScore = avgScore > 0 ? ((5 - avgScore) / 4) * 100 : 0;

      return {
        category: name.length > 15 ? name.substring(0, 12) + '...' : name,
        fullName: name,
        value: parseFloat(riskScore.toFixed(1)),
        originalScore: count > 0 ? (sum / count).toFixed(2) : 0
      };
    });
  };

  const data = getCategoryAverages();

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white p-3 rounded-lg shadow-lg border border-gray-200">
          <p className="font-semibold text-gray-900 mb-1">{data.fullName}</p>
          <p className="text-sm text-gray-600">
            Risco: <span className="font-semibold">{data.value}</span>/100
          </p>
          <p className="text-xs text-gray-500 mt-1">
            Score PRIMA: {data.originalScore}/5
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <Card className="shadow-md">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">
            Fatores de Risco PRIMA-EF
          </CardTitle>
          <TooltipProvider>
            <UITooltip>
              <UITooltipTrigger>
                <Info className="w-4 h-4 text-gray-400 cursor-help" />
              </UITooltipTrigger>
              <UITooltipContent side="left" className="max-w-xs">
                <p className="text-xs">
                  <strong>Escala de Risco:</strong>
                  <br/>• 0-35: Baixo (Verde)
                  <br/>• 36-65: Moderado (Amarelo)
                  <br/>• 66-100: Alto (Vermelho)
                  <br/><br/>
                  Baseado no PRIMA-EF (European Framework for Psychosocial Risk Management)
                </p>
              </UITooltipContent>
            </UITooltip>
          </TooltipProvider>
        </div>
      </CardHeader>
      <CardContent>
        {assessments.length > 0 ? (
          <ResponsiveContainer width="100%" height={400}>
            <RadarChart data={data}>
              <PolarGrid stroke="#e5e7eb" />
              <PolarAngleAxis 
                dataKey="category" 
                tick={{ fontSize: 11, fill: '#6b7280' }}
              />
              <PolarRadiusAxis 
                angle={90} 
                domain={[0, 100]} 
                tick={{ fontSize: 10 }}
                tickCount={6}
              />
              <Radar 
                name="Nível de Risco" 
                dataKey="value" 
                stroke="#5E2C91" 
                fill="#A77BCA" 
                fillOpacity={0.6}
                strokeWidth={2}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend 
                wrapperStyle={{ paddingTop: '20px' }}
                iconType="circle"
              />
            </RadarChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-[400px] flex flex-col items-center justify-center text-gray-400">
            <p className="text-center">Aguardando dados de avaliações</p>
            <p className="text-xs mt-2 text-center max-w-md">
              Os fatores de risco serão exibidos após colaboradores responderem ao questionário PRIMA-EF
            </p>
          </div>
        )}
        
        {assessments.length > 0 && (
          <div className="mt-4 p-4 bg-gray-50 rounded-lg">
            <p className="text-xs text-gray-600 leading-relaxed">
              <strong>Interpretação:</strong> Este radar mostra os 10 fatores psicossociais do PRIMA-EF. 
              Quanto mais externa a área preenchida, maior o risco organizacional naquele fator.
              Fatores com pontuação &gt;65 requerem atenção prioritária.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}