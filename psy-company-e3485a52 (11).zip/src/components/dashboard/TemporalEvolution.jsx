import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { format, parseISO } from "date-fns";

export default function TemporalEvolution({ assessments }) {
  const getTemporalData = () => {
    const monthlyData = {};

    assessments.forEach(assessment => {
      if (assessment.completed_at) {
        const month = format(parseISO(assessment.completed_at), 'MM/yyyy');
        
        if (!monthlyData[month]) {
          monthlyData[month] = {
            month,
            ibc: [],
            prima: [],
            phq9: [],
            gad7: []
          };
        }

        if (assessment.ibc_score) monthlyData[month].ibc.push(assessment.ibc_score);
        if (assessment.prima_score) monthlyData[month].prima.push(assessment.prima_score);
        if (assessment.phq9_score !== undefined) monthlyData[month].phq9.push(assessment.phq9_score);
        if (assessment.gad7_score !== undefined) monthlyData[month].gad7.push(assessment.gad7_score);
      }
    });

    return Object.values(monthlyData).map(data => ({
      month: data.month,
      IBC: data.ibc.length > 0 ? (data.ibc.reduce((a, b) => a + b, 0) / data.ibc.length).toFixed(1) : null,
      PRIMA: data.prima.length > 0 ? (data.prima.reduce((a, b) => a + b, 0) / data.prima.length).toFixed(2) : null,
      'PHQ-9': data.phq9.length > 0 ? (data.phq9.reduce((a, b) => a + b, 0) / data.phq9.length).toFixed(1) : null,
      'GAD-7': data.gad7.length > 0 ? (data.gad7.reduce((a, b) => a + b, 0) / data.gad7.length).toFixed(1) : null
    })).sort((a, b) => {
      const [monthA, yearA] = a.month.split('/');
      const [monthB, yearB] = b.month.split('/');
      return new Date(yearA, monthA - 1) - new Date(yearB, monthB - 1);
    });
  };

  const data = getTemporalData();

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="text-lg font-semibold">
          Evolução Temporal dos Indicadores
        </CardTitle>
      </CardHeader>
      <CardContent>
        {data.length > 0 ? (
          <ResponsiveContainer width="100%" height={350}>
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis yAxisId="left" domain={[0, 100]} />
              <YAxis yAxisId="right" orientation="right" domain={[0, 27]} />
              <Tooltip />
              <Legend />
              <Line yAxisId="left" type="monotone" dataKey="IBC" stroke="#3b82f6" strokeWidth={2} />
              <Line yAxisId="left" type="monotone" dataKey="PRIMA" stroke="#10b981" strokeWidth={2} />
              <Line yAxisId="right" type="monotone" dataKey="PHQ-9" stroke="#f59e0b" strokeWidth={2} />
              <Line yAxisId="right" type="monotone" dataKey="GAD-7" stroke="#8b5cf6" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-[350px] flex items-center justify-center text-gray-400">
            Aguardando dados históricos
          </div>
        )}
      </CardContent>
    </Card>
  );
}