import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertTriangle, ArrowRight } from "lucide-react";

const PRIMA_CATEGORIES = {
  'A': { name: 'Teor do Trabalho', action: 'Diversificar tarefas e dar significado ao trabalho' },
  'B': { name: 'Carga e Ritmo', action: 'Revisar distribuição de demandas e prazos' },
  'C': { name: 'Horário', action: 'Flexibilizar jornadas e garantir previsibilidade' },
  'D': { name: 'Controle', action: 'Aumentar autonomia e participação em decisões' },
  'E': { name: 'Ambiente', action: 'Melhorar condições físicas e ergonômicas' },
  'F': { name: 'Cultura', action: 'Fortalecer comunicação e reconhecimento' },
  'G': { name: 'Relações', action: 'Promover suporte social e prevenir assédio' },
  'H': { name: 'Papéis', action: 'Clarificar responsabilidades e expectativas' },
  'I': { name: 'Carreira', action: 'Criar trilhas de desenvolvimento e crescimento' },
  'J': { name: 'Interface Lar-Trabalho', action: 'Políticas de equilíbrio e desconexão' }
};

export default function CriticalFactors({ assessments }) {
  const getCriticalFactors = () => {
    const categoryItems = {
      'A': [1, 2, 3],
      'B': [4, 5, 6],
      'C': [7, 8, 9],
      'D': [10, 11, 12],
      'E': [13, 14, 15],
      'F': [16, 17, 18],
      'G': [19, 20, 21],
      'H': [22, 23, 24],
      'I': [25, 26, 27],
      'J': [28, 29, 30]
    };

    const factors = [];

    Object.entries(PRIMA_CATEGORIES).forEach(([key, categoryInfo]) => {
      let sum = 0;
      let count = 0;

      assessments.forEach(assessment => {
        if (assessment.prima_responses) {
          categoryItems[key].forEach(item => {
            const value = assessment.prima_responses[`q${item}`];
            if (value) {
              sum += value;
              count++;
            }
          });
        }
      });

      if (count > 0) {
        const avgScore = sum / count;
        // Converter para risco (0-100), quanto maior pior
        const riskScore = ((5 - avgScore) / 4) * 100;
        
        if (riskScore >= 65) {
          factors.push({
            name: categoryInfo.name,
            score: parseFloat(riskScore.toFixed(1)),
            action: categoryInfo.action,
            primaScore: avgScore.toFixed(2)
          });
        }
      }
    });

    return factors.sort((a, b) => b.score - a.score).slice(0, 5);
  };

  const criticalFactors = getCriticalFactors();

  const getRiskColor = (score) => {
    if (score >= 75) return '#E74C3C';
    if (score >= 65) return '#F39C12';
    return '#FFD84D';
  };

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg font-semibold">
          <AlertTriangle className="w-5 h-5 text-orange-600" />
          Fatores Críticos
        </CardTitle>
        <p className="text-sm text-gray-600 mt-1">
          Principais áreas de risco psicossocial que requerem atenção
        </p>
      </CardHeader>
      <CardContent>
        {criticalFactors.length > 0 ? (
          <div className="space-y-4">
            {criticalFactors.map((factor, index) => (
              <div
                key={index}
                className="p-4 rounded-lg border-2 transition-all hover:shadow-md"
                style={{ 
                  borderColor: getRiskColor(factor.score),
                  backgroundColor: `${getRiskColor(factor.score)}10`
                }}
              >
                <div className="flex items-start justify-between gap-4 mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h4 className="font-semibold" style={{ color: '#2E2E2E' }}>
                        {factor.name}
                      </h4>
                      <Badge 
                        className="font-semibold"
                        style={{ 
                          backgroundColor: getRiskColor(factor.score),
                          color: 'white'
                        }}
                      >
                        {factor.score.toFixed(0)}
                      </Badge>
                    </div>
                    <p className="text-sm mb-2" style={{ color: '#6B6B6B' }}>
                      Score PRIMA: {factor.primaScore}/5
                    </p>
                  </div>
                </div>
                
                <div className="p-3 rounded-md mb-3" style={{ backgroundColor: '#F8F6FB' }}>
                  <p className="text-xs font-semibold mb-1" style={{ color: '#4B2672' }}>
                    💡 Recomendação:
                  </p>
                  <p className="text-sm" style={{ color: '#6B6B6B' }}>
                    {factor.action}
                  </p>
                </div>

                <Button 
                  variant="outline" 
                  size="sm"
                  className="w-full font-semibold"
                  style={{ 
                    borderColor: '#4B2672',
                    color: '#4B2672'
                  }}
                >
                  Criar Plano de Ação
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            ))}

            <div className="mt-6 p-4 rounded-lg" style={{ backgroundColor: '#F8F6FB' }}>
              <p className="text-sm leading-relaxed" style={{ color: '#6B6B6B' }}>
                <strong style={{ color: '#4B2672' }}>Nota:</strong> Fatores com score ≥ 65 indicam exposição elevada a riscos organizacionais. 
                Recomenda-se implementar medidas preventivas e corretivas conforme NR-01.
              </p>
            </div>
          </div>
        ) : (
          <div className="h-[200px] flex flex-col items-center justify-center text-gray-400">
            <AlertTriangle className="w-12 h-12 mb-3 opacity-30" />
            <p className="font-medium">Nenhum fator crítico identificado</p>
            <p className="text-xs mt-2 text-center max-w-md">
              Isso indica baixa exposição a riscos psicossociais ou ausência de dados. 
              Aguarde mais respostas para análise precisa.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}