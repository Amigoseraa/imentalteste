import React from "react";
import { Card, CardHeader } from "@/components/ui/card";
import { Activity, Users, Brain, AlertTriangle, TrendingUp, TrendingDown } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

export default function IMScoreKPIs({ assessments, employees, engagementRate }) {
  
  // Calcular IM-Score (iMental Score) - DADOS REAIS
  const calculateIMScore = () => {
    if (assessments.length === 0) return { score: 0, trend: 0 };
    
    const validScores = assessments.filter(a => 
      (a.phq9_score !== undefined || a.gad7_score !== undefined || a.prima_score !== undefined)
    );
    
    if (validScores.length === 0) return { score: 0, trend: 0 };
    
    let mentalHealthComponent = 0;
    let psychosocialComponent = 0;
    let engagementComponent = parseFloat(engagementRate) || 0;
    
    // Componente Saúde Mental (45% do peso)
    const mentalHealthScores = validScores.filter(a => 
      a.phq9_score !== undefined || a.gad7_score !== undefined
    );
    
    if (mentalHealthScores.length > 0) {
      const mentalHealthValues = mentalHealthScores.map(a => {
        let phq9Normalized = 0;
        let gad7Normalized = 0;
        let count = 0;
        
        if (a.phq9_score !== undefined) {
          phq9Normalized = ((27 - a.phq9_score) / 27) * 100;
          count++;
        }
        if (a.gad7_score !== undefined) {
          gad7Normalized = ((21 - a.gad7_score) / 21) * 100;
          count++;
        }
        
        return count > 0 ? (phq9Normalized + gad7Normalized) / count : 0;
      });
      
      mentalHealthComponent = mentalHealthValues.reduce((a, b) => a + b, 0) / mentalHealthValues.length;
    }
    
    // Componente Riscos Psicossociais (45% do peso)
    const psychosocialScores = validScores.filter(a => a.prima_score !== undefined);
    
    if (psychosocialScores.length > 0) {
      const psychosocialValues = psychosocialScores.map(a => {
        // PRIMA: 1-5, converter para 0-100 (quanto maior PRIMA, melhor)
        return ((a.prima_score - 1) / 4) * 100;
      });
      
      psychosocialComponent = psychosocialValues.reduce((a, b) => a + b, 0) / psychosocialValues.length;
    }
    
    // Calcular pesos dinâmicos
    let totalWeight = 0;
    let weightedSum = 0;
    
    if (mentalHealthScores.length > 0) {
      weightedSum += mentalHealthComponent * 0.45;
      totalWeight += 0.45;
    }
    
    if (psychosocialScores.length > 0) {
      weightedSum += psychosocialComponent * 0.45;
      totalWeight += 0.45;
    }
    
    if (totalWeight > 0) {
      weightedSum += engagementComponent * 0.10;
      totalWeight += 0.10;
    }
    
    const imScore = totalWeight > 0 ? weightedSum / totalWeight : 0;
    
    // TODO: Calcular tendência comparando com período anterior (requer dados históricos)
    return {
      score: parseFloat(imScore.toFixed(1)),
      trend: 0
    };
  };

  // Calcular prevalência de saúde mental - DADOS REAIS
  const getMentalHealthPrevalence = () => {
    const totalWithScores = assessments.filter(a => 
      a.phq9_score !== undefined || a.gad7_score !== undefined
    );
    
    if (totalWithScores.length === 0) return 0;
    
    const moderate = totalWithScores.filter(a => 
      (a.phq9_score !== undefined && a.phq9_score >= 10) ||
      (a.gad7_score !== undefined && a.gad7_score >= 10)
    ).length;
    
    return ((moderate / totalWithScores.length) * 100).toFixed(1);
  };

  // Calcular risco psicossocial - DADOS REAIS
  const getPsychosocialRisk = () => {
    const primaScores = assessments.filter(a => a.prima_score !== undefined);
    if (primaScores.length === 0) return 0;
    
    // Converter PRIMA para risco (quanto menor PRIMA, maior risco)
    const highRisk = primaScores.filter(a => a.prima_score <= 2.5).length;
    return ((highRisk / primaScores.length) * 100).toFixed(1);
  };

  const { score: imScore, trend } = calculateIMScore();
  const mentalHealthPct = parseFloat(getMentalHealthPrevalence());
  const psychosocialRiskPct = parseFloat(getPsychosocialRisk());

  // Cores baseadas no score
  const getScoreColor = (value) => {
    if (value >= 60) return { text: 'text-green-600', bg: 'bg-green-50', icon: 'bg-green-500', label: 'Saudável' };
    if (value >= 35) return { text: 'text-yellow-600', bg: 'bg-yellow-50', icon: 'bg-yellow-500', label: 'Atenção' };
    return { text: 'text-red-600', bg: 'bg-red-50', icon: 'bg-red-500', label: 'Crítico' };
  };

  const scoreColors = getScoreColor(imScore);

  return (
    <TooltipProvider>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* IM-Score Card - DESTAQUE */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Card className="relative overflow-hidden shadow-lg hover:shadow-xl transition-all cursor-help lg:col-span-2">
              <div className="absolute top-0 right-0 w-40 h-40 transform translate-x-12 -translate-y-12 rounded-full opacity-10" style={{ backgroundColor: '#4B2672' }} />
              <CardHeader className="p-8">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Brain className="w-6 h-6" style={{ color: '#4B2672' }} />
                      <p className="text-sm font-semibold text-gray-600">IM-Score</p>
                    </div>
                    <div className="flex items-end gap-4">
                      <div className={`text-6xl font-bold ${scoreColors.text}`}>
                        {assessments.length > 0 ? imScore : '—'}
                      </div>
                      {trend !== 0 && (
                        <div className="flex items-center gap-1 mb-2">
                          {trend > 0 ? (
                            <TrendingUp className="w-5 h-5 text-green-600" />
                          ) : (
                            <TrendingDown className="w-5 h-5 text-red-600" />
                          )}
                          <span className={`text-sm font-semibold ${trend > 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {Math.abs(trend)}%
                          </span>
                        </div>
                      )}
                    </div>
                    <div className="mt-3">
                      <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-semibold ${scoreColors.bg} ${scoreColors.text}`}>
                        {assessments.length > 0 ? scoreColors.label : 'Aguardando dados'}
                      </span>
                    </div>
                  </div>
                  {assessments.length > 0 && (
                    <div className="relative">
                      <svg className="w-32 h-32 transform -rotate-90">
                        <circle
                          cx="64"
                          cy="64"
                          r="56"
                          stroke="#E8E3F5"
                          strokeWidth="12"
                          fill="none"
                        />
                        <circle
                          cx="64"
                          cy="64"
                          r="56"
                          stroke="#4B2672"
                          strokeWidth="12"
                          fill="none"
                          strokeDasharray={`${(imScore / 100) * 351.86} 351.86`}
                          strokeLinecap="round"
                        />
                      </svg>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <span className="text-2xl font-bold" style={{ color: '#4B2672' }}>
                          {imScore}
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              </CardHeader>
            </Card>
          </TooltipTrigger>
          <TooltipContent side="bottom" className="max-w-sm">
            <p className="font-semibold mb-1">IM-Score (iMental Score)</p>
            <p className="text-xs leading-relaxed">
              Indicador consolidado de saúde mental e riscos psicossociais calculado a partir de dados reais.
              <br/><br/>
              <strong>Componentes:</strong>
              <br/>• 45% Saúde Mental (PHQ-9, GAD-7)
              <br/>• 45% Riscos Psicossociais (PRIMA-EF)
              <br/>• 10% Engajamento
              <br/><br/>
              <strong>Interpretação:</strong>
              <br/>• 60-100: 🟢 Saudável
              <br/>• 35-59: 🟡 Atenção
              <br/>• 0-34: 🔴 Crítico
            </p>
          </TooltipContent>
        </Tooltip>

        {/* Engajamento Card */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-all cursor-help">
              <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 bg-blue-500 rounded-full opacity-10" />
              <CardHeader className="p-6">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-600 mb-1">Engajamento</p>
                    <div className="text-4xl font-bold text-blue-600 mb-2">
                      {engagementRate}%
                    </div>
                    <p className="text-xs text-gray-500">
                      {assessments.length}/{employees.length} avaliados
                    </p>
                  </div>
                  <div className="p-3 rounded-xl bg-blue-50 flex-shrink-0">
                    <Users className="w-6 h-6 text-blue-600" />
                  </div>
                </div>
              </CardHeader>
            </Card>
          </TooltipTrigger>
          <TooltipContent side="bottom" className="max-w-xs">
            <p className="font-semibold mb-1">Taxa de Engajamento</p>
            <p className="text-xs">
              Percentual de colaboradores que completaram as avaliações.
              <br/>Meta recomendada: ≥ 70%
            </p>
          </TooltipContent>
        </Tooltip>

        {/* Saúde Mental Card */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-all cursor-help">
              <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 rounded-full opacity-10" style={{ backgroundColor: '#A57CE0' }} />
              <CardHeader className="p-6">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-600 mb-1">Saúde Mental</p>
                    <div className={`text-4xl font-bold mb-2 ${
                      mentalHealthPct < 20 ? 'text-green-600' : 
                      mentalHealthPct < 35 ? 'text-yellow-600' : 'text-red-600'
                    }`}>
                      {assessments.length > 0 ? mentalHealthPct : '—'}%
                    </div>
                    <p className="text-xs text-gray-500">
                      Sintomas moderados+
                    </p>
                  </div>
                  <div className="p-3 rounded-xl flex-shrink-0" style={{ backgroundColor: '#F8F6FB' }}>
                    <Activity className="w-6 h-6" style={{ color: '#A57CE0' }} />
                  </div>
                </div>
              </CardHeader>
            </Card>
          </TooltipTrigger>
          <TooltipContent side="bottom" className="max-w-xs">
            <p className="font-semibold mb-1">Indicador de Saúde Mental</p>
            <p className="text-xs">
              Percentual real de colaboradores com sintomas moderados ou graves de ansiedade (GAD-7 ≥10) ou depressão (PHQ-9 ≥10).
              <br/><br/>
              <strong>Referência:</strong>
              <br/>• &lt;20%: Baixo
              <br/>• 20-35%: Médio
              <br/>• &gt;35%: Alto
            </p>
          </TooltipContent>
        </Tooltip>

        {/* Risco Psicossocial Card */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-all cursor-help">
              <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 rounded-full opacity-10" style={{ backgroundColor: '#FFD84D' }} />
              <CardHeader className="p-6">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-600 mb-1">Risco Psicossocial</p>
                    <div className={`text-4xl font-bold mb-2 ${
                      psychosocialRiskPct < 15 ? 'text-green-600' : 
                      psychosocialRiskPct < 30 ? 'text-orange-600' : 'text-red-600'
                    }`}>
                      {assessments.length > 0 ? psychosocialRiskPct : '—'}%
                    </div>
                    <p className="text-xs text-gray-500">
                      Alto risco
                    </p>
                  </div>
                  <div className="p-3 rounded-xl bg-orange-50 flex-shrink-0">
                    <AlertTriangle className="w-6 h-6 text-orange-600" />
                  </div>
                </div>
              </CardHeader>
            </Card>
          </TooltipTrigger>
          <TooltipContent side="bottom" className="max-w-xs">
            <p className="font-semibold mb-1">Risco Psicossocial</p>
            <p className="text-xs">
              Percentual real de colaboradores expostos a fatores organizacionais de alto risco (PRIMA-EF ≤ 2.5).
              <br/><br/>
              <strong>Classificação:</strong>
              <br/>• &lt;15%: Baixo
              <br/>• 15-30%: Moderado
              <br/>• &gt;30%: Alto
            </p>
          </TooltipContent>
        </Tooltip>
      </div>
    </TooltipProvider>
  );
}