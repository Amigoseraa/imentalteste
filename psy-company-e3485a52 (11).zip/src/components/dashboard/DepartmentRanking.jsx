import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";

export default function DepartmentRanking({ assessments, employees, companies }) {
  // Garantir que assessments, employees e companies são arrays
  const safeAssessments = Array.isArray(assessments) ? assessments : [];
  const safeEmployees = Array.isArray(employees) ? employees : [];
  const safeCompanies = Array.isArray(companies) ? companies : [];

  const getDepartmentData = () => {
    // Extrair departamentos únicos dos colaboradores
    const departmentMap = new Map();
    
    safeEmployees.forEach(emp => {
      if (emp.department_id && !departmentMap.has(emp.department_id)) {
        // Buscar nome do departamento se possível (assumindo que pode estar em algum lugar)
        departmentMap.set(emp.department_id, {
          id: emp.department_id,
          name: emp.department_name || `Departamento ${emp.department_id.substring(0, 8)}`,
          ibc: [],
          prima: []
        });
      }
    });

    // Se não há departamentos, retornar vazio
    if (departmentMap.size === 0) {
      return [];
    }

    // Adicionar scores por departamento
    safeAssessments.forEach(assessment => {
      if (assessment.department_id && departmentMap.has(assessment.department_id)) {
        const dept = departmentMap.get(assessment.department_id);
        
        if (assessment.ibc_score !== undefined && assessment.ibc_score !== null) {
          dept.ibc.push(assessment.ibc_score);
        }
        if (assessment.prima_score !== undefined && assessment.prima_score !== null) {
          dept.prima.push(assessment.prima_score);
        }
      }
    });

    // Calcular médias e retornar apenas departamentos com dados
    return Array.from(departmentMap.values())
      .map(dept => ({
        name: dept.name,
        IBC: dept.ibc.length > 0 ? parseFloat((dept.ibc.reduce((a, b) => a + b, 0) / dept.ibc.length).toFixed(1)) : 0
      }))
      .filter(dept => dept.IBC > 0)
      .sort((a, b) => b.IBC - a.IBC)
      .slice(0, 8);
  };

  const data = getDepartmentData();

  const getColor = (value) => {
    if (value >= 80) return '#10b981';
    if (value >= 60) return '#f59e0b';
    return '#ef4444';
  };

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="text-lg font-semibold">
          Ranking de Departamentos por IBC
        </CardTitle>
      </CardHeader>
      <CardContent>
        {data.length > 0 ? (
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={data} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis type="number" domain={[0, 100]} />
              <YAxis type="category" dataKey="name" width={120} tick={{ fontSize: 12 }} />
              <Tooltip />
              <Bar dataKey="IBC" radius={[0, 8, 8, 0]}>
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={getColor(entry.IBC)} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-[300px] flex items-center justify-center text-gray-400">
            <div className="text-center">
              <p className="font-medium">Aguardando dados de departamentos</p>
              <p className="text-xs mt-2">Os dados aparecerão após avaliações serem concluídas</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}