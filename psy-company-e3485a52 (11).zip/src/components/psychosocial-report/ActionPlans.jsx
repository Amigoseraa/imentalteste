import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, TrendingUp, Clock, CheckCircle } from "lucide-react";
import AutomaticInsights from "../reports/AutomaticInsights";

export default function ActionPlans({ assessments, departments, companyId }) {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold" style={{ color: '#2B2240' }}>
          🛠️ Planos de Ação e Recomendações
        </h2>
        <Button style={{ backgroundColor: '#5E2C91' }} className="text-white">
          <Plus className="w-4 h-4 mr-2" />
          Novo Plano de Ação
        </Button>
      </div>

      <Tabs defaultValue="insights" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="insights">
            🧩 Fatores Críticos
          </TabsTrigger>
          <TabsTrigger value="plans">
            🛠️ Planos Ativos
          </TabsTrigger>
          <TabsTrigger value="evolution">
            📈 Evolução Temporal
          </TabsTrigger>
        </TabsList>

        <TabsContent value="insights" className="mt-6">
          <AutomaticInsights 
            assessments={assessments}
            departments={departments}
          />
        </TabsContent>

        <TabsContent value="plans" className="mt-6">
          <Card>
            <CardContent className="p-8 text-center">
              <Clock className="w-12 h-12 mx-auto text-gray-400 mb-4" />
              <p className="text-gray-600 mb-4">
                Nenhum plano de ação ativo no momento
              </p>
              <Button style={{ backgroundColor: '#5E2C91' }} className="text-white">
                <Plus className="w-4 h-4 mr-2" />
                Criar Primeiro Plano
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="evolution" className="mt-6">
          <Card>
            <CardContent className="p-8 text-center">
              <TrendingUp className="w-12 h-12 mx-auto text-gray-400 mb-4" />
              <p className="text-gray-600">
                Evolução temporal estará disponível após múltiplos ciclos de avaliação
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}