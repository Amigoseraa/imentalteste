import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Brain,
  AlertCircle,
  Building2,
  Calendar,
  Info
} from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { format } from "date-fns";

export default function ExecutiveSummary({ assessments, departments, company }) {
  // Calcular IEP (Índice de Exposição Psicossocial)
  const calculateIEP = () => {
    if (assessments.length === 0) return 0;

    const primaScores = assessments
      .filter(a => a.prima_score !== undefined && a.prima_score !== null)
      .map(a => a.prima_score);

    if (primaScores.length === 0) return 0;

    const avgPrima = primaScores.reduce((a, b) => a + b, 0) / primaScores.length;
    
    // Converter PRIMA (1-5) para risco (0-100), onde maior = pior
    return parseFloat((((5 - avgPrima) / 4) * 100).toFixed(1));
  };

  // Contar fatores críticos
  const countCriticalFactors = () => {
    // Analisar PRIMA por categoria
    const categoryScores = {};
    
    assessments.forEach(a => {
      if (a.prima_responses) {
        // Categorias PRIMA-EF (A-J)
        const categories = {
          'A': [1, 2, 3], 'B': [4, 5, 6], 'C': [7, 8, 9], 'D': [10, 11, 12],
          'E': [13, 14, 15], 'F': [16, 17, 18], 'G': [19, 20, 21], 'H': [22, 23, 24],
          'I': [25, 26, 27], 'J': [28, 29, 30]
        };

        Object.entries(categories).forEach(([cat, items]) => {
          if (!categoryScores[cat]) categoryScores[cat] = [];
          
          items.forEach(item => {
            const value = a.prima_responses[`q${item}`];
            if (value) categoryScores[cat].push(value);
          });
        });
      }
    });

    // Contar categorias com risco alto (média <= 2.5)
    let criticalCount = 0;
    Object.values(categoryScores).forEach(scores => {
      if (scores.length > 0) {
        const avg = scores.reduce((a, b) => a + b, 0) / scores.length;
        if (avg <= 2.5) criticalCount++;
      }
    });

    return criticalCount;
  };

  // Contar departamentos impactados
  const countImpactedDepartments = () => {
    const deptScores = {};

    departments.forEach(dept => {
      deptScores[dept.id] = [];
    });

    assessments.forEach(a => {
      if (a.prima_score && deptScores[a.department_id]) {
        deptScores[a.department_id].push(a.prima_score);
      }
    });

    let impactedCount = 0;
    Object.values(deptScores).forEach(scores => {
      if (scores.length > 0) {
        const avg = scores.reduce((a, b) => a + b, 0) / scores.length;
        // Risco médio ou alto (PRIMA < 3.5)
        if (avg < 3.5) impactedCount++;
      }
    });

    return impactedCount;
  };

  // Última avaliação
  const getLastAssessmentDate = () => {
    if (assessments.length === 0) return null;
    
    const sortedDates = assessments
      .map(a => new Date(a.completed_at))
      .sort((a, b) => b - a);
    
    return sortedDates[0];
  };

  const iep = calculateIEP();
  const criticalFactors = countCriticalFactors();
  const impactedDepartments = countImpactedDepartments();
  const lastDate = getLastAssessmentDate();

  const getIEPColor = (value) => {
    if (value < 35) return { bg: '#D1FAE5', text: '#065F46', border: '#6EE7B7' };
    if (value < 60) return { bg: '#FEF3C7', text: '#92400E', border: '#FCD34D' };
    return { bg: '#FEE2E2', text: '#991B1B', border: '#FCA5A5' };
  };

  const iepColors = getIEPColor(iep);

  return (
    <div>
      <h2 className="text-2xl font-bold mb-6" style={{ color: '#2B2240' }}>
        📊 Resumo Executivo
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* IEP */}
        <Card className="shadow-md hover:shadow-lg transition-all">
          <CardContent className="pt-6">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="flex items-center gap-2 mb-2 cursor-help">
                    <Brain className="w-5 h-5" style={{ color: '#5E2C91' }} />
                    <h3 className="text-sm font-semibold text-gray-700">
                      IEP - Índice de Exposição Psicossocial
                    </h3>
                    <Info className="w-4 h-4 text-gray-400" />
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  <p className="text-xs max-w-xs">
                    Média geral dos fatores psicossociais (0-100). 
                    Calculado a partir do PRIMA-EF. Valores mais altos indicam maior exposição ao risco.
                  </p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <div 
              className="text-5xl font-bold mb-2"
              style={{ color: iepColors.text }}
            >
              {iep.toFixed(0)}
            </div>

            <Badge 
              className="text-xs"
              style={{ 
                backgroundColor: iepColors.bg,
                color: iepColors.text,
                borderColor: iepColors.border
              }}
            >
              {iep < 35 ? '🟢 Baixo' : iep < 60 ? '🟠 Médio' : '🔴 Alto'}
            </Badge>
          </CardContent>
        </Card>

        {/* Fatores Críticos */}
        <Card className="shadow-md hover:shadow-lg transition-all">
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 mb-2">
              <AlertCircle className="w-5 h-5 text-red-600" />
              <h3 className="text-sm font-semibold text-gray-700">
                Fatores Críticos
              </h3>
            </div>

            <div className="text-5xl font-bold text-red-600 mb-2">
              {criticalFactors}
            </div>

            <p className="text-xs text-gray-600">
              Fatores com risco alto (pontuação ≤ 2.5)
            </p>
          </CardContent>
        </Card>

        {/* Departamentos Impactados */}
        <Card className="shadow-md hover:shadow-lg transition-all">
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 mb-2">
              <Building2 className="w-5 h-5 text-orange-600" />
              <h3 className="text-sm font-semibold text-gray-700">
                Departamentos Impactados
              </h3>
            </div>

            <div className="text-5xl font-bold text-orange-600 mb-2">
              {impactedDepartments}
            </div>

            <p className="text-xs text-gray-600">
              Departamentos com risco médio ou alto
            </p>
          </CardContent>
        </Card>

        {/* Última Avaliação */}
        <Card className="shadow-md hover:shadow-lg transition-all">
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 mb-2">
              <Calendar className="w-5 h-5" style={{ color: '#A77BCA' }} />
              <h3 className="text-sm font-semibold text-gray-700">
                Última Avaliação
              </h3>
            </div>

            <div className="text-2xl font-bold mb-2" style={{ color: '#5E2C91' }}>
              {lastDate ? format(lastDate, 'dd/MM/yyyy') : 'N/A'}
            </div>

            <p className="text-xs text-gray-600">
              Data de coleta mais recente
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}