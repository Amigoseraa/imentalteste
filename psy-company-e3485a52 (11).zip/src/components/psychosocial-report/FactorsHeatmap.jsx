import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  ResponsiveContainer,
  Cell
} from "recharts";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet";
import { X, Info } from "lucide-react";

const PRIMA_CATEGORIES = {
  'A': 'Teor do Trabalho',
  'B': 'Carga e Ritmo',
  'C': 'Horário',
  'D': 'Controle',
  'E': 'Ambiente',
  'F': 'Cultura',
  'G': 'Relações',
  'H': 'Papéis',
  'I': 'Carreira',
  'J': 'Interface Lar-Trabalho'
};

export default function FactorsHeatmap({ assessments, departments }) {
  const [selectedCell, setSelectedCell] = useState(null);

  // Calcular scores por departamento e fator
  const getHeatmapData = () => {
    const data = [];

    departments.forEach(dept => {
      const deptAssessments = assessments.filter(a => a.department_id === dept.id);
      
      if (deptAssessments.length === 0) return;

      const categoryScores = {};
      
      const categories = {
        'A': [1, 2, 3], 'B': [4, 5, 6], 'C': [7, 8, 9], 'D': [10, 11, 12],
        'E': [13, 14, 15], 'F': [16, 17, 18], 'G': [19, 20, 21], 'H': [22, 23, 24],
        'I': [25, 26, 27], 'J': [28, 29, 30]
      };

      Object.entries(categories).forEach(([cat, items]) => {
        categoryScores[cat] = [];
        
        deptAssessments.forEach(a => {
          if (a.prima_responses) {
            items.forEach(item => {
              const value = a.prima_responses[`q${item}`];
              if (value) categoryScores[cat].push(value);
            });
          }
        });
      });

      Object.entries(categoryScores).forEach(([cat, scores]) => {
        if (scores.length > 0) {
          const avg = scores.reduce((a, b) => a + b, 0) / scores.length;
          // Converter para risco (0-100), onde maior = pior
          const riskScore = ((5 - avg) / 4) * 100;
          
          data.push({
            department: dept.name,
            factor: PRIMA_CATEGORIES[cat],
            score: riskScore.toFixed(1),
            rawAvg: avg.toFixed(2),
            count: scores.length
          });
        }
      });
    });

    return data;
  };

  // Top 5 fatores críticos
  const getTopFactors = () => {
    const factorScores = {};

    Object.entries(PRIMA_CATEGORIES).forEach(([cat, name]) => {
      factorScores[name] = [];
    });

    const categories = {
      'A': [1, 2, 3], 'B': [4, 5, 6], 'C': [7, 8, 9], 'D': [10, 11, 12],
      'E': [13, 14, 15], 'F': [16, 17, 18], 'G': [19, 20, 21], 'H': [22, 23, 24],
      'I': [25, 26, 27], 'J': [28, 29, 30]
    };

    assessments.forEach(a => {
      if (a.prima_responses) {
        Object.entries(categories).forEach(([cat, items]) => {
          items.forEach(item => {
            const value = a.prima_responses[`q${item}`];
            if (value) factorScores[PRIMA_CATEGORIES[cat]].push(value);
          });
        });
      }
    });

    return Object.entries(factorScores)
      .map(([name, scores]) => {
        if (scores.length === 0) return null;
        const avg = scores.reduce((a, b) => a + b, 0) / scores.length;
        const riskScore = ((5 - avg) / 4) * 100;
        
        return {
          name,
          score: riskScore,
          level: riskScore < 35 ? 'Baixo' : riskScore < 60 ? 'Médio' : 'Alto'
        };
      })
      .filter(f => f !== null)
      .sort((a, b) => b.score - a.score)
      .slice(0, 5);
  };

  const getRiskColor = (score) => {
    if (score < 35) return '#10b981';
    if (score < 60) return '#f59e0b';
    return '#ef4444';
  };

  const getRiskLabel = (score) => {
    if (score < 35) return '🟢 Baixo';
    if (score < 60) return '🟠 Médio';
    return '🔴 Alto';
  };

  const heatmapData = getHeatmapData();
  const topFactors = getTopFactors();

  // Agrupar por departamento
  const departmentGroups = {};
  heatmapData.forEach(item => {
    if (!departmentGroups[item.department]) {
      departmentGroups[item.department] = [];
    }
    departmentGroups[item.department].push(item);
  });

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold" style={{ color: '#2B2240' }}>
        🗺️ Mapa de Fatores Psicossociais
      </h2>

      {/* Heatmap */}
      <Card className="shadow-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            Matriz de Risco por Departamento e Fator
            <Badge variant="outline" className="text-xs">
              <Info className="w-3 h-3 mr-1" />
              Clique nas células para detalhes
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr>
                  <th className="p-3 text-left border-b-2 border-gray-300 font-semibold text-gray-700">
                    Departamento
                  </th>
                  {Object.values(PRIMA_CATEGORIES).map(cat => (
                    <th key={cat} className="p-3 text-center border-b-2 border-gray-300 font-semibold text-gray-700 text-xs">
                      {cat}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {Object.entries(departmentGroups).map(([dept, factors]) => (
                  <tr key={dept} className="hover:bg-gray-50">
                    <td className="p-3 border-b border-gray-200 font-medium">
                      {dept}
                    </td>
                    {Object.values(PRIMA_CATEGORIES).map(catName => {
                      const factor = factors.find(f => f.factor === catName);
                      
                      if (!factor) {
                        return (
                          <td key={catName} className="p-3 border-b border-gray-200 text-center">
                            <div className="w-16 h-16 mx-auto bg-gray-100 rounded flex items-center justify-center text-gray-400 text-xs">
                              N/A
                            </div>
                          </td>
                        );
                      }

                      const score = parseFloat(factor.score);
                      const color = getRiskColor(score);

                      return (
                        <td key={catName} className="p-3 border-b border-gray-200 text-center">
                          <button
                            onClick={() => setSelectedCell(factor)}
                            className="w-16 h-16 mx-auto rounded hover:opacity-80 transition-opacity flex flex-col items-center justify-center text-white font-bold shadow-sm"
                            style={{ backgroundColor: color }}
                          >
                            <span className="text-lg">{score.toFixed(0)}</span>
                            <span className="text-[10px] opacity-90">n={factor.count}</span>
                          </button>
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Legenda */}
          <div className="mt-6 flex items-center justify-center gap-6 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded" style={{ backgroundColor: '#10b981' }}></div>
              <span>🟢 Baixo (&lt;35)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded" style={{ backgroundColor: '#f59e0b' }}></div>
              <span>🟠 Médio (35-60)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded" style={{ backgroundColor: '#ef4444' }}></div>
              <span>🔴 Alto (&gt;60)</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Top 5 Fatores Críticos */}
      <Card className="shadow-md">
        <CardHeader>
          <CardTitle>Top 5 Fatores Críticos</CardTitle>
        </CardHeader>
        <CardContent>
          {topFactors.length > 0 ? (
            <ResponsiveContainer width="100%" height={350}>
              <BarChart data={topFactors} layout="horizontal">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" domain={[0, 100]} />
                <YAxis type="category" dataKey="name" width={150} tick={{ fontSize: 12 }} />
                <RechartsTooltip 
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      return (
                        <div className="bg-white p-3 border rounded shadow-lg">
                          <p className="font-semibold">{payload[0].payload.name}</p>
                          <p className="text-sm">Score: {payload[0].value.toFixed(1)}</p>
                          <p className="text-sm">Nível: {payload[0].payload.level}</p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar dataKey="score" radius={[0, 8, 8, 0]}>
                  {topFactors.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={getRiskColor(entry.score)} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[350px] flex items-center justify-center text-gray-400">
              Aguardando dados
            </div>
          )}
        </CardContent>
      </Card>

      {/* Sheet de detalhes */}
      <Sheet open={!!selectedCell} onOpenChange={() => setSelectedCell(null)}>
        <SheetContent>
          {selectedCell && (
            <>
              <SheetHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <SheetTitle>{selectedCell.factor}</SheetTitle>
                    <SheetDescription>{selectedCell.department}</SheetDescription>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setSelectedCell(null)}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </SheetHeader>

              <div className="mt-6 space-y-4">
                <div className="p-4 rounded-lg" style={{ backgroundColor: '#EFE6F8' }}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium" style={{ color: '#5E2C91' }}>
                      Score de Risco
                    </span>
                    <Badge style={{ 
                      backgroundColor: getRiskColor(parseFloat(selectedCell.score)),
                      color: 'white'
                    }}>
                      {getRiskLabel(parseFloat(selectedCell.score))}
                    </Badge>
                  </div>
                  <p className="text-4xl font-bold" style={{ color: '#5E2C91' }}>
                    {selectedCell.score}
                  </p>
                  <p className="text-xs text-gray-600 mt-2">
                    Baseado em {selectedCell.count} respostas
                  </p>
                </div>

                <div className="p-4 bg-gray-50 rounded-lg">
                  <p className="text-sm text-gray-600">
                    <strong>Score PRIMA Original:</strong> {selectedCell.rawAvg} (escala 1-5)
                  </p>
                </div>

                <div className="p-4 bg-blue-50 rounded-lg">
                  <p className="text-sm font-semibold text-blue-900 mb-2">
                    Interpretação:
                  </p>
                  <p className="text-sm text-blue-800">
                    {parseFloat(selectedCell.score) >= 60 
                      ? 'Risco alto identificado. Requer ação imediata e inclusão no PGR.' 
                      : parseFloat(selectedCell.score) >= 35
                      ? 'Risco moderado. Monitorar e implementar melhorias preventivas.'
                      : 'Risco baixo. Manter controles atuais e monitoramento periódico.'}
                  </p>
                </div>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}