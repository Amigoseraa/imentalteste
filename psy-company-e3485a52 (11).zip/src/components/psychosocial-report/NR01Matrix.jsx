import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet";
import { X, AlertTriangle } from "lucide-react";

const RISK_FACTORS = [
  {
    id: 'demands',
    name: 'Demandas de Trabalho',
    effect: 'Estresse, fadiga, burnout',
    baseProbability: 4,
    baseSeverity: 4
  },
  {
    id: 'control',
    name: 'Baixo Controle/Autonomia',
    effect: 'Desmotivação, frustração, impotência',
    baseProbability: 3,
    baseSeverity: 3
  },
  {
    id: 'support',
    name: 'Falta de Suporte Social',
    effect: 'Isolamento, insegurança, ansiedade',
    baseProbability: 3,
    baseSeverity: 3
  },
  {
    id: 'recognition',
    name: 'Baixo Reconhecimento',
    effect: 'Desmotivação, baixa autoestima, insatisfação',
    baseProbability: 3,
    baseSeverity: 2
  },
  {
    id: 'conflict',
    name: 'Conflito Trabalho-Família',
    effect: 'Exaustão, absenteísmo, conflitos pessoais',
    baseProbability: 4,
    baseSeverity: 4
  },
  {
    id: 'communication',
    name: 'Comunicação Deficiente',
    effect: 'Erros, retrabalho, conflitos',
    baseProbability: 3,
    baseSeverity: 2
  },
  {
    id: 'environment',
    name: 'Ambiente Físico Inadequado',
    effect: 'Desconforto, fadiga, doenças ocupacionais',
    baseProbability: 2,
    baseSeverity: 3
  },
  {
    id: 'roles',
    name: 'Conflito/Ambiguidade de Papéis',
    effect: 'Confusão, estresse, ineficiência',
    baseProbability: 3,
    baseSeverity: 3
  },
  {
    id: 'career',
    name: 'Baixas Perspectivas de Carreira',
    effect: 'Desmotivação, turnover, estagnação',
    baseProbability: 3,
    baseSeverity: 2
  },
  {
    id: 'schedule',
    name: 'Jornadas Excessivas/Irregulares',
    effect: 'Fadiga, problemas de saúde, acidentes',
    baseProbability: 4,
    baseSeverity: 4
  }
];

const RECOMMENDED_ACTIONS = {
  'demands': 'Reavaliar carga e prazos, balanceamento de tarefas, pausas programadas',
  'control': 'Aumentar autonomia decisória, job crafting, delegação efetiva',
  'support': 'Treinamento de lideranças, programas de mentoria, canais de apoio',
  'recognition': 'Programa de reconhecimento, feedback estruturado, celebrações',
  'conflict': 'Política de desconexão, flexibilidade de horários, apoio familiar',
  'communication': 'Reuniões estruturadas, canais claros, transparência organizacional',
  'environment': 'Melhorias ergonômicas, climatização, redução de ruído',
  'roles': 'Matriz RACI, definição clara de responsabilidades, alinhamento',
  'career': 'Planos de desenvolvimento, trilhas de carreira, promoções',
  'schedule': 'Gestão de jornada, banco de horas, turnos equilibrados'
};

export default function NR01Matrix({ assessments, departments }) {
  const [selectedFactor, setSelectedFactor] = useState(null);
  const [editedValues, setEditedValues] = useState({});

  const calculateRiskLevel = (probability, severity) => {
    const riskValue = probability * severity;
    
    if (riskValue >= 16) return { label: '🔴 Alto', color: '#ef4444', value: riskValue };
    if (riskValue >= 9) return { label: '🟠 Médio', color: '#f59e0b', value: riskValue };
    return { label: '🟢 Baixo', color: '#10b981', value: riskValue };
  };

  const handleEdit = (factorId, field, value) => {
    setEditedValues(prev => ({
      ...prev,
      [factorId]: {
        ...prev[factorId],
        [field]: parseInt(value)
      }
    }));
  };

  const enrichedFactors = RISK_FACTORS.map(factor => {
    const edited = editedValues[factor.id] || {};
    const probability = edited.probability || factor.baseProbability;
    const severity = edited.severity || factor.baseSeverity;
    const risk = calculateRiskLevel(probability, severity);

    return {
      ...factor,
      probability,
      severity,
      riskValue: risk.value,
      riskLabel: risk.label,
      riskColor: risk.color,
      action: RECOMMENDED_ACTIONS[factor.id]
    };
  });

  // Ordenar por nível de risco
  const sortedFactors = [...enrichedFactors].sort((a, b) => b.riskValue - a.riskValue);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold" style={{ color: '#2B2240' }}>
        🧩 Matriz NR-01 de Perigos e Riscos
      </h2>

      <Card className="shadow-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-orange-600" />
            Avaliação de Riscos Psicossociais
            <Badge variant="outline" className="text-xs">
              Conforme NR-01
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Fator Psicossocial</TableHead>
                  <TableHead>Efeito Potencial</TableHead>
                  <TableHead className="text-center">Probabilidade</TableHead>
                  <TableHead className="text-center">Severidade</TableHead>
                  <TableHead className="text-center">Nível de Risco</TableHead>
                  <TableHead className="text-center">Classificação</TableHead>
                  <TableHead>Ação Recomendada</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sortedFactors.map((factor) => (
                  <TableRow 
                    key={factor.id}
                    className="hover:bg-gray-50 cursor-pointer"
                    onClick={() => setSelectedFactor(factor)}
                  >
                    <TableCell className="font-medium">{factor.name}</TableCell>
                    <TableCell className="text-sm text-gray-600">{factor.effect}</TableCell>
                    <TableCell className="text-center">
                      <Badge variant="outline">{factor.probability}</Badge>
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge variant="outline">{factor.severity}</Badge>
                    </TableCell>
                    <TableCell className="text-center font-bold">
                      {factor.riskValue}
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge style={{ 
                        backgroundColor: factor.riskColor,
                        color: 'white'
                      }}>
                        {factor.riskLabel}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm text-gray-700 max-w-xs">
                      {factor.action}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {/* Legenda */}
          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <p className="text-sm font-semibold text-gray-700 mb-3">Escala de Avaliação:</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div>
                <p className="font-medium mb-2">Probabilidade:</p>
                <ul className="space-y-1 text-gray-600">
                  <li>1 - Raro (improvável)</li>
                  <li>2 - Pouco provável</li>
                  <li>3 - Provável</li>
                  <li>4 - Muito provável</li>
                  <li>5 - Certo (quase sempre)</li>
                </ul>
              </div>
              <div>
                <p className="font-medium mb-2">Severidade:</p>
                <ul className="space-y-1 text-gray-600">
                  <li>1 - Insignificante</li>
                  <li>2 - Menor</li>
                  <li>3 - Moderada</li>
                  <li>4 - Grave</li>
                  <li>5 - Catastrófica</li>
                </ul>
              </div>
            </div>
            <div className="mt-4">
              <p className="font-medium mb-2">Nível de Risco (Prob × Sev):</p>
              <div className="flex items-center gap-4 text-gray-600">
                <span>🟢 1-8: Baixo</span>
                <span>🟠 9-15: Médio</span>
                <span>🔴 16-25: Alto</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Sheet de detalhes */}
      <Sheet open={!!selectedFactor} onOpenChange={() => setSelectedFactor(null)}>
        <SheetContent className="w-full sm:max-w-2xl overflow-y-auto">
          {selectedFactor && (
            <>
              <SheetHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <SheetTitle>{selectedFactor.name}</SheetTitle>
                    <SheetDescription>{selectedFactor.effect}</SheetDescription>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setSelectedFactor(null)}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </SheetHeader>

              <div className="mt-6 space-y-6">
                {/* Avaliação de Risco */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Avaliação de Risco</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium text-gray-700 mb-2 block">
                          Probabilidade
                        </label>
                        <input
                          type="number"
                          min="1"
                          max="5"
                          value={selectedFactor.probability}
                          onChange={(e) => handleEdit(selectedFactor.id, 'probability', e.target.value)}
                          className="w-full p-2 border rounded"
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium text-gray-700 mb-2 block">
                          Severidade
                        </label>
                        <input
                          type="number"
                          min="1"
                          max="5"
                          value={selectedFactor.severity}
                          onChange={(e) => handleEdit(selectedFactor.id, 'severity', e.target.value)}
                          className="w-full p-2 border rounded"
                        />
                      </div>
                    </div>

                    <div className="p-4 rounded-lg" style={{ backgroundColor: selectedFactor.riskColor + '20' }}>
                      <p className="text-sm font-medium mb-2">Nível de Risco Calculado:</p>
                      <p className="text-3xl font-bold" style={{ color: selectedFactor.riskColor }}>
                        {selectedFactor.riskValue} - {selectedFactor.riskLabel}
                      </p>
                    </div>
                  </CardContent>
                </Card>

                {/* Ações Recomendadas */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Ações Recomendadas</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-700">
                      {selectedFactor.action}
                    </p>
                  </CardContent>
                </Card>

                {/* Botão Criar Plano de Ação */}
                <Button 
                  className="w-full"
                  size="lg"
                  style={{ backgroundColor: '#5E2C91' }}
                >
                  Criar Plano de Ação
                </Button>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}