import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, ArrowRight, Volume2, Save } from "lucide-react";

export default function QuestionScreen({ 
  question, 
  questionnaire, 
  currentQuestion, 
  totalQuestions,
  progress,
  onAnswer, 
  onPrevious, 
  canGoPrevious,
  assessmentName
}) {
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [showError, setShowError] = useState(false);

  const handleNext = () => {
    if (selectedAnswer !== null) {
      onAnswer(selectedAnswer);
      setSelectedAnswer(null);
      setShowError(false);
    } else {
      setShowError(true);
    }
  };

  const handleSpeak = () => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(question.text);
      utterance.lang = 'pt-BR';
      window.speechSynthesis.speak(utterance);
    }
  };

  // Texto introdutório para cada questionário
  const getIntroText = () => {
    if (questionnaire === 'PHQ-9') {
      return 'Nas últimas 2 semanas, com que frequência você foi incomodado pelos seguintes problemas?';
    }
    if (questionnaire === 'GAD-7') {
      return 'Nas últimas 2 semanas, com que frequência você foi incomodado pelos seguintes problemas?';
    }
    if (questionnaire === 'PRIMA-EF') {
      return 'Avalie as seguintes afirmações sobre seu ambiente de trabalho:';
    }
    return null;
  };

  const introText = getIntroText();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-gray-100">
      {/* Header fixo */}
      <div className="bg-white shadow-sm sticky top-0 z-10">
        <div className="max-w-4xl mx-auto p-4">
          <div className="flex items-center justify-between mb-3">
            <div>
              <p className="text-sm font-medium text-gray-600">{assessmentName}</p>
              <p className="text-xs text-gray-500">Pergunta {currentQuestion} de {totalQuestions}</p>
            </div>
            <Button variant="ghost" size="sm" onClick={handleSpeak} title="Ouvir pergunta">
              <Volume2 className="w-4 h-4" />
            </Button>
          </div>
          <Progress value={progress} className="h-2" />
        </div>
      </div>

      {/* Conteúdo */}
      <div className="max-w-4xl mx-auto p-4 py-8">
        <Card className="shadow-xl">
          <CardContent className="p-6 md:p-10">
            <div className="mb-6">
              <Badge className="bg-blue-600 mb-4">{questionnaire}</Badge>
              {question.category && (
                <Badge variant="outline" className="ml-2 mb-4">{question.category}</Badge>
              )}
              
              {/* Texto introdutório fixo */}
              {introText && (
                <div className="mb-4 p-3 bg-blue-50 rounded-lg border border-blue-100">
                  <p className="text-sm text-gray-700 leading-relaxed">
                    {introText}
                  </p>
                </div>
              )}
              
              <h2 className="text-2xl md:text-3xl font-semibold text-gray-900 leading-relaxed">
                {question.text}
              </h2>
            </div>

            <div className="space-y-3 mb-8">
              {question.scale.map((option) => (
                <button
                  key={option.value}
                  onClick={() => {
                    setSelectedAnswer(option.value);
                    setShowError(false);
                  }}
                  className={`w-full p-5 md:p-6 text-left rounded-xl border-2 transition-all ${
                    selectedAnswer === option.value
                      ? 'border-blue-600 bg-blue-50 shadow-md scale-[1.02]'
                      : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  <div className="flex items-center gap-4">
                    <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${
                      selectedAnswer === option.value
                        ? 'border-blue-600 bg-blue-600'
                        : 'border-gray-300'
                    }`}>
                      {selectedAnswer === option.value && (
                        <div className="w-3 h-3 bg-white rounded-full" />
                      )}
                    </div>
                    <span className="text-lg font-medium text-gray-900">{option.label}</span>
                  </div>
                </button>
              ))}
            </div>

            {showError && (
              <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-red-800 text-sm font-medium">
                  Por favor, selecione uma resposta para continuar
                </p>
              </div>
            )}

            <div className="flex gap-3">
              {canGoPrevious && (
                <Button
                  variant="outline"
                  onClick={onPrevious}
                  className="flex-1 h-12 text-base"
                >
                  <ArrowLeft className="w-5 h-5 mr-2" />
                  Voltar
                </Button>
              )}
              <Button
                onClick={handleNext}
                className={`${canGoPrevious ? 'flex-1' : 'w-full'} bg-blue-600 hover:bg-blue-700 h-12 text-base font-semibold`}
              >
                Próxima
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </div>

            <p className="text-sm text-gray-500 text-center mt-4">
              <Save className="w-3 h-3 inline mr-1" />
              Suas respostas são salvas automaticamente
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}