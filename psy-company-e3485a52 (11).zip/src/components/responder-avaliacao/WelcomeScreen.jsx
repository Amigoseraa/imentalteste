
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Heart, Clock, Shield } from "lucide-react";

import IMentalLogo from "../ui/IMentalLogo";

export default function WelcomeScreen({ assessment, questionnaires, company, onStart }) {
  const getEstimatedTime = () => {
    const count = questionnaires.length;
    return `${count * 3}-${count * 5} min`;
  };

  const getQuestionnaireInfo = (type) => {
    const info = {
      'PHQ-9': { name: 'PHQ-9', desc: 'Sintomas Depressivos', color: 'bg-purple-100 text-purple-800' },
      'GAD-7': { name: 'GAD-7', desc: 'Sintomas de Ansiedade', color: 'bg-blue-100 text-blue-800' },
      'PRIMA-EF': { name: 'PRIMA-EF', desc: 'Riscos Psicossociais', color: 'bg-green-100 text-green-800' },
      'HSE-IT': { name: 'HSE-IT', desc: 'Indicador HSE', color: 'bg-yellow-100 text-yellow-800' },
      'JCQ': { name: 'JCQ', desc: 'Conteúdo do Trabalho', color: 'bg-orange-100 text-orange-800' }
    };
    return info[type] || { name: type, desc: '', color: 'bg-gray-100 text-gray-800' };
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-gray-100 flex items-center justify-center p-4">
      <Card className="max-w-2xl w-full shadow-xl">
        <CardContent className="p-8 md:p-12">
          <div className="text-center mb-8">
            <div className="mb-6">
              <IMentalLogo variant="dark" size="large" className="mx-auto" />
            </div>
            <h1 className="text-3xl font-bold mb-3" style={{ color: '#2E2E2E' }}>
              {assessment.assessment_name || 'Avaliação de Bem-Estar'}
            </h1>
            <p className="text-lg text-gray-600 leading-relaxed">
              Obrigado por participar! Suas respostas são <strong>100% confidenciais</strong> e ajudam a melhorar o ambiente de trabalho.
            </p>
          </div>

          <div className="space-y-6 mb-8">
            <div className="flex items-center gap-3 p-4 bg-blue-50 rounded-lg">
              <Clock className="w-6 h-6 text-blue-600 flex-shrink-0" />
              <div>
                <p className="font-semibold text-gray-900">Tempo estimado</p>
                <p className="text-sm text-gray-600">{getEstimatedTime()}</p>
              </div>
            </div>

            <div className="p-4 bg-gray-50 rounded-lg">
              <p className="font-semibold text-gray-900 mb-3">Questionários incluídos:</p>
              <div className="flex flex-wrap gap-2">
                {questionnaires.map((type, idx) => {
                  const info = getQuestionnaireInfo(type);
                  return (
                    <Badge key={idx} className={info.color}>
                      {info.name}
                    </Badge>
                  );
                })}
              </div>
            </div>

            <div className="flex items-start gap-3 p-4 bg-green-50 rounded-lg">
              <Shield className="w-6 h-6 text-green-600 flex-shrink-0 mt-1" />
              <div>
                <p className="font-semibold text-gray-900 mb-1">Privacidade garantida</p>
                <p className="text-sm text-gray-600">
                  Suas respostas individuais não serão compartilhadas. Os dados são usados apenas de forma agregada.
                </p>
              </div>
            </div>
          </div>

          <Button
            onClick={onStart}
            className="w-full bg-blue-600 hover:bg-blue-700 h-14 text-lg font-semibold"
          >
            Iniciar Avaliação
          </Button>

          <p className="text-sm text-gray-500 text-center mt-4">
            Você pode pausar e retomar a qualquer momento
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
