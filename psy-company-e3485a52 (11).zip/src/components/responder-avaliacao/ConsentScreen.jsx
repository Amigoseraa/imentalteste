
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Shield, CheckCircle, X } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";

import IMentalLogo from "../ui/IMentalLogo"; // Added import

export default function ConsentScreen({ company, onAccept, onDecline, loading }) {
  const [accepted, setAccepted] = useState(false);
  const [showDeclineModal, setShowDeclineModal] = useState(false);

  const handleAccept = () => {
    if (!accepted) {
      return;
    }
    onAccept();
  };

  const handleDeclineConfirm = () => {
    setShowDeclineModal(false);
    onDecline();
  };

  return (
    <>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-gray-100 p-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-6">
            <IMentalLogo variant="dark" size="large" className="mx-auto" />
          </div>
          
          <Card className="shadow-xl">
            <CardHeader className="border-b text-white" style={{ background: 'linear-gradient(90deg, #4B2672 0%, #A57CE0 100%)' }}>
              <div className="flex items-center gap-3">
                <Shield className="w-8 h-8" />
                <div>
                  <CardTitle className="text-2xl">Termo de Consentimento</CardTitle>
                  <p className="text-sm mt-1" style={{ color: '#F8F6FB' }}>{company?.name || 'Plataforma iMental'}</p>
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="p-0">
              <div 
                className="p-6 md:p-8 max-h-[60vh] overflow-y-auto space-y-6 text-gray-700 leading-relaxed"
                style={{ fontSize: '16px', lineHeight: '1.6' }}
              >
                <section>
                  <h3 className="font-bold text-lg text-gray-900 mb-2">1. Finalidade da Avaliação</h3>
                  <p>
                    Esta avaliação faz parte do programa de Saúde Mental e Riscos Psicossociais.
                    O objetivo é identificar, de forma anônima e estatística, fatores que impactam o bem-estar e o ambiente de trabalho.
                  </p>
                </section>

                <section>
                  <h3 className="font-bold text-lg text-gray-900 mb-2">2. Confidencialidade e Privacidade</h3>
                  <p>
                    Todas as respostas são confidenciais e tratadas de forma agregada, sem qualquer identificação pessoal.
                    Nenhuma resposta individual é acessível por gestores, líderes ou colegas.
                  </p>
                </section>

                <section>
                  <h3 className="font-bold text-lg text-gray-900 mb-2">3. Voluntariedade</h3>
                  <p>
                    A participação é voluntária. Você pode deixar perguntas em branco ou sair a qualquer momento, sem prejuízo profissional.
                  </p>
                </section>

                <section>
                  <h3 className="font-bold text-lg text-gray-900 mb-2">4. Tratamento de Dados (LGPD)</h3>
                  <p>
                    Seus dados serão tratados conforme a Lei Geral de Proteção de Dados (LGPD - Lei nº 13.709/2018).
                    Não armazenamos dados pessoais identificáveis nas respostas das avaliações.
                  </p>
                </section>

                <section>
                  <h3 className="font-bold text-lg text-gray-900 mb-2">5. Uso dos Resultados</h3>
                  <p>
                    Os resultados agregados serão utilizados para:
                  </p>
                  <ul className="list-disc list-inside ml-4 mt-2 space-y-1">
                    <li>Identificar áreas de melhoria no ambiente de trabalho</li>
                    <li>Desenvolver programas de bem-estar e saúde mental</li>
                    <li>Promover políticas organizacionais mais saudáveis</li>
                  </ul>
                </section>

                <section>
                  <h3 className="font-bold text-lg text-gray-900 mb-2">6. Direito de Recusa</h3>
                  <p>
                    Você tem o direito de não participar ou de interromper a avaliação a qualquer momento, sem necessidade de justificativa.
                  </p>
                </section>

                <section>
                  <h3 className="font-bold text-lg text-gray-900 mb-2">7. Contato</h3>
                  <p>
                    Em caso de dúvidas sobre esta avaliação ou sobre o tratamento de seus dados, entre em contato com o RH da empresa ou com o responsável pela plataforma.
                  </p>
                </section>

                <section className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                  <p className="text-blue-900 font-medium">
                    ✓ Ao prosseguir, você declara ter lido e compreendido este termo, e concorda voluntariamente em participar da avaliação.
                  </p>
                </section>
              </div>

              <div className="border-t bg-gray-50 p-6 sticky bottom-0">
                <div className="flex items-start gap-3 mb-6">
                  <Checkbox
                    id="consent"
                    checked={accepted}
                    onCheckedChange={setAccepted}
                  />
                  <label 
                    htmlFor="consent" 
                    className="text-base font-medium leading-relaxed cursor-pointer select-none"
                  >
                    Li e concordo com os Termos e Condições de Participação
                  </label>
                </div>

                <div className="flex gap-3 justify-between items-center">
                  <Button
                    onClick={handleAccept}
                    disabled={!accepted || loading}
                    className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed h-12 px-8 text-base font-semibold min-w-[220px]"
                  >
                    {loading ? (
                      <>
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                        Iniciando avaliação...
                      </>
                    ) : (
                      <>
                        <CheckCircle className="w-5 h-5 mr-2" />
                        Concordo e Iniciar
                      </>
                    )}
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowDeclineModal(true)}
                    disabled={loading}
                    className="text-gray-600 hover:text-gray-900 hover:bg-gray-100"
                  >
                    Não concordo
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Dialog open={showDeclineModal} onOpenChange={setShowDeclineModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <X className="w-5 h-5 text-orange-600" />
              Tem certeza?
            </DialogTitle>
            <DialogDescription className="text-base mt-4">
              Tem certeza de que não deseja participar agora?
              <br />
              <br />
              Você pode responder mais tarde, sem qualquer prejuízo.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex gap-3">
            <Button
              variant="outline"
              onClick={() => setShowDeclineModal(false)}
              className="flex-1"
            >
              Cancelar
            </Button>
            <Button
              variant="secondary"
              onClick={handleDeclineConfirm}
              className="flex-1"
            >
              Confirmar não concordo
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
