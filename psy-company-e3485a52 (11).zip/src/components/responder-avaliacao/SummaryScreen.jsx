import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, ArrowLeft, Send } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";

export default function SummaryScreen({ assessment, questionnaires, onSubmit, onGoBack, loading }) {
  const [showConfirm, setShowConfirm] = useState(false);

  const getQuestionnaireInfo = (type) => {
    const info = {
      'PHQ-9': { name: 'PHQ-9', desc: 'Sintomas Depressivos', color: 'bg-purple-100 text-purple-800' },
      'GAD-7': { name: 'GAD-7', desc: 'Sintomas de Ansiedade', color: 'bg-blue-100 text-blue-800' },
      'PRIMA-EF': { name: 'PRIMA-EF', desc: 'Riscos Psicossociais', color: 'bg-green-100 text-green-800' },
      'HSE-IT': { name: 'HSE-IT', desc: 'Indicador HSE', color: 'bg-yellow-100 text-yellow-800' },
      'JCQ': { name: 'JCQ', desc: 'Conteúdo do Trabalho', color: 'bg-orange-100 text-orange-800' }
    };
    return info[type] || { name: type, desc: '', color: 'bg-gray-100 text-gray-800' };
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-gray-100 flex items-center justify-center p-4">
      <Card className="max-w-2xl w-full shadow-xl">
        <CardContent className="p-8 md:p-12">
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-3">
              Você chegou ao fim! 🎉
            </h1>
            <p className="text-lg text-gray-600">
              Revise abaixo os questionários completados antes de enviar
            </p>
          </div>

          <div className="space-y-4 mb-8">
            {questionnaires.map((type, idx) => {
              const info = getQuestionnaireInfo(type);
              return (
                <div key={idx} className="flex items-center gap-3 p-4 bg-white rounded-lg border-2 border-gray-200">
                  <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="font-semibold text-gray-900">{info.name}</p>
                    <p className="text-sm text-gray-600">{info.desc}</p>
                  </div>
                  <Badge className={info.color}>Completo</Badge>
                </div>
              );
            })}
          </div>

          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={onGoBack}
              className="flex-1 h-12"
              disabled={loading}
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Revisar
            </Button>
            <Button
              onClick={() => setShowConfirm(true)}
              className="flex-1 bg-blue-600 hover:bg-blue-700 h-12 font-semibold"
              disabled={loading}
            >
              <Send className="w-5 h-5 mr-2" />
              Enviar Respostas
            </Button>
          </div>

          <p className="text-sm text-gray-500 text-center mt-4">
            Após o envio, não será possível editar suas respostas
          </p>
        </CardContent>
      </Card>

      <Dialog open={showConfirm} onOpenChange={setShowConfirm}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmar envio</DialogTitle>
            <DialogDescription>
              Tem certeza de que deseja enviar suas respostas? Após o envio, não será possível fazer alterações.
            </DialogDescription>
          </DialogHeader>
          <div className="flex gap-3 mt-4">
            <Button variant="outline" onClick={() => setShowConfirm(false)} className="flex-1">
              Cancelar
            </Button>
            <Button 
              onClick={() => {
                setShowConfirm(false);
                onSubmit();
              }} 
              className="flex-1 bg-blue-600 hover:bg-blue-700"
              disabled={loading}
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Enviando...
                </>
              ) : (
                'Sim, enviar'
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}