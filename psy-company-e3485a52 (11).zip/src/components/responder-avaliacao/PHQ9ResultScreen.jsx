import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { TrendingUp, AlertTriangle, ArrowRight, BookOpen } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function PHQ9ResultScreen({ score, hasQuestion9Risk, onContinue }) {
  const getInterpretation = () => {
    if (score <= 4) {
      return {
        severity: 'Nenhum / Mínimo',
        color: 'bg-green-100 text-green-800 border-green-200',
        action: 'Nenhum tratamento necessário',
        bgColor: 'bg-green-50'
      };
    }
    if (score <= 9) {
      return {
        severity: 'Leve',
        color: 'bg-blue-100 text-blue-800 border-blue-200',
        action: 'Espera vigilante; repetir PHQ-9 no acompanhamento',
        bgColor: 'bg-blue-50'
      };
    }
    if (score <= 14) {
      return {
        severity: 'Moderado',
        color: 'bg-yellow-100 text-yellow-800 border-yellow-200',
        action: 'Considerar aconselhamento, acompanhamento e/ou farmacoterapia',
        bgColor: 'bg-yellow-50'
      };
    }
    if (score <= 19) {
      return {
        severity: 'Moderadamente Grave',
        color: 'bg-orange-100 text-orange-800 border-orange-200',
        action: 'Tratamento ativo com farmacoterapia e/ou psicoterapia',
        bgColor: 'bg-orange-50'
      };
    }
    return {
      severity: 'Grave',
      color: 'bg-red-100 text-red-800 border-red-200',
      action: 'Início imediato de farmacoterapia e/ou encaminhamento rápido a especialista em saúde mental',
      bgColor: 'bg-red-50'
    };
  };

  const interpretation = getInterpretation();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-gray-100 flex items-center justify-center p-4">
      <div className="max-w-4xl w-full space-y-6">
        {/* Alerta de Risco de Suicídio */}
        {hasQuestion9Risk && (
          <Alert className="bg-red-50 border-2 border-red-300 shadow-lg">
            <AlertTriangle className="w-6 h-6 text-red-600" />
            <AlertDescription className="ml-2">
              <p className="font-bold text-red-900 text-lg mb-2">⚠️ Atenção</p>
              <p className="text-red-800 mb-3">
                Sua resposta indica a presença de pensamentos sobre morte ou autoagressão.
                Este resultado não significa diagnóstico, mas requer avaliação profissional.
              </p>
              <p className="text-red-800 font-semibold">
                Caso esteja se sentindo em risco, procure imediatamente apoio médico ou psicológico, 
                ou entre em contato com um serviço de emergência:
              </p>
              <ul className="mt-2 space-y-1 text-red-800">
                <li className="font-bold">• SAMU – 192</li>
                <li className="font-bold">• CVV (Centro de Valorização da Vida) – 188</li>
                <li className="font-bold">• UPA ou hospital mais próximo</li>
              </ul>
            </AlertDescription>
          </Alert>
        )}

        {/* Card de Interpretação */}
        <Card className="shadow-xl">
          <CardHeader className="border-b bg-gradient-to-r from-blue-600 to-blue-700 text-white">
            <div className="flex items-center gap-3">
              <TrendingUp className="w-8 h-8" />
              <div>
                <CardTitle className="text-2xl">Interpretação dos Resultados – PHQ-9</CardTitle>
                <p className="text-blue-100 text-sm mt-1">Questionário de Saúde do Paciente-9</p>
              </div>
            </div>
          </CardHeader>

          <CardContent className="p-6 md:p-8 space-y-6">
            {/* Pontuação Total */}
            <div className={`p-6 rounded-xl ${interpretation.bgColor} border-2 ${interpretation.color.replace('text-', 'border-').replace('100', '200')}`}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-lg font-semibold text-gray-700">Pontuação Total:</span>
                <Badge className={`text-2xl font-bold px-4 py-2 ${interpretation.color}`}>
                  {score} / 27
                </Badge>
              </div>
              <div className="mt-4">
                <p className="text-sm text-gray-600 mb-1">Gravidade da Depressão:</p>
                <p className="text-xl font-bold" style={{color: interpretation.color.includes('green') ? '#16a34a' : interpretation.color.includes('blue') ? '#2563eb' : interpretation.color.includes('yellow') ? '#ca8a04' : interpretation.color.includes('orange') ? '#ea580c' : '#dc2626'}}>
                  {interpretation.severity}
                </p>
              </div>
            </div>

            {/* Tabela de Interpretação */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">📊 Tabela de Interpretação Completa</h3>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="bg-gray-100">
                      <th className="border border-gray-300 p-3 text-left text-sm font-semibold">Pontuação Total</th>
                      <th className="border border-gray-300 p-3 text-left text-sm font-semibold">Gravidade da Depressão</th>
                      <th className="border border-gray-300 p-3 text-left text-sm font-semibold">Ações de Tratamento Propostas</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className={score <= 4 ? 'bg-green-50' : ''}>
                      <td className="border border-gray-300 p-3 text-sm">0 – 4</td>
                      <td className="border border-gray-300 p-3 text-sm font-medium">Nenhum / Mínimo</td>
                      <td className="border border-gray-300 p-3 text-sm">Nenhum tratamento necessário</td>
                    </tr>
                    <tr className={score >= 5 && score <= 9 ? 'bg-blue-50' : ''}>
                      <td className="border border-gray-300 p-3 text-sm">5 – 9</td>
                      <td className="border border-gray-300 p-3 text-sm font-medium">Leve</td>
                      <td className="border border-gray-300 p-3 text-sm">Espera vigilante; repetir PHQ-9 no acompanhamento</td>
                    </tr>
                    <tr className={score >= 10 && score <= 14 ? 'bg-yellow-50' : ''}>
                      <td className="border border-gray-300 p-3 text-sm">10 – 14</td>
                      <td className="border border-gray-300 p-3 text-sm font-medium">Moderado</td>
                      <td className="border border-gray-300 p-3 text-sm">Considerar aconselhamento, acompanhamento e/ou farmacoterapia</td>
                    </tr>
                    <tr className={score >= 15 && score <= 19 ? 'bg-orange-50' : ''}>
                      <td className="border border-gray-300 p-3 text-sm">15 – 19</td>
                      <td className="border border-gray-300 p-3 text-sm font-medium">Moderadamente Grave</td>
                      <td className="border border-gray-300 p-3 text-sm">Tratamento ativo com farmacoterapia e/ou psicoterapia</td>
                    </tr>
                    <tr className={score >= 20 ? 'bg-red-50' : ''}>
                      <td className="border border-gray-300 p-3 text-sm">20 – 27</td>
                      <td className="border border-gray-300 p-3 text-sm font-medium">Grave</td>
                      <td className="border border-gray-300 p-3 text-sm">Início imediato de farmacoterapia e/ou encaminhamento rápido a especialista em saúde mental</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <p className="text-sm text-gray-600 mt-3 italic">
                <strong>Observação:</strong> Pontuações totais de 5, 10, 15 e 20 representam pontos de corte para depressão leve, moderada, moderadamente grave e grave, respectivamente.
              </p>
            </div>

            {/* Mensagem de Conclusão */}
            <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
              <p className="text-blue-900 text-center">
                <strong>Obrigado por responder!</strong> Suas respostas ajudam a monitorar a saúde emocional e serão analisadas de forma confidencial.
              </p>
            </div>

            {/* Fontes */}
            <div className="border-t pt-6">
              <h4 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                <BookOpen className="w-4 h-4" />
                📚 Fontes
              </h4>
              <div className="space-y-2 text-xs text-gray-600 leading-relaxed">
                <p>• Kroenke K, Spitzer RL, Williams JB. <em>Questionário de Saúde do Paciente-2: Validade de um Rastreador de Depressão de Dois Itens.</em> Assistência Médica. 2003;41:1284-92.</p>
                <p>• Kroenke K, Spitzer RL, Williams JB. <em>PHQ-9: validade de uma medida breve de gravidade da depressão.</em> J Gen Intern Med. 2001;16:606-13.</p>
                <p>• Kroenke K, Spitzer RL. <em>PHQ-9: uma nova medida diagnóstica e de gravidade da depressão.</em> Psychiatr Ann. 2002;32:509-21.</p>
              </div>
            </div>

            {/* Botão de Continuar */}
            <div className="pt-4">
              <Button
                onClick={onContinue}
                className="w-full bg-blue-600 hover:bg-blue-700 h-12 text-base font-semibold"
              >
                {hasQuestion9Risk ? 'Entendi' : 'Continuar'}
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}