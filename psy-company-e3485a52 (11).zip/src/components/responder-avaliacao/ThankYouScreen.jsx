import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle, Heart, Shield, ArrowLeft } from "lucide-react";

export default function ThankYouScreen({ company, onBackToAssessments }) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-gray-100 flex items-center justify-center p-4">
      <Card className="max-w-2xl w-full shadow-xl">
        <CardContent className="p-8 md:p-12 text-center">
          <div className="mb-8">
            <div className="w-24 h-24 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-12 h-12 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-3">
              Avaliação Concluída com Sucesso! 💚
            </h1>
            <p className="text-lg text-gray-600 leading-relaxed">
              Obrigado por contribuir para um ambiente de trabalho mais saudável e acolhedor
            </p>
          </div>

          <div className="bg-gray-50 rounded-xl p-6 mb-8">
            <p className="text-sm text-gray-600 mb-2">Enviado em:</p>
            <p className="text-lg font-semibold text-gray-900">
              {new Date().toLocaleDateString('pt-BR')} às {new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
            </p>
          </div>

          <div className="space-y-4 text-left bg-blue-50 rounded-xl p-6 mb-8">
            <div className="flex items-start gap-3">
              <Shield className="w-6 h-6 text-blue-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-semibold text-gray-900 mb-1">Suas respostas são confidenciais</h3>
                <p className="text-sm text-gray-600">
                  Nenhuma informação individual será compartilhada. Os dados são usados apenas para melhorias organizacionais.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Heart className="w-6 h-6 text-blue-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-semibold text-gray-900 mb-1">Apoio sempre disponível</h3>
                <p className="text-sm text-gray-600">
                  Se você estiver passando por dificuldades emocionais, não hesite em buscar ajuda profissional. 
                  CVV (188) disponível 24h.
                </p>
              </div>
            </div>
          </div>

          <Button
            onClick={onBackToAssessments}
            className="w-full bg-blue-600 hover:bg-blue-700 h-12 text-base font-semibold"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Voltar para Minhas Avaliações
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}