
import React, { useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CheckCircle, Heart, Shield, Lock, AlertTriangle } from "lucide-react";
import { motion } from "framer-motion";
import IMentalLogo from "../ui/IMentalLogo"; // Added import for IMentalLogo

export default function FeedbackConclusao({ company, hasQuestion9Risk, onReturn }) {
  const [countdown, setCountdown] = React.useState(3);

  useEffect(() => {
    // Redirecionamento automático após 3 segundos
    const countdownInterval = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          clearInterval(countdownInterval);
          onReturn();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(countdownInterval);
  }, [onReturn]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-gray-100 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="max-w-2xl w-full space-y-6"
      >
        {/* Alerta de risco (se aplicável) */}
        {hasQuestion9Risk && (
          <Alert className="bg-blue-50 border-2 border-blue-300 shadow-lg">
            <AlertTriangle className="w-6 h-6 text-blue-600" />
            <AlertDescription className="ml-2">
              <p className="font-bold text-blue-900 text-lg mb-2">💙 Você não está sozinho(a)</p>
              <p className="text-blue-800 mb-3">
                Caso esteja se sentindo sobrecarregado ou em sofrimento, procure apoio de um profissional de saúde mental 
                ou entre em contato com o CVV (188).
              </p>
              <p className="text-blue-800 font-semibold">
                Lembre-se: pedir ajuda é um ato de cuidado e coragem.
              </p>
            </AlertDescription>
          </Alert>
        )}

        {/* Card de Conclusão */}
        <Card className="shadow-xl">
          <CardContent className="p-8 md:p-12 text-center">
            {/* Added iMental Logo */}
            <div className="mb-6">
              <IMentalLogo variant="dark" size="default" className="mx-auto" />
            </div>

            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="mb-6"
            >
              {/* Changed background style for CheckCircle icon */}
              <div className="w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6" style={{ background: 'linear-gradient(135deg, #4B2672 0%, #A57CE0 100%)' }}>
                <CheckCircle className="w-12 h-12 text-white" />
              </div>
            </motion.div>

            {/* Changed h1 color */}
            <h1 className="text-3xl font-bold mb-3" style={{ color: '#2E2E2E' }}>
              Obrigado por participar! 💙
            </h1>
            <p className="text-lg text-gray-600 leading-relaxed mb-6">
              Sua colaboração ajuda a construir um ambiente de trabalho mais saudável e equilibrado.
            </p>
            <p className="text-base text-gray-600 leading-relaxed mb-8">
              Suas respostas são analisadas de forma confidencial e coletiva, sem identificação individual.
            </p>

            <div className="bg-gray-50 rounded-xl p-6 mb-6">
              <p className="text-sm text-gray-600 mb-2">Avaliação concluída em:</p>
              <p className="text-lg font-semibold text-gray-900">
                {new Date().toLocaleDateString('pt-BR')} às {new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>

            <div className="space-y-4 text-left bg-blue-50 rounded-xl p-6 mb-8">
              <div className="flex items-start gap-3">
                <Lock className="w-6 h-6 text-blue-600 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-gray-900 mb-1">Privacidade garantida</h3>
                  <p className="text-sm text-gray-600">
                    Seus dados são protegidos pela Lei Geral de Proteção de Dados (LGPD) e nunca são 
                    compartilhados com gestores ou colegas de forma individual.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Heart className="w-6 h-6 text-blue-600 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-gray-900 mb-1">Análise confidencial</h3>
                  <p className="text-sm text-gray-600">
                    Os resultados são analisados apenas por profissionais de saúde qualificados, 
                    de forma coletiva, para identificar oportunidades de melhoria organizacional.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Shield className="w-6 h-6 text-blue-600 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-gray-900 mb-1">Apoio disponível</h3>
                  <p className="text-sm text-gray-600">
                    Se você precisar de apoio emocional, não hesite em buscar ajuda profissional. 
                    CVV: 188 (disponível 24h).
                  </p>
                </div>
              </div>
            </div>

            <Button
              onClick={onReturn}
              className="w-full bg-blue-600 hover:bg-blue-700 h-12 text-base font-semibold mb-3"
            >
              Voltar para Minhas Avaliações
            </Button>

            <p className="text-sm text-gray-500">
              Redirecionando automaticamente em {countdown}s...
            </p>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
