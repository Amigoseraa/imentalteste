import React from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { CheckCircle, Clock, ExternalLink, User, Building2 } from "lucide-react";
import { format, parseISO } from "date-fns";
import { Button } from "@/components/ui/button";
import AssessmentDetailsModal from "./AssessmentDetailsModal";
import AssessmentLinkModal from "./AssessmentLinkModal";

const assessmentTypeLabels = {
  'PRIMA-EF': 'PRIMA-EF',
  'PHQ-9': 'PHQ-9',
  'GAD-7': 'GAD-7',
  'HSE-IT': 'HSE-IT',
  'JCQ': 'JCQ',
  'COMPLETE': 'Completa'
};

export default function AssessmentTable({ assessments, employees, departments, isLoading }) {
  const [selectedAssessment, setSelectedAssessment] = React.useState(null);
  const [showDetails, setShowDetails] = React.useState(false);
  const [showLink, setShowLink] = React.useState(false);

  const getEmployeeName = (employeeId) => {
    const employee = employees.find(e => e.id === employeeId);
    return employee?.name || 'Colaborador';
  };

  const getDepartmentName = (departmentId) => {
    const department = departments.find(d => d.id === departmentId);
    return department?.name || '-';
  };

  const formatAssessmentTypes = (type) => {
    if (!type) return '-';
    const types = type.split(',');
    return types.map(t => assessmentTypeLabels[t] || t).join(', ');
  };

  const handleViewDetails = (assessment) => {
    setSelectedAssessment(assessment);
    setShowDetails(true);
  };

  const handleViewLink = (assessment) => {
    setSelectedAssessment(assessment);
    setShowLink(true);
  };

  if (isLoading) {
    return (
      <div className="space-y-3">
        {[1,2,3,4,5].map(i => (
          <Skeleton key={i} className="h-16 w-full" />
        ))}
      </div>
    );
  }

  if (assessments.length === 0) {
    return null;
  }

  return (
    <>
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="bg-gray-50">
              <TableHead>Colaborador</TableHead>
              <TableHead>Departamento</TableHead>
              <TableHead>Instrumentos</TableHead>
              <TableHead>Data de Envio</TableHead>
              <TableHead>Data de Resposta</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-center">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {assessments.map((assessment) => (
              <TableRow key={assessment.id} className="hover:bg-gray-50">
                <TableCell>
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4 text-gray-400" />
                    <span className="font-medium">{getEmployeeName(assessment.employee_id)}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-gray-400" />
                    {getDepartmentName(assessment.department_id)}
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex flex-wrap gap-1">
                    {formatAssessmentTypes(assessment.assessment_type).split(', ').map((type, idx) => (
                      <Badge key={idx} variant="outline" className="bg-blue-50 text-blue-700 text-xs">
                        {type}
                      </Badge>
                    ))}
                  </div>
                </TableCell>
                <TableCell>
                  {format(parseISO(assessment.created_date), 'dd/MM/yyyy HH:mm')}
                </TableCell>
                <TableCell>
                  {assessment.completed_at 
                    ? format(parseISO(assessment.completed_at), 'dd/MM/yyyy HH:mm')
                    : '-'
                  }
                </TableCell>
                <TableCell>
                  {assessment.completed_at ? (
                    <Badge className="bg-green-100 text-green-800 border-green-200">
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Respondida
                    </Badge>
                  ) : (
                    <Badge className="bg-orange-100 text-orange-800 border-orange-200">
                      <Clock className="w-3 h-3 mr-1" />
                      Pendente
                    </Badge>
                  )}
                </TableCell>
                <TableCell className="text-center">
                  <div className="flex items-center justify-center gap-2">
                    {!assessment.completed_at && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleViewLink(assessment)}
                        className="text-blue-600 hover:text-blue-800 p-0 h-auto"
                      >
                        <ExternalLink className="w-3 h-3 mr-1" />
                        Link
                      </Button>
                    )}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleViewDetails(assessment)}
                      className="text-blue-600 hover:text-blue-800 p-0 h-auto"
                    >
                      Ver Detalhes
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {selectedAssessment && (
        <>
          <AssessmentDetailsModal
            open={showDetails}
            onOpenChange={setShowDetails}
            assessment={selectedAssessment}
            employees={employees}
            departments={departments}
            allAssessments={assessments}
          />
          
          <AssessmentLinkModal
            open={showLink}
            onOpenChange={setShowLink}
            assessment={selectedAssessment}
            employee={employees.find(e => e.id === selectedAssessment.employee_id)}
          />
        </>
      )}
    </>
  );
}