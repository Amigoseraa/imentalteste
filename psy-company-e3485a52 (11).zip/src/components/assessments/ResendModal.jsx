import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowRight, Mail, MessageSquare, Phone, Send, Info, Clock } from "lucide-react";

export default function ResendModal({ 
  open, 
  onOpenChange, 
  departments,
  pendingCount,
  onResend 
}) {
  const [step, setStep] = useState(1);
  const [selectedDepartments, setSelectedDepartments] = useState([]);
  const [selectedChannels, setSelectedChannels] = useState(['email']);
  const [targetFilter, setTargetFilter] = useState('not_completed');
  const [strategy, setStrategy] = useState('multicanal');
  const [respectBusinessHours, setRespectBusinessHours] = useState(true);
  const [templates, setTemplates] = useState({
    email_subject: 'Lembrete: Avaliação de Bem-Estar - [NOME_EMPRESA]',
    email_body: 'Olá!\n\nAinda aguardamos sua participação na avaliação confidencial de bem-estar.\n\nSuas respostas são confidenciais e serão usadas apenas de forma agregada.\n\nAcesse: [LINK]\n\nPrazo: [PRAZO]\n\nObrigado!',
    sms: 'PsyCompany: aguardamos sua avaliação confidencial. Acesse: [LINK] (prazo [PRAZO])',
    whatsapp: 'Olá! Falta pouco 😊 Responda sua avaliação confidencial: [LINK]. Prazo: [PRAZO]. Obrigado!'
  });
  const [sending, setSending] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  React.useEffect(() => {
    if (open) {
      setStep(1);
      setSelectedDepartments([]);
      setSelectedChannels(['email']);
      setTargetFilter('not_completed');
      setStrategy('multicanal');
      setShowConfirm(false);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    
    return () => {
      document.body.style.overflow = '';
    };
  }, [open]);

  const handleDepartmentToggle = (deptId) => {
    setSelectedDepartments(prev =>
      prev.includes(deptId)
        ? prev.filter(id => id !== deptId)
        : [...prev, deptId]
    );
  };

  const handleChannelToggle = (channel) => {
    setSelectedChannels(prev =>
      prev.includes(channel)
        ? prev.filter(c => c !== channel)
        : [...prev, channel]
    );
  };

  const getSelectedCount = () => {
    // Simulação - calcular com base nos filtros
    let count = pendingCount || 0;
    if (targetFilter === 'not_accepted') count = Math.floor(count * 0.3);
    if (targetFilter === 'not_started') count = Math.floor(count * 0.5);
    if (selectedDepartments.length > 0) count = Math.floor(count * 0.7);
    return count;
  };

  const handleConfirmResend = async () => {
    setSending(true);
    await onResend({
      departments: selectedDepartments,
      channels: selectedChannels,
      targetFilter,
      strategy,
      respectBusinessHours,
      templates
    });
    setSending(false);
    setShowConfirm(false);
    onOpenChange(false);
  };

  const selectedCount = getSelectedCount();

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[900px] w-full max-h-[90vh] p-0 gap-0 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="border-b p-6 flex-shrink-0">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold">
              Reenviar Convites Pendentes
            </DialogTitle>
            <p className="text-sm text-gray-500 mt-2">
              Configure o reenvio manual de convites para colaboradores que ainda não responderam
            </p>
          </DialogHeader>
          
          <div className="flex items-center justify-center mt-4">
            <div className="flex items-center gap-2">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 1 ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-500'}`}>
                1
              </div>
              <div className={`w-16 h-1 ${step >= 2 ? 'bg-blue-600' : 'bg-gray-200'}`} />
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 2 ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-500'}`}>
                2
              </div>
              <div className={`w-16 h-1 ${step >= 3 ? 'bg-blue-600' : 'bg-gray-200'}`} />
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 3 ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-500'}`}>
                3
              </div>
            </div>
          </div>
        </div>

        {/* Body rolável */}
        <div className="flex-1 overflow-y-auto p-6" style={{ minHeight: 0 }}>
          {step === 1 && (
            <div className="space-y-6">
              <div>
                <Label className="text-base font-semibold mb-3 block">
                  Escopo do Reenvio
                </Label>
                
                <div className="space-y-4">
                  <div>
                    <Label className="mb-2 block">Filtrar por Status</Label>
                    <RadioGroup value={targetFilter} onValueChange={setTargetFilter}>
                      <div className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50">
                        <RadioGroupItem value="not_completed" id="not_completed" />
                        <Label htmlFor="not_completed" className="cursor-pointer flex-1">
                          Não concluíram (incluindo em andamento)
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50">
                        <RadioGroupItem value="not_started" id="not_started" />
                        <Label htmlFor="not_started" className="cursor-pointer flex-1">
                          Não iniciaram
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50">
                        <RadioGroupItem value="not_accepted" id="not_accepted" />
                        <Label htmlFor="not_accepted" className="cursor-pointer flex-1">
                          Não aceitaram o termo
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>

                  <div>
                    <Label className="mb-2 block">Departamentos (opcional)</Label>
                    <div className="grid grid-cols-2 gap-3">
                      {departments.map(dept => (
                        <div
                          key={dept.id}
                          className="flex items-center gap-2 p-3 border rounded-lg hover:bg-gray-50 cursor-pointer"
                          onClick={() => handleDepartmentToggle(dept.id)}
                        >
                          <Checkbox
                            checked={selectedDepartments.includes(dept.id)}
                            onCheckedChange={() => handleDepartmentToggle(dept.id)}
                          />
                          <Label className="cursor-pointer">{dept.name}</Label>
                        </div>
                      ))}
                    </div>
                    <p className="text-xs text-gray-500 mt-2">
                      Deixe vazio para incluir todos os departamentos
                    </p>
                  </div>

                  <div>
                    <Label className="mb-2 block">Canais de Envio *</Label>
                    <div className="grid grid-cols-3 gap-3">
                      <div
                        className={`flex flex-col items-center gap-2 p-4 border-2 rounded-lg cursor-pointer transition-all ${
                          selectedChannels.includes('email') ? 'border-blue-500 bg-blue-50' : 'hover:bg-gray-50'
                        }`}
                        onClick={() => handleChannelToggle('email')}
                      >
                        <Mail className={`w-6 h-6 ${selectedChannels.includes('email') ? 'text-blue-600' : 'text-gray-400'}`} />
                        <span className="font-medium">E-mail</span>
                        <Checkbox checked={selectedChannels.includes('email')} />
                      </div>
                      <div
                        className={`flex flex-col items-center gap-2 p-4 border-2 rounded-lg cursor-pointer transition-all ${
                          selectedChannels.includes('whatsapp') ? 'border-green-500 bg-green-50' : 'hover:bg-gray-50'
                        }`}
                        onClick={() => handleChannelToggle('whatsapp')}
                      >
                        <MessageSquare className={`w-6 h-6 ${selectedChannels.includes('whatsapp') ? 'text-green-600' : 'text-gray-400'}`} />
                        <span className="font-medium">WhatsApp</span>
                        <Checkbox checked={selectedChannels.includes('whatsapp')} />
                      </div>
                      <div
                        className={`flex flex-col items-center gap-2 p-4 border-2 rounded-lg cursor-pointer transition-all ${
                          selectedChannels.includes('sms') ? 'border-orange-500 bg-orange-50' : 'hover:bg-gray-50'
                        }`}
                        onClick={() => handleChannelToggle('sms')}
                      >
                        <Phone className={`w-6 h-6 ${selectedChannels.includes('sms') ? 'text-orange-600' : 'text-gray-400'}`} />
                        <span className="font-medium">SMS</span>
                        <Checkbox checked={selectedChannels.includes('sms')} />
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <Card className="bg-blue-50 border-blue-200">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Info className="w-5 h-5 text-blue-600" />
                      <span className="font-semibold text-blue-900">Colaboradores selecionados:</span>
                    </div>
                    <Badge className="text-lg px-4 py-1 bg-blue-600">
                      {selectedCount}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <div>
                <Label className="text-base font-semibold mb-3 block">
                  Estratégia de Envio
                </Label>
                
                <RadioGroup value={strategy} onValueChange={setStrategy}>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3 p-4 border-2 rounded-lg hover:bg-gray-50 cursor-pointer">
                      <RadioGroupItem value="multicanal" id="multicanal" className="mt-1" />
                      <div className="flex-1" onClick={() => setStrategy('multicanal')}>
                        <Label htmlFor="multicanal" className="cursor-pointer font-semibold block">
                          Multicanal Simultâneo
                        </Label>
                        <p className="text-sm text-gray-600 mt-1">
                          Dispara em todos os canais selecionados ao mesmo tempo
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-4 border-2 rounded-lg hover:bg-gray-50 cursor-pointer">
                      <RadioGroupItem value="cascata" id="cascata" className="mt-1" />
                      <div className="flex-1" onClick={() => setStrategy('cascata')}>
                        <Label htmlFor="cascata" className="cursor-pointer font-semibold block">
                          Cascata Inteligente
                        </Label>
                        <p className="text-sm text-gray-600 mt-1">
                          Tenta WhatsApp → se falhar, SMS → se falhar, E-mail
                        </p>
                      </div>
                    </div>
                  </div>
                </RadioGroup>
              </div>

              <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
                <Checkbox
                  id="business-hours"
                  checked={respectBusinessHours}
                  onCheckedChange={setRespectBusinessHours}
                />
                <div className="flex-1">
                  <Label htmlFor="business-hours" className="cursor-pointer font-medium flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    Respeitar horário comercial
                  </Label>
                  <p className="text-sm text-gray-600 mt-1">
                    Envios apenas entre 08:00 e 20:00 (fuso America/São_Paulo)
                  </p>
                </div>
              </div>

              <Alert className="bg-yellow-50 border-yellow-200">
                <AlertDescription className="text-yellow-800 text-sm">
                  <strong>Taxa de envio:</strong> Máximo de 60 disparos por minuto por canal (fila automática)
                </AlertDescription>
              </Alert>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
              <div>
                <Label className="text-base font-semibold mb-3 block">
                  Templates de Mensagem
                </Label>
                <p className="text-sm text-gray-600 mb-4">
                  Personalize as mensagens usando: [NOME_EMPRESA], [NOME_AVALIACAO], [LINK], [PRAZO]
                </p>

                <div className="space-y-4">
                  {selectedChannels.includes('email') && (
                    <Card>
                      <CardContent className="p-4 space-y-3">
                        <div className="flex items-center gap-2 text-blue-600">
                          <Mail className="w-5 h-5" />
                          <span className="font-semibold">E-mail</span>
                        </div>
                        <div>
                          <Label htmlFor="email-subject">Assunto</Label>
                          <Input
                            id="email-subject"
                            value={templates.email_subject}
                            onChange={(e) => setTemplates({...templates, email_subject: e.target.value})}
                          />
                        </div>
                        <div>
                          <Label htmlFor="email-body">Corpo da mensagem</Label>
                          <Textarea
                            id="email-body"
                            rows={6}
                            value={templates.email_body}
                            onChange={(e) => setTemplates({...templates, email_body: e.target.value})}
                          />
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {selectedChannels.includes('sms') && (
                    <Card>
                      <CardContent className="p-4 space-y-3">
                        <div className="flex items-center gap-2 text-orange-600">
                          <Phone className="w-5 h-5" />
                          <span className="font-semibold">SMS</span>
                        </div>
                        <div>
                          <Label htmlFor="sms-template">Mensagem (máx. 160 caracteres)</Label>
                          <Textarea
                            id="sms-template"
                            rows={3}
                            value={templates.sms}
                            onChange={(e) => setTemplates({...templates, sms: e.target.value})}
                            maxLength={160}
                          />
                          <p className="text-xs text-gray-500 mt-1">
                            {templates.sms.length}/160 caracteres
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {selectedChannels.includes('whatsapp') && (
                    <Card>
                      <CardContent className="p-4 space-y-3">
                        <div className="flex items-center gap-2 text-green-600">
                          <MessageSquare className="w-5 h-5" />
                          <span className="font-semibold">WhatsApp</span>
                        </div>
                        <div>
                          <Label htmlFor="whatsapp-template">Mensagem</Label>
                          <Textarea
                            id="whatsapp-template"
                            rows={4}
                            value={templates.whatsapp}
                            onChange={(e) => setTemplates({...templates, whatsapp: e.target.value})}
                          />
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </div>
              </div>

              <Alert className="bg-blue-50 border-blue-200">
                <AlertDescription className="text-blue-900 text-sm">
                  <strong>LGPD:</strong> As mensagens serão enviadas apenas aos colaboradores que não optaram por não receber (opt-out). Respeitaremos limites de horário, taxa e privacidade.
                </AlertDescription>
              </Alert>
            </div>
          )}
        </div>

        {/* Footer fixo */}
        <div className="border-t p-4 bg-white flex-shrink-0">
          <div className="flex items-center justify-between gap-3">
            <Button
              variant="outline"
              onClick={() => step > 1 ? setStep(step - 1) : onOpenChange(false)}
            >
              {step === 1 ? 'Cancelar' : 'Voltar'}
            </Button>

            {step < 3 ? (
              <Button
                className="bg-blue-600 hover:bg-blue-700"
                onClick={() => setStep(step + 1)}
                disabled={step === 1 && selectedChannels.length === 0}
              >
                Próximo
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            ) : (
              <Button
                className="bg-blue-600 hover:bg-blue-700"
                onClick={() => setShowConfirm(true)}
              >
                <Send className="w-4 h-4 mr-2" />
                Confirmar Reenvio
              </Button>
            )}
          </div>
        </div>

        {/* Modal de confirmação */}
        {showConfirm && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <Card className="max-w-md w-full">
              <CardContent className="p-6 space-y-4">
                <h3 className="text-lg font-semibold">Confirmar Reenvio</h3>
                <div className="space-y-2 text-sm">
                  <p>Você está prestes a reenviar convites para:</p>
                  <ul className="list-disc list-inside space-y-1 ml-2">
                    <li><strong>{selectedCount}</strong> colaboradores</li>
                    <li>Canais: <strong>{selectedChannels.map(c => c.toUpperCase()).join(', ')}</strong></li>
                    <li>Estratégia: <strong>{strategy === 'multicanal' ? 'Multicanal Simultâneo' : 'Cascata Inteligente'}</strong></li>
                  </ul>
                  <p className="text-gray-600 mt-3">
                    Observação: Respeitaremos os limites de horário comercial, taxa de envio e opt-out.
                  </p>
                </div>
                <div className="flex gap-3">
                  <Button
                    variant="outline"
                    onClick={() => setShowConfirm(false)}
                    className="flex-1"
                    disabled={sending}
                  >
                    Cancelar
                  </Button>
                  <Button
                    onClick={handleConfirmResend}
                    className="flex-1 bg-blue-600 hover:bg-blue-700"
                    disabled={sending}
                  >
                    {sending ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                        Enviando...
                      </>
                    ) : (
                      'Confirmar'
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}