import React from "react";
import { Card, CardHeader } from "@/components/ui/card";
import { Send, CheckCircle, Clock, TrendingUp, Calendar, FileCheck } from "lucide-react";

export default function AssessmentStats({ 
  totalSent, 
  completed, 
  pending, 
  responseRate, 
  lastDate,
  termsAccepted 
}) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-6">
      <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-shadow">
        <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 bg-blue-500 rounded-full opacity-10" />
        <CardHeader className="p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-1">Total Enviadas</p>
              <p className="text-3xl font-bold text-blue-600">{totalSent}</p>
            </div>
            <div className="p-3 rounded-xl bg-blue-50">
              <Send className="w-5 h-5 text-blue-600" />
            </div>
          </div>
        </CardHeader>
      </Card>

      <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-shadow">
        <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 bg-purple-500 rounded-full opacity-10" />
        <CardHeader className="p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-1">Termos Aceitos</p>
              <p className="text-3xl font-bold text-purple-600">{termsAccepted || 0}</p>
            </div>
            <div className="p-3 rounded-xl bg-purple-50">
              <FileCheck className="w-5 h-5 text-purple-600" />
            </div>
          </div>
        </CardHeader>
      </Card>

      <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-shadow">
        <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 bg-green-500 rounded-full opacity-10" />
        <CardHeader className="p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-1">Respondidas</p>
              <p className="text-3xl font-bold text-green-600">{completed}</p>
            </div>
            <div className="p-3 rounded-xl bg-green-50">
              <CheckCircle className="w-5 h-5 text-green-600" />
            </div>
          </div>
        </CardHeader>
      </Card>

      <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-shadow">
        <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 bg-orange-500 rounded-full opacity-10" />
        <CardHeader className="p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-1">Pendentes</p>
              <p className="text-3xl font-bold text-orange-600">{pending}</p>
            </div>
            <div className="p-3 rounded-xl bg-orange-50">
              <Clock className="w-5 h-5 text-orange-600" />
            </div>
          </div>
        </CardHeader>
      </Card>

      <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-shadow">
        <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 bg-indigo-500 rounded-full opacity-10" />
        <CardHeader className="p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-1">Taxa de Resposta</p>
              <p className="text-3xl font-bold text-indigo-600">{responseRate}%</p>
            </div>
            <div className="p-3 rounded-xl bg-indigo-50">
              <TrendingUp className="w-5 h-5 text-indigo-600" />
            </div>
          </div>
        </CardHeader>
      </Card>

      <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-shadow">
        <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 bg-gray-500 rounded-full opacity-10" />
        <CardHeader className="p-6">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-1">Último Envio</p>
              <p className="text-sm font-bold text-gray-600 mt-2">{lastDate}</p>
            </div>
            <div className="p-3 rounded-xl bg-gray-50">
              <Calendar className="w-5 h-5 text-gray-600" />
            </div>
          </div>
        </CardHeader>
      </Card>
    </div>
  );
}