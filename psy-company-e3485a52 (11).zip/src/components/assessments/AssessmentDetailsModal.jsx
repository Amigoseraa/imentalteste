import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Send,
  CheckCircle,
  Clock,
  Lock,
  TrendingUp,
  Mail,
  MessageSquare,
  Phone,
  ArrowLeft,
  Download,
  RefreshCw,
  Shield,
  Activity,
  Users,
  FileText
} from "lucide-react";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from "recharts";
import { format, parseISO, differenceInMinutes } from "date-fns";

const CHANNEL_ICONS = {
  email: Mail,
  whatsapp: MessageSquare,
  sms: Phone
};

const COLORS = {
  email: '#0052CC',
  whatsapp: '#25D366',
  sms: '#F4B400',
  completed: '#33A474',
  in_progress: '#F4B400',
  pending: '#9CA3AF'
};

export default function AssessmentDetailsModal({ 
  open, 
  onOpenChange, 
  assessment,
  employees,
  departments,
  allAssessments
}) {
  const [showResendConfirm, setShowResendConfirm] = useState(false);
  const [exporting, setExporting] = useState(false);

  if (!assessment) return null;

  // Calcular métricas
  const relatedAssessments = allAssessments.filter(a => 
    a.assessment_type === assessment.assessment_type &&
    format(parseISO(a.created_date), 'yyyy-MM') === format(parseISO(assessment.created_date), 'yyyy-MM')
  );

  const invitesSent = relatedAssessments.length;
  const termsAccepted = relatedAssessments.filter(a => a.completed_at || a.prima_responses).length;
  const assessmentsStarted = relatedAssessments.filter(a => 
    a.prima_responses && Object.keys(a.prima_responses).length > 0
  ).length;
  const assessmentsCompleted = relatedAssessments.filter(a => a.completed_at).length;
  const blockedAttempts = 0; // Simulado - implementar lógica real

  // Tempo médio de preenchimento
  const completedWithTime = relatedAssessments.filter(a => a.completed_at && a.created_date);
  const avgTimeMinutes = completedWithTime.length > 0
    ? completedWithTime.reduce((sum, a) => 
        sum + differenceInMinutes(parseISO(a.completed_at), parseISO(a.created_date)), 0
      ) / completedWithTime.length
    : 0;

  // Dados para gráfico de evolução
  const getEvolutionData = () => {
    const dateMap = {};
    relatedAssessments.forEach(a => {
      const date = format(parseISO(a.created_date), 'dd/MM');
      if (!dateMap[date]) {
        dateMap[date] = { date, sent: 0, started: 0, completed: 0 };
      }
      dateMap[date].sent++;
      if (a.prima_responses && Object.keys(a.prima_responses).length > 0) {
        dateMap[date].started++;
      }
      if (a.completed_at) {
        dateMap[date].completed++;
      }
    });
    return Object.values(dateMap).sort((a, b) => a.date.localeCompare(b.date));
  };

  // Dados para gráfico de canais (simulado - adicionar campo real)
  const channelData = [
    { name: 'E-mail', value: Math.floor(invitesSent * 0.45), percentage: 45, color: COLORS.email },
    { name: 'WhatsApp', value: Math.floor(invitesSent * 0.35), percentage: 35, color: COLORS.whatsapp },
    { name: 'SMS', value: Math.floor(invitesSent * 0.20), percentage: 20, color: COLORS.sms }
  ];

  // Dados por departamento
  const getDepartmentData = () => {
    const deptMap = {};
    relatedAssessments.forEach(a => {
      const dept = departments.find(d => d.id === a.department_id);
      const deptName = dept?.name || 'Sem Departamento';
      if (!deptMap[deptName]) {
        deptMap[deptName] = { name: deptName, completed: 0, in_progress: 0, pending: 0 };
      }
      if (a.completed_at) {
        deptMap[deptName].completed++;
      } else if (a.prima_responses && Object.keys(a.prima_responses).length > 0) {
        deptMap[deptName].in_progress++;
      } else {
        deptMap[deptName].pending++;
      }
    });
    return Object.values(deptMap).filter(d => (d.completed + d.in_progress + d.pending) >= 5);
  };

  // Dados de termos
  const consentData = [
    { name: 'Aceitaram', value: termsAccepted, percentage: Math.round((termsAccepted / invitesSent) * 100) },
    { name: 'Não Visualizaram', value: invitesSent - termsAccepted, percentage: Math.round(((invitesSent - termsAccepted) / invitesSent) * 100) }
  ];

  // Logs simulados
  const logs = [
    {
      action: 'Envio inicial',
      date: assessment.created_date,
      user: 'sistema@psycompany.com.br',
      description: `${invitesSent} convites enviados (e-mail, SMS, WhatsApp)`
    },
    ...(termsAccepted > 0 ? [{
      action: 'Termo aceito',
      date: assessment.created_date,
      user: 'colaborador (anon.)',
      description: `${termsAccepted} colaboradores aceitaram o termo`
    }] : []),
    ...(assessmentsCompleted > 0 ? [{
      action: 'Avaliação concluída',
      date: assessment.completed_at || assessment.created_date,
      user: 'colaborador (anon.)',
      description: `${assessmentsCompleted} avaliações concluídas`
    }] : [])
  ];

  const handleExport = async () => {
    setExporting(true);
    // Simular export
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const reportData = {
      assessment_name: `Avaliação ${assessment.assessment_type}`,
      period: format(parseISO(assessment.created_date), 'MMMM yyyy'),
      metrics: {
        sent: invitesSent,
        accepted: termsAccepted,
        started: assessmentsStarted,
        completed: assessmentsCompleted
      },
      generated_at: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Relatorio_Avaliacao_${format(new Date(), 'yyyy-MM-dd')}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    setExporting(false);
  };

  const handleResend = () => {
    setShowResendConfirm(false);
    // Implementar lógica de reenvio
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[90vw] w-full max-h-[90vh] p-0 gap-0 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="border-b p-6 flex-shrink-0">
          <DialogHeader>
            <div className="flex items-start justify-between">
              <div>
                <DialogTitle className="text-2xl font-bold">
                  Detalhes da Avaliação
                </DialogTitle>
                <p className="text-sm text-gray-500 mt-1">
                  Dashboard &gt; Avaliações &gt; {assessment.assessment_type}
                </p>
              </div>
              <Badge className={`text-white ${assessmentsCompleted === invitesSent ? 'bg-green-600' : 'bg-blue-600'}`}>
                {assessmentsCompleted === invitesSent ? 'Finalizada' : 'Em Andamento'}
              </Badge>
            </div>
          </DialogHeader>
        </div>

        {/* Body rolável */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Aviso LGPD */}
          <Alert className="bg-blue-50 border-blue-200">
            <Shield className="w-4 h-4 text-blue-600" />
            <AlertDescription className="text-blue-900 text-sm">
              ⚠️ Os dados exibidos neste relatório são consolidados e anônimos, conforme LGPD (Lei 13.709/2018). 
              Nenhuma informação individual é exibida.
            </AlertDescription>
          </Alert>

          {/* Cards de métricas */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            <MetricCard
              icon={Send}
              label="Convites Enviados"
              value={invitesSent}
              color="blue"
              tooltip="Total de convites disparados"
            />
            <MetricCard
              icon={CheckCircle}
              label="Termos Aceitos"
              value={termsAccepted}
              color="green"
              tooltip="Colaboradores que aceitaram o termo"
            />
            <MetricCard
              icon={Activity}
              label="Iniciadas"
              value={assessmentsStarted}
              color="yellow"
              tooltip="Colaboradores que começaram o preenchimento"
            />
            <MetricCard
              icon={FileText}
              label="Concluídas"
              value={assessmentsCompleted}
              color="green"
              tooltip="Colaboradores que finalizaram"
            />
            <MetricCard
              icon={Lock}
              label="Bloqueios"
              value={blockedAttempts}
              color="gray"
              tooltip="Tentaram responder novamente"
            />
            <MetricCard
              icon={Clock}
              label="Tempo Médio"
              value={`${Math.floor(avgTimeMinutes)}min`}
              color="blue"
              tooltip="Tempo médio de preenchimento"
            />
          </div>

          {/* Informações da Avaliação */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Informações da Avaliação</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <InfoRow label="Nome da Avaliação" value={`Avaliação ${assessment.assessment_type}`} />
                <InfoRow label="Tipo" value={assessment.assessment_type} />
                <InfoRow label="Data de Criação" value={format(parseISO(assessment.created_date), 'dd/MM/yyyy')} />
                <InfoRow label="Total de Colaboradores" value={invitesSent} />
                <InfoRow label="Duração Estimada" value="7 a 10 minutos" />
                <InfoRow label="Taxa de Conclusão" value={`${Math.round((assessmentsCompleted / invitesSent) * 100)}%`} />
              </div>
            </CardContent>
          </Card>

          {/* Gráficos */}
          <div className="grid lg:grid-cols-2 gap-6">
            {/* Evolução Temporal */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  Evolução de Participação
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <LineChart data={getEvolutionData()}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="sent" stroke="#0052CC" name="Enviados" />
                    <Line type="monotone" dataKey="started" stroke="#F4B400" name="Iniciados" />
                    <Line type="monotone" dataKey="completed" stroke="#33A474" name="Concluídos" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Distribuição por Canal */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Distribuição por Canal</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie
                      data={channelData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percentage }) => `${name}: ${percentage}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {channelData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Distribuição por Departamento */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  Status por Departamento
                </CardTitle>
              </CardHeader>
              <CardContent>
                {getDepartmentData().length > 0 ? (
                  <ResponsiveContainer width="100%" height={250}>
                    <BarChart data={getDepartmentData()} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" />
                      <YAxis dataKey="name" type="category" width={120} />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="completed" stackId="a" fill={COLORS.completed} name="Concluídas" />
                      <Bar dataKey="in_progress" stackId="a" fill={COLORS.in_progress} name="Em Andamento" />
                      <Bar dataKey="pending" stackId="a" fill={COLORS.pending} name="Pendentes" />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-[250px] flex items-center justify-center text-gray-400">
                    Dados insuficientes (mínimo 5 por departamento)
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Termos de Consentimento */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Termos de Consentimento</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-center h-[250px]">
                  <div className="text-center">
                    <div className="text-5xl font-bold text-green-600 mb-2">
                      {consentData[0].percentage}%
                    </div>
                    <p className="text-gray-600 font-medium mb-4">Aceitaram os Termos</p>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2 justify-center">
                        <div className="w-3 h-3 bg-green-600 rounded-full" />
                        <span>{consentData[0].value} aceitaram</span>
                      </div>
                      <div className="flex items-center gap-2 justify-center">
                        <div className="w-3 h-3 bg-gray-300 rounded-full" />
                        <span>{consentData[1].value} não visualizaram</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Tabela de Canais */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Envio e Canais</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Canal</TableHead>
                    <TableHead>Enviados</TableHead>
                    <TableHead>Entregues</TableHead>
                    <TableHead>Aceitaram Termo</TableHead>
                    <TableHead>Concluíram</TableHead>
                    <TableHead>Taxa de Conversão</TableHead>
                    <TableHead>Último Envio</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {channelData.map((channel) => {
                    const sent = channel.value;
                    const delivered = Math.floor(sent * 0.96);
                    const accepted = Math.floor(delivered * 0.85);
                    const completed = Math.floor(accepted * 0.70);
                    const conversionRate = Math.round((completed / delivered) * 100);
                    
                    return (
                      <TableRow key={channel.name}>
                        <TableCell className="font-medium flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: channel.color }} />
                          {channel.name}
                        </TableCell>
                        <TableCell>{sent}</TableCell>
                        <TableCell>{delivered}</TableCell>
                        <TableCell>{accepted}</TableCell>
                        <TableCell>{completed}</TableCell>
                        <TableCell>
                          <Badge className={conversionRate >= 65 ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}>
                            {conversionRate}%
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm text-gray-600">
                          {format(parseISO(assessment.created_date), 'dd/MM/yyyy')}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {/* Logs */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Logs e Rastreabilidade</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="max-h-[300px] overflow-y-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Ação</TableHead>
                      <TableHead>Data/Hora</TableHead>
                      <TableHead>Usuário / Sistema</TableHead>
                      <TableHead>Descrição</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {logs.map((log, index) => (
                      <TableRow key={index}>
                        <TableCell className="font-medium">{log.action}</TableCell>
                        <TableCell className="text-sm">
                          {format(parseISO(log.date), 'dd/MM/yyyy HH:mm')}
                        </TableCell>
                        <TableCell className="text-sm">{log.user}</TableCell>
                        <TableCell className="text-sm text-gray-600">{log.description}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Footer fixo */}
        <div className="border-t p-4 bg-white flex-shrink-0">
          <div className="flex items-center justify-between gap-3">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar ao Painel
            </Button>

            <div className="flex gap-3">
              {invitesSent > assessmentsCompleted && (
                <Button
                  variant="outline"
                  onClick={() => setShowResendConfirm(true)}
                >
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Reenviar Pendentes
                </Button>
              )}
              
              <Button
                className="bg-blue-600 hover:bg-blue-700"
                onClick={handleExport}
                disabled={exporting}
              >
                {exporting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                    Exportando...
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4 mr-2" />
                    Exportar Relatório
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>

        {/* Modal de confirmação de reenvio */}
        {showResendConfirm && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <Card className="max-w-md w-full">
              <CardHeader>
                <CardTitle>Confirmar Reenvio</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-600">
                  Tem certeza que deseja reenviar os convites pendentes desta avaliação?
                  O reenvio pode gerar custos adicionais de SMS ou WhatsApp.
                </p>
                <div className="flex gap-3">
                  <Button
                    variant="outline"
                    onClick={() => setShowResendConfirm(false)}
                    className="flex-1"
                  >
                    Cancelar
                  </Button>
                  <Button
                    onClick={handleResend}
                    className="flex-1 bg-blue-600 hover:bg-blue-700"
                  >
                    Confirmar Reenvio
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

function MetricCard({ icon: Icon, label, value, color, tooltip }) {
  const colorClasses = {
    blue: 'bg-blue-50 text-blue-600 border-blue-200',
    green: 'bg-green-50 text-green-600 border-green-200',
    yellow: 'bg-yellow-50 text-yellow-600 border-yellow-200',
    gray: 'bg-gray-50 text-gray-600 border-gray-200'
  };

  return (
    <Card className="hover:shadow-md transition-shadow" title={tooltip}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-2">
          <div className={`p-2 rounded-lg ${colorClasses[color]}`}>
            <Icon className="w-4 h-4" />
          </div>
        </div>
        <div className="text-2xl font-bold text-gray-900 mb-1">{value}</div>
        <div className="text-xs text-gray-600">{label}</div>
      </CardContent>
    </Card>
  );
}

function InfoRow({ label, value }) {
  return (
    <div>
      <p className="text-gray-500 mb-1">{label}</p>
      <p className="font-semibold text-gray-900">{value}</p>
    </div>
  );
}