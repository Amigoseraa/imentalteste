import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Copy, ExternalLink, Mail, Check, LinkIcon, Calendar, MessageSquare, Info } from "lucide-react";
import { format, addDays } from "date-fns";
import { createPageUrl } from "@/utils";

export default function AssessmentLinkModal({ open, onOpenChange, assessment, employee }) {
  const [copied, setCopied] = useState(false);

  if (!assessment || !employee) return null;

  // Link genérico /responder (não mais por avaliação)
  const assessmentUrl = `${window.location.origin}${createPageUrl("Responder")}`;
  
  const expirationDate = assessment.due_date 
    ? new Date(assessment.due_date) 
    : addDays(new Date(assessment.created_date), 14);

  const handleCopy = () => {
    navigator.clipboard.writeText(assessmentUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleOpen = () => {
    window.open(assessmentUrl, '_blank', 'noopener,noreferrer');
  };

  const handleSendEmail = () => {
    const subject = encodeURIComponent('Convite: Avaliação de Bem-Estar - PsyCompany');
    const body = encodeURIComponent(
      `Olá ${employee.name},\n\n` +
      `Você foi convidado(a) a participar de uma avaliação de bem-estar.\n\n` +
      `Para responder:\n` +
      `1. Acesse: ${assessmentUrl}\n` +
      `2. Entre com seu CPF e sua Data de Nascimento\n` +
      `3. Responda as perguntas (leva poucos minutos)\n\n` +
      `Válido até: ${format(expirationDate, 'dd/MM/yyyy')}\n\n` +
      `Suas respostas são confidenciais e anônimas.\n\n` +
      `Obrigado pela sua participação!`
    );
    window.location.href = `mailto:${employee.email}?subject=${subject}&body=${body}`;
  };

  const handleSendWhatsApp = () => {
    const message = encodeURIComponent(
      `Olá ${employee.name}! 😊\n\n` +
      `Você foi convidado(a) para uma avaliação de bem-estar.\n\n` +
      `Acesse: ${assessmentUrl}\n` +
      `Use seu CPF e data de nascimento para entrar.\n\n` +
      `Válido até: ${format(expirationDate, 'dd/MM/yyyy')}\n\n` +
      `Suas respostas são confidenciais 🔒`
    );
    const phone = employee.phone?.replace(/\D/g, '');
    if (phone) {
      window.open(`https://wa.me/${phone}?text=${message}`, '_blank', 'noopener,noreferrer');
    } else {
      alert('Colaborador não possui telefone cadastrado.');
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <LinkIcon className="w-5 h-5 text-blue-600" />
            Link de Convite
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="p-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-blue-900">Colaborador:</span>
                  <span className="text-sm text-blue-800">{employee.name}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-blue-900">Email:</span>
                  <span className="text-sm text-blue-800">{employee.email}</span>
                </div>
                {employee.phone && (
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-blue-900">Telefone:</span>
                    <span className="text-sm text-blue-800">{employee.phone}</span>
                  </div>
                )}
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-blue-900">Prazo:</span>
                  <span className="text-sm text-blue-800 flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {format(expirationDate, 'dd/MM/yyyy')}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          <div>
            <label className="text-sm font-medium text-gray-700 block mb-2">
              Link de Acesso
            </label>
            <div className="flex gap-2">
              <div className="flex-1 p-3 bg-gray-50 rounded-lg border text-sm font-mono break-all">
                {assessmentUrl}
              </div>
            </div>
          </div>

          <Alert className="bg-amber-50 border-amber-200">
            <Info className="w-4 h-4 text-amber-600" />
            <AlertDescription className="text-sm text-amber-900">
              <p className="mb-2">
                <strong>Como usar este link:</strong>
              </p>
              <ul className="list-disc list-inside space-y-1 ml-2">
                <li>Link genérico de acesso ao portal do colaborador</li>
                <li>Será solicitado CPF e data de nascimento</li>
                <li>O colaborador verá todas as suas avaliações pendentes</li>
                <li>Funciona em qualquer dispositivo (desktop, mobile)</li>
                <li>Válido até {format(expirationDate, 'dd/MM/yyyy')}</li>
              </ul>
            </AlertDescription>
          </Alert>

          <div className="flex flex-wrap gap-3">
            <Button
              variant="outline"
              onClick={handleCopy}
              className="flex-1"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 mr-2 text-green-600" />
                  Copiado!
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 mr-2" />
                  Copiar Link
                </>
              )}
            </Button>

            <Button
              variant="outline"
              onClick={handleOpen}
              className="flex-1"
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              Abrir em Nova Aba
            </Button>
          </div>

          <div className="flex flex-wrap gap-3">
            <Button
              onClick={handleSendEmail}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
            >
              <Mail className="w-4 h-4 mr-2" />
              Enviar por E-mail
            </Button>

            {employee.phone && (
              <Button
                onClick={handleSendWhatsApp}
                className="flex-1 bg-green-600 hover:bg-green-700"
              >
                <MessageSquare className="w-4 h-4 mr-2" />
                Enviar por WhatsApp
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}