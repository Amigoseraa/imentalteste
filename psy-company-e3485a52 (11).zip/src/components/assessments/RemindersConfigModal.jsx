import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card, CardContent } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Save, Mail, MessageSquare, Phone, Info, Clock, Bell } from "lucide-react";

export default function RemindersConfigModal({ 
  open, 
  onOpenChange,
  assessment,
  onSave
}) {
  const [config, setConfig] = useState({
    enabled: false,
    hour: '09:00',
    weekdays: ['1', '2', '3', '4', '5'],
    channels: ['email'],
    strategy: 'multicanal',
    max_per_person: 5,
    quiet_start: '20:00',
    quiet_end: '08:00',
    pause_in_progress: true,
    daily_cap: 5000
  });

  const [templates, setTemplates] = useState({
    email_subject: 'Lembrete: sua avaliação PsyCompany (vence em [PRAZO])',
    email_body: 'Olá!\n\nFalta pouco para concluirmos. Suas respostas são confidenciais.\n\nAcesse: [LINK]\n\nObrigado!',
    sms: 'Lembrete PsyCompany: responda sua avaliação confidencial: [LINK]. Prazo: [PRAZO]',
    whatsapp: 'Seguimos contando com você 🙏 Responda aqui: [LINK]. Prazo: [PRAZO] — confidencial.'
  });

  const [saving, setSaving] = useState(false);

  const weekdayLabels = {
    '1': 'Seg',
    '2': 'Ter',
    '3': 'Qua',
    '4': 'Qui',
    '5': 'Sex',
    '6': 'Sáb',
    '7': 'Dom'
  };

  const handleWeekdayToggle = (day) => {
    setConfig(prev => ({
      ...prev,
      weekdays: prev.weekdays.includes(day)
        ? prev.weekdays.filter(d => d !== day)
        : [...prev.weekdays, day]
    }));
  };

  const handleChannelToggle = (channel) => {
    setConfig(prev => ({
      ...prev,
      channels: prev.channels.includes(channel)
        ? prev.channels.filter(c => c !== channel)
        : [...prev.channels, channel]
    }));
  };

  const handleSave = async () => {
    setSaving(true);
    await onSave({ config, templates });
    setSaving(false);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[900px] w-full max-h-[90vh] p-0 gap-0 flex flex-col overflow-hidden">
        <div className="border-b p-6 flex-shrink-0">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold flex items-center gap-2">
              <Bell className="w-6 h-6 text-blue-600" />
              Configurar Lembretes Automáticos
            </DialogTitle>
            <p className="text-sm text-gray-500 mt-2">
              Configure lembretes diários para colaboradores que ainda não concluíram a avaliação
            </p>
          </DialogHeader>
        </div>

        <div className="flex-1 overflow-y-auto p-6" style={{ minHeight: 0 }}>
          <div className="grid lg:grid-cols-2 gap-6">
            <div className="space-y-6">
              <Card>
                <CardContent className="p-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="enabled" className="font-semibold">Ativar lembretes automáticos</Label>
                      <p className="text-sm text-gray-600">Envio diário até resposta ou expiração</p>
                    </div>
                    <Switch
                      id="enabled"
                      checked={config.enabled}
                      onCheckedChange={(checked) => setConfig({...config, enabled: checked})}
                    />
                  </div>
                </CardContent>
              </Card>

              {config.enabled && (
                <>
                  <Card>
                    <CardContent className="p-4 space-y-4">
                      <div>
                        <Label htmlFor="hour">Horário de disparo</Label>
                        <Input
                          id="hour"
                          type="time"
                          value={config.hour}
                          onChange={(e) => setConfig({...config, hour: e.target.value})}
                        />
                        <p className="text-xs text-gray-500 mt-1">Fuso horário: America/São_Paulo</p>
                      </div>

                      <div>
                        <Label className="mb-2 block">Dias da semana</Label>
                        <div className="flex gap-2">
                          {Object.entries(weekdayLabels).map(([day, label]) => (
                            <Button
                              key={day}
                              variant={config.weekdays.includes(day) ? "default" : "outline"}
                              size="sm"
                              className={`flex-1 ${config.weekdays.includes(day) ? 'bg-blue-600' : ''}`}
                              onClick={() => handleWeekdayToggle(day)}
                            >
                              {label}
                            </Button>
                          ))}
                        </div>
                      </div>

                      <div>
                        <Label>Janela silenciosa (não enviar)</Label>
                        <div className="grid grid-cols-2 gap-2 mt-2">
                          <div>
                            <Input
                              type="time"
                              value={config.quiet_start}
                              onChange={(e) => setConfig({...config, quiet_start: e.target.value})}
                            />
                            <p className="text-xs text-gray-500 mt-1">Início</p>
                          </div>
                          <div>
                            <Input
                              type="time"
                              value={config.quiet_end}
                              onChange={(e) => setConfig({...config, quiet_end: e.target.value})}
                            />
                            <p className="text-xs text-gray-500 mt-1">Fim</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-4 space-y-4">
                      <div>
                        <Label className="mb-2 block">Canais para lembrete</Label>
                        <div className="space-y-2">
                          {[
                            { id: 'email', label: 'E-mail', icon: Mail, color: 'text-blue-600' },
                            { id: 'whatsapp', label: 'WhatsApp', icon: MessageSquare, color: 'text-green-600' },
                            { id: 'sms', label: 'SMS', icon: Phone, color: 'text-orange-600' }
                          ].map(channel => (
                            <div
                              key={channel.id}
                              className="flex items-center gap-3 p-3 border rounded-lg hover:bg-gray-50 cursor-pointer"
                              onClick={() => handleChannelToggle(channel.id)}
                            >
                              <Checkbox
                                checked={config.channels.includes(channel.id)}
                                onCheckedChange={() => handleChannelToggle(channel.id)}
                              />
                              <channel.icon className={`w-5 h-5 ${channel.color}`} />
                              <Label className="cursor-pointer">{channel.label}</Label>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div>
                        <Label className="mb-2 block">Estratégia</Label>
                        <RadioGroup value={config.strategy} onValueChange={(value) => setConfig({...config, strategy: value})}>
                          <div className="flex items-center space-x-2 p-3 border rounded-lg">
                            <RadioGroupItem value="multicanal" id="multicanal" />
                            <Label htmlFor="multicanal" className="cursor-pointer">Multicanal simultâneo</Label>
                          </div>
                          <div className="flex items-center space-x-2 p-3 border rounded-lg">
                            <RadioGroupItem value="cascata" id="cascata" />
                            <Label htmlFor="cascata" className="cursor-pointer">Cascata (WhatsApp→SMS→E-mail)</Label>
                          </div>
                        </RadioGroup>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-4 space-y-4">
                      <div>
                        <Label htmlFor="max_per_person">Máximo de lembretes por colaborador</Label>
                        <Input
                          id="max_per_person"
                          type="number"
                          min="1"
                          max="10"
                          value={config.max_per_person}
                          onChange={(e) => setConfig({...config, max_per_person: parseInt(e.target.value)})}
                        />
                        <p className="text-xs text-gray-500 mt-1">Após este número, os lembretes param automaticamente</p>
                      </div>

                      <div>
                        <Label htmlFor="daily_cap">Limite diário total de lembretes</Label>
                        <Input
                          id="daily_cap"
                          type="number"
                          min="100"
                          step="100"
                          value={config.daily_cap}
                          onChange={(e) => setConfig({...config, daily_cap: parseInt(e.target.value)})}
                        />
                        <p className="text-xs text-gray-500 mt-1">Para evitar picos de envio</p>
                      </div>

                      <div className="flex items-center gap-3">
                        <Checkbox
                          id="pause_in_progress"
                          checked={config.pause_in_progress}
                          onCheckedChange={(checked) => setConfig({...config, pause_in_progress: checked})}
                        />
                        <div>
                          <Label htmlFor="pause_in_progress" className="cursor-pointer">
                            Enviar lembrete para &quot;em andamento&quot;
                          </Label>
                          <p className="text-xs text-gray-600">Se iniciou mas não concluiu há mais de 3 dias</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Alert className="bg-blue-50 border-blue-200">
                    <Info className="w-4 h-4 text-blue-600" />
                    <AlertDescription className="text-blue-900 text-sm">
                      <strong>Parada automática:</strong> Os lembretes param quando o colaborador conclui a avaliação, o convite expira ou há opt-out do canal.
                    </AlertDescription>
                  </Alert>
                </>
              )}
            </div>

            <div className="space-y-4">
              {config.enabled && (
                <>
                  <h3 className="text-lg font-semibold">Templates de Lembrete</h3>
                  <p className="text-sm text-gray-600">
                    Personalize usando: [NOME_EMPRESA], [NOME_AVALIACAO], [LINK], [PRAZO]
                  </p>

                  {config.channels.includes('email') && (
                    <Card>
                      <CardContent className="p-4 space-y-3">
                        <div className="flex items-center gap-2 text-blue-600">
                          <Mail className="w-5 h-5" />
                          <span className="font-semibold">E-mail</span>
                        </div>
                        <div>
                          <Label htmlFor="email-subject">Assunto</Label>
                          <Input
                            id="email-subject"
                            value={templates.email_subject}
                            onChange={(e) => setTemplates({...templates, email_subject: e.target.value})}
                          />
                        </div>
                        <div>
                          <Label htmlFor="email-body">Corpo</Label>
                          <Textarea
                            id="email-body"
                            rows={5}
                            value={templates.email_body}
                            onChange={(e) => setTemplates({...templates, email_body: e.target.value})}
                          />
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {config.channels.includes('sms') && (
                    <Card>
                      <CardContent className="p-4 space-y-3">
                        <div className="flex items-center gap-2 text-orange-600">
                          <Phone className="w-5 h-5" />
                          <span className="font-semibold">SMS</span>
                        </div>
                        <div>
                          <Label htmlFor="sms-template">Mensagem</Label>
                          <Textarea
                            id="sms-template"
                            rows={3}
                            value={templates.sms}
                            onChange={(e) => setTemplates({...templates, sms: e.target.value})}
                            maxLength={160}
                          />
                          <p className="text-xs text-gray-500 mt-1">{templates.sms.length}/160</p>
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {config.channels.includes('whatsapp') && (
                    <Card>
                      <CardContent className="p-4 space-y-3">
                        <div className="flex items-center gap-2 text-green-600">
                          <MessageSquare className="w-5 h-5" />
                          <span className="font-semibold">WhatsApp</span>
                        </div>
                        <div>
                          <Label htmlFor="whatsapp-template">Mensagem</Label>
                          <Textarea
                            id="whatsapp-template"
                            rows={4}
                            value={templates.whatsapp}
                            onChange={(e) => setTemplates({...templates, whatsapp: e.target.value})}
                          />
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  <Alert className="bg-yellow-50 border-yellow-200">
                    <AlertDescription className="text-yellow-900 text-sm">
                      <strong>LGPD:</strong> Os dados são minimizados e protegidos. Métricas são agregadas e anônimas. Opt-out será respeitado por canal.
                    </AlertDescription>
                  </Alert>
                </>
              )}
            </div>
          </div>
        </div>

        <div className="border-t p-4 bg-white flex-shrink-0">
          <div className="flex items-center justify-between gap-3">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>

            <Button
              className="bg-blue-600 hover:bg-blue-700"
              onClick={handleSave}
              disabled={saving}
            >
              {saving ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Salvando...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  Salvar Agendamento
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}