
import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Send, Building2, Users, ArrowRight, ArrowLeft, AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

const QUESTIONNAIRES = [
  {
    id: 'PHQ-9',
    name: 'PHQ-9',
    fullName: 'Questionário de Depressão',
    description: '9 itens sobre sintomas depressivos nas últimas 2 semanas',
    type: 'Saúde Mental',
    duration: '2-3 min',
    enabled: true
  },
  {
    id: 'GAD-7',
    name: 'GAD-7',
    fullName: 'Questionário de Ansiedade',
    description: '7 itens sobre sintomas de ansiedade generalizada',
    type: 'Saúde Mental',
    duration: '2 min',
    enabled: true
  },
  {
    id: 'PRIMA-EF',
    name: 'PRIMA-EF',
    fullName: 'Avaliação de Riscos Psicossociais NR-01',
    description: '30 itens sobre fatores de risco psicossocial no trabalho',
    type: 'Riscos Psicossociais',
    duration: '8-10 min',
    enabled: true
  },
  {
    id: 'HSE-IT',
    name: 'HSE-IT',
    fullName: 'Health and Safety Executive Indicator Tool',
    description: '35 itens sobre 7 dimensões de riscos psicossociais',
    type: 'Riscos Psicossociais',
    duration: '10-12 min',
    enabled: true
  },
  {
    id: 'JCQ',
    name: 'JCQ',
    fullName: 'Job Content Questionnaire',
    description: '22 itens sobre demanda, controle e apoio social',
    type: 'Riscos Psicossociais',
    duration: '6-8 min',
    enabled: true
  },
  {
    id: 'COPSOQ',
    name: 'COPSOQ',
    fullName: 'Copenhagen Psychosocial Questionnaire',
    description: 'Questionário abrangente de fatores psicossociais (em breve)',
    type: 'Riscos Psicossociais',
    duration: '15-20 min',
    enabled: false
  }
];

export default function NewAssessmentDialog({ 
  open, 
  onOpenChange, 
  employees, 
  departments,
  onSubmit,
  isSubmitting 
}) {
  const [step, setStep] = useState(1);
  const [assessmentName, setAssessmentName] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState('all');
  const [selectedEmployees, setSelectedEmployees] = useState([]);
  const [selectedQuestionnaires, setSelectedQuestionnaires] = useState([]);
  const [sendEmails, setSendEmails] = useState(false); // Alterado para false por padrão

  React.useEffect(() => {
    if (open) {
      setStep(1);
      setAssessmentName('');
      setDueDate('');
      setSelectedDepartment('all');
      setSelectedEmployees([]);
      setSelectedQuestionnaires([]);
      setSendEmails(false); // Reset to false when opening
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    
    return () => {
      document.body.style.overflow = '';
    };
  }, [open]);

  const filteredEmployees = selectedDepartment === 'all' 
    ? employees 
    : employees.filter(e => e.department_id === selectedDepartment);

  const handleSelectAll = () => {
    if (selectedEmployees.length === filteredEmployees.length) {
      setSelectedEmployees([]);
    } else {
      setSelectedEmployees(filteredEmployees.map(e => e.id));
    }
  };

  const handleEmployeeToggle = (employeeId) => {
    setSelectedEmployees(prev => 
      prev.includes(employeeId)
        ? prev.filter(id => id !== employeeId)
        : [...prev, employeeId]
    );
  };

  const handleQuestionnaireToggle = (questionnaireId) => {
    setSelectedQuestionnaires(prev =>
      prev.includes(questionnaireId)
        ? prev.filter(id => id !== questionnaireId)
        : [...prev, questionnaireId]
    );
  };

  const handleSubmit = () => {
    const selectedEmployeeData = employees.filter(e => 
      selectedEmployees.includes(e.id)
    );
    
    onSubmit({
      assessmentName,
      selectedQuestionnaires,
      selectedEmployees: selectedEmployeeData,
      dueDate,
      sendEmails
    });
  };

  const canProceedStep1 = assessmentName.trim().length > 0;
  const canProceedStep2 = selectedEmployees.length > 0;
  const canSubmit = selectedQuestionnaires.length > 0 && selectedEmployees.length > 0;

  const getTotalDuration = () => {
    let min = 0;
    let max = 0;
    selectedQuestionnaires.forEach(id => {
      const q = QUESTIONNAIRES.find(quest => quest.id === id);
      if (q && q.enabled) {
        const [minTime, maxTime] = q.duration.split('-').map(t => parseInt(t));
        min += minTime;
        max += maxTime || minTime;
      }
    });
    return `${min}-${max} min`;
  };

  const getValidationMessage = () => {
    if (step === 3) {
      if (selectedQuestionnaires.length === 0) return "Selecione ao menos um questionário.";
      if (selectedEmployees.length === 0) return "Nenhum colaborador selecionado.";
    }
    return null;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent 
        className="p-0 gap-0 flex flex-col overflow-hidden"
        style={{ 
          maxWidth: '840px', 
          width: '100%', 
          maxHeight: '92vh',
          borderRadius: '12px'
        }}
      >
        {/* MODAL HEADER */}
        <div className="px-5 py-4 border-b border-gray-200 flex-shrink-0">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold">Nova Avaliação</DialogTitle>
            <DialogDescription className="text-sm text-gray-600 mt-1">
              {step === 1 && 'Defina as informações básicas da avaliação'}
              {step === 2 && 'Selecione os colaboradores que receberão a avaliação'}
              {step === 3 && 'Escolha os questionários e revise antes de enviar'}
            </DialogDescription>
          </DialogHeader>
          
          <div className="flex items-center justify-center mt-4">
            <div className="flex items-center gap-2">
              <button
                onClick={() => step > 1 && !isSubmitting && setStep(1)}
                disabled={isSubmitting}
                className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${
                  step >= 1 ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-500'
                } ${step > 1 && !isSubmitting ? 'cursor-pointer hover:bg-blue-700' : ''}`}
              >
                1
              </button>
              <div className={`w-16 h-1 transition-colors ${step >= 2 ? 'bg-blue-600' : 'bg-gray-200'}`} />
              <button
                onClick={() => step > 2 && canProceedStep1 && !isSubmitting && setStep(2)}
                disabled={isSubmitting || !canProceedStep1}
                className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${
                  step >= 2 ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-500'
                } ${step > 2 && canProceedStep1 && !isSubmitting ? 'cursor-pointer hover:bg-blue-700' : ''}`}
              >
                2
              </button>
              <div className={`w-16 h-1 transition-colors ${step >= 3 ? 'bg-blue-600' : 'bg-gray-200'}`} />
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 3 ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-500'}`}>
                3
              </div>
            </div>
          </div>
        </div>

        {/* MODAL BODY (ROLÁVEL) */}
        <div 
          className="flex-1 overflow-y-auto px-5 py-4"
          style={{ minHeight: 0, paddingBottom: '72px' }}
        >
          {step === 1 && (
            <div className="space-y-6">
              <div className="space-y-3">
                <Label htmlFor="assessmentName">Nome da Avaliação *</Label>
                <Input
                  id="assessmentName"
                  value={assessmentName}
                  onChange={(e) => setAssessmentName(e.target.value)}
                  placeholder="Ex: Avaliação de Riscos Psicossociais - Janeiro 2025"
                  className="text-base"
                />
                <p className="text-xs text-gray-500">
                  Este nome será usado para identificar a avaliação internamente
                </p>
              </div>

              <div className="space-y-3">
                <Label htmlFor="dueDate">Prazo de Resposta (opcional)</Label>
                <Input
                  id="dueDate"
                  type="date"
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  min={new Date().toISOString().split('T')[0]}
                />
                <p className="text-xs text-gray-500">
                  Define uma data limite para resposta (recomendado: 30 dias)
                </p>
              </div>

              <div className="space-y-3">
                <Label>Filtrar por Departamento</Label>
                <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4" />
                        Todos os Departamentos
                      </div>
                    </SelectItem>
                    {departments.map(dept => (
                      <SelectItem key={dept.id} value={dept.id}>
                        <div className="flex items-center gap-2">
                          <Building2 className="w-4 h-4" />
                          {dept.name}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label>Colaboradores * ({selectedEmployees.length} selecionados)</Label>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={handleSelectAll}
                >
                  {selectedEmployees.length === filteredEmployees.length ? 'Desmarcar Todos' : 'Selecionar Todos'}
                </Button>
              </div>
              
              <div className="space-y-3">
                {filteredEmployees.length === 0 ? (
                  <div className="text-center py-12 text-gray-500">
                    Nenhum colaborador encontrado
                  </div>
                ) : (
                  filteredEmployees.map(employee => (
                    <div 
                      key={employee.id}
                      className="flex items-center gap-3 p-3 hover:bg-gray-50 rounded-lg transition-colors cursor-pointer border"
                      onClick={() => handleEmployeeToggle(employee.id)}
                    >
                      <Checkbox
                        checked={selectedEmployees.includes(employee.id)}
                        onCheckedChange={() => handleEmployeeToggle(employee.id)}
                      />
                      <div className="flex-1">
                        <p className="font-medium">{employee.name}</p>
                        <p className="text-sm text-gray-500">{employee.email}</p>
                      </div>
                      {employee.position && (
                        <Badge variant="outline" className="text-xs">
                          {employee.position}
                        </Badge>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
              {/* Validação dentro do Body */}
              {getValidationMessage() && (
                <Alert className="bg-yellow-50 border-yellow-200">
                  <AlertDescription className="text-yellow-800">
                    ⚠️ {getValidationMessage()}
                  </AlertDescription>
                </Alert>
              )}

              {/* Lista de Questionários */}
              <div className="space-y-4">
                <Label className="text-base font-semibold">Questionários * (selecione ao menos um)</Label>
                <div className="grid gap-3">
                  {QUESTIONNAIRES.map(q => (
                    <div
                      key={q.id}
                      className={`border rounded-lg p-4 transition-all ${
                        !q.enabled 
                          ? 'bg-gray-50 opacity-60 cursor-not-allowed' 
                          : selectedQuestionnaires.includes(q.id)
                            ? 'border-blue-500 bg-blue-50 cursor-pointer'
                            : 'hover:border-gray-400 cursor-pointer'
                      }`}
                      onClick={() => q.enabled && handleQuestionnaireToggle(q.id)}
                    >
                      <div className="flex items-start gap-3">
                        {q.enabled && (
                          <Checkbox
                            checked={selectedQuestionnaires.includes(q.id)}
                            onCheckedChange={() => handleQuestionnaireToggle(q.id)}
                            className="mt-1"
                          />
                        )}
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1 flex-wrap">
                            <h4 className="font-semibold">{q.name}</h4>
                            <Badge variant="outline" className="text-xs">
                              {q.type}
                            </Badge>
                            <Badge variant="secondary" className="text-xs">
                              {q.duration}
                            </Badge>
                            {!q.enabled && (
                              <Badge className="bg-yellow-100 text-yellow-800 text-xs">
                                Em Breve
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm font-medium text-gray-700">{q.fullName}</p>
                          <p className="text-sm text-gray-600 mt-1">{q.description}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Divider */}
              <div className="border-t my-6"></div>

              {/* Resumo */}
              <div className="space-y-3">
                <h3 className="font-semibold text-gray-900 text-base">Resumo da Avaliação</h3>
                <div className="grid grid-cols-2 gap-4 text-sm bg-gray-50 p-4 rounded-lg">
                  <div>
                    <p className="text-gray-600">Nome:</p>
                    <p className="font-medium">{assessmentName}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Colaboradores:</p>
                    <p className="font-medium">{selectedEmployees.length}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Questionários:</p>
                    <p className="font-medium">{selectedQuestionnaires.length}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Tempo estimado:</p>
                    <p className="font-medium">{selectedQuestionnaires.length > 0 ? getTotalDuration() : '-'}</p>
                  </div>
                  {dueDate && (
                    <div className="col-span-2">
                      <p className="text-gray-600">Prazo:</p>
                      <p className="font-medium">{new Date(dueDate).toLocaleDateString('pt-BR')}</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Opção de envio de emails - ATUALIZADO */}
              <div className="space-y-3">
                <div className="flex items-start gap-3 p-4 bg-purple-50 rounded-lg border-2" style={{ borderColor: '#A77BCA' }}>
                  <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: '#5E2C91' }} />
                  <div className="flex-1">
                    <p className="font-semibold mb-1" style={{ color: '#5E2C91' }}>
                      📧 Link Único de Acesso
                    </p>
                    <p className="text-sm" style={{ color: '#5E2C91' }}>
                      Todos os colaboradores usarão o mesmo link: <strong>{window.location.origin}/Responder</strong>
                      <br />
                      Cada um acessa com seu próprio CPF e data de nascimento.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg border">
                  <Checkbox
                    id="send-emails"
                    checked={sendEmails}
                    onCheckedChange={setSendEmails}
                  />
                  <div className="flex-1">
                    <Label htmlFor="send-emails" className="cursor-pointer font-medium">
                      Enviar convites por e-mail
                    </Label>
                    <p className="text-xs text-gray-600 mt-1">
                      Os colaboradores receberão um e-mail com instruções e o link de acesso.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* MODAL FOOTER (FIXO) */}
        <div 
          className="border-t border-gray-200 bg-white px-5 py-3 flex-shrink-0"
          style={{ position: 'sticky', bottom: 0, zIndex: 2 }}
        >
          <div className="flex justify-between items-center gap-3">
            <div>
              {step > 1 && (
                <Button 
                  variant="outline" 
                  onClick={() => setStep(step - 1)}
                  disabled={isSubmitting}
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Voltar
                </Button>
              )}
            </div>
            
            <div className="flex gap-3">
              <Button 
                variant="outline" 
                onClick={() => onOpenChange(false)}
                disabled={isSubmitting}
              >
                Cancelar
              </Button>
              
              {step < 3 ? (
                <Button 
                  className="bg-blue-600 hover:bg-blue-700 min-w-[160px]"
                  onClick={() => setStep(step + 1)}
                  disabled={
                    (step === 1 && !canProceedStep1) || 
                    (step === 2 && !canProceedStep2)
                  }
                >
                  Próximo
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              ) : (
                <Button 
                  className="bg-blue-600 hover:bg-blue-700 min-w-[160px]"
                  onClick={handleSubmit}
                  disabled={!canSubmit || isSubmitting}
                >
                  {isSubmitting ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                      Enviando...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4 mr-2" />
                      Gerar e {sendEmails ? 'Enviar' : 'Criar'}
                    </>
                  )}
                </Button>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
