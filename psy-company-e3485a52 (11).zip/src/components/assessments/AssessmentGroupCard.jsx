import React, { useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  ChevronDown,
  ChevronUp,
  Calendar,
  Users,
  FileText,
  Clock,
  BarChart3,
  Link as LinkIcon,
  Download,
  Bell,
  Copy,
  CheckCircle
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { format, parseISO } from "date-fns";
import { toast } from "sonner";

export default function AssessmentGroupCard({ 
  group, 
  employees, 
  departments, 
  company,
  onConfigureReminders,
  onViewReport 
}) {
  const [expanded, setExpanded] = useState(false);
  const [copied, setCopied] = useState(false);

  const total = group.assessments.length;
  const completed = group.assessments.filter(a => a.completed_at).length;
  const pending = total - completed;
  const responseRate = total > 0 ? ((completed / total) * 100).toFixed(0) : 0;

  const getStatusBadge = () => {
    if (completed === 0) return <Badge className="bg-gray-100 text-gray-800">⚪ Aguardando Início</Badge>;
    if (completed === total) return <Badge className="bg-blue-100 text-blue-800">🔵 Concluída</Badge>;
    return <Badge className="bg-green-100 text-green-800">🟢 Em Andamento</Badge>;
  };

  const getEmployeeName = (employeeId) => {
    const employee = employees.find(e => e.id === employeeId);
    return employee?.name || 'Desconhecido';
  };

  const getDepartmentName = (departmentId) => {
    const department = departments.find(d => d.id === departmentId);
    return department?.name || '-';
  };

  const handleCopyLink = async () => {
    const link = `${window.location.origin}/Responder`;
    
    try {
      await navigator.clipboard.writeText(link);
      setCopied(true);
      toast.success('Link copiado. Compartilhe com seus colaboradores.', {
        description: 'Colaboradores acessam com CPF + Data de Nascimento'
      });
      
      setTimeout(() => setCopied(false), 3000);
    } catch (error) {
      console.error('Erro ao copiar link:', error);
      toast.error('Não foi possível copiar o link. Tente novamente.');
    }
  };

  const handleExportCSV = () => {
    const headers = ['Colaborador', 'Departamento', 'Status', 'Data de Envio', 'Data de Resposta'];
    const rows = group.assessments.map(a => [
      getEmployeeName(a.employee_id),
      getDepartmentName(a.department_id),
      a.completed_at ? 'Respondido' : 'Pendente',
      format(parseISO(a.created_date), 'dd/MM/yyyy HH:mm'),
      a.completed_at ? format(parseISO(a.completed_at), 'dd/MM/yyyy HH:mm') : '-'
    ]);

    const csvContent = [headers, ...rows].map(row => row.join(',')).join('\n');
    const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `${group.name.replace(/[^a-z0-9]/gi, '_')}_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    
    toast.success('CSV exportado com sucesso');
  };

  const formatQuestionnaires = (type) => {
    if (!type) return [];
    return type.split(',').map(q => q.trim());
  };

  return (
    <Card className="shadow-md hover:shadow-lg transition-all">
      <CardHeader 
        className="cursor-pointer hover:bg-gray-50 transition-colors"
        style={{ borderLeft: `6px solid ${completed === total ? '#3b82f6' : completed > 0 ? '#10b981' : '#9ca3af'}` }}
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2 flex-wrap">
              <h3 className="text-xl font-bold" style={{ color: '#2B2240' }}>
                {group.name}
              </h3>
              {getStatusBadge()}
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mt-4">
              <div className="flex items-center gap-2 text-gray-600">
                <Calendar className="w-4 h-4" />
                <span>Criada em: {format(parseISO(group.created_date), 'dd/MM/yyyy HH:mm')}</span>
              </div>
              <div className="flex items-center gap-2 text-gray-600">
                <FileText className="w-4 h-4" />
                <span>Questionários: {formatQuestionnaires(group.assessment_type).join(', ')}</span>
              </div>
              <div className="flex items-center gap-2 text-gray-600">
                <Users className="w-4 h-4" />
                <span>Total: {total} colaboradores</span>
              </div>
              {group.due_date && (
                <div className="flex items-center gap-2 text-gray-600">
                  <Clock className="w-4 h-4" />
                  <span>Prazo: {format(parseISO(group.due_date), 'dd/MM/yyyy')}</span>
                </div>
              )}
            </div>

            <div className="mt-4 space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">
                  ✅ Respondidas: <strong className="text-green-600">{completed}</strong> ({responseRate}%)
                  {pending > 0 && (
                    <span className="ml-3">
                      ⏳ Pendentes: <strong className="text-orange-600">{pending}</strong> ({(100 - parseFloat(responseRate)).toFixed(0)}%)
                    </span>
                  )}
                </span>
              </div>
              <Progress value={parseFloat(responseRate)} className="h-2" />
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={(e) => {
                      e.stopPropagation();
                      onViewReport && onViewReport(group);
                    }}
                    className="hover:bg-purple-50"
                  >
                    <BarChart3 className="w-4 h-4" style={{ color: '#5E2C91' }} />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Ver Relatório</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleCopyLink();
                    }}
                    className="hover:bg-purple-50"
                  >
                    {copied ? (
                      <CheckCircle className="w-4 h-4 text-green-600" />
                    ) : (
                      <Copy className="w-4 h-4" style={{ color: '#5E2C91' }} />
                    )}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Copiar Link Único</p>
                  <p className="text-xs text-gray-500">Colaboradores acessam com CPF + Data</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleExportCSV();
                    }}
                    className="hover:bg-purple-50"
                  >
                    <Download className="w-4 h-4" style={{ color: '#5E2C91' }} />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Exportar CSV</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={(e) => {
                      e.stopPropagation();
                      onConfigureReminders && onConfigureReminders(group);
                    }}
                    className="hover:bg-purple-50"
                  >
                    <Bell className="w-4 h-4" style={{ color: '#5E2C91' }} />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Configurar Lembretes</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <Button variant="ghost" size="icon">
              {expanded ? (
                <ChevronUp className="w-5 h-5" style={{ color: '#5E2C91' }} />
              ) : (
                <ChevronDown className="w-5 h-5" style={{ color: '#5E2C91' }} />
              )}
            </Button>
          </div>
        </div>
      </CardHeader>

      {expanded && (
        <CardContent className="border-t">
          <div className="overflow-x-auto max-h-96 overflow-y-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Colaborador</TableHead>
                  <TableHead>Departamento</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Data de Envio</TableHead>
                  <TableHead>Data de Resposta</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {group.assessments.map((assessment) => (
                  <TableRow key={assessment.id}>
                    <TableCell className="font-medium">
                      {getEmployeeName(assessment.employee_id)}
                    </TableCell>
                    <TableCell>{getDepartmentName(assessment.department_id)}</TableCell>
                    <TableCell>
                      {assessment.completed_at ? (
                        <Badge className="bg-green-100 text-green-800">✅ Respondido</Badge>
                      ) : (
                        <Badge className="bg-orange-100 text-orange-800">⏳ Pendente</Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-sm text-gray-600">
                      {format(parseISO(assessment.created_date), 'dd/MM/yyyy HH:mm')}
                    </TableCell>
                    <TableCell className="text-sm text-gray-600">
                      {assessment.completed_at 
                        ? format(parseISO(assessment.completed_at), 'dd/MM/yyyy HH:mm')
                        : '-'
                      }
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      )}
    </Card>
  );
}