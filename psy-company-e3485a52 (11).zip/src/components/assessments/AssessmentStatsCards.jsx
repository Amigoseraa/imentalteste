import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Send, CheckCircle, Clock, TrendingUp, Calendar } from "lucide-react";

export default function AssessmentStatsCards({ assessments, employees, assessmentGroups }) {
  const completedAssessments = assessments.filter(a => a.completed_at);
  const pendingAssessments = assessments.filter(a => !a.completed_at);
  const activeGroups = assessmentGroups.filter(g => 
    g.assessments.some(a => !a.completed_at)
  );
  
  const responseRate = assessments.length > 0 
    ? ((completedAssessments.length / assessments.length) * 100).toFixed(1)
    : 0;

  const lastAssessmentDate = assessmentGroups.length > 0
    ? new Date(assessmentGroups[0].created_date).toLocaleDateString('pt-BR')
    : 'Nenhuma';

  // IBC Médio (se disponível)
  const ibcValues = assessments
    .filter(a => a.ibc_score)
    .map(a => a.ibc_score);
  const avgIBC = ibcValues.length > 0
    ? (ibcValues.reduce((sum, val) => sum + val, 0) / ibcValues.length).toFixed(1)
    : null;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
      <Card className="shadow-md hover:shadow-lg transition-shadow" style={{ borderTop: '4px solid #5E2C91' }}>
        <CardContent className="pt-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ backgroundColor: '#EFE6F8' }}>
              <Send className="w-6 h-6" style={{ color: '#5E2C91' }} />
            </div>
            <div>
              <p className="text-sm text-gray-600">Avaliações Criadas</p>
              <p className="text-2xl font-bold" style={{ color: '#2B2240' }}>
                {assessmentGroups.length}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="shadow-md hover:shadow-lg transition-shadow" style={{ borderTop: '4px solid #10b981' }}>
        <CardContent className="pt-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-green-50 rounded-xl flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Taxa de Resposta</p>
              <p className="text-2xl font-bold text-green-600">
                {responseRate}%
              </p>
              <p className="text-xs text-gray-500">{completedAssessments.length}/{assessments.length}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="shadow-md hover:shadow-lg transition-shadow" style={{ borderTop: '4px solid #f59e0b' }}>
        <CardContent className="pt-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-orange-50 rounded-xl flex items-center justify-center">
              <Clock className="w-6 h-6 text-orange-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Avaliações Ativas</p>
              <p className="text-2xl font-bold text-orange-600">
                {activeGroups.length}
              </p>
              <p className="text-xs text-gray-500">{pendingAssessments.length} pendentes</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="shadow-md hover:shadow-lg transition-shadow" style={{ borderTop: '4px solid #6366f1' }}>
        <CardContent className="pt-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-indigo-50 rounded-xl flex items-center justify-center">
              <Calendar className="w-6 h-6 text-indigo-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Último Envio</p>
              <p className="text-base font-bold text-indigo-600">
                {lastAssessmentDate}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {avgIBC && (
        <Card className="shadow-md hover:shadow-lg transition-shadow" style={{ borderTop: '4px solid #A77BCA' }}>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ backgroundColor: '#EFE6F8' }}>
                <TrendingUp className="w-6 h-6" style={{ color: '#A77BCA' }} />
              </div>
              <div>
                <p className="text-sm text-gray-600">IBC Médio</p>
                <p className="text-2xl font-bold" style={{ color: '#A77BCA' }}>
                  {avgIBC}
                </p>
                <p className="text-xs text-gray-500">Índice de Bem-Estar</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}