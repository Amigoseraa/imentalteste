import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle, Heart, Shield } from "lucide-react";

export default function CompletionScreen({ company, completedAt }) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-gray-100 flex items-center justify-center p-4">
      <Card className="max-w-2xl w-full shadow-xl">
        <CardContent className="p-12 text-center">
          <div className="mb-6">
            <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-12 h-12 text-green-600" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Avaliação Concluída!
            </h1>
            <p className="text-gray-600 text-lg">
              Obrigado por contribuir para um ambiente de trabalho mais saudável
            </p>
          </div>

          <div className="bg-gray-50 rounded-xl p-6 mb-6">
            <p className="text-sm text-gray-600 mb-2">Respondido em:</p>
            <p className="text-lg font-semibold text-gray-900">
              {completedAt.toLocaleDateString('pt-BR')} às {completedAt.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
            </p>
          </div>

          <div className="space-y-4 text-left bg-blue-50 rounded-xl p-6">
            <div className="flex items-start gap-3">
              <Shield className="w-6 h-6 text-blue-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-semibold text-gray-900 mb-1">Suas respostas são confidenciais</h3>
                <p className="text-sm text-gray-600">
                  Nenhuma informação individual será compartilhada. Os dados são usados apenas para melhorias organizacionais.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Heart className="w-6 h-6 text-blue-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-semibold text-gray-900 mb-1">Apoio sempre disponível</h3>
                <p className="text-sm text-gray-600">
                  Se você estiver passando por dificuldades emocionais, não hesite em buscar ajuda profissional. 
                  CVV (188) disponível 24h.
                </p>
              </div>
            </div>
          </div>

          <p className="text-sm text-gray-500 mt-8">
            Você pode fechar esta janela agora.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}