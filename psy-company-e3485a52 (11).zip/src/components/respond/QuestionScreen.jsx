import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, ArrowRight, Volume2 } from "lucide-react";

export default function QuestionScreen({ question, questionnaire, onAnswer, onPrevious, canGoPrevious }) {
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [showError, setShowError] = useState(false);

  const handleNext = () => {
    if (selectedAnswer !== null) {
      onAnswer(selectedAnswer);
      setSelectedAnswer(null);
      setShowError(false);
    } else {
      setShowError(true);
    }
  };

  const handleSpeak = () => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(question.text);
      utterance.lang = 'pt-BR';
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <Card className="shadow-xl">
      <CardContent className="p-8 md:p-12">
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-4">
            <Badge className="bg-blue-600">{questionnaire}</Badge>
            {question.category && (
              <Badge variant="outline">{question.category}</Badge>
            )}
          </div>
          
          <div className="flex items-start gap-4">
            <h2 className="text-2xl md:text-3xl font-semibold text-gray-900 leading-relaxed flex-1">
              {question.text}
            </h2>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleSpeak}
              className="flex-shrink-0"
              title="Ouvir pergunta"
            >
              <Volume2 className="w-5 h-5" />
            </Button>
          </div>
        </div>

        <div className="space-y-3 mb-6">
          {question.scale.map((option) => (
            <button
              key={option.value}
              onClick={() => {
                setSelectedAnswer(option.value);
                setShowError(false);
              }}
              className={`w-full p-4 md:p-6 text-left rounded-xl border-2 transition-all ${
                selectedAnswer === option.value
                  ? 'border-blue-600 bg-blue-50 shadow-md'
                  : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
              }`}
            >
              <div className="flex items-center gap-4">
                <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${
                  selectedAnswer === option.value
                    ? 'border-blue-600 bg-blue-600'
                    : 'border-gray-300'
                }`}>
                  {selectedAnswer === option.value && (
                    <div className="w-3 h-3 bg-white rounded-full" />
                  )}
                </div>
                <span className="text-lg font-medium text-gray-900">{option.label}</span>
              </div>
            </button>
          ))}
        </div>

        {showError && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
            <p className="text-red-800 text-sm font-medium">
              Por favor, selecione uma resposta para continuar
            </p>
          </div>
        )}

        <div className="flex gap-3">
          {canGoPrevious && (
            <Button
              variant="outline"
              onClick={onPrevious}
              className="flex-1 py-6 text-lg"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Voltar
            </Button>
          )}
          <Button
            onClick={handleNext}
            className={`${canGoPrevious ? 'flex-1' : 'w-full'} bg-blue-600 hover:bg-blue-700 py-6 text-lg`}
          >
            Próxima
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}