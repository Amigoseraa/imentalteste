import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Shield, CheckCircle } from "lucide-react";

export default function ConsentTerm({ company, onAccept, onDecline }) {
  const [accepted, setAccepted] = useState(false);
  const [scrolledToBottom, setScrolledToBottom] = useState(false);

  const handleScroll = (e) => {
    const bottom = e.target.scrollHeight - e.target.scrollTop <= e.target.clientHeight + 50;
    if (bottom) {
      setScrolledToBottom(true);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-gray-100 p-4 py-8">
      <div className="max-w-4xl mx-auto">
        <Card className="shadow-xl">
          <CardHeader className="border-b bg-gradient-to-r from-blue-600 to-blue-700 text-white">
            <div className="flex items-center gap-3">
              <Shield className="w-8 h-8" />
              <div>
                <CardTitle className="text-2xl">Termo de Consentimento e Condições de Participação</CardTitle>
                <p className="text-blue-100 text-sm mt-1">PsyCompany – {company?.name || 'Plataforma de Saúde Mental e Riscos Psicossociais'}</p>
              </div>
            </div>
          </CardHeader>
          
          <CardContent className="p-0">
            <div 
              className="p-6 md:p-8 max-h-[60vh] overflow-y-auto space-y-6 text-gray-700 leading-relaxed"
              style={{ fontSize: '16px', lineHeight: '1.6' }}
              onScroll={handleScroll}
            >
              <section>
                <h3 className="font-bold text-lg text-gray-900 mb-2">1. Finalidade da Avaliação</h3>
                <p>
                  Esta avaliação faz parte do programa de Saúde Mental e Riscos Psicossociais conduzido pela PsyCompany, conforme as diretrizes da Norma Regulamentadora NR-01.
                  O objetivo é identificar, de forma anônima e estatística, fatores que impactam o bem-estar e o ambiente de trabalho.
                </p>
              </section>

              <section>
                <h3 className="font-bold text-lg text-gray-900 mb-2">2. Confidencialidade e Privacidade</h3>
                <p>
                  Todas as respostas são confidenciais e tratadas de forma agregada, sem qualquer identificação pessoal.
                  A PsyCompany segue integralmente a Lei Geral de Proteção de Dados Pessoais (LGPD – Lei 13.709/2018).
                </p>
                <p className="mt-2">
                  Nenhuma resposta individual é acessível por gestores, líderes ou colegas.
                  Relatórios são apresentados apenas em grupos com mínimo de 5 respondentes, para garantir o anonimato.
                </p>
              </section>

              <section>
                <h3 className="font-bold text-lg text-gray-900 mb-2">3. Voluntariedade</h3>
                <p>
                  A participação é voluntária. Você pode deixar perguntas em branco ou sair a qualquer momento, sem prejuízo profissional.
                </p>
              </section>

              <section>
                <h3 className="font-bold text-lg text-gray-900 mb-2">4. Uso dos Dados</h3>
                <p>Os dados coletados são utilizados para:</p>
                <ul className="list-disc list-inside ml-4 mt-2 space-y-1">
                  <li>Gerar indicadores corporativos de saúde mental e riscos psicossociais</li>
                  <li>Promover melhorias organizacionais</li>
                  <li>Apoiar pesquisas científicas anônimas para aprimorar práticas de saúde ocupacional</li>
                </ul>
                <p className="mt-2">
                  Os resultados são consolidados por área e nunca expõem indivíduos.
                </p>
              </section>

              <section>
                <h3 className="font-bold text-lg text-gray-900 mb-2">5. Proteção de Dados Sensíveis</h3>
                <p>
                  As informações relacionadas à sua saúde emocional são classificadas como dados sensíveis.
                  A PsyCompany adota medidas técnicas e organizacionais rigorosas de segurança digital e acesso restrito.
                  Nenhum dado é compartilhado com terceiros não autorizados.
                </p>
              </section>

              <section>
                <h3 className="font-bold text-lg text-gray-900 mb-2">6. Comunicação de Apoio</h3>
                <p>
                  Caso uma resposta indique risco elevado (por exemplo, sintomas severos de ansiedade ou ideação suicida), 
                  o sistema exibirá automaticamente uma mensagem empática e contatos de ajuda, como o CVV (188) e canais internos de apoio emocional, sem identificação individual.
                </p>
              </section>

              <section>
                <h3 className="font-bold text-lg text-gray-900 mb-2">7. Direitos do Participante</h3>
                <p>
                  Conforme a LGPD, você pode solicitar informações sobre o tratamento de seus dados pessoais pelo canal: <strong>lgpd@psycompany.com.br</strong>.
                  Você pode também solicitar a exclusão de seus dados identificáveis a qualquer momento.
                </p>
              </section>

              <section>
                <h3 className="font-bold text-lg text-gray-900 mb-2">8. Armazenamento</h3>
                <p>
                  Os dados ficam armazenados por até 24 meses em ambiente seguro e criptografado, e depois são anonimizados para fins estatísticos.
                </p>
              </section>

              <section>
                <h3 className="font-bold text-lg text-gray-900 mb-2">9. Consentimento</h3>
                <p>
                  Ao clicar em "Concordo e Iniciar Avaliação", você declara ter lido e compreendido este Termo, consentindo livremente com o tratamento das informações para as finalidades descritas.
                </p>
              </section>
            </div>

            <div className="border-t bg-gray-50 p-6 sticky bottom-0">
              <div className="flex items-start gap-3 mb-4">
                <Checkbox
                  id="consent"
                  checked={accepted}
                  onCheckedChange={setAccepted}
                  disabled={!scrolledToBottom}
                />
                <label htmlFor="consent" className="text-sm font-medium leading-relaxed cursor-pointer">
                  Li e concordo com os Termos e Condições de Participação
                  {!scrolledToBottom && (
                    <span className="block text-xs text-gray-500 mt-1">
                      Role até o final para habilitar
                    </span>
                  )}
                </label>
              </div>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={onDecline}
                  className="flex-1"
                >
                  Não Concordo
                </Button>
                <Button
                  onClick={onAccept}
                  disabled={!accepted}
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Concordo e Iniciar Avaliação
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}