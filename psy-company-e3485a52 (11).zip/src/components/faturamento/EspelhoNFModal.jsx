import React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Download, Printer } from "lucide-react";
import { format } from "date-fns";

export default function EspelhoNFModal({ open, onClose, data }) {
  if (!data) return null;

  const formatCurrency = (value) => {
    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPDF = () => {
    // Aqui você integraria com biblioteca de geração de PDF
    // Por enquanto, apenas simula o download
    alert('Funcionalidade de download PDF em desenvolvimento');
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">Espelho de Nota Fiscal</DialogTitle>
          <DialogDescription>
            Documento espelho de faturamento - Não substitui a Nota Fiscal oficial
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 print:space-y-4">
          {/* Cabeçalho */}
          <div className="border-b pb-4">
            <div className="grid grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-gray-600 text-sm mb-2">Emitente (Consultoria)</h3>
                <p className="font-bold text-lg" style={{ color: '#4B2672' }}>
                  {data.consultoria}
                </p>
              </div>
              <div className="text-right">
                <h3 className="font-semibold text-gray-600 text-sm mb-2">Competência</h3>
                <p className="font-bold text-lg">
                  {format(new Date(data.competencia + '-01'), 'MMMM/yyyy')}
                </p>
              </div>
            </div>
          </div>

          {/* Dados da Empresa */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-semibold text-gray-700 mb-3">Dados do Tomador (Empresa)</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-600">Razão Social</p>
                <p className="font-semibold">{data.empresa}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">CNPJ</p>
                <p className="font-semibold">{data.cnpj}</p>
              </div>
            </div>
          </div>

          {/* Base de Cálculo */}
          <div>
            <h3 className="font-semibold text-gray-700 mb-3">Base de Cálculo</h3>
            <div className="border rounded-lg overflow-hidden">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="text-left p-3 text-sm font-semibold text-gray-700">Descrição</th>
                    <th className="text-right p-3 text-sm font-semibold text-gray-700">Quantidade</th>
                    <th className="text-right p-3 text-sm font-semibold text-gray-700">Valor Unitário</th>
                    <th className="text-right p-3 text-sm font-semibold text-gray-700">Subtotal</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-t">
                    <td className="p-3">
                      <p className="font-medium">{data.base}</p>
                      <p className="text-xs text-gray-500">Modelo: {data.modelo.replace(/_/g, ' ')}</p>
                    </td>
                    <td className="p-3 text-right">{data.base_quantidade || 1}</td>
                    <td className="p-3 text-right">{formatCurrency(data.preco_unitario)}</td>
                    <td className="p-3 text-right font-semibold">{formatCurrency(data.valor_bruto)}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Resumo Financeiro */}
          <div className="bg-gray-50 p-6 rounded-lg">
            <h3 className="font-semibold text-gray-700 mb-4">Resumo Financeiro</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Valor Bruto</span>
                <span className="font-semibold text-lg">{formatCurrency(data.valor_bruto)}</span>
              </div>
              
              {data.desconto_percent > 0 && (
                <div className="flex justify-between items-center text-red-600">
                  <span>Desconto ({data.desconto_percent}%)</span>
                  <span className="font-semibold">- {formatCurrency(data.descontos)}</span>
                </div>
              )}
              
              <div className="border-t pt-3 flex justify-between items-center">
                <span className="text-lg font-bold text-gray-800">Valor Líquido</span>
                <span className="text-2xl font-bold" style={{ color: '#00B37E' }}>
                  {formatCurrency(data.valor_liquido)}
                </span>
              </div>

              <div className="flex justify-between items-center mt-4 pt-4 border-t">
                <span className="text-gray-600">Vencimento</span>
                <span className="font-bold text-lg">
                  {format(new Date(data.vencimento), 'dd/MM/yyyy')}
                </span>
              </div>
            </div>
          </div>

          {/* Observações */}
          <div className="text-xs text-gray-500 border-t pt-4">
            <p className="mb-1">
              <strong>Observações Importantes:</strong>
            </p>
            <ul className="list-disc list-inside space-y-1">
              <li>Este documento é um espelho de faturamento e não substitui a Nota Fiscal oficial.</li>
              <li>A NF-e será enviada após a confirmação do pagamento ou conforme cronograma fiscal.</li>
              <li>Valores calculados automaticamente conforme contrato vigente entre as partes.</li>
              <li>Em caso de dúvidas, entre em contato com o departamento financeiro.</li>
            </ul>
          </div>
        </div>

        {/* Ações */}
        <div className="flex justify-end gap-3 pt-4 border-t print:hidden">
          <Button variant="outline" onClick={handlePrint}>
            <Printer className="w-4 h-4 mr-2" />
            Imprimir
          </Button>
          <Button 
            onClick={handleDownloadPDF}
            style={{ backgroundColor: '#4B2672', color: 'white' }}
          >
            <Download className="w-4 h-4 mr-2" />
            Baixar PDF
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}