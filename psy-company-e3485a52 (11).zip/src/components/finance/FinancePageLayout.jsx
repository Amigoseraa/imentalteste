import React from "react";
import FinanceSubMenu from "./FinanceSubMenu";

export default function FinancePageLayout({ children, currentPage, userRole, title, subtitle, actions }) {
  return (
    <div className="flex min-h-screen bg-gray-50">
      <FinanceSubMenu currentPage={currentPage} userRole={userRole} />
      
      <div className="flex-1 p-6 overflow-auto">
        {/* Breadcrumb */}
        <div className="mb-4">
          <p className="text-sm text-gray-500">
            Financeiro <span className="mx-2">›</span> <span className="text-purple-600 font-medium">{title}</span>
          </p>
        </div>

        {/* Header */}
        <div className="flex justify-between items-start mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{title}</h1>
            {subtitle && <p className="text-gray-600 mt-1">{subtitle}</p>}
          </div>
          {actions && <div className="flex gap-3">{actions}</div>}
        </div>

        {/* Content */}
        {children}
      </div>
    </div>
  );
}