import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";
import { formatCurrency } from "../billing/billingHelpers";

export default function FinanceKPICard({ 
  title, 
  value, 
  delta, 
  format = 'currency', 
  icon: Icon,
  colorScheme = 'purple',
  subtitle 
}) {
  const colors = {
    purple: { bg: '#F3E8FF', text: '#6B46C1', icon: '#805AD5' },
    green: { bg: '#C6F6D5', text: '#2F855A', icon: '#38A169' },
    yellow: { bg: '#FEFCBF', text: '#D69E2E', icon: '#ECC94B' },
    red: { bg: '#FED7D7', text: '#C53030', icon: '#E53E3E' },
    gray: { bg: '#E2E8F0', text: '#4A5568', icon: '#718096' }
  };

  const scheme = colors[colorScheme] || colors.purple;

  const formatValue = (val) => {
    if (format === 'currency') return formatCurrency(val);
    if (format === 'percent') return `${val.toFixed(1)}%`;
    if (format === 'days') return `${val.toFixed(0)} dias`;
    return val.toLocaleString('pt-BR');
  };

  const getDeltaIcon = () => {
    if (!delta || delta === 0) return <Minus className="w-4 h-4" />;
    if (delta > 0) return <TrendingUp className="w-4 h-4" />;
    return <TrendingDown className="w-4 h-4" />;
  };

  const getDeltaColor = () => {
    if (!delta || delta === 0) return 'text-gray-500';
    // Para receita/MRR/ARR, positivo é bom; para DSO/inadimplência, negativo é bom
    const isGoodMetric = ['mrr', 'arr', 'receita'].includes(title.toLowerCase());
    if (isGoodMetric) {
      return delta > 0 ? 'text-green-600' : 'text-red-600';
    } else {
      return delta < 0 ? 'text-green-600' : 'text-red-600';
    }
  };

  return (
    <Card className="shadow-md hover:shadow-lg transition-shadow">
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div>
            <p className="text-sm font-medium text-gray-600 mb-1">{title}</p>
            {subtitle && (
              <p className="text-xs text-gray-500">{subtitle}</p>
            )}
          </div>
          {Icon && (
            <div 
              className="p-3 rounded-xl"
              style={{ backgroundColor: scheme.bg }}
            >
              <Icon className="w-6 h-6" style={{ color: scheme.icon }} />
            </div>
          )}
        </div>
        
        <p 
          className="text-3xl font-bold mb-2"
          style={{ color: scheme.text }}
        >
          {formatValue(value)}
        </p>

        {delta !== undefined && delta !== null && (
          <div className={`flex items-center gap-1 text-sm font-semibold ${getDeltaColor()}`}>
            {getDeltaIcon()}
            <span>{Math.abs(delta).toFixed(1)}%</span>
            <span className="text-xs text-gray-500 ml-1">vs mês anterior</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}