import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Activity,
  TrendingUp,
  Clock,
  Bell,
  LineChart,
  Users,
  FileText,
  SlidersHorizontal,
  Receipt
} from "lucide-react";

const menuItems = [
  { name: 'Visão Geral', path: 'FinanceOverview', icon: Activity },
  { name: 'Receitas (MRR/ARR)', path: 'FinanceReceitas', icon: TrendingUp },
  { name: 'Recebíveis', path: 'FinanceRecebiveis', icon: Clock },
  { name: 'Cobrança', path: 'FinanceCobranca', icon: Bell },
  { name: 'Previsões', path: 'FinanceForecast', icon: LineChart },
  { name: 'Clientes', path: 'FinanceClientes', icon: Users },
  { name: 'Relatórios', path: 'FinanceRelatorios', icon: FileText },
  { name: 'Configurações', path: 'FinanceConfig', icon: SlidersHorizontal },
  { name: 'Faturamento', path: 'FaturamentoAdmin', icon: Receipt, divider: true },
];

export default function FinanceSubMenu({ currentPage, userRole }) {
  // Ajustar path de faturamento baseado no role
  const adjustedMenuItems = menuItems.map(item => {
    if (item.path === 'FaturamentoAdmin') {
      return {
        ...item,
        path: userRole === 'admin' ? 'FaturamentoAdmin' : 'FaturamentoConsultoria'
      };
    }
    return item;
  });

  return (
    <div className="w-64 bg-white border-r border-gray-200 h-[calc(100vh-4rem)] sticky top-16 overflow-y-auto">
      <div className="p-4">
        <h2 className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-4">
          Módulo Financeiro
        </h2>
        <nav className="space-y-1">
          {adjustedMenuItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.path;

            return (
              <React.Fragment key={item.path}>
                {item.divider && <div className="border-t border-gray-200 my-2" />}
                <Link
                  to={createPageUrl(item.path)}
                  className={`flex items-center px-3 py-2 text-sm font-medium rounded-md transition-all ${
                    isActive
                      ? 'bg-purple-50 text-purple-700'
                      : 'text-gray-700 hover:bg-gray-50 hover:text-purple-600'
                  }`}
                >
                  <Icon className={`w-5 h-5 mr-3 ${isActive ? 'text-purple-600' : 'text-gray-400'}`} />
                  {item.name}
                </Link>
              </React.Fragment>
            );
          })}
        </nav>
      </div>
    </div>
  );
}