import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarIcon, DollarSign } from "lucide-react";
import { format } from "date-fns";
import { formatCurrency } from "../billing/billingHelpers";

export default function PaymentModal({ recebivel, onClose, onSubmit }) {
  const [formData, setFormData] = useState({
    valor_liquido: recebivel.saldo,
    meio: 'transferencia',
    pago_em: new Date(),
    referencia: '',
    observacoes: ''
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const isPagamentoTotal = formData.valor_liquido >= recebivel.saldo;

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Registrar Pagamento</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-purple-900">Título</span>
              <span className="font-semibold text-purple-900">{recebivel.titulo_num}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-purple-900">Saldo Devedor</span>
              <span className="text-lg font-bold text-purple-600">
                {formatCurrency(recebivel.saldo)}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="valor_liquido">Valor do Pagamento *</Label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="valor_liquido"
                  type="number"
                  step="0.01"
                  min="0.01"
                  max={recebivel.saldo}
                  value={formData.valor_liquido}
                  onChange={(e) => setFormData({ ...formData, valor_liquido: parseFloat(e.target.value) })}
                  className="pl-10"
                  required
                />
              </div>
              <p className="text-xs text-gray-500 mt-1">
                {isPagamentoTotal ? 'Pagamento total (liquidação)' : 'Pagamento parcial'}
              </p>
            </div>

            <div>
              <Label htmlFor="meio">Meio de Pagamento *</Label>
              <Select value={formData.meio} onValueChange={(value) => setFormData({ ...formData, meio: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="boleto">Boleto</SelectItem>
                  <SelectItem value="pix">PIX</SelectItem>
                  <SelectItem value="transferencia">Transferência/Depósito</SelectItem>
                  <SelectItem value="cartao">Cartão</SelectItem>
                  <SelectItem value="outro">Outro</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Data do Pagamento *</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {formData.pago_em ? format(formData.pago_em, 'dd/MM/yyyy') : 'Selecione'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={formData.pago_em}
                    onSelect={(date) => setFormData({ ...formData, pago_em: date })}
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div>
              <Label htmlFor="referencia">Referência / Nº Documento</Label>
              <Input
                id="referencia"
                value={formData.referencia}
                onChange={(e) => setFormData({ ...formData, referencia: e.target.value })}
                placeholder="Ex: Comprovante 12345"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="observacoes">Observações</Label>
            <Textarea
              id="observacoes"
              value={formData.observacoes}
              onChange={(e) => setFormData({ ...formData, observacoes: e.target.value })}
              placeholder="Informações adicionais sobre o pagamento..."
              rows={3}
            />
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" className="bg-purple-600 hover:bg-purple-700 text-white">
              <DollarSign className="w-4 h-4 mr-2" />
              Registrar Pagamento
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}