import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend, BarChart, Bar, XAxis, YAxis, CartesianGrid } from "recharts";
import { Clock } from "lucide-react";
import { formatCurrency } from "../billing/billingHelpers";

export default function AgingWidget({ data, view = 'pie' }) {
  const agingData = [
    { name: '0-15 dias', value: data.bucket_0_15 || 0, color: '#48BB78' },
    { name: '16-30 dias', value: data.bucket_16_30 || 0, color: '#ECC94B' },
    { name: '31-60 dias', value: data.bucket_31_60 || 0, color: '#ED8936' },
    { name: '61-90 dias', value: data.bucket_61_90 || 0, color: '#F56565' },
    { name: '+90 dias', value: data.bucket_90_plus || 0, color: '#C53030' }
  ];

  const totalValue = agingData.reduce((acc, item) => acc + item.value, 0);

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="w-5 h-5 text-purple-600" />
          Aging de Recebíveis
        </CardTitle>
      </CardHeader>
      <CardContent>
        {totalValue > 0 ? (
          <>
            {view === 'pie' ? (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={agingData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ percent }) => `${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    dataKey="value"
                  >
                    {agingData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => formatCurrency(value)} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={agingData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                  <YAxis tickFormatter={(value) => `R$ ${(value / 1000).toFixed(0)}k`} />
                  <Tooltip formatter={(value) => formatCurrency(value)} />
                  <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                    {agingData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
            <div className="mt-4 text-center">
              <p className="text-sm text-gray-600">
                Total em aberto: <span className="font-bold text-purple-600">{formatCurrency(totalValue)}</span>
              </p>
            </div>
          </>
        ) : (
          <div className="h-[300px] flex items-center justify-center text-gray-400">
            <div className="text-center">
              <Clock className="w-12 h-12 mx-auto mb-2 opacity-30" />
              <p>Nenhum recebível em aberto</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}