import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { 
  DollarSign, 
  Calendar, 
  FileText, 
  Clock,
  AlertCircle,
  X
} from "lucide-react";
import { format } from "date-fns";
import { formatCurrency } from "../billing/billingHelpers";

export default function ReceivableDrawer({ recebivel, onClose, onPayment, onCancel }) {
  const [showCancelDialog, setShowCancelDialog] = useState(false);
  const [motivoCancelamento, setMotivoCancelamento] = useState('');

  const handleCancel = () => {
    if (!motivoCancelamento.trim()) {
      return;
    }
    onCancel(motivoCancelamento);
    setShowCancelDialog(false);
  };

  const getStatusBadge = (status) => {
    const badges = {
      em_aberto: <Badge className="bg-blue-100 text-blue-800">Em Aberto</Badge>,
      parcial: <Badge className="bg-yellow-100 text-yellow-800">Parcial</Badge>,
      liquidado: <Badge className="bg-green-100 text-green-800">Liquidado</Badge>,
      vencido: <Badge className="bg-red-100 text-red-800">Vencido</Badge>,
      cancelado: <Badge className="bg-gray-100 text-gray-800">Cancelado</Badge>
    };
    return badges[status] || status;
  };

  return (
    <>
      <Dialog open={true} onOpenChange={onClose}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between">
              <span>Detalhes do Recebível</span>
              {getStatusBadge(recebivel.status)}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            {/* Metadados */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-xs text-gray-500">Nº Título</Label>
                <p className="font-semibold">{recebivel.titulo_num}</p>
              </div>
              <div>
                <Label className="text-xs text-gray-500">Referência</Label>
                <p className="font-semibold">{recebivel.referencia || '—'}</p>
              </div>
              <div>
                <Label className="text-xs text-gray-500">Valor Original</Label>
                <p className="font-semibold text-purple-600">
                  {formatCurrency(recebivel.valor_original)}
                </p>
              </div>
              <div>
                <Label className="text-xs text-gray-500">Saldo Devedor</Label>
                <p className="font-semibold text-orange-600">
                  {formatCurrency(recebivel.saldo)}
                </p>
              </div>
              <div>
                <Label className="text-xs text-gray-500">Competência</Label>
                <p className="font-semibold">{recebivel.competencia}</p>
              </div>
              <div>
                <Label className="text-xs text-gray-500">Forma de Pagamento</Label>
                <p className="font-semibold capitalize">
                  {recebivel.forma_pagamento.replace('_', '/')}
                </p>
              </div>
              <div>
                <Label className="text-xs text-gray-500">Emissão</Label>
                <p className="font-semibold">
                  {format(new Date(recebivel.emissao), 'dd/MM/yyyy')}
                </p>
              </div>
              <div>
                <Label className="text-xs text-gray-500">Vencimento</Label>
                <p className="font-semibold">
                  {format(new Date(recebivel.vencimento), 'dd/MM/yyyy')}
                </p>
              </div>
            </div>

            {/* Observações */}
            {recebivel.observacoes && (
              <div>
                <Label className="text-xs text-gray-500 mb-2">Observações</Label>
                <p className="text-sm bg-gray-50 p-3 rounded">{recebivel.observacoes}</p>
              </div>
            )}

            {/* Histórico */}
            {recebivel.historico && recebivel.historico.length > 0 && (
              <div>
                <Label className="text-xs text-gray-500 mb-3">Histórico de Eventos</Label>
                <div className="space-y-2">
                  {recebivel.historico.map((evento, idx) => (
                    <div key={idx} className="flex gap-3 text-sm">
                      <div className="w-2 h-2 rounded-full bg-purple-600 mt-2" />
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold capitalize">
                            {evento.evento.replace('_', ' ')}
                          </span>
                          <span className="text-xs text-gray-500">
                            {format(new Date(evento.data), 'dd/MM/yyyy HH:mm')}
                          </span>
                        </div>
                        {evento.detalhes && (
                          <p className="text-gray-600 mt-1">{evento.detalhes}</p>
                        )}
                        <p className="text-xs text-gray-500 mt-1">Por: {evento.usuario}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Ações */}
            <div className="flex justify-end gap-3 pt-4 border-t">
              {recebivel.status !== 'cancelado' && recebivel.status !== 'liquidado' && (
                <>
                  <Button
                    variant="outline"
                    onClick={onPayment}
                    className="text-purple-600 border-purple-600"
                  >
                    <DollarSign className="w-4 h-4 mr-2" />
                    Registrar Pagamento
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setShowCancelDialog(true)}
                    className="text-red-600 border-red-600"
                  >
                    <X className="w-4 h-4 mr-2" />
                    Cancelar Título
                  </Button>
                </>
              )}
              <Button variant="ghost" onClick={onClose}>
                Fechar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Dialog de Cancelamento */}
      {showCancelDialog && (
        <Dialog open={true} onOpenChange={() => setShowCancelDialog(false)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Cancelar Título</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="motivo">Motivo do Cancelamento *</Label>
                <Textarea
                  id="motivo"
                  value={motivoCancelamento}
                  onChange={(e) => setMotivoCancelamento(e.target.value)}
                  placeholder="Descreva o motivo do cancelamento..."
                  rows={4}
                />
              </div>
              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={() => setShowCancelDialog(false)}>
                  Cancelar
                </Button>
                <Button
                  onClick={handleCancel}
                  disabled={!motivoCancelamento.trim()}
                  className="bg-red-600 hover:bg-red-700 text-white"
                >
                  Confirmar Cancelamento
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}