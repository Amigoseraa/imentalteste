import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar } from "recharts";
import { TrendingUp } from "lucide-react";
import { formatCurrency } from "../billing/billingHelpers";

export default function MRRChart({ data, showMovements = false }) {
  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-purple-600" />
          {showMovements ? 'Movimentações de MRR' : 'Evolução de MRR'}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {data && data.length > 0 ? (
          <>
            {!showMovements ? (
              <ResponsiveContainer width="100%" height={350}>
                <LineChart data={data}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                  <YAxis 
                    tickFormatter={(value) => `R$ ${(value / 1000).toFixed(0)}k`}
                    tick={{ fontSize: 12 }}
                  />
                  <Tooltip formatter={(value) => formatCurrency(value)} />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="mrr" 
                    stroke="#6B46C1" 
                    strokeWidth={3} 
                    dot={{ r: 4 }}
                    name="MRR"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="receita_realizada" 
                    stroke="#38A169" 
                    strokeWidth={2} 
                    dot={{ r: 3 }}
                    name="Receita Realizada"
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <ResponsiveContainer width="100%" height={350}>
                <BarChart data={data}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                  <YAxis 
                    tickFormatter={(value) => `R$ ${(value / 1000).toFixed(0)}k`}
                    tick={{ fontSize: 12 }}
                  />
                  <Tooltip formatter={(value) => formatCurrency(value)} />
                  <Legend />
                  <Bar dataKey="novas" stackId="a" fill="#48BB78" name="Novas" />
                  <Bar dataKey="expansao" stackId="a" fill="#4299E1" name="Expansão" />
                  <Bar dataKey="contracao" stackId="a" fill="#F6AD55" name="Contração" />
                  <Bar dataKey="churn" stackId="a" fill="#F56565" name="Churn" />
                </BarChart>
              </ResponsiveContainer>
            )}
          </>
        ) : (
          <div className="h-[350px] flex items-center justify-center text-gray-400">
            Aguardando dados históricos
          </div>
        )}
      </CardContent>
    </Card>
  );
}