import React from "react";
import { Card, CardHeader, CardContent } from "@/components/ui/card";
import { DollarSign, FileText, CheckCircle, Send, AlertCircle, Settings } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";

export default function BillingKPIs({ faturas = [], divergencias = [], autoConfig }) {
  const mrrEstimado = faturas
    .filter(f => f.status === 'PREVIA')
    .reduce((acc, f) => acc + (f.valor_liquido || 0), 0);

  const faturasEditadas = faturas.filter(f => f.status === 'EDITADA');
  const valorEditadas = faturasEditadas.reduce((acc, f) => acc + (f.valor_liquido || 0), 0);

  const faturasAutorizadas = faturas.filter(f => f.status === 'AUTORIZADA');
  const valorAutorizadas = faturasAutorizadas.reduce((acc, f) => acc + (f.valor_liquido || 0), 0);

  const faturasEnviadas = faturas.filter(f => f.status === 'ENVIADA');
  const valorEnviadas = faturasEnviadas.reduce((acc, f) => acc + (f.valor_liquido || 0), 0);

  const faturasVencidas = faturas.filter(f => f.status === 'VENCIDA');
  const inadimplencia = faturasVencidas.reduce((acc, f) => acc + (f.valor_liquido || 0), 0);

  const formatCurrency = (value) => {
    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 0 });
  };

  const automacaoAtiva = autoConfig?.auto_aprovar || autoConfig?.auto_enviar;

  return (
    <TooltipProvider>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-6 mb-6">
        <Tooltip>
          <TooltipTrigger asChild>
            <Card className="shadow-md hover:shadow-lg transition-all cursor-help">
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <p className="text-xs font-medium text-gray-600 mb-1">MRR Estimado</p>
                    <p className="text-2xl font-bold" style={{ color: '#A0AEC0' }}>
                      {formatCurrency(mrrEstimado)}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      Prévias automáticas
                    </p>
                  </div>
                  <div className="p-2 rounded-lg" style={{ backgroundColor: '#EDF2F7' }}>
                    <DollarSign className="w-5 h-5" style={{ color: '#A0AEC0' }} />
                  </div>
                </div>
              </CardHeader>
            </Card>
          </TooltipTrigger>
          <TooltipContent>
            <p className="text-xs max-w-xs">Receita recorrente mensal estimada com base nas prévias automáticas</p>
          </TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <Card className="shadow-md hover:shadow-lg transition-all cursor-help">
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <p className="text-xs font-medium text-gray-600 mb-1">Faturas Editadas</p>
                    <p className="text-2xl font-bold" style={{ color: '#D69E2E' }}>
                      {faturasEditadas.length}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      {formatCurrency(valorEditadas)}
                    </p>
                  </div>
                  <div className="p-2 rounded-lg" style={{ backgroundColor: '#FEFCBF' }}>
                    <FileText className="w-5 h-5" style={{ color: '#D69E2E' }} />
                  </div>
                </div>
              </CardHeader>
            </Card>
          </TooltipTrigger>
          <TooltipContent>
            <p className="text-xs max-w-xs">Faturas com ajustes manuais aguardando aprovação</p>
          </TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <Card className="shadow-md hover:shadow-lg transition-all cursor-help">
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <p className="text-xs font-medium text-gray-600 mb-1">Autorizadas</p>
                    <p className="text-2xl font-bold" style={{ color: '#805AD5' }}>
                      {faturasAutorizadas.length}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      {formatCurrency(valorAutorizadas)}
                    </p>
                  </div>
                  <div className="p-2 rounded-lg" style={{ backgroundColor: '#E9D8FD' }}>
                    <CheckCircle className="w-5 h-5" style={{ color: '#805AD5' }} />
                  </div>
                </div>
              </CardHeader>
            </Card>
          </TooltipTrigger>
          <TooltipContent>
            <p className="text-xs max-w-xs">Faturas aprovadas e prontas para envio</p>
          </TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <Card className="shadow-md hover:shadow-lg transition-all cursor-help">
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <p className="text-xs font-medium text-gray-600 mb-1">Enviadas</p>
                    <p className="text-2xl font-bold" style={{ color: '#38A169' }}>
                      {faturasEnviadas.length}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      {formatCurrency(valorEnviadas)}
                    </p>
                  </div>
                  <div className="p-2 rounded-lg" style={{ backgroundColor: '#C6F6D5' }}>
                    <Send className="w-5 h-5" style={{ color: '#38A169' }} />
                  </div>
                </div>
              </CardHeader>
            </Card>
          </TooltipTrigger>
          <TooltipContent>
            <p className="text-xs max-w-xs">Faturas já disparadas para os clientes</p>
          </TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <Card className="shadow-md hover:shadow-lg transition-all cursor-help">
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <p className="text-xs font-medium text-gray-600 mb-1">Vencidas</p>
                    <p className="text-2xl font-bold text-red-600">
                      {faturasVencidas.length}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      {formatCurrency(inadimplencia)}
                    </p>
                  </div>
                  <div className="p-2 rounded-lg bg-red-50">
                    <AlertCircle className="w-5 h-5 text-red-600" />
                  </div>
                </div>
              </CardHeader>
            </Card>
          </TooltipTrigger>
          <TooltipContent>
            <p className="text-xs max-w-xs">Faturas vencidas e não pagas</p>
          </TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <Card className="shadow-md hover:shadow-lg transition-all cursor-help">
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <p className="text-xs font-medium text-gray-600 mb-1">Automação</p>
                    {automacaoAtiva ? (
                      <>
                        <Badge className="bg-green-100 text-green-800 mt-2">
                          ✓ Ativa
                        </Badge>
                        <p className="text-xs text-gray-500 mt-1">
                          {autoConfig?.auto_aprovar && '✓ Auto-aprovar'}
                        </p>
                        <p className="text-xs text-gray-500">
                          {autoConfig?.auto_enviar && '✓ Auto-enviar'}
                        </p>
                      </>
                    ) : (
                      <Badge className="bg-gray-100 text-gray-600 mt-2">
                        Desativada
                      </Badge>
                    )}
                  </div>
                  <div className="p-2 rounded-lg bg-blue-50">
                    <Settings className="w-5 h-5 text-blue-600" />
                  </div>
                </div>
              </CardHeader>
            </Card>
          </TooltipTrigger>
          <TooltipContent>
            <p className="text-xs max-w-xs">Status da automação de faturamento</p>
          </TooltipContent>
        </Tooltip>
      </div>
    </TooltipProvider>
  );
}