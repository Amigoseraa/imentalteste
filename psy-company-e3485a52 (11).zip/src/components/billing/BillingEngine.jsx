import { format, addMonths } from "date-fns";

/**
 * Engine unificada de cálculo de faturamento
 * Funciona tanto para Admin→Consultorias quanto Consultoria→Empresas
 */

export async function generateBillingPreview({
  competencia,
  emitenteTipo, // 'ADMIN' ou 'CONSULTORIA'
  emitenteId, // null para admin, consultoria_id para consultoria
  targets, // Array de consultorias ou empresas
  contratos, // Array de contratos (ContratoConsultoria ou ContratoEmpresa)
  baseData, // Dados para cálculo (empresas, colaboradores, etc)
  base44
}) {
  const previews = [];
  const divergencias = [];

  for (const target of targets) {
    try {
      // Buscar contrato vigente
      const contrato = contratos.find(c => {
        if (emitenteTipo === 'ADMIN') {
          return c.consultoria_id === target.id && c.status === 'ATIVO';
        } else {
          return c.empresa_id === target.id && c.consultoria_id === emitenteId && c.status === 'ATIVO';
        }
      });

      if (!contrato) {
        divergencias.push({
          alvo: target.name || target.nome_fantasia,
          motivo: 'Sem contrato ativo'
        });
        continue;
      }

      // Validar vigência
      if (contrato.data_fim) {
        const dataFim = new Date(contrato.data_fim);
        const competenciaDate = new Date(competencia + '-01');
        if (competenciaDate > dataFim) {
          divergencias.push({
            alvo: target.name || target.nome_fantasia,
            motivo: 'Contrato vencido'
          });
          continue;
        }
      }

      // Calcular base de cálculo
      const calculoBase = calcularBase({
        modelo: contrato.modelo_cobranca,
        target,
        baseData,
        emitenteId,
        emitenteTipo
      });

      if (calculoBase.quantidade === 0 && contrato.modelo_cobranca !== 'FIXO_MENSAL') {
        divergencias.push({
          alvo: target.name || target.nome_fantasia,
          motivo: `Base de cálculo zerada (${calculoBase.descricao})`
        });
      }

      // Calcular valores
      let valorBruto = 0;
      const itens = [];

      switch (contrato.modelo_cobranca) {
        case 'FIXO_MENSAL':
          valorBruto = contrato.valor_fixo || 0;
          itens.push({
            descricao: 'Mensalidade Fixa',
            quantidade: 1,
            valor_unitario: valorBruto,
            valor_total: valorBruto
          });
          break;

        case 'POR_EMPRESA_ATIVA':
          valorBruto = calculoBase.quantidade * (contrato.valor_unitario || 0);
          itens.push({
            descricao: `${calculoBase.quantidade} empresa(s) ativa(s)`,
            quantidade: calculoBase.quantidade,
            valor_unitario: contrato.valor_unitario || 0,
            valor_total: valorBruto
          });
          break;

        case 'POR_COLABORADOR_ATIVO':
          valorBruto = calculoBase.quantidade * (contrato.valor_unitario || 0);
          itens.push({
            descricao: `${calculoBase.quantidade} colaborador(es) ativo(s)`,
            quantidade: calculoBase.quantidade,
            valor_unitario: contrato.valor_unitario || 0,
            valor_total: valorBruto
          });
          break;

        case 'HIBRIDO':
          const fixo = contrato.valor_fixo || 0;
          const variavel = calculoBase.quantidade * (contrato.valor_unitario || 0);
          valorBruto = fixo + variavel;
          
          if (fixo > 0) {
            itens.push({
              descricao: 'Valor Fixo Mensal',
              quantidade: 1,
              valor_unitario: fixo,
              valor_total: fixo
            });
          }
          
          if (variavel > 0) {
            itens.push({
              descricao: `${calculoBase.quantidade} colaborador(es) ativo(s)`,
              quantidade: calculoBase.quantidade,
              valor_unitario: contrato.valor_unitario || 0,
              valor_total: variavel
            });
          }
          break;
      }

      // Aplicar desconto
      const descontoValor = valorBruto * ((contrato.desconto_percent || 0) / 100);
      let valorLiquido = valorBruto - descontoValor;

      // Aplicar mínimo mensal
      if (contrato.minimo_mensal && valorLiquido < contrato.minimo_mensal) {
        valorLiquido = contrato.minimo_mensal;
      }

      // Calcular vencimento
      const [ano, mes] = competencia.split('-');
      const proximoMes = addMonths(new Date(parseInt(ano), parseInt(mes) - 1, 1), 1);
      const diaVencimento = Math.min(contrato.vencimento_dia || 10, 28);
      const vencimento = format(
        new Date(proximoMes.getFullYear(), proximoMes.getMonth(), diaVencimento),
        'yyyy-MM-dd'
      );

      // Criar prévia de fatura
      const alvoTipo = emitenteTipo === 'ADMIN' ? 'CONSULTORIA' : 'EMPRESA';
      const idempotencyKey = `${competencia}|${alvoTipo}|${target.id}`;

      const fatura = {
        competencia,
        alvo_tipo: alvoTipo,
        alvo_id: target.id,
        alvo_nome: target.name || target.nome_fantasia || 'Sem nome',
        emitente_tipo: emitenteTipo,
        emitente_id: emitenteId || 'admin',
        contrato_id: contrato.id,
        modelo_cobranca: contrato.modelo_cobranca,
        itens,
        valor_bruto: valorBruto,
        desconto_percent: contrato.desconto_percent || 0,
        desconto_valor: descontoValor,
        valor_liquido: valorLiquido,
        status: 'PREVIA',
        vencimento_em: vencimento,
        meta: {
          base_calculo: calculoBase,
          contrato_ref: {
            modelo: contrato.modelo_cobranca,
            valor_fixo: contrato.valor_fixo,
            valor_unitario: contrato.valor_unitario,
            minimo_mensal: contrato.minimo_mensal
          }
        },
        idempotency_key: idempotencyKey
      };

      previews.push(fatura);
    } catch (error) {
      console.error(`Erro ao calcular fatura para ${target.name}:`, error);
      divergencias.push({
        alvo: target.name || target.nome_fantasia,
        motivo: `Erro no cálculo: ${error.message}`
      });
    }
  }

  return { previews, divergencias };
}

function calcularBase({ modelo, target, baseData, emitenteId, emitenteTipo }) {
  switch (modelo) {
    case 'FIXO_MENSAL':
      return {
        quantidade: 1,
        descricao: 'Valor fixo mensal'
      };

    case 'POR_EMPRESA_ATIVA':
      // Para Admin→Consultoria: contar empresas da consultoria
      const empresas = baseData.empresas.filter(e => 
        e.consultoria_id === target.id && e.status === 'active'
      );
      return {
        quantidade: empresas.length,
        descricao: `${empresas.length} empresa(s) ativa(s)`
      };

    case 'POR_COLABORADOR_ATIVO':
      if (emitenteTipo === 'ADMIN') {
        // Admin→Consultoria: contar todos colaboradores das empresas da consultoria
        const empresasConsultoria = baseData.empresas.filter(e => 
          e.consultoria_id === target.id && e.status === 'active'
        );
        const empresaIds = empresasConsultoria.map(e => e.id);
        const colaboradores = baseData.colaboradores.filter(c => 
          empresaIds.includes(c.company_id) && c.status === 'active'
        );
        return {
          quantidade: colaboradores.length,
          descricao: `${colaboradores.length} colaborador(es) ativo(s)`
        };
      } else {
        // Consultoria→Empresa: contar colaboradores da empresa
        const colaboradores = baseData.colaboradores.filter(c => 
          c.company_id === target.id && c.status === 'active'
        );
        return {
          quantidade: colaboradores.length,
          descricao: `${colaboradores.length} colaborador(es) ativo(s)`
        };
      }

    case 'HIBRIDO':
      // Mesma lógica do POR_COLABORADOR_ATIVO para a parte variável
      if (emitenteTipo === 'ADMIN') {
        const empresasConsultoria = baseData.empresas.filter(e => 
          e.consultoria_id === target.id && e.status === 'active'
        );
        const empresaIds = empresasConsultoria.map(e => e.id);
        const colaboradores = baseData.colaboradores.filter(c => 
          empresaIds.includes(c.company_id) && c.status === 'active'
        );
        return {
          quantidade: colaboradores.length,
          descricao: `Fixo + ${colaboradores.length} colaborador(es)`
        };
      } else {
        const colaboradores = baseData.colaboradores.filter(c => 
          c.company_id === target.id && c.status === 'active'
        );
        return {
          quantidade: colaboradores.length,
          descricao: `Fixo + ${colaboradores.length} colaborador(es)`
        };
      }

    default:
      return {
        quantidade: 0,
        descricao: 'Modelo desconhecido'
      };
  }
}