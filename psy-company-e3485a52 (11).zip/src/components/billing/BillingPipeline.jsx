import React from "react";
import { BILLING_STATUS, STATUS_ORDER } from "./billingHelpers";
import { FileText, Edit, CheckCircle, Send, Check } from "lucide-react";

const ICONS = {
  FileText,
  Edit,
  CheckCircle,
  Send,
  Check
};

export default function BillingPipeline({ currentStatus, faturasCounts }) {
  const steps = [
    { key: 'PREVIA', label: 'Prévia', icon: 'FileText' },
    { key: 'EDITADA', label: 'Editada', icon: 'Edit' },
    { key: 'AUTORIZADA', label: 'Autorizada', icon: 'CheckCircle' },
    { key: 'ENVIADA', label: 'Enviada', icon: 'Send' }
  ];

  const currentIndex = STATUS_ORDER.indexOf(currentStatus);

  return (
    <div className="bg-white rounded-xl p-6 shadow-md mb-6">
      <h3 className="text-sm font-semibold text-gray-600 mb-4">Fluxo do Faturamento</h3>
      <div className="flex items-center justify-between">
        {steps.map((step, index) => {
          const Icon = ICONS[step.icon];
          const isActive = index <= currentIndex;
          const isCurrent = index === currentIndex;
          const statusInfo = BILLING_STATUS[step.key];
          const count = faturasCounts[step.key] || 0;

          return (
            <React.Fragment key={step.key}>
              <div className="flex flex-col items-center flex-1">
                <div
                  className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
                    isActive 
                      ? 'shadow-lg' 
                      : 'bg-gray-100'
                  }`}
                  style={{ 
                    backgroundColor: isActive ? statusInfo.bgColor : undefined,
                    borderWidth: isCurrent ? '3px' : '0px',
                    borderColor: isActive ? statusInfo.color : undefined
                  }}
                >
                  <Icon 
                    className="w-6 h-6" 
                    style={{ color: isActive ? statusInfo.color : '#A0AEC0' }}
                  />
                </div>
                <p 
                  className={`text-xs font-medium mt-2 ${
                    isActive ? 'text-gray-900' : 'text-gray-400'
                  }`}
                >
                  {step.label}
                </p>
                {count > 0 && (
                  <span 
                    className="text-xs font-bold mt-1 px-2 py-0.5 rounded-full"
                    style={{ 
                      backgroundColor: statusInfo.bgColor,
                      color: statusInfo.color
                    }}
                  >
                    {count}
                  </span>
                )}
              </div>
              {index < steps.length - 1 && (
                <div className="flex-1 h-0.5 mx-2 mt-[-40px]" style={{
                  backgroundColor: isActive ? statusInfo.color : '#E2E8F0'
                }} />
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
}