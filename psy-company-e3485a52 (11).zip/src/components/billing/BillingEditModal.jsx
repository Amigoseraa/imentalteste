import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Save, RefreshCw, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function BillingEditModal({ open, onClose, fatura, onSave, onRecalculate }) {
  const [formData, setFormData] = useState({
    itens: fatura?.itens || [{ descricao: '', quantidade: 1, valor_unitario: 0 }],
    desconto_percent: fatura?.desconto_percent || 0,
    vencimento_em: fatura?.vencimento_em || '',
    observacoes: fatura?.observacoes || ''
  });

  const calcularValores = () => {
    const valor_bruto = formData.itens.reduce((acc, item) => 
      acc + (item.quantidade * item.valor_unitario), 0
    );
    const desconto_valor = valor_bruto * (formData.desconto_percent / 100);
    const valor_liquido = valor_bruto - desconto_valor;

    return { valor_bruto, desconto_valor, valor_liquido };
  };

  const handleAddItem = () => {
    setFormData({
      ...formData,
      itens: [...formData.itens, { descricao: '', quantidade: 1, valor_unitario: 0 }]
    });
  };

  const handleRemoveItem = (index) => {
    const newItens = formData.itens.filter((_, i) => i !== index);
    setFormData({ ...formData, itens: newItens });
  };

  const handleItemChange = (index, field, value) => {
    const newItens = [...formData.itens];
    newItens[index] = { ...newItens[index], [field]: value };
    setFormData({ ...formData, itens: newItens });
  };

  const handleSave = () => {
    const valores = calcularValores();
    onSave({
      ...formData,
      ...valores,
      origem_calculo: 'MANUAL',
      status: 'EDITADA'
    });
  };

  const { valor_bruto, desconto_valor, valor_liquido } = calcularValores();

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">Editar Fatura</DialogTitle>
          <DialogDescription>
            {fatura?.alvo_nome} — {fatura?.competencia}
          </DialogDescription>
          {fatura?.origem_calculo === 'MANUAL' && (
            <Badge className="bg-yellow-100 text-yellow-800 w-fit">
              Editada Manualmente
            </Badge>
          )}
        </DialogHeader>

        <Alert className="bg-blue-50 border-blue-200">
          <AlertDescription className="text-sm text-blue-800">
            💡 Alterações manuais mudam o status para "Editada". Use "Recalcular" para restaurar o valor automático.
          </AlertDescription>
        </Alert>

        <div className="space-y-6">
          {/* Itens */}
          <div>
            <div className="flex justify-between items-center mb-3">
              <Label className="text-base font-semibold">Itens da Fatura</Label>
              <Button variant="outline" size="sm" onClick={handleAddItem}>
                + Adicionar Item
              </Button>
            </div>

            <div className="border rounded-lg overflow-hidden">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="text-left p-3 text-sm font-semibold text-gray-700">Descrição</th>
                    <th className="text-right p-3 text-sm font-semibold text-gray-700">Qtd</th>
                    <th className="text-right p-3 text-sm font-semibold text-gray-700">Valor Unit.</th>
                    <th className="text-right p-3 text-sm font-semibold text-gray-700">Subtotal</th>
                    <th className="w-12"></th>
                  </tr>
                </thead>
                <tbody>
                  {formData.itens.map((item, index) => (
                    <tr key={index} className="border-t">
                      <td className="p-2">
                        <Input
                          value={item.descricao}
                          onChange={(e) => handleItemChange(index, 'descricao', e.target.value)}
                          placeholder="Ex: Colaboradores ativos"
                        />
                      </td>
                      <td className="p-2">
                        <Input
                          type="number"
                          value={item.quantidade}
                          onChange={(e) => handleItemChange(index, 'quantidade', parseFloat(e.target.value))}
                          className="text-right"
                        />
                      </td>
                      <td className="p-2">
                        <Input
                          type="number"
                          step="0.01"
                          value={item.valor_unitario}
                          onChange={(e) => handleItemChange(index, 'valor_unitario', parseFloat(e.target.value))}
                          className="text-right"
                        />
                      </td>
                      <td className="p-2 text-right font-semibold">
                        {(item.quantidade * item.valor_unitario).toLocaleString('pt-BR', { 
                          style: 'currency', 
                          currency: 'BRL' 
                        })}
                      </td>
                      <td className="p-2">
                        {formData.itens.length > 1 && (
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => handleRemoveItem(index)}
                          >
                            <X className="w-4 h-4 text-red-600" />
                          </Button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Desconto e Vencimento */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="desconto">Desconto (%)</Label>
              <Input
                id="desconto"
                type="number"
                step="0.01"
                value={formData.desconto_percent}
                onChange={(e) => setFormData({ ...formData, desconto_percent: parseFloat(e.target.value) })}
              />
            </div>
            <div>
              <Label htmlFor="vencimento">Vencimento</Label>
              <Input
                id="vencimento"
                type="date"
                value={formData.vencimento_em}
                onChange={(e) => setFormData({ ...formData, vencimento_em: e.target.value })}
              />
            </div>
          </div>

          {/* Observações */}
          <div>
            <Label htmlFor="observacoes">Observações</Label>
            <Textarea
              id="observacoes"
              value={formData.observacoes}
              onChange={(e) => setFormData({ ...formData, observacoes: e.target.value })}
              placeholder="Observações adicionais..."
              rows={3}
            />
          </div>

          {/* Resumo Financeiro */}
          <div className="bg-gray-50 p-4 rounded-lg space-y-2">
            <div className="flex justify-between">
              <span className="text-gray-600">Valor Bruto:</span>
              <span className="font-semibold">
                {valor_bruto.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
              </span>
            </div>
            {desconto_valor > 0 && (
              <div className="flex justify-between text-red-600">
                <span>Desconto ({formData.desconto_percent}%):</span>
                <span className="font-semibold">
                  - {desconto_valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                </span>
              </div>
            )}
            <div className="flex justify-between pt-2 border-t text-lg">
              <span className="font-bold">Valor Líquido:</span>
              <span className="font-bold" style={{ color: '#38A169' }}>
                {valor_liquido.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
              </span>
            </div>
          </div>
        </div>

        <DialogFooter className="flex justify-between">
          <Button variant="outline" onClick={onRecalculate}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Recalcular Automático
          </Button>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button onClick={handleSave} style={{ backgroundColor: '#805AD5', color: 'white' }}>
              <Save className="w-4 h-4 mr-2" />
              Salvar Alterações
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}