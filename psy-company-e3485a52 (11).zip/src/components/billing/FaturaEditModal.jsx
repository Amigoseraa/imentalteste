import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle, Save, RefreshCw, Calendar } from "lucide-react";
import { format } from "date-fns";

export default function FaturaEditModal({ fatura, open, onClose, onSave, onRecalcular }) {
  const [formData, setFormData] = useState({
    itens: fatura?.itens || [],
    desconto_percent: fatura?.desconto_percent || 0,
    vencimento_em: fatura?.vencimento_em || '',
    observacoes: fatura?.observacoes || ''
  });

  const handleItemChange = (index, field, value) => {
    const newItens = [...formData.itens];
    newItens[index] = {
      ...newItens[index],
      [field]: value
    };
    
    // Recalcular valor_total do item
    if (field === 'quantidade' || field === 'valor_unitario') {
      const qtd = field === 'quantidade' ? parseFloat(value) || 0 : newItens[index].quantidade;
      const valor = field === 'valor_unitario' ? parseFloat(value) || 0 : newItens[index].valor_unitario;
      newItens[index].valor_total = qtd * valor;
    }
    
    setFormData({ ...formData, itens: newItens });
  };

  const calcularValores = () => {
    const valorBruto = formData.itens.reduce((acc, item) => acc + (item.valor_total || 0), 0);
    const descontoValor = valorBruto * (formData.desconto_percent / 100);
    const valorLiquido = valorBruto - descontoValor;
    
    return { valorBruto, descontoValor, valorLiquido };
  };

  const handleSave = () => {
    const { valorBruto, descontoValor, valorLiquido } = calcularValores();
    
    onSave({
      ...formData,
      valor_bruto: valorBruto,
      desconto_valor: descontoValor,
      valor_liquido: valorLiquido,
      status: 'EDITADA',
      origem_calculo: 'MANUAL'
    });
  };

  const handleRecalcular = () => {
    if (window.confirm('Descartar alterações e recalcular automaticamente?')) {
      onRecalcular();
      onClose();
    }
  };

  const { valorBruto, descontoValor, valorLiquido } = calcularValores();

  if (!fatura) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <span>Editar Fatura</span>
            {fatura.origem_calculo === 'MANUAL' && (
              <Badge className="bg-yellow-100 text-yellow-800">
                Editada manualmente
              </Badge>
            )}
          </DialogTitle>
          <DialogDescription>
            {fatura.alvo_nome} • Competência: {format(new Date(fatura.competencia + '-01'), 'MMMM/yyyy')}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {fatura.origem_calculo === 'MANUAL' && (
            <Alert className="bg-yellow-50 border-yellow-200">
              <AlertCircle className="h-4 w-4 text-yellow-600" />
              <AlertDescription className="text-yellow-800">
                Esta fatura foi editada manualmente. Para retornar ao cálculo automático, clique em "Recalcular".
              </AlertDescription>
            </Alert>
          )}

          {/* Itens da Fatura */}
          <div>
            <Label className="text-base font-semibold mb-3 block">Itens da Fatura</Label>
            <div className="border rounded-lg overflow-hidden">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="text-left p-3 text-sm font-semibold">Descrição</th>
                    <th className="text-right p-3 text-sm font-semibold w-24">Qtd</th>
                    <th className="text-right p-3 text-sm font-semibold w-32">Valor Unit.</th>
                    <th className="text-right p-3 text-sm font-semibold w-32">Subtotal</th>
                  </tr>
                </thead>
                <tbody>
                  {formData.itens.map((item, index) => (
                    <tr key={index} className="border-t">
                      <td className="p-2">
                        <Input
                          value={item.descricao}
                          onChange={(e) => handleItemChange(index, 'descricao', e.target.value)}
                          className="border-0 focus:ring-1"
                        />
                      </td>
                      <td className="p-2">
                        <Input
                          type="number"
                          step="1"
                          value={item.quantidade}
                          onChange={(e) => handleItemChange(index, 'quantidade', e.target.value)}
                          className="text-right border-0 focus:ring-1"
                        />
                      </td>
                      <td className="p-2">
                        <Input
                          type="number"
                          step="0.01"
                          value={item.valor_unitario}
                          onChange={(e) => handleItemChange(index, 'valor_unitario', e.target.value)}
                          className="text-right border-0 focus:ring-1"
                        />
                      </td>
                      <td className="p-2 text-right font-medium">
                        R$ {(item.valor_total || 0).toFixed(2)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Resumo Financeiro */}
          <div className="bg-gray-50 p-4 rounded-lg space-y-3">
            <Label className="text-base font-semibold">Resumo Financeiro</Label>
            
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Valor Bruto:</span>
              <span className="font-semibold text-lg">
                R$ {valorBruto.toFixed(2)}
              </span>
            </div>

            <div className="flex justify-between items-center gap-4">
              <Label htmlFor="desconto">Desconto (%):</Label>
              <div className="flex items-center gap-2">
                <Input
                  id="desconto"
                  type="number"
                  step="0.01"
                  min="0"
                  max="100"
                  value={formData.desconto_percent}
                  onChange={(e) => setFormData({ ...formData, desconto_percent: parseFloat(e.target.value) || 0 })}
                  className="w-24 text-right"
                />
                <span className="text-red-600 font-medium w-32 text-right">
                  - R$ {descontoValor.toFixed(2)}
                </span>
              </div>
            </div>

            <div className="border-t pt-3 flex justify-between items-center">
              <span className="text-lg font-bold">Valor Líquido:</span>
              <span className="text-2xl font-bold" style={{ color: '#00B37E' }}>
                R$ {valorLiquido.toFixed(2)}
              </span>
            </div>
          </div>

          {/* Vencimento */}
          <div>
            <Label htmlFor="vencimento" className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              Data de Vencimento
            </Label>
            <Input
              id="vencimento"
              type="date"
              value={formData.vencimento_em}
              onChange={(e) => setFormData({ ...formData, vencimento_em: e.target.value })}
              className="mt-2"
            />
          </div>

          {/* Observações */}
          <div>
            <Label htmlFor="observacoes">Observações</Label>
            <Textarea
              id="observacoes"
              value={formData.observacoes}
              onChange={(e) => setFormData({ ...formData, observacoes: e.target.value })}
              placeholder="Informações adicionais sobre esta fatura..."
              rows={3}
              className="mt-2"
            />
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button
            variant="outline"
            onClick={handleRecalcular}
            className="flex items-center gap-2"
          >
            <RefreshCw className="w-4 h-4" />
            Recalcular Automático
          </Button>
          <Button
            variant="outline"
            onClick={onClose}
          >
            Cancelar
          </Button>
          <Button
            onClick={handleSave}
            style={{ backgroundColor: '#4B2672', color: 'white' }}
            className="flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            Salvar Alterações
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}