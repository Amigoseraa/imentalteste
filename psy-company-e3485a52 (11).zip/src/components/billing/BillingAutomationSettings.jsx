import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Settings, Save, Calendar, Zap } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function BillingAutomationSettings({ open, onClose, config, onSave }) {
  const [formData, setFormData] = useState({
    auto_gerar: config?.auto_gerar || false,
    auto_aprovar: config?.auto_aprovar || false,
    auto_emitir: config?.auto_emitir || false,
    auto_enviar: config?.auto_enviar || false,
    dia_execucao: config?.dia_execucao || 1,
    hora_execucao: config?.hora_execucao || '08:00',
    email_notificacao: config?.email_notificacao || ''
  });

  const handleSave = () => {
    onSave(formData);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Configurações de Automação
          </DialogTitle>
          <DialogDescription>
            Configure o faturamento automático mensal
          </DialogDescription>
        </DialogHeader>

        <Alert className="bg-purple-50 border-purple-200">
          <Zap className="h-4 w-4 text-purple-600" />
          <AlertDescription className="text-sm text-purple-800">
            <strong>Automatize seu processo financeiro:</strong> Configure para gerar, aprovar e enviar faturas automaticamente no dia escolhido.
          </AlertDescription>
        </Alert>

        <div className="space-y-6">
          {/* Toggles */}
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 rounded-lg border">
              <div>
                <Label className="font-semibold">Gerar Prévias Automaticamente</Label>
                <p className="text-xs text-gray-500">Calcular faturas todo início de mês</p>
              </div>
              <Switch
                checked={formData.auto_gerar}
                onCheckedChange={(checked) => setFormData({ ...formData, auto_gerar: checked })}
              />
            </div>

            <div className="flex items-center justify-between p-3 rounded-lg border">
              <div>
                <Label className="font-semibold">Aprovar Faturas Automaticamente</Label>
                <p className="text-xs text-gray-500">Autorizar automaticamente após cálculo</p>
              </div>
              <Switch
                checked={formData.auto_aprovar}
                onCheckedChange={(checked) => setFormData({ ...formData, auto_aprovar: checked })}
              />
            </div>

            <div className="flex items-center justify-between p-3 rounded-lg border">
              <div>
                <Label className="font-semibold">Emitir Automaticamente</Label>
                <p className="text-xs text-gray-500">Gerar espelhos de NF após aprovação</p>
              </div>
              <Switch
                checked={formData.auto_emitir}
                onCheckedChange={(checked) => setFormData({ ...formData, auto_emitir: checked })}
              />
            </div>

            <div className="flex items-center justify-between p-3 rounded-lg border">
              <div>
                <Label className="font-semibold">Enviar E-mails Automaticamente</Label>
                <p className="text-xs text-gray-500">Disparar cobranças por e-mail após emissão</p>
              </div>
              <Switch
                checked={formData.auto_enviar}
                onCheckedChange={(checked) => setFormData({ ...formData, auto_enviar: checked })}
              />
            </div>
          </div>

          {/* Agendamento */}
          {formData.auto_gerar && (
            <div className="space-y-4 p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-2 mb-3">
                <Calendar className="w-4 h-4" style={{ color: '#805AD5' }} />
                <Label className="font-semibold">Agendamento</Label>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="dia">Dia do Mês (1-28)</Label>
                  <Input
                    id="dia"
                    type="number"
                    min="1"
                    max="28"
                    value={formData.dia_execucao}
                    onChange={(e) => setFormData({ ...formData, dia_execucao: parseInt(e.target.value) })}
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Execução automática todo dia {formData.dia_execucao}
                  </p>
                </div>

                <div>
                  <Label htmlFor="hora">Horário</Label>
                  <Input
                    id="hora"
                    type="time"
                    value={formData.hora_execucao}
                    onChange={(e) => setFormData({ ...formData, hora_execucao: e.target.value })}
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Horário de execução
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Notificações */}
          <div>
            <Label htmlFor="email">E-mail para Notificações</Label>
            <Input
              id="email"
              type="email"
              value={formData.email_notificacao}
              onChange={(e) => setFormData({ ...formData, email_notificacao: e.target.value })}
              placeholder="financeiro@empresa.com"
            />
            <p className="text-xs text-gray-500 mt-1">
              Receber relatórios de execução automática
            </p>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancelar
          </Button>
          <Button onClick={handleSave} style={{ backgroundColor: '#805AD5', color: 'white' }}>
            <Save className="w-4 h-4 mr-2" />
            Salvar Configurações
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}