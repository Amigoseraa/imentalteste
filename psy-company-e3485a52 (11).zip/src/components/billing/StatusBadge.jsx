import React from "react";
import { Badge } from "@/components/ui/badge";
import { 
  FileText, 
  Edit, 
  CheckCircle, 
  Send, 
  DollarSign, 
  AlertCircle, 
  XCircle 
} from "lucide-react";

export default function StatusBadge({ status, size = "default" }) {
  const statusConfig = {
    PREVIA: {
      label: 'Prévia Automática',
      icon: FileText,
      className: 'bg-gray-100 text-gray-700 border-gray-300',
      iconColor: 'text-gray-500'
    },
    EDITADA: {
      label: 'Editada',
      icon: Edit,
      className: 'bg-yellow-100 text-yellow-800 border-yellow-300',
      iconColor: 'text-yellow-600'
    },
    AUTORIZADA: {
      label: 'Autorizada',
      icon: CheckCircle,
      className: 'bg-blue-100 text-blue-800 border-blue-300',
      iconColor: 'text-blue-600'
    },
    ENVIADA: {
      label: 'Enviada',
      icon: Send,
      className: 'bg-purple-100 text-purple-800 border-purple-300',
      iconColor: 'text-purple-600'
    },
    PAGA: {
      label: 'Paga',
      icon: DollarSign,
      className: 'bg-green-100 text-green-800 border-green-300',
      iconColor: 'text-green-600'
    },
    VENCIDA: {
      label: 'Vencida',
      icon: AlertCircle,
      className: 'bg-red-100 text-red-800 border-red-300',
      iconColor: 'text-red-600'
    },
    CANCELADA: {
      label: 'Cancelada',
      icon: XCircle,
      className: 'bg-gray-100 text-gray-600 border-gray-300',
      iconColor: 'text-gray-500'
    }
  };

  const config = statusConfig[status] || statusConfig.PREVIA;
  const Icon = config.icon;
  
  const sizeClass = size === "sm" ? "text-xs px-2 py-0.5" : "text-sm px-2.5 py-0.5";

  return (
    <Badge 
      variant="outline" 
      className={`${config.className} ${sizeClass} flex items-center gap-1 w-fit font-medium`}
    >
      <Icon className={`w-3 h-3 ${config.iconColor}`} />
      {config.label}
    </Badge>
  );
}