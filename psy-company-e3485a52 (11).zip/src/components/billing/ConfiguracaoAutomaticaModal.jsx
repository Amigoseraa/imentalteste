import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Settings, Save, Clock, Calendar, Mail } from "lucide-react";

export default function ConfiguracaoAutomaticaModal({ config, open, onClose, onSave }) {
  const [formData, setFormData] = useState({
    auto_gerar: config?.auto_gerar || false,
    auto_aprovar: config?.auto_aprovar || false,
    auto_emitir: config?.auto_emitir || false,
    auto_enviar: config?.auto_enviar || false,
    dia_execucao: config?.dia_execucao || 1,
    hora_execucao: config?.hora_execucao || '08:00',
    dia_vencimento_padrao: config?.dia_vencimento_padrao || 10,
    email_notificacao: config?.email_notificacao || ''
  });

  const handleSave = () => {
    onSave(formData);
  };

  const isAutomacaoCompleta = formData.auto_gerar && formData.auto_aprovar && formData.auto_emitir && formData.auto_enviar;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Configuração de Faturamento Automático
          </DialogTitle>
          <DialogDescription>
            Configure as automações do ciclo de faturamento
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {isAutomacaoCompleta && (
            <Alert className="bg-green-50 border-green-200">
              <AlertDescription className="text-green-800">
                ✅ <strong>Automação Completa Ativa</strong><br/>
                O sistema irá gerar, aprovar, emitir e enviar faturas automaticamente no dia {formData.dia_execucao} às {formData.hora_execucao}.
              </AlertDescription>
            </Alert>
          )}

          {/* Etapas de Automação */}
          <div className="space-y-4">
            <h3 className="font-semibold text-sm text-gray-700">Etapas do Ciclo de Faturamento</h3>
            
            <div className="space-y-3 pl-4 border-l-2 border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="auto_gerar" className="font-medium">1. Gerar Prévias Automaticamente</Label>
                  <p className="text-xs text-gray-500 mt-1">Calcular faturas do mês automaticamente</p>
                </div>
                <Switch
                  id="auto_gerar"
                  checked={formData.auto_gerar}
                  onCheckedChange={(checked) => setFormData({ ...formData, auto_gerar: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="auto_aprovar" className="font-medium">2. Aprovar Automaticamente</Label>
                  <p className="text-xs text-gray-500 mt-1">Autorizar faturas após geração (sem revisão manual)</p>
                </div>
                <Switch
                  id="auto_aprovar"
                  checked={formData.auto_aprovar}
                  onCheckedChange={(checked) => setFormData({ ...formData, auto_aprovar: checked })}
                  disabled={!formData.auto_gerar}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="auto_emitir" className="font-medium">3. Emitir Automaticamente</Label>
                  <p className="text-xs text-gray-500 mt-1">Gerar espelhos de NF após aprovação</p>
                </div>
                <Switch
                  id="auto_emitir"
                  checked={formData.auto_emitir}
                  onCheckedChange={(checked) => setFormData({ ...formData, auto_emitir: checked })}
                  disabled={!formData.auto_aprovar}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="auto_enviar" className="font-medium">4. Enviar E-mails Automaticamente</Label>
                  <p className="text-xs text-gray-500 mt-1">Disparar faturas por e-mail após emissão</p>
                </div>
                <Switch
                  id="auto_enviar"
                  checked={formData.auto_enviar}
                  onCheckedChange={(checked) => setFormData({ ...formData, auto_enviar: checked })}
                  disabled={!formData.auto_emitir}
                />
              </div>
            </div>
          </div>

          {/* Agendamento */}
          {formData.auto_gerar && (
            <div className="space-y-4 pt-4 border-t">
              <h3 className="font-semibold text-sm text-gray-700 flex items-center gap-2">
                <Clock className="w-4 h-4" />
                Agendamento da Execução
              </h3>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="dia_execucao">Dia do Mês (1-28)</Label>
                  <Input
                    id="dia_execucao"
                    type="number"
                    min="1"
                    max="28"
                    value={formData.dia_execucao}
                    onChange={(e) => setFormData({ ...formData, dia_execucao: parseInt(e.target.value) })}
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label htmlFor="hora_execucao">Horário</Label>
                  <Input
                    id="hora_execucao"
                    type="time"
                    value={formData.hora_execucao}
                    onChange={(e) => setFormData({ ...formData, hora_execucao: e.target.value })}
                    className="mt-2"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Configurações Adicionais */}
          <div className="space-y-4 pt-4 border-t">
            <h3 className="font-semibold text-sm text-gray-700 flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              Configurações Adicionais
            </h3>
            
            <div>
              <Label htmlFor="dia_vencimento">Dia Padrão de Vencimento (1-28)</Label>
              <Input
                id="dia_vencimento"
                type="number"
                min="1"
                max="28"
                value={formData.dia_vencimento_padrao}
                onChange={(e) => setFormData({ ...formData, dia_vencimento_padrao: parseInt(e.target.value) })}
                className="mt-2"
              />
              <p className="text-xs text-gray-500 mt-1">
                As faturas vencerão no dia {formData.dia_vencimento_padrao} do mês seguinte
              </p>
            </div>

            <div>
              <Label htmlFor="email_notificacao" className="flex items-center gap-2">
                <Mail className="w-4 h-4" />
                E-mail para Notificações
              </Label>
              <Input
                id="email_notificacao"
                type="email"
                value={formData.email_notificacao}
                onChange={(e) => setFormData({ ...formData, email_notificacao: e.target.value })}
                placeholder="seu@email.com"
                className="mt-2"
              />
              <p className="text-xs text-gray-500 mt-1">
                Receba notificações sobre execuções e divergências
              </p>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancelar
          </Button>
          <Button
            onClick={handleSave}
            style={{ backgroundColor: '#4B2672', color: 'white' }}
            className="flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            Salvar Configuração
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}