/**
 * Helpers para o módulo de faturamento
 */

export const BILLING_STATUS = {
  PREVIA: { 
    label: "Prévia Automática", 
    color: "#A0AEC0",
    bgColor: "#EDF2F7",
    icon: "FileText"
  },
  EDITADA: { 
    label: "Editada Manualmente", 
    color: "#D69E2E",
    bgColor: "#FEFCBF",
    icon: "Edit"
  },
  AUTORIZADA: { 
    label: "Autorizada", 
    color: "#805AD5",
    bgColor: "#E9D8FD",
    icon: "CheckCircle"
  },
  ENVIADA: { 
    label: "Enviada", 
    color: "#38A169",
    bgColor: "#C6F6D5",
    icon: "Send"
  },
  PAGA: { 
    label: "Paga", 
    color: "#2F855A",
    bgColor: "#9AE6B4",
    icon: "CheckCircle"
  },
  VENCIDA: { 
    label: "Vencida", 
    color: "#E53E3E",
    bgColor: "#FED7D7",
    icon: "AlertCircle"
  },
  CANCELADA: { 
    label: "Cancelada", 
    color: "#718096",
    bgColor: "#E2E8F0",
    icon: "XCircle"
  }
};

export const STATUS_TRANSITIONS = {
  PREVIA: ['EDITADA', 'AUTORIZADA', 'CANCELADA'],
  EDITADA: ['PREVIA', 'AUTORIZADA', 'CANCELADA'],
  AUTORIZADA: ['ENVIADA', 'CANCELADA'],
  ENVIADA: ['PAGA', 'VENCIDA', 'CANCELADA'],
  PAGA: [],
  VENCIDA: ['PAGA', 'CANCELADA'],
  CANCELADA: []
};

export const STATUS_ORDER = ['PREVIA', 'EDITADA', 'AUTORIZADA', 'ENVIADA', 'PAGA'];

export function canTransitionTo(currentStatus, newStatus) {
  return STATUS_TRANSITIONS[currentStatus]?.includes(newStatus) || false;
}

export function getNextActions(status) {
  const actions = {
    PREVIA: [
      { label: 'Editar', action: 'edit', variant: 'outline', icon: 'Edit' },
      { label: 'Aprovar', action: 'approve', variant: 'default', icon: 'CheckCircle' }
    ],
    EDITADA: [
      { label: 'Recalcular', action: 'recalculate', variant: 'outline', icon: 'RefreshCw' },
      { label: 'Aprovar', action: 'approve', variant: 'default', icon: 'CheckCircle' }
    ],
    AUTORIZADA: [
      { label: 'Enviar', action: 'send', variant: 'default', icon: 'Send' }
    ],
    ENVIADA: [
      { label: 'Reenviar', action: 'resend', variant: 'outline', icon: 'Send' },
      { label: 'Marcar Paga', action: 'markAsPaid', variant: 'default', icon: 'CheckCircle' }
    ],
    VENCIDA: [
      { label: 'Reenviar', action: 'resend', variant: 'outline', icon: 'Send' },
      { label: 'Marcar Paga', action: 'markAsPaid', variant: 'default', icon: 'CheckCircle' }
    ],
    PAGA: [],
    CANCELADA: []
  };

  return actions[status] || [];
}

export function addHistoricoEntry(fatura, acao, statusNovo, usuario, observacao = '') {
  const historico = fatura.historico || [];
  
  return [
    ...historico,
    {
      acao,
      status_anterior: fatura.status,
      status_novo: statusNovo,
      usuario,
      data: new Date().toISOString(),
      observacao
    }
  ];
}

export function formatCurrency(value) {
  return value.toLocaleString('pt-BR', { 
    style: 'currency', 
    currency: 'BRL',
    minimumFractionDigits: 2
  });
}

export function isOverdue(fatura) {
  if (fatura.status === 'PAGA' || fatura.status === 'CANCELADA') return false;
  if (!fatura.vencimento_em) return false;
  
  return new Date(fatura.vencimento_em) < new Date();
}

export function getStatusStep(status) {
  return STATUS_ORDER.indexOf(status);
}