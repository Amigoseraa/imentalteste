import React from "react";

export default function IMentalLogo({ variant = "dark", size = "default", className = "" }) {
  const heights = {
    small: "28px",
    default: "40px",
    large: "120px"
  };

  const logoSrc = variant === "light" 
    ? "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ec5a7712e4d9c5e3485a52/74f5477a0_2.png"
    : "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ec5a7712e4d9c5e3485a52/ea03daa72_1.png";

  return (
    <img
      src={logoSrc}
      alt="iMental – Solução de Saúde Mental Corporativa"
      title="iMental"
      aria-label="Logotipo iMental"
      style={{ 
        height: heights[size] || heights.default,
        width: "auto",
        objectFit: "contain"
      }}
      className={`transition-opacity duration-200 hover:opacity-90 ${className}`}
    />
  );
}