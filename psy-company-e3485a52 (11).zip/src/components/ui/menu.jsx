/**
 * Schema centralizado de navegação
 * Define TODA a estrutura de menus do sistema
 */

import {
  Home,
  Building2,
  ClipboardList,
  Users,
  Settings,
  FileText,
  LayoutDashboard,
  DollarSign,
  Briefcase,
  Package
} from "lucide-react";

export const MENU_SCHEMA = {
  // Admin (sem impersonation)
  ADMIN: [
    {
      key: 'admin_dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
      path: '/AdminDashboard',
      resource: 'admin:dashboard'
    },
    {
      key: 'consultorias',
      label: 'Consultorias',
      icon: Briefcase,
      path: '/Consultorias',
      resource: 'admin:consultorias'
    },
    {
      key: 'planos',
      label: 'Planos',
      icon: Package,
      path: '/Planos',
      resource: 'admin:planos'
    },
    {
      key: 'financeiro',
      label: 'Financeiro',
      icon: DollarSign,
      resource: 'admin:financeiro',
      submenu: [
        { label: 'Visão Geral', path: '/FinanceOverview' },
        { label: 'Receitas', path: '/FinanceReceitas' },
        { label: 'Recebíveis', path: '/FinanceRecebiveis' },
        { label: 'Cobrança', path: '/FinanceCobranca' },
        { label: 'Previsão', path: '/FinanceForecast' },
        { label: 'Clientes', path: '/FinanceClientes' },
        { label: 'Relatórios', path: '/FinanceRelatorios' },
        { label: 'Configurações', path: '/FinanceConfig' }
      ]
    },
    {
      key: 'diagnostico',
      label: 'Diagnóstico',
      icon: Settings,
      path: '/SystemDiagnostics',
      resource: 'admin:diagnostico'
    }
  ],

  // Consultoria
  CONSULTORIA: [
    {
      key: 'consultoria_dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
      path: '/ConsultoriaDashboard',
      resource: 'consultoria:dashboard'
    },
    {
      key: 'empresas',
      label: 'Empresas',
      icon: Building2,
      path: '/Companies',
      resource: 'consultoria:empresas'
    },
    {
      key: 'faturamento',
      label: 'Faturamento',
      icon: DollarSign,
      path: '/FaturamentoConsultoria',
      resource: 'consultoria:financeiro'
    },
    {
      key: 'config',
      label: 'Configurações',
      icon: Settings,
      path: '/Personalizacao',
      resource: 'consultoria:config'
    }
  ],

  // Empresa
  EMPRESA: [
    {
      key: 'dashboard',
      label: 'Dashboard',
      icon: Home,
      path: '/Dashboard',
      resource: 'empresa:dashboard'
    },
    {
      key: 'avaliacoes',
      label: 'Avaliações',
      icon: ClipboardList,
      path: '/Assessments',
      resource: 'empresa:avaliacoes'
    },
    {
      key: 'cadastros',
      label: 'Cadastros',
      icon: Users,
      resource: 'empresa:cad',
      submenu: [
        { label: 'Departamentos', path: '/Departments', icon: Building2 },
        { label: 'GHE', path: '/GHE', icon: Briefcase },
        { label: 'Colaboradores', path: '/Employees', icon: Users }
      ]
    },
    {
      key: 'relatorios',
      label: 'Relatórios',
      icon: FileText,
      path: '/Reports',
      resource: 'empresa:relatorios'
    },
    {
      key: 'config',
      label: 'Configurações',
      icon: Settings,
      path: '/Settings',
      resource: 'empresa:config'
    }
  ],

  // Colaborador
  COLAB: [
    {
      key: 'minhas_avaliacoes',
      label: 'Minhas Avaliações',
      icon: ClipboardList,
      path: '/ColaboradorAvaliacoes',
      resource: 'self'
    },
    {
      key: 'perfil',
      label: 'Meu Perfil',
      icon: Settings,
      path: '/Settings',
      resource: 'self'
    }
  ]
};

/**
 * Retorna o menu apropriado baseado no contexto
 */
export function getMenuForContext(context) {
  if (!context) return [];

  const { role, impersonating, impersonation_type } = context;

  // Admin sem impersonation
  if (role === 'admin' && !impersonating) {
    return MENU_SCHEMA.ADMIN;
  }

  // Admin impersonando consultoria OU usuário consultoria
  if ((role === 'admin' && impersonation_type === 'consultoria') || role === 'consultoria') {
    return MENU_SCHEMA.CONSULTORIA;
  }

  // Admin impersonando empresa OU usuário empresa
  if ((role === 'admin' && impersonation_type === 'empresa') || role === 'manager') {
    return MENU_SCHEMA.EMPRESA;
  }

  // Colaborador
  if (role === 'employee') {
    return MENU_SCHEMA.COLAB;
  }

  return [];
}