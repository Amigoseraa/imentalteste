/**
 * Sistema centralizado de Controle de Acesso (ACL)
 * Define permissões por papel: ADMIN, CONSULTORIA, EMPRESA, COLAB
 */

export const ROLES = {
  ADMIN: 'admin',
  CONSULTORIA: 'consultoria',
  EMPRESA: 'manager',
  COLAB: 'employee'
};

export const RESOURCES = {
  GLOBAL: 'global',
  ADMIN_DASHBOARD: 'admin:dashboard',
  ADMIN_CONSULTORIAS: 'admin:consultorias',
  ADMIN_PLANOS: 'admin:planos',
  ADMIN_FINANCEIRO: 'admin:financeiro',
  ADMIN_DIAGNOSTICO: 'admin:diagnostico',
  
  CONSULTORIA_DASHBOARD: 'consultoria:dashboard',
  CONSULTORIA_EMPRESAS: 'consultoria:empresas',
  CONSULTORIA_FINANCEIRO: 'consultoria:financeiro',
  CONSULTORIA_CONFIG: 'consultoria:config',
  
  EMPRESA_DASHBOARD: 'empresa:dashboard',
  EMPRESA_CAD: 'empresa:cad',
  EMPRESA_AVALIACOES: 'empresa:avaliacoes',
  EMPRESA_RELATORIOS: 'empresa:relatorios',
  EMPRESA_CONFIG: 'empresa:config',
  
  COLAB_AVALIACOES: 'self',
  COLAB_PERFIL: 'self'
};

/**
 * Verifica se o usuário tem permissão para acessar um recurso
 */
export function can(role, action, resource, ctx = {}) {
  if (!role || !resource) {
    return false;
  }

  // Admin tem acesso total (exceto quando impersonando)
  if (role === ROLES.ADMIN) {
    return true;
  }

  // Consultoria
  if (role === ROLES.CONSULTORIA) {
    if (!ctx.consultoria_id) {
      return false;
    }
    
    if (resource.startsWith('consultoria:')) {
      return true;
    }
    
    if (resource.startsWith('empresa:') && ctx.consultoria_id) {
      return true;
    }
    
    return false;
  }

  // Empresa
  if (role === ROLES.EMPRESA) {
    if (!ctx.company_id) {
      return false;
    }
    
    if (resource.startsWith('empresa:')) {
      return true;
    }
    
    return false;
  }

  // Colaborador
  if (role === ROLES.COLAB) {
    if (resource === 'self') {
      return true;
    }
    
    return false;
  }

  return false;
}

/**
 * Extrai contexto do usuário incluindo impersonation
 */
export function getUserContext(user) {
  if (!user) return null;

  const impersonationData = localStorage.getItem('admin_impersonation');
  let impersonation = null;
  
  if (impersonationData) {
    try {
      impersonation = JSON.parse(impersonationData);
    } catch (e) {
      console.error('Error parsing impersonation data:', e);
      localStorage.removeItem('admin_impersonation');
    }
  }

  let effectiveRole = user.role || user.user_role;
  let consultoria_id = user.consultoria_id;
  let company_id = user.company_id;

  if (impersonation) {
    if (impersonation.type === 'consultoria') {
      effectiveRole = ROLES.CONSULTORIA;
      consultoria_id = impersonation.consultoria_id;
      company_id = null;
    } else if (impersonation.type === 'empresa') {
      effectiveRole = ROLES.EMPRESA;
      company_id = impersonation.company_id;
      consultoria_id = impersonation.consultoria_id;
    }
  }

  return {
    user_id: user.id,
    email: user.email,
    role: effectiveRole,
    original_role: user.role || user.user_role,
    company_id,
    consultoria_id,
    impersonating: !!impersonation,
    impersonation_type: impersonation?.type
  };
}

/**
 * Wrapper para verificar permissão e redirecionar se negado
 */
export function requirePermission(role, resource, ctx, navigate) {
  if (!can(role, 'read', resource, ctx)) {
    navigate('/Error403');
    return false;
  }
  return true;
}

/**
 * Hook para verificar permissões em componentes
 */
export function usePermission(role, resource, ctx) {
  return can(role, 'read', resource, ctx);
}