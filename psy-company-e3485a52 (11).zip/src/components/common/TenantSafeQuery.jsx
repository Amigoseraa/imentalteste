import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { getTenantContext, filterByTenant } from "../utils/tenancyGuards";
import { queryWithLogging } from "../utils/observability";

export const useTenantSafeQuery = (entityName, options = {}) => {
  const [user, setUser] = React.useState(null);
  const [tenantContext, setTenantContext] = React.useState(null);

  React.useEffect(() => {
    const loadContext = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
        const context = await getTenantContext(userData);
        setTenantContext(context);
      } catch (error) {
        console.error('Error loading tenant context:', error);
      }
    };
    loadContext();
  }, []);

  return useQuery({
    queryKey: [entityName, tenantContext?.consultoriaId, tenantContext?.empresaId, options.filters],
    queryFn: async () => {
      if (!tenantContext) return [];

      const operation = async () => {
        let records;
        
        if (options.filters) {
          records = await base44.entities[entityName].filter(options.filters, options.sort, options.limit);
        } else {
          records = await base44.entities[entityName].list(options.sort, options.limit);
        }

        return filterByTenant(records, tenantContext, entityName);
      };

      return queryWithLogging(entityName, operation, {}, tenantContext);
    },
    enabled: !!tenantContext && (options.enabled !== false),
    ...options
  });
};

export default function TenantSafeQuery({ entityName, children, renderEmpty, renderError, renderLoading }) {
  const { data, isLoading, error } = useTenantSafeQuery(entityName);

  if (isLoading) {
    return renderLoading ? renderLoading() : <div className="p-4">Carregando...</div>;
  }

  if (error) {
    return renderError ? renderError(error) : (
      <div className="p-4 text-red-600">Erro ao carregar dados: {error.message}</div>
    );
  }

  if (!data || data.length === 0) {
    return renderEmpty ? renderEmpty() : (
      <div className="p-4 text-gray-500">Nenhum registro encontrado</div>
    );
  }

  return children(data);
}