import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { AlertCircle, RefreshCw, Home } from "lucide-react";

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo);
    
    this.setState({
      error,
      errorInfo
    });
  }

  handleReload = () => {
    window.location.reload();
  };

  handleGoHome = () => {
    window.location.href = '/';
  };

  render() {
    if (this.state.hasError) {
      const isDevelopment = window.location.hostname === 'localhost' || 
                           window.location.hostname === '127.0.0.1';

      return (
        <div className="min-h-screen flex items-center justify-center p-4" style={{ backgroundColor: '#F8F6FB' }}>
          <Card className="max-w-2xl w-full border-2 border-red-200">
            <CardContent className="p-8">
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-full bg-red-100 flex items-center justify-center mb-6">
                  <AlertCircle className="w-8 h-8 text-red-600" />
                </div>
                
                <h1 className="text-2xl font-bold text-gray-900 mb-2">
                  Ops! Algo deu errado
                </h1>
                
                <p className="text-gray-600 mb-6 max-w-md">
                  Encontramos um erro inesperado. Nossa equipe foi notificada e está trabalhando para resolver.
                </p>

                {isDevelopment && this.state.error && (
                  <details className="w-full mb-6 text-left">
                    <summary className="cursor-pointer text-sm font-medium text-gray-700 mb-2">
                      Detalhes técnicos do erro
                    </summary>
                    <div className="bg-gray-100 p-4 rounded-lg overflow-auto max-h-64">
                      <pre className="text-xs text-red-600 whitespace-pre-wrap">
                        {this.state.error.toString()}
                        {'\n\n'}
                        {this.state.errorInfo?.componentStack}
                      </pre>
                    </div>
                  </details>
                )}

                <div className="flex gap-4">
                  <Button
                    onClick={this.handleReload}
                    className="text-white"
                    style={{ backgroundColor: '#4B2672' }}
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Recarregar Página
                  </Button>
                  <Button
                    onClick={this.handleGoHome}
                    variant="outline"
                  >
                    <Home className="w-4 h-4 mr-2" />
                    Ir para Início
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;