import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Inbox, 
  Building, 
  Users, 
  ClipboardList, 
  FileText,
  Search,
  AlertCircle
} from "lucide-react";

const iconMap = {
  inbox: Inbox,
  building: Building,
  users: Users,
  clipboard: ClipboardList,
  file: FileText,
  search: Search,
  alert: AlertCircle,
};

export default function EmptyState({ 
  icon = "inbox",
  title, 
  description, 
  primaryAction,
  secondaryAction 
}) {
  const Icon = iconMap[icon] || Inbox;
  
  return (
    <div 
      className="flex items-center justify-center p-8 min-h-[400px]" 
      data-testid="empty-state"
    >
      <Card className="max-w-md w-full text-center shadow-lg">
        <CardContent className="p-8">
          <div className="flex justify-center mb-4">
            <div 
              className="w-16 h-16 rounded-full flex items-center justify-center"
              style={{ backgroundColor: '#F3EFF7' }}
            >
              <Icon className="w-8 h-8" style={{ color: '#6B5B7F' }} />
            </div>
          </div>
          
          <h3 
            className="text-xl font-semibold mb-2"
            style={{ color: '#4B2672' }}
            data-testid="empty-title"
          >
            {title}
          </h3>
          
          {description && (
            <p 
              className="text-sm mb-6"
              style={{ color: '#6B5B7F' }}
              data-testid="empty-description"
            >
              {description}
            </p>
          )}
          
          <div className="flex gap-3 justify-center">
            {primaryAction && (
              <Button
                onClick={primaryAction.onClick}
                className="text-white"
                style={{ backgroundColor: '#4B2672' }}
                data-testid="empty-primary-action"
              >
                {primaryAction.label}
              </Button>
            )}
            
            {secondaryAction && (
              <Button
                variant="outline"
                onClick={secondaryAction.onClick}
                data-testid="empty-secondary-action"
              >
                {secondaryAction.label}
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}