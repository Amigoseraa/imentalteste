import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight } from "lucide-react";

export default function QuickLinks({ links = [] }) {
  if (links.length === 0) return null;

  return (
    <Card className="shadow-md">
      <CardContent className="p-6">
        <h3 className="text-sm font-semibold text-gray-700 mb-4">Acesso Rápido</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {links.map((link, index) => (
            <Link
              key={index}
              to={createPageUrl(link.href)}
              className="flex items-center justify-between p-3 rounded-lg border border-gray-200 hover:border-purple-300 hover:bg-purple-50 transition-all group"
            >
              <div className="flex items-center gap-3">
                {link.icon && <link.icon className="w-5 h-5 text-gray-500 group-hover:text-purple-600" />}
                <div>
                  <p className="text-sm font-medium text-gray-900">{link.label}</p>
                  {link.description && (
                    <p className="text-xs text-gray-500">{link.description}</p>
                  )}
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-gray-400 group-hover:text-purple-600" />
            </Link>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}