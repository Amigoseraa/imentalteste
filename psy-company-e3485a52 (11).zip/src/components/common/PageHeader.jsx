import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ChevronRight } from "lucide-react";

export default function PageHeader({ 
  title, 
  description, 
  breadcrumbs = [], 
  actions = [],
  showBack = true 
}) {
  const navigate = useNavigate();

  return (
    <div className="space-y-4">
      {/* Breadcrumbs */}
      {breadcrumbs.length > 0 && (
        <div className="flex items-center gap-2 text-sm">
          {showBack && (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate(-1)}
              className="h-8 w-8"
              title="Voltar"
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
          )}
          {breadcrumbs.map((crumb, index) => (
            <React.Fragment key={index}>
              {index > 0 && <ChevronRight className="w-4 h-4 text-gray-400" />}
              {crumb.href ? (
                <Link 
                  to={createPageUrl(crumb.href)} 
                  className="text-gray-600 hover:text-gray-900 transition-colors"
                >
                  {crumb.label}
                </Link>
              ) : (
                <span className={index === breadcrumbs.length - 1 ? "text-gray-900 font-medium" : "text-gray-600"}>
                  {crumb.label}
                </span>
              )}
            </React.Fragment>
          ))}
        </div>
      )}

      {/* Title and Actions */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold" style={{ color: '#2E2E2E' }}>{title}</h1>
          {description && (
            <p className="text-gray-500 mt-2">{description}</p>
          )}
        </div>
        {actions.length > 0 && (
          <div className="flex gap-3 flex-wrap">
            {actions}
          </div>
        )}
      </div>
    </div>
  );
}