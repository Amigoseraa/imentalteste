import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ShieldAlert } from "lucide-react";

export default function ForbiddenState({ 
  title = "Acesso negado",
  description = "Você não tem permissão para acessar esta página.",
  onBack
}) {
  return (
    <div 
      className="flex items-center justify-center p-8 min-h-[400px]" 
      data-testid="forbidden-state"
    >
      <Card className="max-w-md w-full text-center shadow-lg">
        <CardContent className="p-8">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 rounded-full bg-orange-100 flex items-center justify-center">
              <ShieldAlert className="w-8 h-8 text-orange-600" />
            </div>
          </div>
          
          <h3 
            className="text-xl font-semibold mb-2 text-gray-900"
            data-testid="forbidden-title"
          >
            {title}
          </h3>
          
          <p 
            className="text-sm mb-6 text-gray-600"
            data-testid="forbidden-description"
          >
            {description}
          </p>
          
          <Button
            variant="outline"
            onClick={onBack || (() => window.history.back())}
            data-testid="forbidden-back-button"
          >
            Voltar
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}