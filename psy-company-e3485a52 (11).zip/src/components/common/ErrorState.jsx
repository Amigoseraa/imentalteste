import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { AlertTriangle, RefreshCw } from "lucide-react";

export default function ErrorState({ 
  title = "Erro ao carregar dados",
  description = "Ocorreu um erro ao carregar as informações. Tente novamente.",
  onRetry,
  showBackButton = false,
  onBack
}) {
  return (
    <div 
      className="flex items-center justify-center p-8 min-h-[400px]" 
      data-testid="error-state"
    >
      <Card className="max-w-md w-full text-center shadow-lg">
        <CardContent className="p-8">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 rounded-full bg-red-100 flex items-center justify-center">
              <AlertTriangle className="w-8 h-8 text-red-600" />
            </div>
          </div>
          
          <h3 
            className="text-xl font-semibold mb-2 text-gray-900"
            data-testid="error-title"
          >
            {title}
          </h3>
          
          <p 
            className="text-sm mb-6 text-gray-600"
            data-testid="error-description"
          >
            {description}
          </p>
          
          <div className="flex gap-3 justify-center">
            {showBackButton && onBack && (
              <Button
                variant="outline"
                onClick={onBack}
                data-testid="error-back-button"
              >
                Voltar
              </Button>
            )}
            
            {onRetry && (
              <Button
                onClick={onRetry}
                className="text-white"
                style={{ backgroundColor: '#4B2672' }}
                data-testid="error-retry-button"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Tentar Novamente
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}