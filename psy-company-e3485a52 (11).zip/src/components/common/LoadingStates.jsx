import React from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";

export function PageSkeleton() {
  return (
    <div className="p-4 md:p-8 space-y-6" data-testid="page-skeleton">
      <div className="space-y-2">
        <div className="h-8 w-64 bg-gray-200 rounded animate-pulse" />
        <div className="h-4 w-96 bg-gray-200 rounded animate-pulse" />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {[1, 2, 3, 4].map(i => (
          <Card key={i} className="animate-pulse">
            <CardHeader className="h-24 bg-gray-100" />
          </Card>
        ))}
      </div>
      
      <Card className="animate-pulse">
        <CardHeader className="h-16 bg-gray-100" />
        <CardContent className="space-y-3">
          {[1, 2, 3, 4, 5].map(i => (
            <div key={i} className="h-12 bg-gray-100 rounded" />
          ))}
        </CardContent>
      </Card>
    </div>
  );
}

export function TableSkeleton({ rows = 5 }) {
  return (
    <div className="space-y-3" data-testid="table-skeleton">
      {[...Array(rows)].map((_, i) => (
        <div key={i} className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg animate-pulse">
          <div className="w-12 h-12 bg-gray-200 rounded-full" />
          <div className="flex-1 space-y-2">
            <div className="h-4 bg-gray-200 rounded w-1/4" />
            <div className="h-3 bg-gray-200 rounded w-1/3" />
          </div>
          <div className="w-24 h-8 bg-gray-200 rounded" />
        </div>
      ))}
    </div>
  );
}

export function ListSkeleton({ items = 3 }) {
  return (
    <div className="space-y-4" data-testid="list-skeleton">
      {[...Array(items)].map((_, i) => (
        <Card key={i} className="animate-pulse">
          <CardContent className="p-6">
            <div className="space-y-3">
              <div className="h-5 bg-gray-200 rounded w-3/4" />
              <div className="h-4 bg-gray-200 rounded w-1/2" />
              <div className="h-4 bg-gray-200 rounded w-full" />
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

export function CardSkeleton() {
  return (
    <Card className="animate-pulse" data-testid="card-skeleton">
      <CardHeader className="space-y-2">
        <div className="h-4 bg-gray-200 rounded w-1/3" />
        <div className="h-8 bg-gray-200 rounded w-1/2" />
      </CardHeader>
      <CardContent>
        <div className="h-4 bg-gray-200 rounded w-2/3" />
      </CardContent>
    </Card>
  );
}