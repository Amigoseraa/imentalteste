import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Trophy, TrendingUp, Users } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function ConsultoriaRankings({ companies, employees, assessments, faturas, currentMonth }) {
  // Top 5 Empresas por Faturamento
  const revenueRanking = companies
    .map(c => {
      const companyFaturas = faturas.filter(f => 
        f.company_id === c.id && f.competencia === currentMonth && f.status === 'paga'
      );
      const revenue = companyFaturas.reduce((acc, f) => acc + (f.valor_total || 0), 0);
      return { ...c, revenue };
    })
    .sort((a, b) => b.revenue - a.revenue)
    .slice(0, 5);

  // Top 5 Empresas por Engajamento
  const engagementRanking = companies
    .map(c => {
      const companyAssessments = assessments.filter(a => a.company_id === c.id);
      const completed = companyAssessments.filter(a => a.completed_at).length;
      const engagement = companyAssessments.length > 0
        ? ((completed / companyAssessments.length) * 100)
        : 0;
      return { ...c, engagement, completed, total: companyAssessments.length };
    })
    .sort((a, b) => b.engagement - a.engagement)
    .slice(0, 5);

  // Top 5 Empresas por Crescimento
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
  
  const growthRanking = companies
    .map(c => {
      const allEmployees = employees.filter(e => e.company_id === c.id && e.status === 'active');
      const newEmployees = employees.filter(e => 
        e.company_id === c.id && 
        e.created_date && 
        new Date(e.created_date) > thirtyDaysAgo
      );
      return { ...c, newEmployees: newEmployees.length, totalEmployees: allEmployees.length };
    })
    .sort((a, b) => b.newEmployees - a.newEmployees)
    .slice(0, 5);

  const formatCurrency = (value) => {
    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 0 });
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold" style={{ color: '#2E2E2E' }}>
        🏆 Rankings Internos
      </h2>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Top 5 Faturamento */}
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Trophy className="w-5 h-5" style={{ color: '#FFD84D' }} />
              Top 5 por Faturamento
            </CardTitle>
          </CardHeader>
          <CardContent>
            {revenueRanking.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50">
                    <TableHead>#</TableHead>
                    <TableHead>Empresa</TableHead>
                    <TableHead className="text-right">Receita</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {revenueRanking.map((c, idx) => (
                    <TableRow key={c.id}>
                      <TableCell className="font-semibold">{idx + 1}</TableCell>
                      <TableCell className="font-medium">{c.name}</TableCell>
                      <TableCell className="text-right text-green-600 font-semibold">
                        {formatCurrency(c.revenue)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <p className="text-center py-8 text-gray-400">Sem dados</p>
            )}
          </CardContent>
        </Card>

        {/* Top 5 Engajamento */}
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <TrendingUp className="w-5 h-5" style={{ color: '#4B2672' }} />
              Top 5 por Engajamento
            </CardTitle>
          </CardHeader>
          <CardContent>
            {engagementRanking.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50">
                    <TableHead>#</TableHead>
                    <TableHead>Empresa</TableHead>
                    <TableHead className="text-right">Taxa</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {engagementRanking.map((c, idx) => (
                    <TableRow key={c.id}>
                      <TableCell className="font-semibold">{idx + 1}</TableCell>
                      <TableCell className="font-medium">{c.name}</TableCell>
                      <TableCell className="text-right font-semibold" style={{ color: '#4B2672' }}>
                        {c.engagement.toFixed(0)}%
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <p className="text-center py-8 text-gray-400">Sem dados</p>
            )}
          </CardContent>
        </Card>

        {/* Top 5 Crescimento */}
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Users className="w-5 h-5 text-green-600" />
              Top 5 por Crescimento
            </CardTitle>
          </CardHeader>
          <CardContent>
            {growthRanking.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50">
                    <TableHead>#</TableHead>
                    <TableHead>Empresa</TableHead>
                    <TableHead className="text-right">Novos</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {growthRanking.map((c, idx) => (
                    <TableRow key={c.id}>
                      <TableCell className="font-semibold">{idx + 1}</TableCell>
                      <TableCell className="font-medium">{c.name}</TableCell>
                      <TableCell className="text-right text-green-600 font-semibold">
                        +{c.newEmployees}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <p className="text-center py-8 text-gray-400">Sem dados</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}