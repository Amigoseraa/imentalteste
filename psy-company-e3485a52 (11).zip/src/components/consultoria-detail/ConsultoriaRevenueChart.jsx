import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { DollarSign, TrendingUp, AlertCircle } from "lucide-react";
import { format, subMonths } from "date-fns";

export default function ConsultoriaRevenueChart({ faturas, faturamentoMesAtual, mrr }) {
  // Gerar dados dos últimos 6 meses
  const getRevenueData = () => {
    const data = [];
    for (let i = 5; i >= 0; i--) {
      const date = subMonths(new Date(), i);
      const monthKey = format(date, 'yyyy-MM');
      const monthName = format(date, 'MMM/yy');
      
      const monthFaturas = faturas.filter(f => f.competencia === monthKey);
      const pagas = monthFaturas.filter(f => f.status === 'paga').reduce((acc, f) => acc + (f.valor_total || 0), 0);
      const pendentes = monthFaturas.filter(f => f.status === 'pendente').reduce((acc, f) => acc + (f.valor_total || 0), 0);
      
      data.push({
        month: monthName,
        pagas,
        pendentes,
        total: pagas + pendentes
      });
    }
    return data;
  };

  const revenueData = getRevenueData();
  
  const faturasAtrasadas = faturas.filter(f => f.status === 'vencida' || f.status === 'atrasada').length;
  const valorAtrasado = faturas
    .filter(f => f.status === 'vencida' || f.status === 'atrasada')
    .reduce((acc, f) => acc + (f.valor_total || 0), 0);

  const formatCurrency = (value) => {
    return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 0 });
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold" style={{ color: '#2E2E2E' }}>
        💰 Faturamento e Receita
      </h2>

      <div className="grid lg:grid-cols-4 gap-6">
        {/* KPIs Resumidos */}
        <Card className="shadow-md">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-green-600" />
              MRR
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-green-600">
              {formatCurrency(mrr)}
            </p>
            <p className="text-xs text-gray-500 mt-1">Receita recorrente</p>
          </CardContent>
        </Card>

        <Card className="shadow-md">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <TrendingUp className="w-4 h-4" style={{ color: '#4B2672' }} />
              Faturas Pagas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold" style={{ color: '#4B2672' }}>
              {formatCurrency(faturamentoMesAtual)}
            </p>
            <p className="text-xs text-gray-500 mt-1">Mês atual</p>
          </CardContent>
        </Card>

        <Card className="shadow-md">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-yellow-600" />
              Faturas Pendentes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-yellow-600">
              {faturas.filter(f => f.status === 'pendente').length}
            </p>
            <p className="text-xs text-gray-500 mt-1">Aguardando pagamento</p>
          </CardContent>
        </Card>

        <Card className="shadow-md">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-600" />
              Inadimplência
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-red-600">
              {faturasAtrasadas}
            </p>
            <p className="text-xs text-gray-500 mt-1">
              {formatCurrency(valorAtrasado)}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Gráfico de Linha */}
      <Card className="shadow-md">
        <CardHeader>
          <CardTitle>📊 Evolução de Faturamento (6 meses)</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={revenueData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className="bg-white p-3 rounded-lg shadow-lg border border-gray-200">
                        <p className="font-semibold mb-1">{payload[0].payload.month}</p>
                        <p className="text-sm text-green-600">
                          Pagas: {formatCurrency(payload[0].payload.pagas)}
                        </p>
                        <p className="text-sm text-yellow-600">
                          Pendentes: {formatCurrency(payload[0].payload.pendentes)}
                        </p>
                        <p className="text-sm font-semibold" style={{ color: '#4B2672' }}>
                          Total: {formatCurrency(payload[0].payload.total)}
                        </p>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Line type="monotone" dataKey="pagas" stroke="#00B37E" strokeWidth={2} />
              <Line type="monotone" dataKey="pendentes" stroke="#FFD84D" strokeWidth={2} />
              <Line type="monotone" dataKey="total" stroke="#4B2672" strokeWidth={2} strokeDasharray="5 5" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}