import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertCircle, AlertTriangle, Bell, TrendingUp } from "lucide-react";
import { toast } from "sonner";
import { format, subDays } from "date-fns";

export default function ConsultoriaAlerts({ companies, assessments, faturas, consultoriaId, currentMonth }) {
  const generateAlerts = () => {
    const alerts = [];
    const sixtyDaysAgo = subDays(new Date(), 60);

    companies.forEach(company => {
      // Alerta: Empresa sem movimento
      const companyAssessments = assessments.filter(a => a.company_id === company.id);
      const lastAssessment = companyAssessments
        .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))[0];

      if (lastAssessment && new Date(lastAssessment.created_date) < sixtyDaysAgo) {
        alerts.push({
          type: 'warning',
          icon: AlertTriangle,
          color: 'text-orange-600',
          bgColor: 'bg-orange-50',
          borderColor: 'border-orange-200',
          title: 'Empresa sem movimento',
          message: `${company.name} não envia avaliações há mais de 60 dias`,
          action: () => toast.info('Entrando em contato...')
        });
      }

      // Alerta: Baixo engajamento
      const completedCount = companyAssessments.filter(a => a.completed_at).length;
      const engagement = companyAssessments.length > 0
        ? (completedCount / companyAssessments.length) * 100
        : 0;

      if (engagement < 40 && companyAssessments.length > 0) {
        alerts.push({
          type: 'info',
          icon: Bell,
          color: 'text-blue-600',
          bgColor: 'bg-blue-50',
          borderColor: 'border-blue-200',
          title: 'Baixo engajamento',
          message: `${company.name} tem apenas ${engagement.toFixed(0)}% de respostas`,
          action: () => toast.info('Enviando notificação...')
        });
      }

      // Alerta: Alta performance
      if (engagement >= 85 && companyAssessments.length >= 10) {
        alerts.push({
          type: 'success',
          icon: TrendingUp,
          color: 'text-green-600',
          bgColor: 'bg-green-50',
          borderColor: 'border-green-200',
          title: 'Alta performance',
          message: `${company.name} atingiu ${engagement.toFixed(0)}% de engajamento`,
          action: null
        });
      }
    });

    // Alerta: Faturas atrasadas
    const overdueInvoices = faturas.filter(f => 
      (f.status === 'vencida' || f.status === 'atrasada') && f.competencia === currentMonth
    );

    if (overdueInvoices.length > 0) {
      const totalOverdue = overdueInvoices.reduce((acc, f) => acc + (f.valor_total || 0), 0);
      alerts.push({
        type: 'critical',
        icon: AlertCircle,
        color: 'text-red-600',
        bgColor: 'bg-red-50',
        borderColor: 'border-red-200',
        title: 'Faturas atrasadas',
        message: `${overdueInvoices.length} fatura(s) vencida(s) totalizando ${totalOverdue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}`,
        action: () => toast.info('Gerando cobrança...')
      });
    }

    return alerts
      .sort((a, b) => {
        const priority = { critical: 0, warning: 1, info: 2, success: 3 };
        return priority[a.type] - priority[b.type];
      })
      .slice(0, 6);
  };

  const alerts = generateAlerts();

  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell className="w-5 h-5" style={{ color: '#FFD84D' }} />
          Alertas Inteligentes
        </CardTitle>
      </CardHeader>
      <CardContent>
        {alerts.length > 0 ? (
          <div className="space-y-3">
            {alerts.map((alert, idx) => (
              <div
                key={idx}
                className={`p-3 rounded-lg border ${alert.bgColor} ${alert.borderColor} transition-all hover:shadow-md`}
              >
                <div className="flex items-start gap-3">
                  <alert.icon className={`w-5 h-5 ${alert.color} flex-shrink-0 mt-0.5`} />
                  <div className="flex-1">
                    <p className={`text-sm font-semibold ${alert.color} mb-1`}>
                      {alert.title}
                    </p>
                    <p className="text-xs text-gray-600 leading-relaxed">
                      {alert.message}
                    </p>
                    {alert.action && (
                      <Button
                        size="sm"
                        variant="outline"
                        className="mt-2"
                        onClick={alert.action}
                      >
                        Ação
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <Bell className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-sm text-gray-500">Nenhum alerta no momento</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}