
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Brain,
  Frown,
  Activity,
  Users,
  AlertCircle,
  TrendingUp,
  Info,
} from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { format, parseISO, startOfMonth } from "date-fns";
import { base44 } from "@/api/base44Client";
import { Badge } from "@/components/ui/badge";

// Helper function to get color based on score (duplicated for modularity in AutomaticInsights)
const getColor = (value) => {
  if (!value) return "#f3f4f6";
  const num = parseFloat(value);
  if (num <= 4) return "#10b981";
  if (num <= 9) return "#f59e0b";
  if (num <= 14) return "#f97316";
  return "#ef4444";
};

// New AutomaticInsights Component
function AutomaticInsights({ assessments, departments }) {
  const [insights, setInsights] = useState(null);
  const [loadingInsights, setLoadingInsights] = useState(false);

  // Helper functions for insights (duplicated from dashboard for modularity)
  const calculateMHScore = (assessmentsData) => {
    if (assessmentsData.length === 0) return 0;

    const totalScore = assessmentsData.reduce((sum, a) => {
      const phq9 = a.phq9_score || 0;
      const gad7 = a.gad7_score || 0;

      const normalized = 100 - (((phq9 / 27) + (gad7 / 21)) / 2) * 100;
      return sum + normalized;
    }, 0);

    return (totalScore / assessmentsData.length).toFixed(1);
  };

  const calculatePHQ9Average = (assessmentsData) => {
    const withPHQ9 = assessmentsData.filter(
      (a) => a.phq9_score !== undefined && a.phq9_score !== null
    );
    if (withPHQ9.length === 0) return 0;

    const sum = withPHQ9.reduce((acc, a) => acc + a.phq9_score, 0);
    return (sum / withPHQ9.length).toFixed(1);
  };

  const calculateGAD7Average = (assessmentsData) => {
    const withGAD7 = assessmentsData.filter(
      (a) => a.gad7_score !== undefined && a.gad7_score !== null
    );
    if (withGAD7.length === 0) return 0;

    const sum = withGAD7.reduce((acc, a) => acc + a.gad7_score, 0);
    return (sum / withGAD7.length).toFixed(1);
  };

  const casesInAlert = (assessmentsData) => {
    const alerts = assessmentsData.filter(
      (a) => (a.phq9_score && a.phq9_score >= 10) || (a.gad7_score && a.gad7_score >= 10)
    ).length;

    return assessmentsData.length > 0
      ? ((alerts / assessmentsData.length) * 100).toFixed(1)
      : 0;
  };

  const getDepartmentDistribution = (assessmentsData, departmentsData) => {
    const deptData = {};

    departmentsData.forEach((dept) => {
      deptData[dept.id] = {
        name: dept.name,
        phq9: [],
        gad7: [],
      };
    });

    assessmentsData.forEach((a) => {
      if (deptData[a.department_id]) {
        if (a.phq9_score !== undefined)
          deptData[a.department_id].phq9.push(a.phq9_score);
        if (a.gad7_score !== undefined)
          deptData[a.department_id].gad7.push(a.gad7_score);
      }
    });

    return Object.values(deptData)
      .filter((d) => d.phq9.length > 0 || d.gad7.length > 0)
      .map((d) => ({
        name: d.name,
        phq9Avg:
          d.phq9.length > 0
            ? (d.phq9.reduce((a, b) => a + b, 0) / d.phq9.length).toFixed(1)
            : null,
        gad7Avg:
          d.gad7.length > 0
            ? (d.gad7.reduce((a, b) => a + b, 0) / d.gad7.length).toFixed(1)
            : null,
        respondentes: Math.max(d.phq9.length, d.gad7.length),
      }));
  };

  // Generate Insights with AI
  useEffect(() => {
    const generateInsights = async () => {
      if (assessments.length === 0) {
        setInsights(null); // Clear insights if no data
        setLoadingInsights(false);
        return;
      }

      setLoadingInsights(true);

      try {
        const deptDistribution = getDepartmentDistribution(assessments, departments);
        const mhScore = calculateMHScore(assessments);
        const alertRate = casesInAlert(assessments);
        const phq9Avg = calculatePHQ9Average(assessments);
        const gad7Avg = calculateGAD7Average(assessments);

        // Sort departments by average PHQ-9 or GAD-7 to find the most critical
        const sortedDept = [...deptDistribution].sort((a, b) => {
            const scoreA = Math.max(parseFloat(a.phq9Avg || 0), parseFloat(a.gad7Avg || 0));
            const scoreB = Math.max(parseFloat(b.phq9Avg || 0), parseFloat(b.gad7Avg || 0));
            return scoreB - scoreA; // Descending order
        });
        const mostCriticalDept = sortedDept.length > 0 ? sortedDept[0] : null;

        const prompt = `
Analise os seguintes dados de saúde mental corporativa e gere um insight em português. O insight deve ser conciso (máximo 3 frases), profissional e empático, abordando os pontos principais:

- Score de Saúde Mental Geral da Empresa: ${mhScore}/100
- Taxa de Casos em Alerta (PHQ-9 ou GAD-7 >= 10): ${alertRate}%
- PHQ-9 Médio (Depressão): ${phq9Avg}
- GAD-7 Médio (Ansiedade): ${gad7Avg}
${mostCriticalDept ? `- Departamento com maior índice de alerta: ${mostCriticalDept.name} (PHQ-9 médio: ${mostCriticalDept.phq9Avg || 'N/A'}, GAD-7 médio: ${mostCriticalDept.gad7Avg || 'N/A'})` : ''}

Com base nesses dados, gere um parágrafo conciso (máximo 3 frases) explicando:
1. Uma observação sobre o estado geral da saúde mental da empresa ou um destaque sobre o departamento mais crítico, se houver.
2. Uma recomendação prática e acionável para a gestão.
3. Mantenha um tom profissional, empático e de suporte.
        `;

        const response = await base44.integrations.Core.InvokeLLM({
          prompt,
          response_json_schema: {
            type: "object",
            properties: {
              insight: { type: "string" },
            },
          },
        });

        setInsights(response.insight);
      } catch (error) {
        console.error("Error generating insights:", error);
        setInsights("Não foi possível gerar insights automáticos no momento devido a um erro. Por favor, tente novamente mais tarde.");
      } finally {
        setLoadingInsights(false);
      }
    };

    generateInsights();
  }, [assessments, departments]); // Re-run if assessments or departments change

  return (
    <Card className="shadow-md border-2" style={{ borderColor: "#A77BCA", backgroundColor: "#EFE6F8" }}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2" style={{ color: "#5E2C91" }}>
          <TrendingUp className="w-5 h-5" />
          Análise Inteligente
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loadingInsights ? (
          <div className="flex items-center gap-3">
            <div className="w-5 h-5 border-2 border-purple-600 border-t-transparent rounded-full animate-spin"></div>
            <p className="text-sm" style={{ color: "#5E2C91" }}>
              Gerando análise inteligente...
            </p>
          </div>
        ) : insights ? (
          <p className="text-sm leading-relaxed" style={{ color: "#5E2C91" }}>
            {insights}
          </p>
        ) : (
          <p className="text-sm" style={{ color: "#5E2C91" }}>
            Dados insuficientes para gerar análise no momento. Certifique-se de que há avaliações completas e departamentos cadastrados.
          </p>
        )}
      </CardContent>
    </Card>
  );
}

export default function MentalHealthDashboard({ assessments, employees, departments }) {
  // Calcular Score de Saúde Mental (0-100, invertido)
  const calculateMHScore = () => {
    if (assessments.length === 0) return 0;

    const totalScore = assessments.reduce((sum, a) => {
      const phq9 = a.phq9_score || 0;
      const gad7 = a.gad7_score || 0;

      // Normalizar: PHQ-9 máx 27, GAD-7 máx 21
      // Score invertido: quanto menor a pontuação, melhor a saúde
      const normalized = 100 - (((phq9 / 27) + (gad7 / 21)) / 2) * 100;
      return sum + normalized;
    }, 0);

    return (totalScore / assessments.length).toFixed(1);
  };

  // Média PHQ-9
  const calculatePHQ9Average = () => {
    const withPHQ9 = assessments.filter(
      (a) => a.phq9_score !== undefined && a.phq9_score !== null
    );
    if (withPHQ9.length === 0) return 0;

    const sum = withPHQ9.reduce((acc, a) => acc + a.phq9_score, 0);
    return (sum / withPHQ9.length).toFixed(1);
  };

  // Média GAD-7
  const calculateGAD7Average = () => {
    const withGAD7 = assessments.filter(
      (a) => a.gad7_score !== undefined && a.gad7_score !== null
    );
    if (withGAD7.length === 0) return 0;

    const sum = withGAD7.reduce((acc, a) => acc + a.gad7_score, 0);
    return (sum / withGAD7.length).toFixed(1);
  };

  // Taxa de Engajamento
  const engagementRate =
    employees.length > 0
      ? ((assessments.length / employees.length) * 100).toFixed(1)
      : 0;

  // Casos em Alerta (PHQ≥10 ou GAD≥10)
  const casesInAlert = () => {
    const alerts = assessments.filter(
      (a) => (a.phq9_score && a.phq9_score >= 10) || (a.gad7_score && a.gad7_score >= 10)
    ).length;

    return assessments.length > 0
      ? ((alerts / assessments.length) * 100).toFixed(1)
      : 0;
  };

  // Distribuição de Severidade
  const getSeverityDistribution = () => {
    const phq9Distribution = { minimal: 0, mild: 0, moderate: 0, severe: 0 };
    const gad7Distribution = { minimal: 0, mild: 0, moderate: 0, severe: 0 };

    assessments.forEach((a) => {
      // PHQ-9: 0-4 minimal, 5-9 mild, 10-14 moderate, 15-19 moderately severe, 20-27 severe
      if (a.phq9_score !== undefined && a.phq9_score !== null) {
        if (a.phq9_score <= 4) phq9Distribution.minimal++;
        else if (a.phq9_score <= 9) phq9Distribution.mild++;
        else if (a.phq9_score <= 14) phq9Distribution.moderate++;
        else phq9Distribution.severe++;
      }

      // GAD-7: 0-4 minimal, 5-9 mild, 10-14 moderate, 15-21 severe
      if (a.gad7_score !== undefined && a.gad7_score !== null) {
        if (a.gad7_score <= 4) gad7Distribution.minimal++;
        else if (a.gad7_score <= 9) gad7Distribution.mild++;
        else if (a.gad7_score <= 14) gad7Distribution.moderate++;
        else gad7Distribution.severe++;
      }
    });

    const total = assessments.length || 1;

    return [
      {
        name: "PHQ-9 (Depressão)",
        nenhum: ((phq9Distribution.minimal / total) * 100).toFixed(1),
        leve: ((phq9Distribution.mild / total) * 100).toFixed(1),
        moderado: ((phq9Distribution.moderate / total) * 100).toFixed(1),
        grave: ((phq9Distribution.severe / total) * 100).toFixed(1),
      },
      {
        name: "GAD-7 (Ansiedade)",
        nenhum: ((gad7Distribution.minimal / total) * 100).toFixed(1),
        leve: ((gad7Distribution.mild / total) * 100).toFixed(1),
        moderado: ((gad7Distribution.moderate / total) * 100).toFixed(1),
        grave: ((gad7Distribution.severe / total) * 100).toFixed(1),
      },
    ];
  };

  // Distribuição Geral (Pie)
  const getOverallDistribution = () => {
    let minimal = 0,
      mild = 0,
      moderate = 0,
      severe = 0;

    assessments.forEach((a) => {
      const avgScore = ((a.phq9_score || 0) + (a.gad7_score || 0)) / 2;

      if (avgScore <= 4) minimal++;
      else if (avgScore <= 9) mild++;
      else if (avgScore <= 14) moderate++;
      else severe++;
    });

    return [
      { name: "Sem Sintomas", value: minimal, color: "#10b981" },
      { name: "Sintomas Leves", value: mild, color: "#f59e0b" },
      { name: "Sintomas Moderados", value: moderate, color: "#f97316" },
      { name: "Sintomas Graves", value: severe, color: "#ef4444" },
    ];
  };

  // Tendência Temporal
  const getTemporalTrend = () => {
    const monthlyData = {};

    assessments.forEach((a) => {
      if (!a.completed_at) return;

      const month = format(startOfMonth(parseISO(a.completed_at)), "MM/yyyy");

      if (!monthlyData[month]) {
        monthlyData[month] = { phq9: [], gad7: [], count: 0 };
      }

      if (a.phq9_score !== undefined)
        monthlyData[month].phq9.push(a.phq9_score);
      if (a.gad7_score !== undefined)
        monthlyData[month].gad7.push(a.gad7_score);
      monthlyData[month].count++;
    });

    return Object.entries(monthlyData)
      .map(([month, data]) => ({
        month,
        "PHQ-9":
          data.phq9.length > 0
            ? (data.phq9.reduce((a, b) => a + b, 0) / data.phq9.length).toFixed(
                1
              )
            : null,
        "GAD-7":
          data.gad7.length > 0
            ? (data.gad7.reduce((a, b) => a + b, 0) / data.gad7.length).toFixed(
                1
              )
            : null,
        respondentes: data.count,
      }))
      .sort((a, b) => {
        const [monthA, yearA] = a.month.split("/");
        const [monthB, yearB] = b.month.split("/");
        return new Date(yearA, monthA - 1) - new Date(yearB, monthB - 1);
      });
  };

  // Distribuição por Departamento (Heatmap data)
  const getDepartmentDistribution = () => {
    const deptData = {};

    departments.forEach((dept) => {
      deptData[dept.id] = {
        name: dept.name,
        phq9: [],
        gad7: [],
      };
    });

    assessments.forEach((a) => {
      if (deptData[a.department_id]) {
        if (a.phq9_score !== undefined)
          deptData[a.department_id].phq9.push(a.phq9_score);
        if (a.gad7_score !== undefined)
          deptData[a.department_id].gad7.push(a.gad7_score);
      }
    });

    return Object.values(deptData)
      .filter((d) => d.phq9.length > 0 || d.gad7.length > 0)
      .map((d) => ({
        name: d.name,
        phq9Avg:
          d.phq9.length > 0
            ? (d.phq9.reduce((a, b) => a + b, 0) / d.phq9.length).toFixed(1)
            : null,
        gad7Avg:
          d.gad7.length > 0
            ? (d.gad7.reduce((a, b) => a + b, 0) / d.gad7.length).toFixed(1)
            : null,
        respondentes: Math.max(d.phq9.length, d.gad7.length),
      }));
  };

  const mhScore = parseFloat(calculateMHScore());
  const phq9Avg = parseFloat(calculatePHQ9Average());
  const gad7Avg = parseFloat(calculateGAD7Average());
  const alertPct = parseFloat(casesInAlert());

  const getMHColor = (score) => {
    if (score >= 75)
      return { color: "text-green-600", bg: "bg-green-50", icon: "bg-green-500" };
    if (score >= 50)
      return { color: "text-yellow-600", bg: "bg-yellow-50", icon: "bg-yellow-500" };
    return { color: "text-red-600", bg: "bg-red-50", icon: "bg-red-500" };
  };

  const mhColors = getMHColor(mhScore);
  const severityData = getSeverityDistribution();
  const overallDist = getOverallDistribution();
  const temporalData = getTemporalTrend();
  const deptData = getDepartmentDistribution();


  return (
    <div className="space-y-8">
      {/* Indicadores Principais */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-shadow">
          <div
            className={`absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 ${mhColors.icon} rounded-full opacity-10`}
          />
          <CardHeader className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <div className="flex items-center gap-2 mb-1">
                        <p className="text-sm font-medium text-gray-600">
                          Saúde Mental Média
                        </p>
                        <Info className="w-4 h-4 text-gray-400" />
                      </div>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="text-xs max-w-xs">
                        Índice composto (0-100) baseado em PHQ-9 e GAD-7.
                        Quanto maior, melhor a saúde mental.
                      </p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
                <p className={`text-4xl font-bold ${mhColors.color}`}>
                  {mhScore}
                </p>
                <p className="text-xs text-gray-500 mt-2">
                  {mhScore >= 75 ? "Saudável" : mhScore >= 50 ? "Atenção" : "Crítico"}
                </p>
              </div>
              <div className={`p-3 rounded-xl ${mhColors.bg}`}>
                <Brain className={`w-6 h-6 ${mhColors.color}`} />
              </div>
            </div>
          </CardHeader>
        </Card>

        <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-shadow">
          <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 bg-purple-500 rounded-full opacity-10" />
          <CardHeader className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <div className="flex items-center gap-2 mb-1">
                        <p className="text-sm font-medium text-gray-600">
                          Depressão (PHQ-9)
                        </p>
                        <Info className="w-4 h-4 text-gray-400" />
                      </div>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="text-xs max-w-xs">
                        Escala 0-27. Leve: 5-9, Moderado: 10-14, Grave: ≥15
                      </p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
                <p className="text-4xl font-bold text-purple-600">{phq9Avg}</p>
                <p className="text-xs text-gray-500 mt-2">Média geral</p>
              </div>
              <div className="p-3 rounded-xl bg-purple-50">
                <Frown className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </CardHeader>
        </Card>

        <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-shadow">
          <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 bg-blue-500 rounded-full opacity-10" />
          <CardHeader className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <div className="flex items-center gap-2 mb-1">
                        <p className="text-sm font-medium text-gray-600">
                          Ansiedade (GAD-7)
                        </p>
                        <Info className="w-4 h-4 text-gray-400" />
                      </div>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="text-xs max-w-xs">
                        Escala 0-21. Leve: 5-9, Moderado: 10-14, Grave: ≥15
                      </p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
                <p className="text-4xl font-bold text-blue-600">{gad7Avg}</p>
                <p className="text-xs text-gray-500 mt-2">Média geral</p>
              </div>
              <div className="p-3 rounded-xl bg-blue-50">
                <Activity className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </CardHeader>
        </Card>

        <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-shadow">
          <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 bg-teal-500 rounded-full opacity-10" />
          <CardHeader className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-gray-600 mb-1">
                  Taxa de Engajamento
                </p>
                <p className="text-4xl font-bold text-teal-600">
                  {engagementRate}%
                </p>
                <p className="text-xs text-gray-500 mt-2">
                  {assessments.length} respondentes
                </p>
              </div>
              <div className="p-3 rounded-xl bg-teal-50">
                <Users className="w-6 h-6 text-teal-600" />
              </div>
            </div>
          </CardHeader>
        </Card>

        <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-shadow">
          <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 bg-orange-500 rounded-full opacity-10" />
          <CardHeader className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <div className="flex items-center gap-2 mb-1">
                        <p className="text-sm font-medium text-gray-600">
                          Casos em Alerta
                        </p>
                        <Info className="w-4 h-4 text-gray-400" />
                      </div>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="text-xs max-w-xs">
                        Colaboradores com PHQ-9 ≥10 ou GAD-7 ≥10
                      </p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
                <p className="text-4xl font-bold text-orange-600">
                  {alertPct}%
                </p>
                <p className="text-xs text-gray-500 mt-2">Moderado/Grave</p>
              </div>
              <div className="p-3 rounded-xl bg-orange-50">
                <AlertCircle className="w-6 h-6 text-orange-600" />
              </div>
            </div>
          </CardHeader>
        </Card>
      </div>

      {/* Distribuição de Severidade */}
      <div className="grid lg:grid-cols-2 gap-6">
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle>Distribuição de Severidade por Instrumento</CardTitle>
          </CardHeader>
          <CardContent>
            {severityData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={severityData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                  <YAxis />
                  <RechartsTooltip />
                  <Legend />
                  <Bar dataKey="nenhum" stackId="a" fill="#10b981" name="Sem Sintomas" />
                  <Bar dataKey="leve" stackId="a" fill="#f59e0b" name="Leve" />
                  <Bar dataKey="moderado" stackId="a" fill="#f97316" name="Moderado" />
                  <Bar dataKey="grave" stackId="a" fill="#ef4444" name="Grave" />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-gray-400">
                Aguardando dados
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="shadow-md">
          <CardHeader>
            <CardTitle>Distribuição Geral de Severidade</CardTitle>
          </CardHeader>
          <CardContent>
            {overallDist.length > 0 && overallDist.some((d) => d.value > 0) ? (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={overallDist}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {overallDist.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <RechartsTooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-gray-400">
                Aguardando dados
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Tendência Temporal */}
      <Card className="shadow-md">
        <CardHeader>
          <CardTitle>Evolução Temporal da Saúde Mental</CardTitle>
        </CardHeader>
        <CardContent>
          {temporalData.length > 0 ? (
            <ResponsiveContainer width="100%" height={350}>
              <LineChart data={temporalData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis domain={[0, 27]} />
                <RechartsTooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      return (
                        <div className="bg-white p-3 border rounded shadow-lg">
                          <p className="font-semibold">
                            {payload[0].payload.month}
                          </p>
                          <p className="text-sm text-purple-600">
                            PHQ-9: {payload[0].value}
                          </p>
                          <p className="text-sm text-blue-600">
                            GAD-7: {payload[1]?.value || "-"}
                          </p>
                          <p className="text-xs text-gray-500 mt-1">
                            {payload[0].payload.respondentes} respondentes
                          </p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Legend />
                <Line type="monotone" dataKey="PHQ-9" stroke="#a855f7" strokeWidth={3} />
                <Line type="monotone" dataKey="GAD-7" stroke="#3b82f6" strokeWidth={3} />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[350px] flex items-center justify-center text-gray-400">
              Aguardando dados históricos
            </div>
          )}
        </CardContent>
      </Card>

      {/* Distribuição por Departamento */}
      <Card className="shadow-md">
        <CardHeader>
          <CardTitle>Mapa de Calor - Saúde Mental por Departamento</CardTitle>
        </CardHeader>
        <CardContent>
          {deptData.length > 0 ? (
            <div className="overflow-x-auto">
              <div className="min-w-[600px]">
                <div className="grid grid-cols-4 gap-2 mb-2 font-semibold text-sm text-gray-600">
                  <div>Departamento</div>
                  <div className="text-center">PHQ-9</div>
                  <div className="text-center">GAD-7</div>
                  <div className="text-center">Respondentes</div>
                </div>
                {deptData.map((dept, idx) => (
                  <div key={idx} className="grid grid-cols-4 gap-2 mb-2 items-center">
                    <div className="font-medium text-gray-800">{dept.name}</div>
                    <div
                      className="p-3 rounded text-center font-semibold"
                      style={{ backgroundColor: getColor(dept.phq9Avg), color: "#fff" }}
                      title={`PHQ-9: ${dept.phq9Avg || "N/A"}`}
                    >
                      {dept.phq9Avg || "-"}
                    </div>
                    <div
                      className="p-3 rounded text-center font-semibold"
                      style={{ backgroundColor: getColor(dept.gad7Avg), color: "#fff" }}
                      title={`GAD-7: ${dept.gad7Avg || "N/A"}`}
                    >
                      {dept.gad7Avg || "-"}
                    </div>
                    <div className="text-center text-gray-600">
                      {dept.respondentes}
                    </div>
                  </div>
                ))}
                <div className="mt-6 flex items-center justify-center gap-6 text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded" style={{ backgroundColor: "#10b981" }}></div>
                    <span>Baixo (≤4)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded" style={{ backgroundColor: "#f59e0b" }}></div>
                    <span>Leve (5-9)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded" style={{ backgroundColor: "#f97316" }}></div>
                    <span>Moderado (10-14)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded" style={{ backgroundColor: "#ef4444" }}></div>
                    <span>Grave (≥15)</span>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="h-[200px] flex items-center justify-center text-gray-400">
              Aguardando dados por departamento
            </div>
          )}
        </CardContent>
      </Card>

      {/* Insights Automáticos */}
      <div>
        <h2 className="text-2xl font-bold mb-4" style={{ color: "#2B2240" }}>
          Insights Automáticos
        </h2>
        <AutomaticInsights assessments={assessments} departments={departments} />
      </div>
    </div>
  );
}
