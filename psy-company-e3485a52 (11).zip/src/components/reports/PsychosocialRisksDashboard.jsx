
import React, { useState, useEffect, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  AlertTriangle,
  Building2,
  TrendingUp,
  Info,
  Shield
} from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  ResponsiveContainer,
  Tooltip as RechartsTooltip,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Legend,
  ScatterChart,
  Scatter,
  ZAxis
} from "recharts";
import { base44 } from "@/api/base44Client";

const PRIMA_CATEGORIES = {
  'A': 'Teor do Trabalho',
  'B': 'Carga e Ritmo',
  'C': 'Horário',
  'D': 'Controle',
  'E': 'Ambiente',
  'F': 'Cultura',
  'G': 'Relações',
  'H': 'Papéis',
  'I': 'Carreira',
  'J': 'Interface Lar-Trabalho'
};

// New AutomaticInsights Component
function AutomaticInsights({ iep, topRisks, topDepts, assessmentsCount }) {
  const [insights, setInsights] = useState(null);
  const [loadingInsights, setLoadingInsights] = useState(false);

  useEffect(() => {
    const generateInsights = async () => {
      // Clear previous insights if data becomes insufficient
      if (assessmentsCount === 0 || iep === undefined || topRisks.length === 0 || topDepts.length === 0) {
        setInsights(null);
        setLoadingInsights(false); // Ensure loading is off if no data
        return;
      }

      setLoadingInsights(true);

      try {
        const prompt = `
Analise os seguintes dados de riscos psicossociais corporativos e gere um insight em português:

- IEP (Índice de Exposição): ${iep}/100
- Top 3 Fatores de Risco (PRIMA-EF): ${JSON.stringify(topRisks.slice(0, 3))}
- Departamentos mais críticos: ${JSON.stringify(topDepts.slice(0, 3))}

Gere um parágrafo conciso (max 3 frases) explicando:
1. Quais fatores psicossociais estão mais críticos
2. Uma recomendação prática para o PGR
3. Tom profissional e técnico
        `;

        const response = await base44.integrations.Core.InvokeLLM({
          prompt,
          response_json_schema: {
            type: "object",
            properties: {
              insight: { type: "string" }
            }
          }
        });

        setInsights(response.insight);
      } catch (error) {
        console.error('Error generating insights:', error);
        setInsights("Ocorreu um erro ao gerar os insights."); // User-friendly error message
      } finally {
        setLoadingInsights(false);
      }
    };

    // Trigger insight generation when relevant data changes
    if (assessmentsCount > 0 && iep !== undefined && topRisks.length > 0 && topDepts.length > 0) {
      generateInsights();
    } else {
      setInsights(null); // Clear insights if conditions are not met
    }
  }, [iep, topRisks, topDepts, assessmentsCount]); // Dependencies for useEffect

  return (
    <Card className="shadow-md border-2" style={{ borderColor: '#A77BCA', backgroundColor: '#EFE6F8' }}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2" style={{ color: '#5E2C91' }}>
          <TrendingUp className="w-5 h-5" />
          Insights e Ações Recomendadas
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loadingInsights ? (
          <div className="flex items-center gap-3">
            <div className="w-5 h-5 border-2 border-purple-600 border-t-transparent rounded-full animate-spin"></div>
            <p className="text-sm" style={{ color: '#5E2C91' }}>Gerando análise técnica...</p>
          </div>
        ) : insights ? (
          <p className="text-sm leading-relaxed" style={{ color: '#5E2C91' }}>
            {insights}
          </p>
        ) : (
          <p className="text-sm" style={{ color: '#5E2C91' }}>
            Dados insuficientes para gerar insights no momento.
          </p>
        )}
      </CardContent>
    </Card>
  );
}


export default function PsychosocialRisksDashboard({ assessments, employees, departments }) {
  // Calcular IEP (Índice de Exposição Psicossocial)
  const calculateIEP = useCallback(() => {
    if (assessments.length === 0) return 0;

    const primaScores = assessments
      .filter(a => a.prima_score !== undefined && a.prima_score !== null)
      .map(a => a.prima_score);

    if (primaScores.length === 0) return 0;

    const avgPrima = primaScores.reduce((a, b) => a + b, 0) / primaScores.length;

    // Normalizar para 0-100 (PRIMA é 1-5, quanto menor, pior)
    // Formula: ((score - min) / (max - min)) * 100
    // For PRIMA: min=1, max=5. Lower score is worse.
    // To make higher value = worse: ((5 - avgPrima) / 4) * 100
    // To make higher value = better: ((avgPrima - 1) / 4) * 100 (which is what was used)
    // The previous implementation for IEP implies higher score is *better* (less risk).
    // Let's keep it consistent with the previous logic for 'calculateIEP' which maps to 0-100 where 100 is "better" (less risk).
    return parseFloat((((avgPrima - 1) / 4) * 100).toFixed(1));
  }, [assessments]);

  // Top Fatores de Risco
  const getTopRiskFactors = useCallback(() => {
    const itemScores = {};

    for (let i = 1; i <= 30; i++) {
      itemScores[i] = [];
    }

    assessments.forEach(a => {
      if (a.prima_responses) {
        for (let i = 1; i <= 30; i++) {
          const value = a.prima_responses[`q${i}`];
          if (value) {
            itemScores[i].push(value);
          }
        }
      }
    });

    const avgScores = Object.entries(itemScores)
      .map(([item, scores]) => {
        if (scores.length === 0) return null;
        const avg = scores.reduce((a, b) => a + b, 0) / scores.length;
        return {
          item: parseInt(item),
          avg: avg.toFixed(2),
          count: scores.length
        };
      })
      .filter(s => s !== null)
      // Sort by average score ascending (lower score means higher risk)
      .sort((a, b) => parseFloat(a.avg) - parseFloat(b.avg))
      .slice(0, 5);

    return avgScores;
  }, [assessments]);

  // Departamentos com maior exposição
  const getTopRiskDepartments = useCallback(() => {
    const deptScores = {};

    departments.forEach(dept => {
      deptScores[dept.id] = {
        name: dept.name,
        scores: []
      };
    });

    assessments.forEach(a => {
      if (a.prima_score && deptScores[a.department_id]) {
        deptScores[a.department_id].scores.push(a.prima_score);
      }
    });

    return Object.values(deptScores)
      .filter(d => d.scores.length > 0)
      .map(d => ({
        name: d.name,
        avg: (d.scores.reduce((a, b) => a + b, 0) / d.scores.length).toFixed(2),
        count: d.scores.length
      }))
      // Sort by average score ascending (lower score means higher risk)
      .sort((a, b) => parseFloat(a.avg) - parseFloat(b.avg))
      .slice(0, 5);
  }, [assessments, departments]);

  // Status de Risco Global
  const getRiskStatus = useCallback(() => {
    const iep = calculateIEP();

    // Interpretation of IEP: higher is better (less risk)
    if (iep >= 70) return { status: 'Baixo', color: '#10b981', icon: 'bg-green-500' }; // Low risk, good score
    if (iep >= 50) return { status: 'Moderado', color: '#f59e0b', icon: 'bg-yellow-500' }; // Moderate risk
    return { status: 'Alto', color: '#ef4444', icon: 'bg-red-500' }; // High risk, low score
  }, [calculateIEP]);

  // Categorias PRIMA
  const getPrimaCategories = useCallback(() => {
    const categoryItems = {
      'A': [1, 2, 3], 'B': [4, 5, 6], 'C': [7, 8, 9], 'D': [10, 11, 12],
      'E': [13, 14, 15], 'F': [16, 17, 18], 'G': [19, 20, 21], 'H': [22, 23, 24],
      'I': [25, 26, 27], 'J': [28, 29, 30]
    };

    return Object.entries(PRIMA_CATEGORIES).map(([key, name]) => {
      let sum = 0;
      let count = 0;

      assessments.forEach(assessment => {
        if (assessment.prima_responses) {
          categoryItems[key].forEach(item => {
            const value = assessment.prima_responses[`q${item}`];
            if (value) {
              sum += value;
              count++;
            }
          });
        }
      });

      return {
        category: name,
        average: count > 0 ? parseFloat((sum / count).toFixed(2)) : 0
      };
    });
  }, [assessments]);

  // Radar Chart Data
  const getRadarData = useCallback(() => {
    return getPrimaCategories();
  }, [getPrimaCategories]);

  // Fatores de Risco por Categoria (Horizontal Bar)
  const getRiskByCategory = useCallback(() => {
    const categories = getPrimaCategories();

    return categories.map(c => ({
      name: c.category.split(' ')[0] + (c.category.split(' ')[1] ? ' ' + c.category.split(' ')[1] : ''),
      // Assuming lower average score indicates higher risk
      alto: c.average > 0 && c.average <= 2.4 ? 100 : 0, // Average 1.0 to 2.4 is High Risk
      medio: c.average > 2.4 && c.average <= 3.4 ? 100 : 0, // Average 2.5 to 3.4 is Medium Risk
      baixo: c.average > 3.4 ? 100 : 0, // Average 3.5 to 5.0 is Low Risk
      value: c.average
    }));
  }, [getPrimaCategories]);

  // Correlação Saúde Mental x Riscos
  const getCorrelationData = useCallback(() => {
    const data = [];

    departments.forEach(dept => {
      const deptAssessments = assessments.filter(a => a.department_id === dept.id);

      if (deptAssessments.length === 0) return;

      const primaScores = deptAssessments
        .filter(a => a.prima_score)
        .map(a => a.prima_score);

      const mhScores = deptAssessments.map(a => {
        // Normalize PHQ-9 (max 27) and GAD-7 (max 21)
        // Higher score = worse mental health. We want "Saúde Mental" to be higher = better.
        const phq9_normalized = a.phq9_score !== undefined && a.phq9_score !== null ? (a.phq9_score / 27) : 0; // 0=good, 1=worst
        const gad7_normalized = a.gad7_score !== undefined && a.gad7_score !== null ? (a.gad7_score / 21) : 0; // 0=good, 1=worst
        
        // Take the average of the two normalized scores
        // If one is missing, consider only the other, if both missing result in 0 (best case)
        let count = 0;
        let sum_normalized = 0;
        if (a.phq9_score !== undefined && a.phq9_score !== null) { sum_normalized += phq9_normalized; count++; }
        if (a.gad7_score !== undefined && a.gad7_score !== null) { sum_normalized += gad7_normalized; count++; }
        
        // Average normalized score (0 = best mental health, 1 = worst mental health)
        return count > 0 ? sum_normalized / count : 0;
      });

      if (primaScores.length > 0 && mhScores.length > 0) {
        const avgPrima = primaScores.reduce((a, b) => a + b, 0) / primaScores.length;
        const avgMH_normalized_worst = mhScores.reduce((a, b) => a + b, 0) / mhScores.length;

        // IEP is already higher = better (less risk)
        const iep_value = (((avgPrima - 1) / 4) * 100);

        // Saúde Mental: 0 = worst, 1 = best. Scale to 0-100 where 100 is best.
        const sm_value = (1 - avgMH_normalized_worst) * 100;

        data.push({
          name: dept.name,
          iep: iep_value,
          sm: sm_value,
          size: deptAssessments.length
        });
      }
    });

    return data;
  }, [assessments, departments]);


  const iep = calculateIEP();
  const topRisks = getTopRiskFactors();
  const topDepts = getTopRiskDepartments();
  const riskStatus = getRiskStatus();
  const primaCategories = getPrimaCategories();
  const radarData = getRadarData();
  const riskByCategory = getRiskByCategory();
  const correlationData = getCorrelationData();

  return (
    <div className="space-y-8">
      {/* Indicadores-Chave */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="relative overflow-hidden shadow-md hover:shadow-lg transition-shadow">
          <div className={`absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 ${riskStatus.icon} rounded-full opacity-10`} />
          <CardHeader className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <div className="flex items-center gap-2 mb-1">
                        <p className="text-sm font-medium text-gray-600">IEP</p>
                        <Info className="w-4 h-4 text-gray-400" />
                      </div>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="text-xs max-w-xs">
                        Índice de Exposição Psicossocial (0-100).
                        Baseado em PRIMA-EF. Valores mais altos indicam menor risco.
                      </p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
                <p className="text-4xl font-bold" style={{ color: riskStatus.color }}>
                  {iep.toFixed(1)}
                </p>
                <p className="text-xs text-gray-500 mt-2">
                  Risco {riskStatus.status}
                </p>
              </div>
              <div className="p-3 rounded-xl" style={{ backgroundColor: riskStatus.color + '20' }}>
                <Shield className="w-6 h-6" style={{ color: riskStatus.color }} />
              </div>
            </div>
          </CardHeader>
        </Card>

        <Card className="shadow-md">
          <CardHeader className="p-6">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-1">Fator Mais Crítico</p>
              <p className="text-lg font-bold text-orange-600">
                {topRisks[0] ? `Item ${topRisks[0].item}` : 'N/A'}
              </p>
              <p className="text-xs text-gray-500 mt-2">
                Média: {topRisks[0]?.avg || '-'} (menor = pior)
              </p>
            </div>
          </CardHeader>
        </Card>

        <Card className="shadow-md">
          <CardHeader className="p-6">
            <div className="flex items-start gap-2">
              <Building2 className="w-5 h-5 text-blue-600 mt-1" />
              <div>
                <p className="text-sm font-medium text-gray-600 mb-1">Dept. Crítico</p>
                <p className="text-lg font-bold text-blue-600">
                  {topDepts[0]?.name || 'N/A'}
                </p>
                <p className="text-xs text-gray-500 mt-2">
                  Média: {topDepts[0]?.avg || '-'} (menor = pior)
                </p>
              </div>
            </div>
          </CardHeader>
        </Card>

        <Card className="relative overflow-hidden shadow-md">
          <div className="absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 bg-purple-500 rounded-full opacity-10" />
          <CardHeader className="p-6">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-1">Respondentes</p>
              <p className="text-4xl font-bold text-purple-600">
                {assessments.length}
              </p>
              <p className="text-xs text-gray-500 mt-2">
                Avaliações completas
              </p>
            </div>
          </CardHeader>
        </Card>
      </div>

      {/* Gráfico Radar */}
      <div className="grid lg:grid-cols-2 gap-6">
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle>Teia de Riscos - Categorias PRIMA-EF</CardTitle>
          </CardHeader>
          <CardContent>
            {radarData.length > 0 ? (
              <ResponsiveContainer width="100%" height={350}>
                <RadarChart data={radarData}>
                  <PolarGrid />
                  <PolarAngleAxis dataKey="category" tick={{ fontSize: 10 }} />
                  <PolarRadiusAxis angle={90} domain={[0, 5]} />
                  <Radar name="Média" dataKey="average" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.5} />
                  <RechartsTooltip />
                </RadarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[350px] flex items-center justify-center text-gray-400">
                Aguardando dados
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="shadow-md">
          <CardHeader>
            <CardTitle>Fatores de Risco por Categoria</CardTitle>
          </CardHeader>
          <CardContent>
            {riskByCategory.length > 0 ? (
              <ResponsiveContainer width="100%" height={350}>
                <BarChart data={riskByCategory} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" domain={[0, 100]} />
                  <YAxis dataKey="name" type="category" width={120} tick={{ fontSize: 11 }} />
                  <RechartsTooltip
                    formatter={(value, name, props) => {
                      if (name === 'alto') return ['Risco Alto', 'Status'];
                      if (name === 'medio') return ['Risco Médio', 'Status'];
                      if (name === 'baixo') return ['Risco Baixo', 'Status'];
                      return value;
                    }}
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        return (
                          <div className="bg-white p-3 border rounded shadow-lg">
                            <p className="font-semibold text-sm">{payload[0].payload.name}</p>
                            <p className="text-xs text-gray-600">Média PRIMA: {payload[0].payload.value}</p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Legend
                    formatter={(value) => {
                      if (value === 'alto') return 'Risco Alto (Média ≤ 2.4)';
                      if (value === 'medio') return 'Risco Médio (Média 2.5-3.4)';
                      if (value === 'baixo') return 'Risco Baixo (Média ≥ 3.5)';
                      return value;
                    }}
                  />
                  <Bar dataKey="baixo" stackId="a" fill="#10b981" name="baixo" />
                  <Bar dataKey="medio" stackId="a" fill="#f59e0b" name="medio" />
                  <Bar dataKey="alto" stackId="a" fill="#ef4444" name="alto" />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[350px] flex items-center justify-center text-gray-400">
                Aguardando dados
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Correlação */}
      <Card className="shadow-md">
        <CardHeader>
          <CardTitle>Correlação: Saúde Mental x Riscos Psicossociais</CardTitle>
        </CardHeader>
        <CardContent>
          {correlationData.length > 0 ? (
            <ResponsiveContainer width="100%" height={350}>
              <ScatterChart>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis
                  type="number"
                  dataKey="iep"
                  name="IEP"
                  domain={[0, 100]}
                  label={{ value: 'Exposição Psicossocial (IEP, Maior = Melhor)', position: 'insideBottom', offset: -5 }}
                />
                <YAxis
                  type="number"
                  dataKey="sm"
                  name="SM"
                  domain={[0, 100]}
                  label={{ value: 'Saúde Mental (Maior = Melhor)', angle: -90, position: 'insideLeft' }}
                />
                <ZAxis type="number" dataKey="size" range={[50, 400]} />
                <RechartsTooltip
                  cursor={{ strokeDasharray: '3 3' }}
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      return (
                        <div className="bg-white p-3 border rounded shadow-lg">
                          <p className="font-semibold text-sm">{payload[0].payload.name}</p>
                          <p className="text-xs">IEP: {payload[0].payload.iep.toFixed(1)}</p>
                          <p className="text-xs">Saúde Mental: {payload[0].payload.sm.toFixed(1)}</p>
                          <p className="text-xs text-gray-500">{payload[0].payload.size} respondentes</p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Scatter name="Departamentos" data={correlationData} fill="#8b5cf6" />
              </ScatterChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[350px] flex items-center justify-center text-gray-400">
              Aguardando dados
            </div>
          )}
        </CardContent>
      </Card>

      {/* Insights Automáticos */}
      <div>
        <h2 className="text-2xl font-bold mb-4" style={{ color: '#2B2240' }}>
          Insights Automáticos
        </h2>
        <AutomaticInsights
          iep={iep}
          topRisks={topRisks}
          topDepts={topDepts}
          assessmentsCount={assessments.length}
        />
      </div>
    </div>
  );
}
