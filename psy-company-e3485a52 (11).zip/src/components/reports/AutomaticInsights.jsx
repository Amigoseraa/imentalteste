import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Lightbulb, 
  AlertTriangle, 
  TrendingUp, 
  ChevronRight,
  Download,
  Phone,
  X
} from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { toast } from "sonner";

const generateInsights = (assessments, departments) => {
  const insights = [];
  
  if (assessments.length < 8) {
    return [{
      id: 'insufficient-sample',
      priority: 'info',
      title: 'Amostra insuficiente',
      summary: 'Aguardando mais respostas para gerar insights estatisticamente relevantes.',
      explanation: `Atualmente temos ${assessments.length} respostas. Recomendamos no mínimo 8 respondentes por recorte.`,
      factors: [],
      actions: [],
      confidence: 'low'
    }];
  }

  const phq9Scores = assessments.filter(a => a.phq9_score !== undefined).map(a => a.phq9_score);
  const gad7Scores = assessments.filter(a => a.gad7_score !== undefined).map(a => a.gad7_score);
  const primaScores = assessments.filter(a => a.prima_score !== undefined).map(a => a.prima_score);

  const avgPHQ9 = phq9Scores.length > 0 ? phq9Scores.reduce((a,b) => a+b, 0) / phq9Scores.length : 0;
  const avgGAD7 = gad7Scores.length > 0 ? gad7Scores.reduce((a,b) => a+b, 0) / gad7Scores.length : 0;
  const avgPRIMA = primaScores.length > 0 ? primaScores.reduce((a,b) => a+b, 0) / primaScores.length : 0;

  const psRisk = primaScores.length > 0 ? ((5 - avgPRIMA) / 4) * 100 : 0;
  const smIndex = 100 - (((avgPHQ9 / 27) + (avgGAD7 / 21)) / 2) * 100;

  if (psRisk > 60) {
    insights.push({
      id: 'high-ps-risk',
      priority: 'P1',
      title: 'Risco Psicossocial Elevado Detectado',
      summary: `O indicador de risco psicossocial está em ${psRisk.toFixed(0)}%, sugerindo exposição significativa.`,
      explanation: `Baseado em: PRIMA-EF médio ${avgPRIMA.toFixed(2)} (escala 1-5, quanto menor pior)`,
      factors: [
        { name: 'PRIMA-EF', value: avgPRIMA.toFixed(2), status: 'high' }
      ],
      actions: [
        {
          title: 'Redesenho de Carga de Trabalho',
          description: 'Revisar distribuição de demandas e priorizar tarefas críticas',
          effort: 'médio',
          impact: 'alto',
          deadline: 'curto prazo',
          responsible: 'RH + Liderança',
          kpi: 'Reduzir PS-Risk em 15 pontos em 90 dias'
        },
        {
          title: 'Programa de Pausas Guiadas',
          description: 'Implementar pausas regulares e técnicas de recuperação',
          effort: 'baixo',
          impact: 'médio',
          deadline: 'imediato',
          responsible: 'SST',
          kpi: 'Adesão de 70% dos colaboradores'
        }
      ],
      confidence: 'high'
    });
  }

  if (avgPHQ9 >= 10) {
    const severity = avgPHQ9 >= 15 ? 'graves' : 'moderados';
    insights.push({
      id: 'elevated-depression',
      priority: avgPHQ9 >= 15 ? 'P1' : 'P2',
      title: `Sintomas Depressivos ${severity.charAt(0).toUpperCase() + severity.slice(1)} Identificados`,
      summary: `PHQ-9 médio de ${avgPHQ9.toFixed(1)} indica presença de sintomas ${severity}.`,
      explanation: `Baseado em: PHQ-9 ${avgPHQ9.toFixed(1)} (0-27, ≥10 = moderado, ≥15 = grave)`,
      factors: [
        { name: 'PHQ-9', value: avgPHQ9.toFixed(1), status: 'high' }
      ],
      actions: [
        {
          title: 'Campanha Psicoeducativa',
          description: 'Palestras sobre saúde mental, sinais de alerta e recursos disponíveis',
          effort: 'baixo',
          impact: 'médio',
          deadline: 'curto prazo',
          responsible: 'RH',
          kpi: 'Alcançar 80% dos colaboradores'
        },
        {
          title: 'Linha de Cuidado Psicológico',
          description: 'Disponibilizar psicologia breve e encaminhamentos',
          effort: 'alto',
          impact: 'alto',
          deadline: 'médio prazo',
          responsible: 'RH + SESMT',
          kpi: 'Reduzir PHQ-9 médio em 3 pontos em 6 meses'
        }
      ],
      confidence: 'high'
    });
  }

  if (avgGAD7 >= 10) {
    const severity = avgGAD7 >= 15 ? 'graves' : 'moderados';
    insights.push({
      id: 'elevated-anxiety',
      priority: avgGAD7 >= 15 ? 'P1' : 'P2',
      title: `Sintomas de Ansiedade ${severity.charAt(0).toUpperCase() + severity.slice(1)}`,
      summary: `GAD-7 médio de ${avgGAD7.toFixed(1)} sugere sintomas ${severity} de ansiedade.`,
      explanation: `Baseado em: GAD-7 ${avgGAD7.toFixed(1)} (0-21, ≥10 = moderado, ≥15 = grave)`,
      factors: [
        { name: 'GAD-7', value: avgGAD7.toFixed(1), status: 'high' }
      ],
      actions: [
        {
          title: 'Grupos de Apoio e Técnicas de Relaxamento',
          description: 'Criar espaços seguros para compartilhamento e práticas de mindfulness',
          effort: 'médio',
          impact: 'médio',
          deadline: 'curto prazo',
          responsible: 'RH',
          kpi: 'Participação de 40% do público-alvo'
        },
        {
          title: 'Treinamento de Gestão de Estresse',
          description: 'Capacitar colaboradores em técnicas de manejo de ansiedade',
          effort: 'médio',
          impact: 'alto',
          deadline: 'médio prazo',
          responsible: 'RH + Consultoria Externa',
          kpi: 'Reduzir GAD-7 médio em 2 pontos em 6 meses'
        }
      ],
      confidence: 'high'
    });
  }

  if (psRisk > 50 && smIndex < 60) {
    insights.push({
      id: 'combined-risk',
      priority: 'P1',
      title: 'Risco Combinado: Exposição Psicossocial + Sintomas',
      summary: 'Riscos ocupacionais elevados associados a indicadores baixos de saúde mental.',
      explanation: `PS-Risk: ${psRisk.toFixed(0)}% | SM-Index: ${smIndex.toFixed(0)} | Sugere relação entre condições de trabalho e bem-estar`,
      factors: [
        { name: 'PS-Risk', value: `${psRisk.toFixed(0)}%`, status: 'high' },
        { name: 'SM-Index', value: smIndex.toFixed(0), status: 'low' }
      ],
      actions: [
        {
          title: 'Intervenção Integrada RH + SST',
          description: 'Abordagem conjunta para fatores organizacionais e suporte psicológico',
          effort: 'alto',
          impact: 'alto',
          deadline: 'médio prazo',
          responsible: 'RH + SESMT + Liderança',
          kpi: 'Melhorar ambos os índices em 15% em 6 meses'
        }
      ],
      confidence: 'high'
    });
  }

  const phq9Item9Count = assessments.filter(a => {
    const responses = a.phq9_responses || {};
    return responses['question_9'] && responses['question_9'] > 0;
  }).length;

  const phq9Item9Percentage = (phq9Item9Count / assessments.length) * 100;

  if (phq9Item9Percentage >= 5) {
    insights.push({
      id: 'ethical-alert',
      priority: 'P1',
      title: 'Alerta Ético: Sinalização de Sofrimento',
      summary: 'Identificamos respostas que sugerem necessidade de atenção e suporte.',
      explanation: 'Caso alguém esteja em sofrimento, procure apoio profissional ou CVV 188.',
      factors: [],
      actions: [
        {
          title: 'Divulgar Canais de Apoio',
          description: 'Reforçar comunicação sobre CVV 188, psicologia interna e recursos disponíveis',
          effort: 'baixo',
          impact: 'alto',
          deadline: 'imediato',
          responsible: 'RH',
          kpi: '100% dos colaboradores informados'
        }
      ],
      confidence: 'high',
      isEthicalAlert: true
    });
  }

  insights.sort((a, b) => {
    const priorityOrder = { 'P1': 1, 'P2': 2, 'P3': 3, 'info': 4 };
    return priorityOrder[a.priority] - priorityOrder[b.priority];
  });

  return insights;
};

export default function AutomaticInsights({ assessments, departments }) {
  const [selectedInsight, setSelectedInsight] = useState(null);
  const [selectedActions, setSelectedActions] = useState([]);

  const insights = generateInsights(assessments, departments);

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'P1': return 'bg-red-100 text-red-800 border-red-300';
      case 'P2': return 'bg-orange-100 text-orange-800 border-orange-300';
      case 'P3': return 'bg-purple-100 text-purple-800 border-purple-300';
      default: return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  const getEffortBadge = (effort) => {
    const colors = {
      'baixo': 'bg-green-100 text-green-800',
      'médio': 'bg-yellow-100 text-yellow-800',
      'alto': 'bg-red-100 text-red-800'
    };
    return colors[effort] || 'bg-gray-100 text-gray-800';
  };

  const getImpactBadge = (impact) => {
    const colors = {
      'baixo': 'bg-gray-100 text-gray-800',
      'médio': 'bg-blue-100 text-blue-800',
      'alto': 'bg-green-100 text-green-800'
    };
    return colors[impact] || 'bg-gray-100 text-gray-800';
  };

  const handleExportSummary = () => {
    toast.success('Sumário Executivo será gerado em breve', {
      description: 'O PDF será enviado para seu e-mail'
    });
  };

  const handleExportPGR = () => {
    toast.success('Documento PGR/AET em preparação', {
      description: 'O arquivo será disponibilizado para download'
    });
  };

  const handleCreateActionPlan = () => {
    if (selectedActions.length === 0) {
      toast.error('Selecione pelo menos uma ação');
      return;
    }
    
    toast.success('Plano de Ação criado', {
      description: `${selectedActions.length} ações adicionadas ao plano`
    });
    
    setSelectedInsight(null);
    setSelectedActions([]);
  };

  const toggleAction = (actionTitle) => {
    setSelectedActions(prev => 
      prev.includes(actionTitle) 
        ? prev.filter(a => a !== actionTitle)
        : [...prev, actionTitle]
    );
  };

  if (insights.length === 0) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <Lightbulb className="w-12 h-12 mx-auto text-gray-400 mb-4" />
          <p className="text-gray-600">
            Nenhum insight disponível. Complete avaliações para gerar diagnósticos automáticos.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap gap-3">
        <Button onClick={handleExportSummary} variant="outline">
          <Download className="w-4 h-4 mr-2" />
          Sumário Executivo (PDF)
        </Button>
        <Button onClick={handleExportPGR} variant="outline">
          <Download className="w-4 h-4 mr-2" />
          Exportar para PGR/AET
        </Button>
      </div>

      <div className="grid gap-4">
        {insights.map((insight) => (
          <Card 
            key={insight.id}
            className={`transition-all hover:shadow-lg ${
              insight.isEthicalAlert ? 'border-2 border-red-300 bg-red-50' : ''
            }`}
          >
            <CardHeader>
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    {insight.isEthicalAlert ? (
                      <AlertTriangle className="w-6 h-6 text-red-600" />
                    ) : (
                      <Lightbulb className="w-6 h-6 text-purple-600" />
                    )}
                    <CardTitle className="text-lg">{insight.title}</CardTitle>
                  </div>
                  <p className="text-gray-600 text-sm mb-3">{insight.summary}</p>
                  
                  <div className="flex flex-wrap items-center gap-2 text-xs">
                    <Badge className={`${getPriorityColor(insight.priority)} border`}>
                      {insight.priority === 'info' ? 'INFO' : insight.priority}
                    </Badge>
                    
                    {insight.factors.map((factor, idx) => (
                      <Badge key={idx} variant="outline" className="bg-gray-50">
                        {factor.name}: {factor.value}
                        {factor.status === 'high' && ' ↑'}
                        {factor.status === 'low' && ' ↓'}
                      </Badge>
                    ))}
                    
                    {insight.confidence && (
                      <Badge variant="outline" className="bg-blue-50">
                        Confiança: {insight.confidence === 'high' ? 'Alta' : 'Média'}
                      </Badge>
                    )}
                  </div>
                </div>

                {insight.actions.length > 0 && (
                  <Button
                    onClick={() => {
                      setSelectedInsight(insight);
                      setSelectedActions([]);
                    }}
                    size="sm"
                    style={{ backgroundColor: '#5E2C91' }}
                    className="text-white"
                  >
                    Ver ações sugeridas
                    <ChevronRight className="w-4 h-4 ml-1" />
                  </Button>
                )}
              </div>
            </CardHeader>

            {insight.isEthicalAlert && (
              <CardContent>
                <Alert className="bg-white border-red-200">
                  <Phone className="w-4 h-4" />
                  <AlertDescription>
                    <strong>Canais de Apoio:</strong> CVV 188 (24h) | Psicologia Interna | Emergência 192
                  </AlertDescription>
                </Alert>
              </CardContent>
            )}
          </Card>
        ))}
      </div>

      <Sheet open={!!selectedInsight} onOpenChange={() => setSelectedInsight(null)}>
        <SheetContent className="w-full sm:max-w-2xl overflow-y-auto">
          {selectedInsight && (
            <>
              <SheetHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <SheetTitle className="text-xl mb-2">
                      {selectedInsight.title}
                    </SheetTitle>
                    <SheetDescription>
                      {selectedInsight.explanation}
                    </SheetDescription>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setSelectedInsight(null)}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </SheetHeader>

              <div className="mt-6 space-y-4">
                <h3 className="font-semibold text-lg flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-green-600" />
                  Ações Sugeridas
                </h3>

                {selectedInsight.actions.map((action, idx) => (
                  <Card 
                    key={idx}
                    className={`cursor-pointer transition-all ${
                      selectedActions.includes(action.title)
                        ? 'border-2 border-purple-500 bg-purple-50'
                        : 'hover:border-gray-300'
                    }`}
                    onClick={() => toggleAction(action.title)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <input
                          type="checkbox"
                          checked={selectedActions.includes(action.title)}
                          onChange={() => toggleAction(action.title)}
                          className="mt-1"
                        />
                        <div className="flex-1">
                          <h4 className="font-semibold mb-2">{action.title}</h4>
                          <p className="text-sm text-gray-600 mb-3">{action.description}</p>
                          
                          <div className="grid grid-cols-2 gap-2 text-xs">
                            <div>
                              <span className="text-gray-500">Esforço:</span>
                              <Badge className={`ml-2 ${getEffortBadge(action.effort)}`}>
                                {action.effort}
                              </Badge>
                            </div>
                            <div>
                              <span className="text-gray-500">Impacto:</span>
                              <Badge className={`ml-2 ${getImpactBadge(action.impact)}`}>
                                {action.impact}
                              </Badge>
                            </div>
                            <div>
                              <span className="text-gray-500">Prazo:</span>
                              <span className="ml-2 font-medium">{action.deadline}</span>
                            </div>
                            <div>
                              <span className="text-gray-500">Responsável:</span>
                              <span className="ml-2 font-medium">{action.responsible}</span>
                            </div>
                          </div>

                          <div className="mt-2 p-2 bg-gray-50 rounded text-xs">
                            <strong>KPI:</strong> {action.kpi}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}

                <Button
                  onClick={handleCreateActionPlan}
                  className="w-full"
                  size="lg"
                  style={{ backgroundColor: '#5E2C91' }}
                  disabled={selectedActions.length === 0}
                >
                  Criar Plano de Ação ({selectedActions.length} {selectedActions.length === 1 ? 'ação' : 'ações'})
                </Button>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}