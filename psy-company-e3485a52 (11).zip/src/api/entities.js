import { base44 } from './base44Client';


export const Company = base44.entities.Company;

export const Department = base44.entities.Department;

export const Employee = base44.entities.Employee;

export const Assessment = base44.entities.Assessment;

export const Action = base44.entities.Action;

export const Consultoria = base44.entities.Consultoria;

export const GHE = base44.entities.GHE;

export const PlanoConsultoria = base44.entities.PlanoConsultoria;

export const Fatura = base44.entities.Fatura;

export const ContratoConsultoria = base44.entities.ContratoConsultoria;

export const ContratoEmpresa = base44.entities.ContratoEmpresa;

export const ConfiguracaoFaturamento = base44.entities.ConfiguracaoFaturamento;

export const Pagamento = base44.entities.Pagamento;

export const FinanceSnapshot = base44.entities.FinanceSnapshot;

export const DunningLog = base44.entities.DunningLog;

export const FinanceSettings = base44.entities.FinanceSettings;

export const Recebivel = base44.entities.Recebivel;

export const InviteToken = base44.entities.InviteToken;

export const AuditLog = base44.entities.AuditLog;

export const MediaItem = base44.entities.MediaItem;

export const MediaAssignment = base44.entities.MediaAssignment;

export const MediaProgress = base44.entities.MediaProgress;

export const MediaFeedback = base44.entities.MediaFeedback;

export const MediaPlaylist = base44.entities.MediaPlaylist;

export const MediaPlaylistItem = base44.entities.MediaPlaylistItem;

export const MediaAnalyticsSnapshot = base44.entities.MediaAnalyticsSnapshot;

export const Denuncia = base44.entities.Denuncia;

export const MensagemDenuncia = base44.entities.MensagemDenuncia;

export const DenunciaAnalytics = base44.entities.DenunciaAnalytics;



// auth sdk:
export const User = base44.auth;